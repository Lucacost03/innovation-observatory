import assert from 'node:assert/strict';
import fs from 'node:fs';
import {runEnsemble, simulate} from '../dist/engine.mjs';
import {simulationFindings} from '../dist/findings.mjs';
import {sectorYear, sectorOverview} from '../dist/sector-view.mjs';

const profiles = JSON.parse(fs.readFileSync(new URL('../dist/data/profiles.json', import.meta.url)));
const close = (actual, expected, label) => assert(
  Math.abs(actual - expected) <= 1e-8 * Math.max(1, Math.abs(actual), Math.abs(expected)),
  `${label}: ${actual} versus ${expected}`,
);
let checkedYears = 0;

function reconcile(rows) {
  for (let year = 1; year < rows.length; year++) {
    const row = rows[year], previous = rows[year - 1];
    const support = row.cashSupport + row.unemploymentBenefits + row.publicResearchNonBusiness;
    const loanPrincipal = row.businessLoanRepayments + row.exitLoanRepayments;
    const bonds = row.householdBondPurchases + row.bankBondPurchases;
    close(row.loans - previous.loans, row.businessCreditIssued - loanPrincipal - row.loanWriteoffs, 'Business loans');
    close(row.publicDebt - previous.publicDebt, bonds-row.publicBondRedemptions, 'Public debt');
    close(row.governmentInterest, row.governmentInterestToBank + row.governmentInterestToHouseholds + row.governmentInterestToCentralBank, 'Public interest');
    close(row.householdDeposits - previous.householdDeposits,
      row.wages - row.wageWithholding + row.firmDividends + row.bankDividends + support
      + row.assetPurchasesFromHouseholds + row.governmentInterestToHouseholds + row.publicBondRedemptionsToHouseholds + row.liquidationDistributions + row.corporateBondInterest
      + row.householdDepositInterest + row.foreignAssetIncome + row.corporateBondRepayments + row.corporateBondRecoveries
      + row.actualHousingRent - row.bankRentalIncome + row.imputedHousingRent + row.mortgageOriginations + row.pensionWithdrawals + row.bankFundingInterest
      - row.mortgageInterest - row.mortgageRepayments - row.nominalHousingConstruction - row.bankHousingSales - row.pensionContributions - row.pensionEquitySales
      - row.nominalConsumption - row.householdBondPurchases - row.startupFunding - row.businessEquityIssued
      - row.corporateBondsIssued - row.foreignAssetPurchases - row.financialIncomeTaxPaid - row.wealthTaxPaid, 'Household deposits');
    close(row.firmDeposits - previous.firmDeposits,
      row.nominalConsumptionGoods + row.nominalGovernment + row.nominalHousingConstruction + row.publicRDGrants + row.businessCreditIssued
      + row.nominalExports + row.firmDepositInterest + row.startupFunding + row.businessEquityIssued
      + row.corporateBondsIssued - row.wages - row.firmDividends - row.governmentFirmDividends - row.pensionDividends - row.profitTaxPaid - row.loanInterest
      - row.corporateBondInterest - row.corporateBondRepayments - row.corporateBondRecoveries
      - loanPrincipal - row.loanRecoveries - row.liquidationDistributions - row.governmentLiquidationProceeds - row.pensionLiquidationProceeds, 'Firm deposits');
    close(row.governmentDeposits - previous.governmentDeposits,
      row.centralBankRemittance + row.wageWithholding + row.profitTaxPaid + row.nominalConsumptionTax + row.financialIncomeTaxPaid + row.wealthTaxPaid + row.importTariffRevenue + row.governmentFirmDividends + row.governmentLiquidationProceeds + bonds - row.publicBondRedemptions - row.nominalGovernment
      - row.publicRDGrants - support - row.governmentInterest - row.recap, 'Government deposits');
    close(row.bankEquity - previous.bankEquity,
      row.centralBankReserveInterest + row.loanInterest + row.governmentInterestToBank + row.loanRecoveries - row.loanWriteoffs
      - row.bankDividends - row.householdDepositInterest - row.firmDepositInterest + row.recap
      + row.mortgageInterest + row.bankRentalIncome - row.bankFundingInterest - row.pensionDepositInterest - row.mortgageWriteoffs - row.bankHousingDepreciation + row.bankHousingValuation, 'Bank equity');
    close(row.foreignGain, row.foreignGainUSA + row.foreignGainCHN + row.foreignGainROW, 'Foreign gains');
    checkedYears++;
  }
}

for (const profile of profiles) for (const seed of [2026, 9945]) {
  reconcile(simulate({...profile.params, periods: 40}, seed).rows);
}
for (const profile of profiles) {
  reconcile(simulate({...profile.params, periods: 40, priceDynamics: 1, quantityPriceAdjustment: .1}, 2026,
    {shocks: [{type: 'supply', start: 4, duration: 2, magnitude: -25, recovery: .4}]}).rows);
}
for (const firmDynamics of [0, 1]) {
  const stress = simulate({
    firms: 20, households: 50, periods: 40, firmDynamics, firmLiquidity: 0,
    householdWealth: 600, initialLeverage: .8, maxLeverage: 0,
    loanRate: 20, creditAvailability: 0, defaultAfter: 1, bankBackstop: 1,
  }, 2026, {shocks: [{type: 'demand', start: 1, duration: 25, magnitude: -85, recovery: 0}]});
  assert(stress.rows.some(row => row.loanWriteoffs > 0));
  assert(stress.rows.some(row => row.recap > 0));
  reconcile(stress.rows);
}

const italy = profiles.find(p => p.code === 'ITA').params;
const params = {...italy, foreignForecast: 0, periods: 8, replications: 2, seed: 2026}; // This block explicitly tests custom fixed-growth paths.
const common = {params, reference: params};
const neutral = runEnsemble(common);
const comparison = runEnsemble({...common, paths: [
  {key: 'usGrowth', start: 2, end: 2, target: 3, mode: 'step'},
], shocks: [{type: 'demand', start: 1, duration: 8, magnitude: -70, recovery: 0}]});
const opening = sectorYear(comparison, 'scenario', 0);
assert(!opening.recorded);
assert(opening.relations.every(link => link.directions.every(d => d.items.every(i => i.value === null))));
const scenario = sectorYear(comparison, 'scenario', 4);
const reference = sectorYear(comparison, 'baseline', 4);
const lag = comparison.first.scenario.params.adoptionLag;
assert(scenario.recorded && reference.recorded);
assert.equal(scenario.donors[0].growth, 3);
assert.equal(reference.donors[0].growth, italy.usGrowth);
assert.equal(scenario.donors[0].available, comparison.first.scenario.foreignHistory[Math.max(0, 3 - lag)].USA);
assert.equal(scenario.donors[0].closing, comparison.first.scenario.foreignHistory[4].USA);
const settled = runEnsemble({params: {...params, burnIn: 4, replications: 1}});
const settledYearZero = sectorYear(settled, 'scenario', 0);
assert(settledYearZero.recorded);
assert.equal(settledYearZero.donors[0].available, settled.first.scenario.foreignHistory[Math.max(0, 3 - lag)].USA);
assert.match(simulationFindings(neutral).heading, /close to the reference/);
assert.match(simulationFindings(comparison).heading, /lower/);
assert.notDeepEqual(simulationFindings(neutral), simulationFindings(comparison));

const accounts = runEnsemble({
  params:{...params,financialIncomeTax:20,wealthTax:1,initialHouseholdForeignAssets:5,foreignPortfolioWeight:20},
  reference:params,
});
const openingAccounts = sectorOverview(sectorYear(accounts,'scenario',0),'households');
assert.equal(openingAccounts.revenueTotal,null);
assert.equal(openingAccounts.expenseTotal,null);
assert.equal(openingAccounts.assets.find(item=>item.label==='Bank deposits').value,italy.householdWealth);
close(openingAccounts.assets.find(item=>item.label==='Foreign investments').value,5,'Opening foreign assets');
assert(Number.isFinite(sectorOverview(settledYearZero,'firms').revenueTotal));

for(const side of ['scenario','baseline'])for(const year of [1,4,8]){
  const view=sectorYear(accounts,side,year),r=view.row;
  const households=sectorOverview(view,'households'),firms=sectorOverview(view,'firms');
  const government=sectorOverview(view,'government'),banks=sectorOverview(view,'banks');
  const support=r.cashSupport+r.unemploymentBenefits+r.publicResearchNonBusiness;
  const householdTaxes=r.nominalConsumptionTax+r.wageWithholding+r.financialIncomeTaxPaid+r.wealthTaxPaid;
  const sumItems=items=>items.reduce((total,item)=>total+item.value,0);
  close(households.revenueTotal,r.wages+r.firmDividends+r.corporateBondInterest+r.bankDividends
    +r.householdDepositInterest+r.bankFundingInterest+r.governmentInterestToHouseholds+support,'Domestic household income');
  close(households.expenseTotal,r.nominalConsumptionGoods+r.nominalHousingConstruction+r.mortgageInterest+r.bankRentalIncome+householdTaxes,'Domestic household expenses');
  close(firms.revenueTotal,r.nominalConsumptionGoods+r.nominalHousingConstruction+r.nominalGovernment+r.publicRDGrants+r.firmDepositInterest,'Domestic firm revenue');
  close(firms.expenseTotal,r.wages+r.firmDividends+r.governmentFirmDividends+r.pensionDividends+r.corporateBondInterest+r.loanInterest+r.profitTaxPaid,'Domestic firm outflows');
  close(government.revenueTotal,householdTaxes+r.profitTaxPaid+r.governmentFirmDividends+r.centralBankRemittance,'Government current revenue');
  close(government.expenseTotal,r.nominalGovernment+r.publicRDGrants+support+r.governmentInterest,'Government expenses');
  close(banks.revenueTotal,r.loanInterest+r.pensionDividends+r.mortgageInterest+r.bankRentalIncome+r.governmentInterestToBank+r.governmentInterestToCentralBank,'Bank revenue');
  close(banks.expenseTotal,r.bankDividends+r.householdDepositInterest+r.firmDepositInterest+r.bankFundingInterest+r.centralBankRemittance,'Bank expenses');
  close(sumItems(government.liabilities),r.publicDebt,'Government debt');
  close(sumItems(firms.liabilities),r.loans+r.householdCorporateBonds,'Firm debt');
  close(sumItems(banks.assets)-sumItems(banks.liabilities),r.bankEquity+r.centralBankEquity,'Consolidated financial balance sheet');
  for(const overview of [households,firms,government,banks]){
    assert.equal(overview.peers.length,3);
    close(overview.revenueTotal,overview.peers.reduce((total,peer)=>total+peer.revenueTotal,0),'Income by counterparty');
    close(overview.expenseTotal,overview.peers.reduce((total,peer)=>total+peer.expenseTotal,0),'Expenses by counterparty');
  }
}

console.log(`PASS: ${checkedYears} annual ledgers reconcile. Donor timing, reference switching and run-specific findings verified.`);

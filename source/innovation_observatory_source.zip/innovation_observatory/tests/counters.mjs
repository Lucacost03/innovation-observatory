import assert from 'node:assert/strict';
import {simulate} from '../dist/engine.mjs';
import {DEFAULTS} from '../dist/parameters.mjs';
const timeline=simulate({...DEFAULTS,periods:8,replications:1},22,{snapshots:true,
 paths:[{key:'firmDynamics',start:3,end:3,target:0,mode:'step'}]});
for(let t=3;t<timeline.agents.length;t++)assert(timeline.agents[t].every(f=>f.exitProbability===0));
const stress=simulate({...DEFAULTS,periods:12,firmDynamics:0,firmLiquidity:0,householdWealth:600,
 consumptionIncome:0,consumptionWealth:0,initialLeverage:.8,maxLeverage:0,loanSpread:20-DEFAULTS.initialPolicyRate,
 creditAvailability:0,defaultAfter:1,incomeSupport:0,publicResearch:0,unemploymentReplacement:0},11,
 {shocks:[{type:'demand',start:1,duration:12,magnitude:-85,recovery:0}]});
assert(stress.rows.some(x=>x.defaults>0&&x.loanWriteoffs>0));
console.log('PASS: disabled-turnover risk labels and fixed-population loan write-off counters.');

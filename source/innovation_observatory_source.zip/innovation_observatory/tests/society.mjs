import assert from 'node:assert/strict';
import fs from 'node:fs';
import {simulate,Economy,quantile} from '../dist/engine.mjs';
import {simulate as preMacro} from '../research/frozen_engine_v1_18_1/engine.mjs';
import {simulate as frozen} from '../research/frozen_engine_v1_16/engine.mjs';
import {PARAMETERS,MODEL_VERSION,sanitize} from '../dist/parameters.mjs';
const read=name=>JSON.parse(fs.readFileSync(new URL('../'+name,import.meta.url)));
const profiles=read('dist/data/profiles.json').map(p=>({...p,params:{...p.params,foreignForecast:0}})),prior=read('research/frozen_engine_v1_16/profiles.json');
const inputs=read('dist/data/society_benchmarks.json').countries,observations=read('dist/data/finance_validation.json').recent.legacy.predictions;
const sum=(rows,key)=>rows.slice(1).reduce((s,r)=>s+(r[key]??0),0);
const close=(a,b,label)=>assert(Math.abs(a-b)<=1e-8*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} != ${b}`);
let paths=0,years=0,maxResidual=0,mortgageDefaults=0,foreclosurePaths=0,educationResponses=0;
const outcomes=[],seeds=[2026,9945,17864];
function checked(params,seed,options={}){
 const r=simulate(params,seed,options);paths++;
 for(let t=0;t<r.rows.length;t++){
  const a=r.rows[t];assert(Object.values(a).every(Number.isFinite));
  close(a.labourIncome+a.grossCapitalIncome+a.netProductionTaxes,a.nominalOutput,'Income GDP');
  close(a.employment+a.unemployment,100,'Employment shares');
  assert(a.laborForce>0&&a.populationMillions>0&&a.humanCapitalLevel>0);
  if(!t)continue;years++;const b=r.rows[t-1];
  close(a.populationIndex-b.populationIndex,a.births-a.deaths+a.netMigration,'Population balance');
  close(a.housingStock-b.housingStock,a.housingConstruction-a.housingDepreciation,'Housing structures');
  close(a.householdMortgageDebt-b.householdMortgageDebt,a.mortgageOriginations-a.mortgageRepayments-a.mortgagePrincipalExtinguished,'Mortgage stock/flow');
  close(a.newMortgageRate,Math.max(0,Math.min(30,r.params.initialPolicyRate+r.params.mortgageSpread+r.params.mortgagePassThrough*(a.policyRate-r.params.initialPolicyRate))),'Policy-linked mortgage quote');
  close(a.pensionCash-b.pensionCash,a.pensionContributions-a.pensionWithdrawals+a.pensionDividends+a.pensionDepositInterest+a.pensionLiquidationProceeds+a.pensionEquitySales,'Fund cash');
  close(a.nominalOutput,a.nominalConsumption+a.nominalGovernment+a.grossInvestment+a.nominalExports-a.nominalImports,'Expenditure GDP');
  close(a.nationalSaving-a.grossInvestment,a.currentAccount,'S-I=CA');close(a.netForeignAssetChange,a.currentAccount,'NFA=CA');
  assert(a.publicEducationSpending<=a.nominalGovernment+1e-8&&a.privateEducationSpending<=a.nominalConsumption+1e-8);
  assert(a.mortgageOriginations>=-1e-8&&a.householdMortgageDebt>=-1e-8);
  maxResidual=Math.max(maxResidual,a.relativeResidual,a.financeResidual,Math.abs(a.savingIdentityResidual)/Math.max(1,a.nominalOutput));mortgageDefaults+=a.mortgageDefaults;
 }
 if(sum(r.rows,'mortgageDefaults'))foreclosurePaths++;
 return r;
}
for(const profile of profiles){
 const p=sanitize(profile.params);
 for(const d of PARAMETERS)if(profile.params[d.key]!=null)close(p[d.key],profile.params[d.key],profile.code+' no clipped '+d.key);
 const e=new Economy(p,2026),opening=e.initialSnapshot(),source=inputs[profile.code].params;
 close(opening.output,100,'Opening GDP');close(opening.capital+opening.housingStock,100*p.capitalOutputRatio,'No duplicate capital');
 close(opening.householdMortgageDebt,source.initialMortgageGDP,'Mortgage benchmark');close(opening.pensionAssets,source.initialPrivatePensionGDP,'Fund benchmark');
 close(e.households.reduce((s,h)=>s+h.pensionValue,0),opening.pensionAssets,'Member claims match fund assets');
 for(const seed of seeds)for(const variant of ['baseline','stress']){
  const options=variant==='stress'?{shocks:[{type:'demand',start:5,duration:5,magnitude:-60,recovery:.3},{type:'policyRate',start:5,duration:5,magnitude:8,recovery:.3}],paths:[{key:'netMigrationRate',start:12,end:12,target:-1,mode:'step'},{key:'publicEducationQuality',start:4,end:4,target:1.5,mode:'step'}]}:{};
  const r=checked({...profile.params,periods:40},seed,options),last=r.rows.at(-1);
  outcomes.push({code:profile.code,seed,variant,finalGDP:last.output,population:last.populationMillions,humanCapital:last.humanCapitalIndex,mortgageDefaults:sum(r.rows,'mortgageDefaults'),pensionWithdrawals:sum(r.rows,'pensionWithdrawals'),pensionDelay:sum(r.rows,'pensionUnpaidWithdrawals'),finalPublicDebtGDP:last.publicDebtGDP,newMortgages:sum(r.rows,'mortgageOriginations'),construction:sum(r.rows,'housingConstruction')});
 }
}
const italy=sanitize(profiles.find(p=>p.code==='ITA').params);
const schoolBase=checked({...italy,periods:30},2026),schoolBetter=checked({...italy,periods:30},2026,{paths:[{key:'publicEducationQuality',start:4,end:4,target:1.5,mode:'step'},{key:'privateEducationQuality',start:4,end:4,target:1.5,mode:'step'}]});
for(let t=0;t<4+italy.educationLag;t++){close(schoolBase.rows[t].humanCapitalLevel,schoolBetter.rows[t].humanCapitalLevel,'Education lag');close(schoolBase.rows[t].output,schoolBetter.rows[t].output,'No instantaneous education GDP gain');}
assert(schoolBetter.rows.at(-1).humanCapitalLevel>schoolBase.rows.at(-1).humanCapitalLevel);educationResponses++;
const growth=checked({...italy,periods:20,birthRate:2,netMigrationRate:1},2026),decline=checked({...italy,periods:20,birthRate:.3,netMigrationRate:-1},2026);
assert(growth.rows.at(-1).populationMillions>growth.rows[0].populationMillions);assert(decline.rows.at(-1).populationMillions<decline.rows[0].populationMillions);
const debtShock=checked({...italy,periods:20,defaultAfter:1,incomeSupport:0,publicPensionGDP:0,financialMarket:0},2026,{shocks:[{type:'demand',start:1,duration:15,magnitude:-90,recovery:0},{type:'policyRate',start:1,duration:15,magnitude:15,recovery:0}]});
assert(sum(debtShock.rows,'mortgageDefaults')>0);assert(sum(debtShock.rows,'housingForeclosures')>0);
const boundaryKeys=['birthRate','deathRate','netMigrationRate','publicEducationQuality','privateEducationQuality','educationElasticity','migrantHumanCapital','publicPensionContributionShare','privatePensionContributionRate','privatePensionWithdrawalRate','mortgagePassThrough','mortgageRepricing','mortgageTerm','mortgageLTV','mortgageDebtServiceLimit','mortgageRiskWeight','housingDepreciation','housingTurnover','housingInvestorDemand','housePriceAdjustment','housingRateSensitivity','rentAdjustment'];
for(const key of boundaryKeys){const d=PARAMETERS.find(d=>d.key===key);for(const value of [d.min,d.max])checked({...italy,[key]:value,periods:8},2026);}
for(let mask=0;mask<16;mask++)checked({...italy,periods:8,populationDynamics:mask&1?1:0,educationEnabled:mask&2?1:0,pensionEnabled:mask&4?1:0,housingEnabled:mask&8?1:0},2026);
let unchangedValues=0;
for(const profile of prior){
 const params={...profile.params,periods:8,populationDynamics:0,educationEnabled:0,pensionEnabled:0,housingEnabled:0};
 checked(params,2026);const a=preMacro(params,2026),b=frozen(params,2026);paths++;years+=8;
 for(let t=0;t<a.rows.length;t++)for(const key of Object.keys(b.rows[t])){close(a.rows[t][key],b.rows[t][key],profile.code+' frozen '+key);unchangedValues++;}
}
const predictions=profiles.map(profile=>{
 const prediction={code:profile.code,observed:observations.find(r=>r.code===profile.code).observed};
 for(const [mode,fn,p]of [['before',frozen,prior.find(r=>r.code===profile.code).params],['after',simulate,profile.params]]){
  const a=seeds.map(seed=>fn({...p,periods:8},seed).rows[2]);paths+=seeds.length;years+=seeds.length*8;
  prediction[mode]={gdp:quantile(a.map(r=>100*(Math.sqrt(r.output/100)-1)),.5),unemployment:quantile(a.map(r=>r.unemployment),.5),inflation:quantile(a.map(r=>r.inflation),.5)};
 }
 return prediction;
});
const errors=mode=>Object.fromEntries(['gdp','unemployment','inflation'].map(key=>{const residuals=predictions.filter(r=>r.code!=='EU27').map(r=>r[mode][key]-r.observed[key]);return[key,{rmse:Math.sqrt(residuals.reduce((s,x)=>s+x*x,0)/residuals.length),mae:residuals.reduce((s,x)=>s+Math.abs(x),0)/residuals.length}];}));
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,maxResidual,openingPresets:profiles.length,unchangedValues,mortgageDefaults,foreclosurePaths,educationResponses,outcomes,
 checks:['All source inputs enter without clipping. Opening total capital and investment are split rather than duplicated.','Three cohort stocks, changing labor force, mortgage principal, funded claims and cash reconcile.','Housing services enter GDP; imputed rent creates no cash; existing dwellings and pension redemptions are asset transactions.','Existing public support is split into pensions and other support. Funding uses existing withholding without another tax.','Bank loans, term funding, pension assets and every government/household/firm financial ledger reconcile. S-I=CA and annual NFA transactions=CA remain enforced.','School quality has no human-capital effect before the configured lag. Better quality raises new-worker skills in the tested pair.','Both population growth and decline occur; severe shocks trigger mortgage default/foreclosure and creditor losses.','Historical 1.18.1 with all four society additions and published foreign projections off reproduces every shared 1.16 row value; the current zero floor deliberately differs later within floating-point tolerance.'],
 education:{baselineHumanCapital:schoolBase.rows.at(-1).humanCapitalIndex,betterHumanCapital:schoolBetter.rows.at(-1).humanCapitalIndex,lag:italy.educationLag,firstChangedYear:4+italy.educationLag},
 benchmark:{protocol:'Frozen 1.16 versus society additions with published foreign forecasts off, three shared seeds, all27countries equally weighted, previously examined2025data; no coefficient selection. New housing, pension and demographic definitions differ from the frozen aggregate-sector model. This is a diagnostic, not untouched validation.',before:errors('before'),after:errors('after'),predictions},
 limitations:['Three-cohort aging, fixed labor participation and migrant age/skill allocations are approximations. No demographic forecast or micro-household age distribution is estimated.','Education funding proxies do not identify provider ownership, school quality or causal labor productivity elasticities.','Private schemes with DB obligations are approximated by funded accounts without guarantees. Several opening ratios use2021or explicit2023proxies. Withdrawals are asset redemptions; fund returns may be illiquid.','Housing assets cover structures, exclude land, and map national/current-price concepts to model units. Opening financing residuals use policy-linked household term claims, not observed bond portfolios.','Housing/rent prices, fixed sample tenure preferences, construction response to replacement costs, debt-service limits, depreciation, bank risk weights, nonrecourse foreclosure and mortgage repricing remain unestimated. Owner-occupied rent is outside the consumer-price basket.']};
fs.writeFileSync(new URL('../dist/data/society_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,outcomes:undefined,benchmark:{...report.benchmark,predictions:undefined}}));

import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {distributionStats,histogram,debtMetrics} from '../dist/distribution.mjs';
import {financialWealth} from '../dist/finance.mjs';
import {simulate,runEnsemble} from '../dist/engine.mjs';
import {metricValue,MODEL_VERSION} from '../dist/parameters.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';

const close=(a,b,label)=>assert(Math.abs(a-b)<1e-9*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} vs ${b}`);
const total=values=>values.reduce((sum,value)=>sum+value,0);
const profiles=JSON.parse(readFileSync(new URL('../research/frozen_engine_v1_16/profiles.json',import.meta.url)));
const italy=profiles.find(p=>p.code==='ITA').params;
close(distributionStats([1,1,1,1]).gini,0,'Equal incomes');
close(distributionStats([0,0,0,4]).gini,.75,'Concentrated incomes');
close(distributionStats([-1,2]).gini,1.5,'Negative income is not clipped');
assert.equal(distributionStats([-2,0]).gini,null);
assert.equal(distributionStats([-1,1]).gini,null);
assert.equal(distributionStats([0,0]).gini,0);
assert.equal(metricValue({incomeGini:0,incomeGiniDefined:0},'incomeGini'),null);
assert.equal(metricValue({debtRatioDefined:0,privateDebtGDP:0},'privateDebtGDP'),null);
assert.throws(()=>distributionStats([NaN]));
for(const values of [[0,0,0],[2,2,2],[-3,-1,0,0,8],[1,2,3,4,5,6,7]]) {
  const stats=distributionStats(values),hist=histogram(values);
  assert.equal(total(hist.bins.map(bin=>bin.count)),values.length);
  close(total(hist.bins.map(bin=>bin.share)),100,'Histogram shares');
  if(stats.total>0)close(total(stats.quintiles.map(group=>group.share)),100,'Quintile shares');
  close(total(stats.quintiles.map(group=>group.mean))/5,stats.mean,'Equal-size group averages');
  assert(hist.low<=Math.min(...values)&&hist.high>=Math.max(...values));
}
const assets=financialWealth([{cash:1,bonds:2,foreignAssets:3},{cash:4,bonds:5,foreignAssets:0}],
  [{corporateBonds:{holders:[1,2]},ventureEquity:{holders:[3,4]},businessEquity:{holders:[5,6]}}],2);
assert.deepEqual(assets,[18,21]);
assert.deepEqual(debtMetrics(100,30,20,200),{privateDebt:50,debtRatioDefined:1,publicDebtGDP:50,privateDebtGDP:25});

let paths=0,years=0,maxForeignResidual=0,maxWealthResidual=0,valuationYears=0,negativeIncomeYears=0;
function inspect(run) {
  paths++;
  for(let t=0;t<run.rows.length;t++) {
    const row=run.rows[t],sample=run.householdDistributions[t];
    assert.equal(sample.income.length,run.params.households);
    assert.equal(sample.wealth.length,run.params.households);
    const income=distributionStats(sample.income),wealth=distributionStats(sample.wealth);
    close(total(sample.income),row.householdIncomeTotal,'Income total');
    close(total(sample.wealth),row.householdWealthTotal,'Wealth total');
    if(income.giniDefined)close(row.incomeGini,income.gini,'Income Gini');
    else assert.equal(metricValue(row,'incomeGini'),null);
    close(row.wealthGini,wealth.gini,'Wealth Gini');
    const recorded=row.householdDeposits+row.householdPublicDebt+row.householdCorporateBonds
      +row.householdVentureEquity+row.householdBusinessEquity+row.householdForeignAssets;
    const wealthResidual=Math.abs(total(sample.wealth)-recorded)/Math.max(1,recorded);
    maxWealthResidual=Math.max(maxWealthResidual,wealthResidual);
    close(total(sample.wealth),recorded,'Recorded financial wealth');
    close(row.publicDebtGDP,100*row.publicDebt/row.nominalOutput,'Public debt uses nominal GDP');
    close(row.privateDebtGDP,100*(row.loans+row.householdCorporateBonds)/row.nominalOutput,'Private debt scope');
    close(row.netForeignAssets,row.foreignAssetsAtCost-row.foreignLiabilities,'Assets less liabilities');
    close(row.netForeignPosition,row.netForeignAssets+row.foreignAssetValuationBalance,'Market position');
    if(t) {
      const prior=run.rows[t-1];
      close(row.netForeignAssets-prior.netForeignAssets,row.currentAccount,'NFA change equals CA');
      close(row.netForeignAssetChange,row.currentAccount,'Read-only NFA flow');
      close(row.foreignAssetValuationBalance-prior.foreignAssetValuationBalance,row.foreignAssetValuation,'Separate currency gains');
      close(row.netForeignPosition-prior.netForeignPosition,row.currentAccount+row.foreignAssetValuation,'Current-value position');
      close(row.nationalSaving-row.grossInvestment,row.currentAccount,'S minus I equals CA');
      maxForeignResidual=Math.max(maxForeignResidual,Math.abs(row.netForeignAssetResidual)/Math.max(1,Math.abs(row.netForeignAssets)));
      valuationYears+=Number(Math.abs(row.foreignAssetValuation)>1e-8);
      negativeIncomeYears+=Number(income.negativeCount>0);
      years++;
    }
  }
}
for(const profile of profiles)for(const seed of [2026,9945]) {
  inspect(simulate({...profile.params,periods:40,foreignPortfolioWeight:20,initialHouseholdForeignAssets:10},seed,
    {snapshots:true,shocks:seed===9945?[
      {type:'demand',start:6,duration:3,magnitude:-30,recovery:.5},
      {type:'exchangeRate',start:5,duration:2,magnitude:-20,recovery:.5},
    ]:[]}));
}
for(const foreignPortfolioWeight of [0,100])inspect(simulate({...italy,periods:12,foreignPortfolioWeight,
  initialHouseholdForeignAssets:15,wealthTax:5,financialIncomeTax:40},888,{snapshots:true}));
inspect(simulate({...italy,periods:8,burnIn:5},2026,{snapshots:true}));
const result=runEnsemble({params:{...italy,periods:8,replications:2},reference:italy});
for(const key of ['incomeGini','wealthGini','publicDebtGDP','privateDebtGDP','netForeignAssets','netForeignAssetChange']) {
  assert(key in result.scenario[8]);
  assert(key in result.raw.scenario[0].rows[8]);
}
close(result.scenario[0].incomeGini.median,italy.initialIncomeGini,'Empirical opening income Gini');
assert.equal(result.scenario[0].netForeignAssetChange.median,null);
assert.equal(result.first.scenario.householdDistributions.length,9);
const migrated=restoreConfiguration({modelVersion:'1.12.0',country:'ITA',params:result.params,reference:result.reference,
  paths:[],shocks:[],preset:'custom'},profiles);
assert(migrated.migrated&&!migrated.rebuildPreset);
assert.deepEqual(migrated.state.params,result.params);
assert.deepEqual(migrated.state.reference,result.reference);
assert(valuationYears>0&&negativeIncomeYears>0);
assert(maxForeignResidual<1e-8&&maxWealthResidual<1e-8);
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,
  maxForeignResidual,maxWealthResidual,valuationYears,negativeIncomeYears,
  scope:'Accounting and reporting verification. No additional forecast-accuracy claim. Household wealth is recorded financial wealth; private debt covers active business loans and corporate bonds.'};
writeFileSync(new URL('../dist/data/distribution_validation_1_14.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify(report));

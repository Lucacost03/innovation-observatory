import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {simulate, runEnsemble} from '../dist/engine.mjs';
import {publicPurchases, bankPublicExposure, lendingRoom} from '../dist/fiscal.mjs';
import {advanceMonetary, initializeMonetary} from '../dist/monetary.mjs';
import {sanitize} from '../dist/parameters.mjs';
import {simulationFindings} from '../dist/findings.mjs';

const root = new URL('../',import.meta.url);
const read = path => JSON.parse(readFileSync(new URL(path,root)));
const profiles = read('research/frozen_engine_v1_16/profiles.json');
const source = read('dist/data/official_data_manifest.json').find(x=>x.name==='public_investment_growth');
assert.equal(createHash('sha256').update(readFileSync(new URL(source.path,root))).digest('hex'),source.sha256);
const italy = profiles.find(profile=>profile.code==='ITA').params;
const params = sanitize({...italy, tradeEnabled:0,policyDynamics:0,currencyDynamics:0, periods:8, replications:1, seed:2026});
const close = (a,b) => assert(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(a),Math.abs(b)),`${a} differs from ${b}`);

const indexed = publicPurchases(params,70,100,0,1);
const procyclical = publicPurchases({...params,publicBudgetStability:0},70,100,0,1);
assert.equal(indexed.publicBudgetBase,100);
assert.equal(procyclical.publicBudgetBase,70);
assert(indexed.plannedPublicDemand>procyclical.plannedPublicDemand);
const base = simulate(params,params.seed).rows;
const cut = simulate({...params,governmentShare:params.governmentShare-5},params.seed).rows;
assert.deepEqual(cut[0],base[0]);
close(base[1].plannedPublicDemand-cut[1].plannedPublicDemand,5);
const path = {key:'governmentShare',start:3,end:3,target:params.governmentShare-5,mode:'step'};
const phased = simulate(params,params.seed,{paths:[path]}).rows;
assert.deepEqual(phased.slice(0,3),base.slice(0,3));
assert(phased[3].plannedPublicDemand<base[3].plannedPublicDemand);

const rule = {...params,policyDynamics:1};
const initial = initializeMonetary(rule);
const high = advanceMonetary(initial,rule,8);
assert(high.effectiveLoanRate>initial.effectiveLoanRate);
assert(high.newPublicRate>high.publicDebtRate&&high.publicDebtRate>initial.publicDebtRate);
close(high.publicDebtRate,params.bondRate+params.bondRepricing*(high.newPublicRate-params.bondRate));
const lower = advanceMonetary(high,rule,0);
assert(lower.newPublicRate<high.newPublicRate);
assert(lower.publicDebtRate<high.publicDebtRate&&lower.publicDebtRate>lower.newPublicRate);

assert.equal(lendingRoom(20,50,30,20,.25),42.5);
assert.equal(lendingRoom(20,50,30,0,.4),Infinity);
assert.equal(bankPublicExposure({newPublicRate:2,effectiveLoanRate:6},0).publicCreditWeight,.2);
assert.equal(bankPublicExposure({newPublicRate:4,effectiveLoanRate:4},0).publicCreditWeight,.3);
assert.equal(bankPublicExposure({newPublicRate:7,effectiveLoanRate:4},0).publicCreditWeight,.4);
assert(bankPublicExposure(initial,2).publicCreditWeight>bankPublicExposure(initial,0).publicCreditWeight);
const constrained=simulate({...params,capitalRequirement:25},params.seed).rows;
assert(constrained[1].bankCreditCrowdedOut>0);
assert(constrained.every(r=>r.publicCreditWeight>=.2&&r.publicCreditWeight<=.4));

let maximumResidual=0;
for (const profile of profiles) for (const seed of [2026,9945]) {
  // This fixture isolates a closed economy: no foreign cash income either.
  const config = {...profile.params,tradeEnabled:0,foreignPortfolioWeight:0,initialHouseholdForeignAssets:0,periods:40,policyDynamics:1,currencyDynamics:1};
  const change = {...path,start:8,end:8,target:profile.params.governmentShare-5};
  const rows = simulate(config,seed,{paths:[change]}).rows;
  for (let year=1;year<rows.length;year++) {
    const r=rows[year],previous=rows[year-1];
    close(r.governmentInterestToBank,previous.bankPublicDebt*r.publicDebtRate/100);
    close(r.governmentInterestToHouseholds,previous.householdPublicDebt*r.publicDebtRate/100);
    close(r.nationalSaving,r.householdSaving+r.firmSaving+r.bankSaving+r.publicSaving);
    close(r.nationalSaving,r.nominalOutput-r.nominalConsumption-r.nominalGovernment);
    close(r.grossInvestment,r.producerPrice*(r.investment+r.inventoryChange));
    close(r.nationalSaving-r.grossInvestment,r.currentAccount);
    close(r.publicSaving-r.recap+r.governmentLiquidationProceeds,r.governmentDeposits-previous.governmentDeposits-r.publicDebt+previous.publicDebt);
    assert(r.currentAccount===0&&r.bankCreditCrowdedOut>=0&&r.relativeResidual<1e-8);
    maximumResidual=Math.max(maximumResidual,Math.abs(r.savingIdentityResidual)/Math.max(1,r.nominalOutput));
  }
}
const experiment = runEnsemble({params,reference:params,paths:[path]});
assert(simulationFindings(experiment).findings.some(text=>text.includes('planning fewer purchases')));
console.log('PASS: opening composition, public budget timing, both policy-sensitive debt rates, crowding out and saving accounts over 56 forty-year paths. Maximum relative saving residual '+maximumResidual);

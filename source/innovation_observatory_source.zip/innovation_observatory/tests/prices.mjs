import assert from 'node:assert/strict';
import fs from 'node:fs';
import {Economy, simulate, runEnsemble} from '../dist/engine.mjs';
import {advancePrices, spendingTurnover} from '../dist/prices.mjs';
import {initializeMonetary, advanceMonetary} from '../dist/monetary.mjs';
import {DEFAULTS, sanitize} from '../dist/parameters.mjs';
import {sectorYear} from '../dist/sector-view.mjs';
import {simulationFindings} from '../dist/findings.mjs';

const profiles = JSON.parse(fs.readFileSync(new URL('../research/frozen_engine_v1_16/profiles.json', import.meta.url)));
const italy = profiles.find(profile => profile.code === 'ITA').params;
const params = sanitize({...italy, tradeEnabled:0,policyDynamics:0,currencyDynamics:0, periods:8, replications:1, seed:2026});
const fixed = {...params, priceDynamics:0, policyDynamics:0, currencyDynamics:0};
const close = (actual, expected) => assert(
  Math.abs(actual - expected) <= 1e-9 * Math.max(1, Math.abs(actual), Math.abs(expected)),
  `${actual} differs from ${expected}`,
);
assert(!Object.hasOwn(DEFAULTS,'inflationAnchor'));
assert(profiles.every(profile => profile.params.priceDynamics === 1));

const flat = simulate(fixed, params.seed).rows;
assert.equal(flat[0].inflation,params.initialInflation);
assert.equal(flat[0].consumerPriceIndex,100);
for (const row of flat.slice(1)) {
  assert.equal(row.producerPrice, 1);
  assert.equal(row.inflation, 0);
  assert.equal(row.nominalOutput, row.output);
}

const basePrice = {producerPrice:1, consumerPrice:1};
const settings = {...params, consumptionTax:0};
const price = inputs => advancePrices(basePrice,1,settings,{money:100,velocity:1,goods:100,...inputs}).inflation;
close(price({}),0);
assert(price({money:130})>0 && price({money:70})<0);
assert(price({velocity:1.3})>0 && price({velocity:.7})<0);
assert(price({goods:70})>0 && price({goods:130})<0);
close(price({money:1e8}),20);
close(price({money:0}),-10);

const quiet = simulate(params,params.seed).rows;
const moreMoney = simulate({...params,householdWealth:params.householdWealth+20},params.seed).rows;
assert(moreMoney[1].inflation>quiet[1].inflation);
const pulse = {key:'velocityShift',start:2,end:4,target:25,mode:'pulse'};
const faster = simulate(params,params.seed,{paths:[pulse]}).rows;
assert.deepEqual(faster.slice(0,2),quiet.slice(0,2));
assert(faster[2].moneyVelocity>quiet[2].moneyVelocity && faster[2].inflation>quiet[2].inflation);
close(faster[5].moneyVelocity,quiet[5].moneyVelocity);

const higherVAT = Math.min(35, params.consumptionTax + 5);
const vatPath = {key:'consumptionTax',start:2,end:2,target:higherVAT,mode:'step'};
const vat = simulate(fixed,params.seed,{paths:[vatPath]}).rows;
assert.equal(vat[2].producerInflation,0);
close(vat[2].inflation,100*((1+higherVAT/100)/(1+params.consumptionTax/100)-1));
assert.equal(vat[3].inflation,0);

// Set the test velocity each year to give an identical 2% price increase.
// This controls prices without adding a fixed inflation rate to the simulator.
const moderate = new Economy({...fixed,priceDynamics:1,quantityPriceAdjustment:1},params.seed);
let previous = moderate.initialSnapshot();
for (let year=1;year<=8;year++) {
  moderate.p.initialMoneyVelocity = 1.02 * previous.producerPrice * previous.goodsOutput / previous.privateMoney;
  previous = moderate.step(year,year);
  close(previous.inflation,2);
  close(previous.consumerPriceIndex,100*1.02**year);
  if (year === 1) assert(Math.abs(previous.output/flat[1].output-1)<.005);
}

const policy = {...params,policyDynamics:1,currencyDynamics:1};
const opening = initializeMonetary(policy);
const hot = advanceMonetary(opening,{...policy,policyDynamics:0},8);
const cool = advanceMonetary(opening,{...policy,policyDynamics:0},0);
const tight = advanceMonetary(opening,policy,8);
assert(hot.realPolicyRate<0 && cool.realPolicyRate>0);
assert(hot.currencyStrength<100 && cool.currencyStrength>100);
assert(hot.currencyPriceContribution>0 && cool.currencyPriceContribution<0);
assert(tight.policyRate>hot.policyRate && tight.currencyStrength>hot.currencyStrength);
assert(tight.effectiveLoanRate>hot.effectiveLoanRate);
assert(spendingTurnover(policy,params,.6,tight.policyRate,1).velocity
  < spendingTurnover(policy,params,.6,hot.policyRate,1).velocity);

let largestResidual=0;
for (const profile of profiles) for (const seed of [2026,9945]) {
  const config = {...profile.params,tradeEnabled:0,periods:40,priceDynamics:1,policyDynamics:1,currencyDynamics:1};
  const {rows} = simulate(config,seed,{paths:[pulse]});
  for (const [year,row] of rows.entries()) {
    close(row.privateMoney,row.householdDeposits+row.firmDeposits);
    close(row.nominalOutput,row.nominalConsumption+row.nominalGovernment+row.producerPrice*(row.investment+row.inventoryChange));
    if (year) {
      const prior = rows[year-1];
      close(row.priceMoney,prior.privateMoney);
      close(row.priceGoods,prior.goodsOutput);
      close(row.realizedVelocity,row.producerPrice*row.goodsOutput/Math.max(1e-9,(row.priceMoney+row.privateMoney)/2));
      const moneyBalance = r => r.loans + r.bankPublicDebt + r.bankNetForeignPosition + r.householdMortgageDebt + r.bankHousingValue - r.bankEquity - r.governmentDeposits - r.pensionCash - r.financialTermFunding;
      close(row.privateMoney-prior.privateMoney,moneyBalance(row)-moneyBalance(prior));
      close(row.policyInflationSignal,year === 1 ? profile.params.initialPolicyInflation : prior.inflation);
    }
    largestResidual=Math.max(largestResidual,row.relativeResidual,Math.abs(row.nominalGDPResidual)/Math.max(1,row.nominalOutput));
  }
}
const stressed = simulate({...params, periods:120, firms:20, households:50, quantityPriceAdjustment:1},params.seed,
  {shocks:[{type:'supply',start:2,duration:4,magnitude:-80,recovery:.5}]}).rows;
assert(stressed.some(row=>row.priceBoundHit));
assert(stressed.every(row=>row.producerPrice>0 && row.relativeResidual<1e-8));

const ensemble = runEnsemble({params,reference:fixed,paths:[pulse]});
const view = sectorYear(ensemble,'scenario',2);
const purchases = view.relations.find(link=>link.id==='households-firms').directions[0].items[0].value;
assert.equal(purchases,ensemble.first.scenario.rows[2].nominalConsumptionGoods);
assert(simulationFindings(ensemble).findings.some(text=>text.includes('Consumer prices')));
console.log('PASS: money and velocity, output, 2% inflation, VAT, real-rate feedback and 56 reconciled 40-year paths. Maximum relative residual '+largestResidual);

import assert from 'node:assert/strict';
import fs from 'node:fs';
import {simulate,quantile} from '../research/frozen_engine_v1_15/engine.mjs';
import {PARAMETERS,DEFAULTS,MODEL_VERSION,sanitize} from '../dist/parameters.mjs';
import {restoreConfiguration,resetEconomyParameters} from '../dist/configuration.mjs';
import {HouseholdMarket} from '../dist/finance.mjs';

const read=path=>JSON.parse(fs.readFileSync(new URL('../'+path,import.meta.url)));
const profiles=read('research/frozen_engine_v1_16/profiles.json'),benchmarks=read('dist/data/capital_input_benchmarks.json');
const prior=read('research/capital_inputs_prior.json');
const observations=read('dist/data/finance_validation.json').recent.legacy.predictions;
const close=(a,b,label)=>assert(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(a),Math.abs(b)),label+': '+a+' vs '+b);
const keys=['foreignPortfolioWeight','financialIncomeTax','wealthTax'];
for(const profile of profiles){
 const b=benchmarks[profile.code],p=sanitize(profile.params);
 assert(p.foreignPortfolioWeight>0&&p.financialIncomeTax>0);
 for(const key of keys){assert.equal(p[key],profile.params[key]);assert.equal(profile.provenance[key].status,'proxy');assert(profile.provenance[key].url.startsWith('https://'));}
 const weights=['ventureWeight','businessEquityWeight','corporateBondWeight','governmentBondWeight'].reduce((s,key)=>s+p[key],0);
 close(p.foreignPortfolioWeight/(weights+p.foreignPortfolioWeight),b.foreignPortfolioShare,'Weight to share mapping');
 const savers=Array.from({length:3},()=>({cash:100}));
 const market=new HouseholdMarket(savers,[0,0,0],{...p,marketDepositShare:100});
 close(market.orders.foreignAssets.reduce((a,b)=>a+b,0)/market.budget,b.foreignPortfolioShare,'Executed order allocation');
 if(!b.financialIncomeTaxFallback)close(p.financialIncomeTax,b.capitalIncomeTaxGDP*b.gdpEURmillion/b.householdPropertyIncomeEURmillion,'Tax numerator/denominator');
 assert(p.incomeTax<=prior[profile.code].incomeTax);
 const reset=resetEconomyParameters(p,{...p,foreignPortfolioWeight:0,financialIncomeTax:0,wealthTax:0});
 for(const key of keys)assert.equal(reset[key],p[key]);
}
const italy=profiles.find(p=>p.code==='ITA'),germany=profiles.find(p=>p.code==='DEU');
assert.equal(italy.params.wealthTax,.2);
assert.equal(germany.params.wealthTax,0); // No invented financial-wealth levy.
assert(germany.provenance.wealthTax.note.includes('not the absence of all'));
const saved={modelVersion:'1.14.1',country:'ITA',params:{...prior.ITA,...Object.fromEntries(keys.map(key=>[key,0]))},
 reference:{...prior.ITA,...Object.fromEntries(keys.map(key=>[key,0]))},referenceLabel:'Pinned reference',
 paths:[{key:'importTariff',start:4,end:4,target:20,mode:'step'}],shocks:[{type:'demand',start:3,duration:1,magnitude:-10,recovery:0,eventId:'event-1',eventName:'Saved event'}],preset:'custom'};
const migrated=restoreConfiguration(saved,profiles);
assert(migrated.migrated&&!migrated.rebuildPreset&&migrated.capitalInputsUpdated===8);
assert.deepEqual(migrated.state.shocks,saved.shocks);assert.deepEqual(migrated.state.paths,saved.paths);assert.equal(migrated.state.referenceLabel,saved.referenceLabel);
for(const side of ['params','reference'])for(const key of [...keys,'incomeTax'])assert.equal(migrated.state[side][key],italy.params[key]);
const custom=restoreConfiguration({...saved,params:{...saved.params,foreignPortfolioWeight:33,financialIncomeTax:22,wealthTax:.4,incomeTax:31}},profiles);
assert.equal(custom.state.params.foreignPortfolioWeight,33);assert.equal(custom.state.params.financialIncomeTax,22);assert.equal(custom.state.params.wealthTax,.4);assert.equal(custom.state.params.incomeTax,31);
const replay=restoreConfiguration({...saved,modelVersion:MODEL_VERSION},profiles);
assert.equal(replay.state.params.financialIncomeTax,0); // Current explicit edits survive.
assert(PARAMETERS.find(p=>p.key==='foreignPortfolioWeight').max>1020);

let paths=0,years=0,maxResidual=0;
function run(params,seed,options){
 const result=simulate(params,seed,options);paths++;
 for(const row of result.rows.slice(1)){
  years++;maxResidual=Math.max(maxResidual,row.relativeResidual,row.financeResidual,Math.abs(row.savingIdentityResidual)/Math.max(1,Math.abs(row.nominalOutput)),Math.abs(row.netForeignAssetChange-row.currentAccount)/Math.max(1,Math.abs(row.currentAccount)));
  assert(row.publicCreditWeight>=.2&&row.publicCreditWeight<=.4);
  close(row.nationalSaving-row.grossInvestment,row.currentAccount,'S-I=CA');
  close(row.netForeignAssetChange,row.currentAccount,'External transactions');
  assert(row.foreignAssetsAtCost>0&&row.foreignLiabilities>0);
 }
 return result.rows;
}
const seeds=[2026,9945,17864,25783,33702];
const predictions=profiles.map(profile=>{
 const byMode={};
 for(const [mode,params]of Object.entries({before:{...prior[profile.code],...Object.fromEntries(keys.map(key=>[key,0]))},after:profile.params})){
  const rows=seeds.map(seed=>run({...params,periods:8},seed)[2]);
  byMode[mode]={gdp:quantile(rows.map(r=>100*(Math.sqrt(r.output/100)-1)),.5),unemployment:quantile(rows.map(r=>r.unemployment),.5),inflation:quantile(rows.map(r=>r.inflation),.5)};
 }
 return{code:profile.code,observed:observations.find(row=>row.code===profile.code).observed,...byMode};
});
const error=mode=>Object.fromEntries(['gdp','unemployment','inflation'].map(key=>{
 const gaps=predictions.filter(p=>p.code!=='EU27').map(p=>p[mode][key]-p.observed[key]);
 return[key,{rmse:Math.sqrt(gaps.reduce((s,g)=>s+g*g,0)/gaps.length),mae:gaps.reduce((s,g)=>s+Math.abs(g),0)/gaps.length}];
}));
const stress=[];
for(const profile of profiles)for(const seed of seeds.slice(0,3))for(const scenario of ['default','events']){
 const options=scenario==='default'?{}:{shocks:[{type:'demand',start:4,duration:2,magnitude:-20,recovery:.5},{type:'foreignDemand',start:10,duration:2,magnitude:25,recovery:0},{type:'exchangeRate',start:16,duration:2,magnitude:-10,recovery:.5}]};
 const rows=run({...profile.params,periods:40},seed,options).slice(1),last=rows.at(-1);
 stress.push({code:profile.code,seed,scenario,minExports:Math.min(...rows.map(r=>r.exports)),minImports:Math.min(...rows.map(r=>r.imports)),finalRealGDP:last.output,finalEmployment:last.employment,finalPublicDebtGDP:last.publicDebtGDP,
  financialTaxPaid:rows.reduce((s,r)=>s+r.financialIncomeTaxPaid,0),wealthTaxPaid:rows.reduce((s,r)=>s+r.wealthTaxPaid,0),foreignPurchases:rows.reduce((s,r)=>s+r.foreignAssetPurchases,0)});
}
const example=run({...italy.params,periods:8},2026)[1];
assert(example.financialIncomeTaxPaid>0&&example.wealthTaxPaid>0&&example.foreignAssetPurchases>0);
assert(maxResidual<1e-8);
const report={status:'PASS',modelVersion:'1.15.0',currentInputCheckVersion:MODEL_VERSION,executedAt:new Date().toISOString(),presets:profiles.length,paths,years,maxResidual,
 inputChecks:['All portfolio and income-tax presets have positive source-backed proxies.','No weight is silently clipped; planned market-order shares match the source mapping.','National wealth-levy scope is retained, including valid zeros.','Capital receipts are removed from the prior wage-tax allocation.','Older zero defaults refresh without losing named events, paths or pinned references. Custom values and current explicit zeros replay.'],
 benchmark:{protocol:'Same frozen engine 1.15, same 2023 inputs apart from the four documented capital/tax mappings, five common seeds, 27 equal-weight countries. Previously examined 2025 observations; not an untouched holdout. GDP is annualized over 2023-2025. No settings selected from these errors.',before:error('before'),after:error('after'),predictions},
 stress:{paths:stress.length,years:stress.length*40,pathsWithPositiveTrade:stress.filter(p=>p.minExports>0&&p.minImports>0).length,pathsBelowHalfOpeningGDP:stress.filter(p=>p.finalRealGDP<50).length,pathsWithDebtAbove300GDP:stress.filter(p=>p.finalPublicDebtGDP>300).length,outcomes:stress},
 italyYear1:{financialIncomeTaxPaid:example.financialIncomeTaxPaid,wealthTaxPaid:example.wealthTaxPaid,foreignAssetPurchases:example.foreignAssetPurchases},
 scope:'Improved empirical input coverage, scope and allocation; macroeconomic forecasting validity remains unestablished. All results retained.'};
fs.writeFileSync(new URL('../dist/data/capital_input_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,benchmark:{...report.benchmark,predictions:undefined},stress:{...report.stress,outcomes:undefined}}));

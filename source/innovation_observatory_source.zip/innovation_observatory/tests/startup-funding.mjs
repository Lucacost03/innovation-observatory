import fs from 'node:fs';
import assert from 'node:assert/strict';
import {simulate} from '../dist/engine.mjs';
import {MODEL_VERSION} from '../dist/parameters.mjs';
import {simulate as frozen} from '../research/venture_candidates/instrumented/engine.mjs';
const profiles=JSON.parse(fs.readFileSync(new URL('../research/venture_candidates/input_profiles.json',import.meta.url)));
const sum=(rows,key)=>rows.reduce((s,x)=>s+(x[key]??0),0);
const rows=[];let maxResidual=0,sharedValues=0;
for(const profile of profiles)for(const seed of [2026,9945,17864]){
 const input={...profile.params,periods:40};
 const earlier=frozen(input,seed,{snapshots:false});
 const costOnly=simulate({...input,foreignPoolId:0,startupScaleBasis:0,startupSizeHeterogeneity:0},seed,{snapshots:false});
 for(let t=0;t<=40;t++)for(const [key,value]of Object.entries(earlier.rows[t])){
  if(['labourIncomeShare','capitalIncomeShare'].includes(key)||key.startsWith('vc')||!Object.hasOwn(costOnly.rows[t],key))continue;
  assert(Math.abs(value-costOnly.rows[t][key])<1e-9*Math.max(1,Math.abs(value)),profile.code+' legacy '+key);sharedValues++;
 }
 const candidate=simulate({...input,foreignPoolId:0,startupScaleBasis:1,startupSizeHeterogeneity:1},seed,{snapshots:false});
 for(const x of candidate.rows)maxResidual=Math.max(maxResidual,x.relativeResidual);
 const summarize=r=>({finalGDP:r.rows.at(-1).output,finalUnemployment:r.rows.at(-1).unemployment,finalFirms:r.rows.at(-1).firmCount,entries:sum(r.rows,'entries'),lateEntries:sum(r.rows.slice(-10),'entries'),lateFunding:sum(r.rows.slice(-10),'ventureFunding')});
 rows.push({country:profile.code,seed,earlier:summarize(earlier),candidate:summarize(candidate)});
}
const result={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths:rows.length*3,years:rows.length*3*40,sharedValues,maxResidual,rows,interpretation:'The exact purchase-cost correction reproduces the nine original paths, excluding the two deliberately rebased income-share fields in engine 1.21. Opening-scale varied entrants remove the mechanical survivor-size threshold. Aggregate outcomes are mixed and entry is not guaranteed. These are controlled structural/accounting comparisons, not empirical forecast validation. No parameter was chosen to force upward funding or GDP.'};
fs.writeFileSync(new URL('../dist/data/startup_funding_validation.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));

import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {simulate,runEnsemble} from '../dist/engine.mjs';
import {simulate as preMacro} from '../research/frozen_engine_v1_18_1/engine.mjs';
import {simulate as frozen} from '../research/frozen_engine_v1_17/engine.mjs';
import {FOREIGN_PROJECTIONS as data,foreignGrowthRates} from '../dist/foreign.mjs';
import {MODEL_VERSION,metricValue,sanitize} from '../dist/parameters.mjs';
import {openingEventDraft,newEvent,eventPreview,shocksFromEvents} from '../dist/event-schedule.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';

const read=name=>JSON.parse(fs.readFileSync(new URL('../'+name,import.meta.url)));
const profiles=read('dist/data/profiles.json'),oldProfiles=read('research/frozen_engine_v1_17/profiles.json');
const italy=sanitize(profiles.find(x=>x.code==='ITA').params);
const close=(a,b,label='equality')=>assert(Math.abs(a-b)<1e-9*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} vs ${b}`);
let paths=0,years=0,maxResidual=0,unchangedValues=0;
const outcomes=[];
function checked(params,seed,options={}){
 const run=simulate(params,seed,options);paths++;
 for(let t=0;t<run.rows.length;t++){
  const r=run.rows[t];assert(Object.values(r).every(Number.isFinite),'finite rows');
  if(!t)continue;years++;
  const prior=run.rows[t-1];
  close(r.labourIncome+r.grossCapitalIncome+r.netProductionTaxes,r.nominalOutput,'income GDP');
  close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+r.nominalExports-r.nominalImports,'expenditure GDP');
  close(r.nationalSaving-r.grossInvestment,r.currentAccount,'S-I=CA');
  close(r.netForeignAssetChange,r.currentAccount,'NFA=CA');
  close(r.populationIndex-prior.populationIndex,r.births-r.deaths+r.netMigration,'population');
  close(r.householdMortgageDebt-prior.householdMortgageDebt,r.mortgageOriginations-r.mortgageRepayments-r.mortgagePrincipalExtinguished,'mortgage stock');
  close(r.pensionCash-prior.pensionCash,r.pensionContributions-r.pensionWithdrawals+r.pensionDividends+r.pensionDepositInterest+r.pensionLiquidationProceeds+r.pensionEquitySales,'pension cash');
  for(const code of ['USA','CHN','ROW']){
   const key='foreignTFPIndex'+code,growth=r['foreignTFPGrowth'+code];
   close(r[key],prior[key]*(1+growth/100),'annual foreign compounding');
   assert(r[key]>0);
  }
  maxResidual=Math.max(maxResidual,r.relativeResidual);
 }
 return run;
}

// Source hashes, complete annual paths and exact within-country conversion.
for(const {code} of data.scenarios)for(const provider of ['USA','CHN','ROW']){
 const series=data.multipliers[code][provider];assert.equal(series.length,78);
 close(series[0],1);assert(series.every(v=>Number.isFinite(v)&&v>0));
}
for(const source of [data.sources.data,data.sources.structure]){
 const name=source===data.sources.data?'oecd_eo117_efflabs_gdp.csv':'oecd_eo117_structure.xml';
 const hash=crypto.createHash('sha256').update(fs.readFileSync(new URL('../research/forecast_source_candidates/'+name,import.meta.url))).digest('hex');
 assert.equal(hash,source.sha256);
}
const raw=read('research/forecast_source_candidates/oecd_candidate_extraction.json').rawLevels;
const pool=fs.readFileSync(new URL('../dist/data/pwt_rest_of_world_weights.csv',import.meta.url),'utf8').trim().split(/\r?\n/);
const csvLine=line=>line.split(/,(?=(?:(?:[^\"]*\"){2})*[^\"]*$)/).map(value=>value.startsWith('\"')?value.slice(1,-1).replaceAll('\"\"','\"'):value);
const header=csvLine(pool.shift()),members=pool.map(line=>Object.fromEntries(csvLine(line).map((v,i)=>[header[i],v])));
const covered=members.filter(x=>data.row.codes.includes(x.countrycode));
assert.equal(covered.length,47);assert(!data.row.codes.includes('USA')&&!data.row.codes.includes('CHN'));
close(data.row.outputCoverage,covered.reduce((s,x)=>s+Number(x.cgdpo),0)/members.reduce((s,x)=>s+Number(x.cgdpo),0));
for(const scenario of data.scenarios)for(let year=2023;year<=2100;year++){
 for(const provider of ['USA','CHN'])close(data.multipliers[scenario.code][provider][year-2023],(raw[provider][scenario.code].EFFLABS[year]/raw[provider][scenario.code].EFFLABS[2023])**.67,'source conversion');
 const numerator=covered.reduce((s,x)=>s+Number(x.cgdpo)*Number(x.ctfp)*(raw[x.countrycode][scenario.code].EFFLABS[year]/raw[x.countrycode][scenario.code].EFFLABS[2023])**.67,0);
 const denominator=covered.reduce((s,x)=>s+Number(x.cgdpo)*Number(x.ctfp),0);
 close(data.multipliers[scenario.code].ROW[year-2023],numerator/denominator,'fixed-weight ROW');
}

for(const profile of profiles)for(let scenario=0;scenario<6;scenario++)for(const seed of [2026,9945]){
 assert.equal(profile.params.foreignForecast,1);
 const r=checked({...profile.params,foreignProjectionScenario:scenario,periods:40},seed);
 for(let year=0;year<=40;year++)for(const provider of ['USA','CHN','ROW'])close(r.rows[year]['foreignTFPIndex'+provider],100*data.multipliers[data.scenarios[scenario].code][provider][year],'published annual path');
 outcomes.push({country:profile.code,scenario:data.scenarios[scenario].code,seed,finalGDP:r.rows.at(-1).output,finalChinaIndex:r.rows.at(-1).foreignTFPIndexCHN,maxResidual:Math.max(...r.rows.map(x=>x.relativeResidual))});
}

// Source scenarios can switch prospectively without resetting already grown levels.
const scenarioPath=[{key:'foreignProjectionScenario',start:8,end:8,target:3,mode:'step'}];
const base=checked({...italy,periods:40},2026),changed=checked({...italy,periods:40},2026,{paths:scenarioPath});
assert.deepEqual(base.rows.slice(0,8),changed.rows.slice(0,8));
for(const provider of ['USA','CHN','ROW']){
 let level=100;
 for(let year=1;year<=40;year++){
  const scenario=year<8?0:3,rate=foreignGrowthRates({...italy,foreignProjectionScenario:scenario},year)[provider].applied;
  level*=1+rate/100;close(changed.rows[year]['foreignTFPIndex'+provider],level,'prospective scenario change');
 }
}

// Positive/negative/overlapping events, timing, fading and persistent level effects.
for(const country of ['ITA','DEU','EU27'])for(const seed of [2026,9945])for(const magnitude of [-1,.5]){
 const params={...profiles.find(x=>x.code===country).params,periods:20};
 const shocks=['USA','CHN','ROW'].map(code=>({type:'foreignTFP'+code,start:4,duration:3,magnitude,recovery:.5,eventId:'technology',eventName:'Foreign productivity surprise'}));
 const plain=checked(params,seed),r=checked(params,seed,{shocks});
 assert.deepEqual(plain.rows.slice(0,4),r.rows.slice(0,4));
 for(let year=4;year<=20;year++)for(const code of ['USA','CHN','ROW']){
  const offset=magnitude*.5**Math.max(0,year-6);
  close(r.rows[year]['foreignTFPGrowth'+code]-plain.rows[year]['foreignTFPGrowth'+code],offset,'growth event');
 }
}
const endingShock={type:'foreignTFPUSA',start:4,duration:1,magnitude:1,recovery:0};
const ending=checked({...italy,periods:16},2026,{shocks:[endingShock]});
close(ending.rows[5].foreignTFPGrowthUSA,base.rows[5].foreignTFPGrowthUSA);
assert(ending.rows[16].foreignTFPIndexUSA>base.rows[16].foreignTFPIndexUSA);
const overlap=checked({...italy,periods:16},2026,{shocks:[endingShock,{...endingShock,magnitude:-.25}]});
close(overlap.rows[4].foreignTFPGrowthUSA-base.rows[4].foreignTFPGrowthUSA,.75,'overlap adds');

// Direct adoption waits for the completed donor history, never the new forecast endpoint.
const isolated={...italy,periods:16,tradeEnabled:0,firmDynamics:0,rdBusiness:0,innovationEfficiency:0,diffusion:0,foreignContact:1,priceDynamics:0,educationEnabled:0};
const lagBase=checked(isolated,2026),lagged=checked(isolated,2026,{shocks:['USA','CHN','ROW'].map(code=>({type:'foreignTFP'+code,start:4,duration:1,magnitude:5,recovery:0}))});
for(let year=0;year<4+italy.adoptionLag+1;year++)close(lagged.rows[year].technology,lagBase.rows[year].technology,'adoption delay');
assert(lagged.rows[4+italy.adoptionLag+1].technology>lagBase.rows[4+italy.adoptionLag+1].technology);

const tail=checked({...italy,periods:100},2026);
assert.equal(tail.rows[77].foreignProjectionCalendarYear,2100);assert.equal(tail.rows[77].foreignProjectionExtrapolated,0);
assert.equal(tail.rows[78].foreignProjectionExtrapolated,1);
for(const code of ['USA','CHN','ROW'])close(tail.rows[77]['foreignTFPGrowth'+code],tail.rows[100]['foreignTFPGrowth'+code],'explicit tail');
const settled=checked({...italy,periods:8,burnIn:4},2026);
assert.equal(settled.rows[0].foreignProjectionCalendarYear,2027);
close(settled.rows[0].foreignTFPIndexUSA,100*data.multipliers.BAU1.USA[4]);
assert.equal(metricValue(base.rows[0],'foreignTFPGrowthUSA'),null);

for(const country of ['ITA','DEU','EU27'])for(const seed of [2026,9945,17864]){
 const p={...oldProfiles.find(x=>x.code===country).params,foreignForecast:0,periods:24};
 checked(p,seed);const current=preMacro(p,seed),old=frozen(p,seed);paths++;years+=24;
 for(let t=0;t<old.rows.length;t++)for(const [key,value]of Object.entries(old.rows[t])){close(current.rows[t][key],value,'unchanged 1.17 '+key);unchangedValues++;}
}

// Existing examples have full timing and effective numbers; a fresh draft is not auto-applied.
const draft=openingEventDraft([],40);assert(draft.exampleLoaded);assert.equal(draft.events.length,1);
for(const name of ['custom','downturn','production','exports','innovation']){
 const example=newEvent([],40,name),shocks=shocksFromEvents([example]);
 assert(shocks.length>0&&shocks.every(x=>x.magnitude!==0&&x.start>0&&x.duration>0));
 assert(eventPreview([example],example.start).some(x=>Math.abs(x.change)>0));
}
const persisted=shocksFromEvents(draft.events);assert.deepEqual(openingEventDraft(persisted,40),{events:draft.events,exampleLoaded:false});
const prior={modelVersion:'1.17.0',country:'ITA',params:{...oldProfiles.find(x=>x.code==='ITA').params,rdBusiness:2},reference:oldProfiles.find(x=>x.code==='ITA').params,paths:[],shocks:persisted,preset:'custom',referenceLabel:'Pinned'};
const restored=restoreConfiguration(prior,profiles);assert(!restored.rebuildPreset);assert.equal(restored.state.params.foreignForecast,1);assert.equal(restored.state.params.rdBusiness,2);assert.deepEqual(restored.state.shocks,persisted);
const custom=restoreConfiguration({...prior,paths:[{key:'usGrowth',start:4,end:4,target:2,mode:'step'}]},profiles);assert(custom.foreignProjectionPreserved);assert.equal(custom.state.params.foreignForecast,0);
const paired=runEnsemble({params:{...italy,periods:8,replications:2},reference:{...italy,periods:8,replications:2}});paths+=4;years+=32;
assert.deepEqual(paired.raw.baseline,paired.raw.scenario);maxResidual=Math.max(maxResidual,paired.residuals.maxRelative);

const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,maxResidual,unchangedValues,
 source:{scenarioCount:6,annualYears:78,providers:3,rowCountries:47,rowOutputCoverage:data.row.outputCoverage},outcomes,
 checks:['Frozen OECD data hashes and all source-to-TFP transformations verified; fixed 2023 ROW weights exclude USA and China.',
 'All 28 current opening economies run with all six projections across two seeds; population, pensions, mortgages and GDP/financial identities reconcile.',
 'Published annual rates compound exactly; prospective scenario changes retain accumulated levels. Rates after 2100 are explicitly extrapolated.',
 'Positive, negative, overlapping and fading foreign growth events have no pre-start effects. A finished growth shock leaves its accumulated level change.',
 'Direct domestic adoption uses delayed completed foreign history, with no access to the new endpoint.',
 'Historical1.18.1with forecasts disabled reproduces common frozen1.17row values; current monetary/CPI corrections intentionally differ. Paired unchanged experiments match exactly.',
 'Example drafts and named event persistence include timing and nonzero effects; old custom fixed-growth paths migrate without being ignored.'],
 limitation:'Accounting and source/timing checks do not establish forecast accuracy. The 2025/2026 OECD vintage cannot be used as a past-only 2023 forecast. TFP conversion and coverage are explicit proxies.'};
fs.writeFileSync(new URL('../dist/data/foreign_projection_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,outcomes:undefined},null,2));

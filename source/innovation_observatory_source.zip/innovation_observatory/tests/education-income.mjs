import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {incomeAccount} from '../dist/income-account.mjs';
import {simulate,Economy} from '../dist/engine.mjs';
import {simulate as frozen} from '../research/frozen_engine_v1_20/engine.mjs';
import {DEFAULTS,MODEL_VERSION,METRICS,metricValue} from '../dist/parameters.mjs';
import {EDUCATION_QUALITY as quality} from '../dist/education-quality-data.mjs';
import {restoreConfiguration,restoreEducationQuality,restoreEducationPaths} from '../dist/configuration.mjs';
const read=f=>JSON.parse(fs.readFileSync(new URL('../'+f,import.meta.url)));
// Freeze the original study's macro inputs: this release intentionally changes trade, R&D and GDP-share calibration.
const liveProfiles=read('dist/data/profiles.json'),macroPrior=read('research/macro_external_tfp/prior_parameters.json');
const profiles=liveProfiles.map(p=>({...p,params:{...macroPrior.find(x=>x.code===p.code).params,domesticForecast:0,foreignSettlementInterest:0,openingMacroCalibration:0,otherForeignIncomeGDP:0,initialInventoryChange:0,currencyPPPAdjustment:0}})),prior=read('research/frozen_engine_v1_20/profiles.json');
const close=(a,b,label,t=1e-9)=>assert(Math.abs(a-b)<=t*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} != ${b}`);
for(const s of quality.sourceManifest)if(s.sha256){const file=new URL('../research/education_2026/'+s.file,import.meta.url);if(s.optionalInSourceBundle&&!fs.existsSync(file))continue;const raw=fs.readFileSync(file);assert.equal(crypto.createHash('sha256').update(raw).digest('hex'),s.sha256);}
assert.equal(Object.keys(quality.countries).length,30);assert.equal(quality.formatChecks.length,174);
for(const check of quality.formatChecks)close(check.catalog,check.repository,'Catalog and repository copies',1e-11);
assert(new Set(Object.values(quality.countries).map(c=>c.learningQuality)).size>20);
for(const p of profiles){
 const c=quality.countries[p.code],old=prior.find(x=>x.code===p.code);
 close(p.params.initialLearningScore,c.harmonizedScore,'Country learning score');close(p.params.initialEducationQuality,c.harmonizedScore/625,'World Bank quality adjustment');
 close(p.params.publicEducationQuality,c.learningQuality,'Public national-anchor fallback');close(p.params.privateEducationQuality,c.learningQuality,'Household-funded national-anchor fallback');
 close(p.params.initialHumanCapital,old.params.initialHumanCapital,'Adult PWT stock retained');
 assert(p.provenance.publicEducationQuality.sectorAssignment.includes('assumed'));
 if(p.code!=='EU27')close((c.expectedSchoolYears+c.expectedPrePrimaryYears)*c.learningQuality,c.learningAdjustedSchoolYears,'Published LAYS formula',2e-7);
 assert.equal(c.releaseYear,2026);assert.equal(c.scoreInterval,null);
}
assert.equal(quality.countries.CHN.assessmentYear,2015);assert(quality.countries.CHN.coverage.toLowerCase().includes('extrapolated'));
assert.equal(Math.round(quality.countries.USA.harmonizedScore),510);assert.equal(Math.round(quality.countries.ITA.harmonizedScore),500);assert.equal(quality.countries.CHN.harmonizedScore,441);
let weights=0,euScore=0;for(const [code,w]of Object.entries(quality.countries.EU27.weights)){weights+=w;euScore+=w*quality.countries[code].harmonizedScore;}close(weights,1,'EU weights');close(euScore,quality.countries.EU27.harmonizedScore,'EU pupil-cohort aggregation');
assert(!METRICS.netProductionTaxes,'The display has only the two factor incomes.');
const example=incomeAccount(90,50,10,3,100);close(example.factorIncomeGDP,93,'Factor-income denominator');close(example.labourIncomeShare,100*50/93,'Labour income share');close(example.capitalIncomeShare,100*43/93,'Capital income share');close(example.labourIncomeShare+example.capitalIncomeShare,100,'Two shares');close(example.labourIncome+example.grossCapitalIncome+example.netProductionTaxes,100,'Market-price GDP still reconciles');
const loss=incomeAccount(90,110,10,0,100);assert(loss.capitalIncomeShare<0&&loss.labourIncomeShare>100);close(loss.labourIncomeShare+loss.capitalIncomeShare,100,'Negative capital income retained');
const zero=incomeAccount(0,0,0,0,0);assert.equal(zero.factorIncomeSharesDefined,0);assert.equal(metricValue(zero,'labourIncomeShare'),null);
const changed=new Set(['labourIncomeShare','capitalIncomeShare']);
let paths=0,years=0,sharedValues=0,maxResidual=0,maxShareGap=0;const cases=[];
function compare(before,after,label){
 assert.equal(before.rows.length,after.rows.length);
 for(let t=0;t<after.rows.length;t++){
  const r=after.rows[t];assert(Object.values(r).every(Number.isFinite));maxResidual=Math.max(maxResidual,r.relativeResidual);
  if(r.factorIncomeSharesDefined){const gap=Math.abs(r.labourIncomeShare+r.capitalIncomeShare-100);maxShareGap=Math.max(maxShareGap,gap);assert(gap<1e-12);}
  for(const [key,value]of Object.entries(before.rows[t]))if(typeof value==='number'&&!changed.has(key)){close(r[key],value,label+' unchanged '+key);sharedValues++;}
 }
 paths+=2;years+=2*(after.rows.length-1);
}
// No automatic GDP boost from measuring an existing country's learning level.
for(const p of profiles)for(const seed of [2026,9945]){
 const old=prior.find(x=>x.code===p.code),a=frozen({...old.params,periods:40},seed,{snapshots:false}),b=simulate({...p.params,periods:40},seed,{snapshots:false});compare(a,b,p.code+' baseline');
 cases.push({country:p.code,seed,score:p.params.initialLearningScore,quality:p.params.initialEducationQuality,finalGDP:b.rows.at(-1).output,unchangedEconomy:true});
}
let educationFirstChange=null;
for(const code of ['ITA','USA','CHN']){
 const p=profiles.find(x=>x.code===code),old=prior.find(x=>x.code===code),q=p.params.initialEducationQuality;
 const oldPaths=['publicEducationQuality','privateEducationQuality'].map(key=>({key,start:4,end:4,target:1.5,mode:'step'}));
 const newPaths=restoreEducationPaths(oldPaths,old.params,p.params);
 const a=frozen({...old.params,periods:30},2026,{paths:oldPaths}),b=simulate({...p.params,periods:30},2026,{paths:newPaths});compare(a,b,code+' same relative quality reform');
 const base=simulate({...p.params,periods:30},2026);paths++;years+=30;
 const first=b.rows.findIndex((r,t)=>Math.abs(r.humanCapitalIndex-base.rows[t].humanCapitalIndex)>1e-10);
 assert.equal(first,4+(p.params.educationLag??DEFAULTS.educationLag));educationFirstChange=first;
 for(let t=0;t<first;t++){close(b.rows[t].humanCapitalIndex,base.rows[t].humanCapitalIndex,'No premature skill response');close(b.rows[t].output,base.rows[t].output,'No premature GDP response');}
 assert(b.rows.at(-1).humanCapitalIndex>base.rows.at(-1).humanCapitalIndex);
 const e=new Economy(p.params,2026),flow={};e.society.closeEducation({...e.p,publicEducationQuality:q*1.5},flow,2*e.p.initialGovernmentShare,0,1,e.p.initialGovernmentShare,50);
 close(flow.publicEducationFundingIndex,200,'Funding once');close(flow.effectivePublicEducationIndex,300,'Quality once relative to own anchor');
 const saved={country:code,modelVersion:'1.20.0',params:{...old.params,publicEducationQuality:1.4,educationElasticity:.35},reference:old.params,paths:oldPaths,shocks:[],preset:'custom'};
 const migrated=restoreConfiguration(saved,profiles);assert(!migrated.rebuildPreset);close(migrated.state.params.publicEducationQuality/q,1.4,'Authored relative quality preserved');close(migrated.state.params.educationElasticity,.35,'Authored elasticity preserved');close(migrated.state.paths[0].target/q,1.5,'Timeline preserved');
 const again=restoreConfiguration(migrated.state,profiles);assert.deepEqual(again.state,migrated.state,'Migration idempotent');
 for(const invalid of [true,false,null,''])assert.throws(()=>restoreConfiguration({...saved,paths:[{key:'publicEducationQuality',start:4,end:4,target:invalid,mode:'step'}]},profiles));
 const imported=restoreEducationQuality(old.params,p.params);close(imported.publicEducationQuality,q,'JSON import quality migration');
}
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,sharedValues,maxResidual,maxShareGap,educationFirstChange,sourceFormatChecks:174,learningFormulaChecks:29,educationPillarFormulaChecks:29,countryBaselines:cases,unchangedKeysException:['labourIncomeShare','capitalIncomeShare'],checks:['Labour and capital income shares total 100% on the stated factor-income base; market-price GDP/taxes and all ledgers remain reconciled. Negative capital income is retained and a nonpositive denominator shows undefined shares.','29 national learning scores and their quality mappings reproduce two official formats; EU27 aggregation, source vintages and China extrapolation are explicit.','At the original study’s frozen pre-1.23 macro inputs, all 30 presets × 2 seeds retain every earlier economic row value within tolerance except the intentionally rebased income shares. Measuring opening quality adds no arbitrary GDP boost.','Same relative education reforms retain the prior dynamic response and delayed skill effect. No education elasticity, lag or immediate GDP multiplier is newly estimated.','Saved scenario/reference quality settings, timeline targets and JSON import conversion preserve relative policy choices and migrate once.'],limitations:quality.limitations,forecastAccuracy:'No new out-of-sample forecasting improvement is claimed. This release corrects the definition of displayed shares and the empirical source anchors; causal school efficiency and public/private differences remain unidentified.'};
fs.writeFileSync(new URL('../dist/data/education_income_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,countryBaselines:undefined,limitations:undefined}));

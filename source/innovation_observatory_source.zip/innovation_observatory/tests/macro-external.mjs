import fs from 'node:fs';
import assert from 'node:assert/strict';
import {Economy,simulate} from '../dist/engine.mjs';
import {MODEL_VERSION,DEFAULTS,sanitize,metricValue} from '../dist/parameters.mjs';
import {HOME_FRONTIERS} from '../dist/home-frontier-data.mjs';
import {homeFrontierGrowth,settleOtherForeignIncome} from '../dist/macro-channels.mjs';
import {initializeMonetary,advanceMonetary} from '../dist/monetary.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';
const read=f=>JSON.parse(fs.readFileSync(new URL('../'+f,import.meta.url)));
const profiles=read('dist/data/profiles.json'),prior=read('research/macro_external_tfp/prior_parameters.json'),source=read('dist/data/macro_external_benchmarks.json'),fiscalSource=read('dist/data/fiscal_benchmarks.json');
const close=(a,b,label,t=1e-8)=>assert(Math.abs(a-b)<=t*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} versus ${b}`);
const seeds=[2026,9945,17864,25783,33702];let paths=0,years=0,maxResidual=0;const comparisons=[],longRuns=[];
function check(run,label){paths++;years+=run.rows.length-1;for(let t=0;t<run.rows.length;t++){
 const r=run.rows[t];for(const[k,v]of Object.entries(r))if(typeof v==='number')assert(Number.isFinite(v),label+' '+k);
 assert(r.relativeResidual<1e-8);maxResidual=Math.max(maxResidual,r.relativeResidual);
 close(r.currentAccount,r.nominalExports-r.nominalImports+r.foreignAssetIncome+(r.bankForeignIncome??0)+(r.otherForeignIncome??0)-(r.governmentInterestToForeign??0),label+' CA components');
 close(r.currentAccountGDP,100*r.currentAccount/r.nominalOutput,label+' CA/GDP');
 close(r.nationalSaving-r.grossInvestment,r.currentAccount,label+' S-I=CA');
 if(t){close(r.netForeignAssets-run.rows[t-1].netForeignAssets,r.currentAccount,label+' independent NFA change');close(r.netForeignAssetChange,r.currentAccount,label+' reported NFA change');}
 assert(r.exports>0&&r.imports>0&&r.foreignAssetsAtCost>0&&r.foreignLiabilities>0,label+' positive gross channels');
 }}
for(const p of profiles){
 const params=sanitize(p.params),b=source.countries[p.code],e=new Economy(params,2026),r=e.initialSnapshot();
 for(const[k,v]of Object.entries(p.params))if(Object.hasOwn(DEFAULTS,k))close(params[k],v,p.code+' raw bound '+k,1e-12);
 close(r.currentAccountGDP,b.currentAccountGDP,p.code+' observed opening CA');
 close(r.nominalExports-r.nominalImports,b.goodsServicesBalanceGDP,p.code+' full opening net trade');
 close(r.government,p.params.fiscalCoverage?fiscalSource.countries[p.code].opening.governmentConsumption:b.governmentConsumptionGDP,p.code+' matched source government GDP denominator');
 close(r.grossInvestment,b.fixedInvestmentGDP+b.inventoryInvestmentGDP,p.code+' gross investment');
 close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+r.nominalExports-r.nominalImports,p.code+' opening GDP');
 close(metricValue(r,'currentAccount'),b.currentAccountGDP,p.code+' visible source opening CA');
 assert.equal(metricValue(r,'netForeignAssetChange'),null,'No second application of annual benchmark to opening financial stocks');
 for(let t=1;t<15;t++)close(homeFrontierGrowth(params,t),100*(HOME_FRONTIERS[params.foreignPoolId].multipliers.BAU1[t]/HOME_FRONTIERS[params.foreignPoolId].multipliers.BAU1[t-1]-1),p.code+' home source path');
 const sim=simulate({...params,periods:40},2026,{snapshots:false});check(sim,p.code);
 const last=sim.rows.at(-1);longRuns.push({country:p.code,seed:2026,finalRealGDP:last.output,finalCurrentAccountGDP:last.currentAccountGDP,finalTechnologyTFP:last.technologyTFPLevel,finalOutputTFP:last.tfpLevel,currencyBoundYears:sim.rows.filter(r=>r.currencyStrength<=50.000001||r.currencyStrength>=199.999999).length,employmentBelow50Years:sim.rows.filter(r=>r.employment<50).length,otherIncomeCashShortfall:sim.rows.reduce((s,r)=>s+(r.unpaidForeignIncome??0),0)});
}
close(profiles.find(p=>p.code==='CHN').params.rdBusiness,100*2592.22/126058.2,'China BERD percent units');
assert(source.countries.CHN.observedTFPGrowth>source.countries.USA.observedTFPGrowth&&source.countries.USA.observedTFPGrowth>source.countries.EU27.observedTFPGrowth);
// Net foreign receipts cannot be manufactured by borrowing to buy equal-yield foreign assets.
{
 const p=profiles.find(p=>p.code==='USA').params,e=new Economy(p,2026);let total=e.households.reduce((s,h)=>s+h.cash,0);
 const flow=settleOtherForeignIncome(e.households,-2*total);close(flow.otherForeignIncome,-total,'Cash-constrained outgoing foreign income');close(flow.unpaidForeignIncome,total,'Unpaid income explicit');assert(e.households.every(h=>h.cash>=-1e-12));
 const a=new Economy({...p,currencyDynamics:0,foreignPortfolioWeight:0,initialHouseholdForeignAssets:0},2026),b=new Economy({...p,currencyDynamics:0,foreignPortfolioWeight:0,initialHouseholdForeignAssets:0},2026);
 const principal=10;settleOtherForeignIncome(b.households,-principal);b.households[0].foreignAssets=principal;b.households[0].foreignAssetCost=principal;b.bank.netForeignPosition-=principal;b.bank.foreignLiabilities+=principal;
 const ar=a.step(1,1),br=b.step(1,1);close(br.foreignAssetIncome-ar.foreignAssetIncome,-(br.bankForeignIncome-ar.bankForeignIncome),'Equal-yield gross portfolio income offset');
}
// The FX price reference uses last completed price levels, and can be switched off.
{
 const p=sanitize({...profiles.find(p=>p.code==='USA').params,currencyRateResponse:0,currencyPressure:0}),m=initializeMonetary(p);
 const q=advanceMonetary(m,p,2,{}, {foreign:1.2,domestic:1});assert(q.currencyStrength>100);close(q.currencyPPPLog,.15*Math.log(1.2),'Completed-price reference');
 const off=advanceMonetary(m,{...p,currencyDynamics:0},2,{}, {foreign:1.2,domestic:1});close(off.currencyStrength,100,'FX disabled');
}
for(const code of ['USA','CHN','EU27']){
 const p=profiles.find(p=>p.code===code),old=prior.find(p=>p.code===code).params;
 const saved={country:code,modelVersion:'1.22.0',params:old,reference:old,paths:[],shocks:[],preset:'custom'};
 const restored=restoreConfiguration(saved,profiles);close(restored.state.params.rdBusiness,p.params.rdBusiness,'Refresh only old source RD');close(restored.state.params.exportDemand,p.params.exportDemand,'Refresh old source orders');assert.deepEqual(restoreConfiguration(restored.state,profiles).state,restored.state);
 const authored=restoreConfiguration({...saved,params:{...old,frontierGrowth:1.234,rdBusiness:3.21}},profiles);close(authored.state.params.rdBusiness,3.21,'Custom RD retained');assert.equal(authored.state.params.domesticForecast,0,'Custom fallback frontier retained');
 for(const seed of seeds){
  const baseline={...old,periods:40,domesticForecast:0,foreignSettlementInterest:0,openingMacroCalibration:0,initialExportSales:0,initialInventoryChange:0,otherForeignIncomeGDP:0,currencyPPPAdjustment:0,observedTFPGrowth:0};
  const earlier=simulate(baseline,seed,{snapshots:false}),candidate=simulate({...p.params,periods:40},seed,{snapshots:false});check(candidate,code+' paired');paths++;years+=40;
  const summarize=run=>[0,1,2,10,40].map(t=>({year:t,currentAccountGDP:100*run.rows[t].currentAccount/run.rows[t].nominalOutput,realGDP:run.rows[t].output,outputTFP:run.rows[t].tfpLevel,technologyTFP:run.rows[t].technologyTFPLevel}));
  const scores=[1,2].filter(t=>Number.isFinite(source.countries[code].recentCurrentAccountGDP[String(2023+t)])).map(t=>({calendarYear:2023+t,observed:source.countries[code].recentCurrentAccountGDP[String(2023+t)],earlier:100*earlier.rows[t].currentAccount/earlier.rows[t].nominalOutput,candidate:candidate.rows[t].currentAccountGDP}));
  comparisons.push({country:code,seed,earlier:summarize(earlier),candidate:summarize(candidate),scores});
 }
}
const scores=comparisons.flatMap(x=>x.scores),score=key=>({n:scores.length,MAE:scores.reduce((s,r)=>s+Math.abs(r[key]-r.observed),0)/scores.length,RMSE:Math.sqrt(scores.reduce((s,r)=>s+(r[key]-r.observed)**2,0)/scores.length)});
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,maxResidual,currentAccountDiagnostic:{units:'percentage points of nominal GDP',independentObservedCountryYears:5,pairedSeeds:5,earlier:score('earlier'),candidate:score('candidate'),scope:'USA/China 2024–2025 and EU constructed 2024 where observed (five country-year observations, each compared across five seeds). Same five seeds. Retrospective diagnostic using revised data; not an untouched holdout. No future CA targets used for export-order calibration.'},comparisons,longRuns,
 checks:['All30source presets retain their raw bounded inputs; China BERD is2.056%, not205.9% or clipped10%.','Opening national-accounts components reconcile to GDP100 and full observed CA; source CA is displayed at year0 without applying its annual flow again to opening stocks.','All30×40-year paths and15matched candidate paths retain independent S-I=CA, annual NFA transaction changes, gross two-way trade, and source-correct domestic frontier mapping.','Equal-yield debt-funded foreign portfolios have offsetting foreign funding interest. Outgoing other income is cash-constrained with unpaid amounts reported.','Completed-price FX reference, disabled-FX behavior, source-input migration and authored intervention preservation checked.'],
 limitations:['Historical PWT TFP growth is a benchmark, not a guarantee that USA or China outgrows EU in every future scenario. Firm technology, output residual and national PWT TFP are not interchangeable.','Future current accounts remain endogenous and can change sign. Trade covers a compressed final-good proxy; net primary/secondary income is a household-allocation proxy.','PPP convergence speed, funding spread equality and behavioral coefficients are unestimated. Extreme long-run currency bounds, weak GDP paths and cash-constrained foreign payments are retained in longRuns.','The historical ranking and opening balance corrections are evidence-backed. Broad empirical forecast accuracy remains unestablished.']};
fs.writeFileSync(new URL('../dist/data/macro_external_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,comparisons:undefined,longRuns:undefined}));

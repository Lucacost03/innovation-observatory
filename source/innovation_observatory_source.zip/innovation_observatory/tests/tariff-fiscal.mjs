import fs from 'node:fs';
import assert from 'node:assert/strict';
import {Economy,simulate} from '../dist/engine.mjs';
import {Economy as OldEconomy} from '../research/frozen_engine_v1_29/engine.mjs';
import {sanitize,METRICS,metricValue} from '../dist/parameters.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';
import {settleImportDuty} from '../dist/tariff-settlement.mjs';
import {capitalFiscalPolicy} from '../dist/fiscal-capital.mjs';
import {CAPITAL_FISCAL_PATHS} from '../dist/fiscal-capital-data.mjs';
import {FISCAL_ENGINE} from '../dist/fiscal-data.mjs';
import {sortedMetricEntries} from '../dist/metric-menu.mjs';
const read=p=>JSON.parse(fs.readFileSync(new URL('../'+p,import.meta.url)));
const ps=read('dist/data/profiles.json'),old=read('research/frozen_engine_v1_29/profiles.json'),tariffs=read('dist/data/tariffs_2023.json').countries,refs=read('dist/data/latest_fiscal_references.json');
const close=(a,b,s,t=1e-9)=>assert(Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=t*Math.max(1,Math.abs(a),Math.abs(b)),`${s}: ${a} / ${b}`);
for(const profile of ps){
 const p=sanitize(profile.params),o=old.find(x=>x.code===profile.code),a=new Economy(p,2026),b=new OldEconomy(o.params,2026),t=tariffs[profile.code],member=!['USA','CHN','EU27'].includes(profile.code);
 assert.equal(t.year,2023);assert(t.effectiveTariffPercent>0);close(t.effectiveTariffPercent,100*t.dutiesMillion/t.goodsImportsMillion,'empirical numerator/denominator');close(p.importTariff,t.effectiveTariffPercent,'unrounded tariff input');
 close(a.initialImports,b.initialImports,profile.code+' opening imports');close(a.initialExports,b.initialExports,'opening exports');close(a.initialCurrentAccount,b.initialCurrentAccount,'opening CA');
 const x=a.initialSnapshot(),y=b.initialSnapshot();for(const k of ['output','nominalOutput','publicTotalRevenue','publicTotalExpenditure','publicDeficitGDP','publicDebt','employmentPopulation'])close(x[k],y[k],profile.code+' preserved opening '+k);
 const duty=settleImportDuty(4,p);close(duty.tariffForeignDuty,member?4:0,'tax recipient');close(duty.tariffCollectionFees,member?1:0,'collection compensation');close(duty.tariffNetExternalTransfer,member?3:0,'net settlement');close(duty.governmentTariffTax+duty.tariffCollectionFees,4-duty.tariffNetExternalTransfer,'net public receipt');
 const c=FISCAL_ENGINE[p.foreignPoolId],path=CAPITAL_FISCAL_PATHS[p.foreignPoolId];
 for(const year of [2023,2024,2025,2030]){const f=capitalFiscalPolicy(p,year,c.opening);if(profile.code==='CHN'){assert.equal(f.fiscalCapitalPathAvailable,0);close(f.capitalExpense,c.opening.capitalExpenditure,'missing split preserved');}else{const src=path.records[String(Math.min(year,2025))];close(f.capitalExpense,src.expenditure,'dated expenditure');assert(f.fiscalCapitalExpenseSourceYear<=year);if(Number.isFinite(src.revenue))close(f.capitalRevenue,src.revenue,'dated revenue');if(year>2025)assert.equal(f.fiscalCapitalExtrapolated,1);}}
 close(capitalFiscalPolicy({...p,fiscalCapitalPath:0},2025,c.opening).capitalExpense,c.opening.capitalExpenditure,'legacy fixed capital');
 const saved={modelVersion:'1.29.0',country:profile.code,params:o.params,reference:o.params,paths:[],shocks:[],preset:'custom'},restored=restoreConfiguration(saved,ps).state;
 for(const k of ['importTariff','importShare','otherForeignIncomeGDP','fiscalCapitalPath','tariffSettlement','tariffExternalShare','tariffCollectionShare'])close(restored.params[k],p[k],profile.code+' migrate '+k);
 const edited=restoreConfiguration({...saved,params:{...o.params,importTariff:17.123},paths:[{key:'importTariff',start:4,end:4,target:35,mode:'step'}]},ps).state;close(edited.params.importTariff,17.123,'explicit tariff edit retained');assert.equal(edited.paths[0].target,35);
}
assert.equal(refs.openingYear,2023);assert.equal(refs.countries.ITA.latest.year,2025);assert.equal(refs.countries.ITA.latest.deficitGDP,3.1);assert.equal(refs.countries.DNK.latest.revenueGDP,null);assert.equal(refs.countries.CHN.latest.year,2024);assert(refs.countries.USA.latest.deficitGDP>7);
const ita=ps.find(x=>x.code==='ITA').params,f=FISCAL_ENGINE[ita.foreignPoolId];assert(capitalFiscalPolicy(ita,2024,f.opening).capitalExpense<f.opening.capitalExpenditure-3,'exceptional opening capital spending not repeated');
const settled=simulate({...ita,periods:8,burnIn:2},2026,{snapshots:false});assert.equal(settled.rows[0].calendarYear,2025);assert.equal(settled.rows[1].calendarYear,2026);assert.equal(settled.rows[1].fiscalCapitalExtrapolated,1);
const opening=new Economy(ita,2026).initialSnapshot();assert.equal(metricValue(opening,'publicDebtRatioChange'),null);
const menu=sortedMetricEntries(METRICS);assert.equal(menu.length,Object.values(METRICS).filter(v=>!v.hidden).length);for(let i=1;i<menu.length;i++)assert(menu[i-1][1].label.localeCompare(menu[i][1].label,'en',{sensitivity:'base',numeric:true})<=0,'alphabetical visible graph variables');
console.log('PASS: 30 empirical tariffs, preserved opening data, recipient accounting, dated capital policies, missing sources, saved-input migration, settling calendar and alphabetical graph menu.');

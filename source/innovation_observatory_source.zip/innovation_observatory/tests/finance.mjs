import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {simulate,runEnsemble} from '../dist/engine.mjs';
import {HouseholdMarket,issueClaim,payFirmOwners,repayBusinessDebt} from '../dist/finance.mjs';
import {simulationFindings} from '../dist/findings.mjs';
import {DEFAULTS,METRICS} from '../dist/parameters.mjs';

const profiles=JSON.parse(readFileSync(new URL('../research/frozen_engine_v1_16/profiles.json',import.meta.url)));
const italy=profiles.find(p=>p.code==='ITA').params;
const seed=2026;
const params={...italy,financialMarket:1,periods:8,replications:2,seed};
const close=(a,b,label)=>assert(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} versus ${b}`);
assert.equal(METRICS.output.label,'Real GDP');
assert.equal(METRICS.nominalOutput.label,'Nominal GDP');

const savers=[{cash:20},{cash:10}];
const market=new HouseholdMarket(savers,[10,10],{...DEFAULTS,marketDepositShare:100,ventureWeight:25,
  businessEquityWeight:25,corporateBondWeight:25,governmentBondWeight:25,foreignPortfolioWeight:0});
assert.equal(market.budget,10);
assert.equal(market.purchase('ventureEquity',3,true),null);
assert.deepEqual(savers.map(h=>h.cash),[20,10]);
for(const kind of ['ventureEquity','businessEquity','corporateBonds','governmentBonds']) {
  assert.deepEqual(market.purchase(kind,10),{amount:2.5,buyers:[2.5,0]});
  assert.equal(market.purchase(kind,1),null);
}
assert.deepEqual(savers.map(h=>h.cash),[10,10]);

const investors=[{cash:0,income:0,ownership:.25},{cash:0,income:0,ownership:.75}];
const firm={cash:20,loan:6,founderEquity:10};
issueClaim(firm,'ventureEquity',{amount:10,buyers:[10,0]});
issueClaim(firm,'corporateBonds',{amount:6,buyers:[2,4]});
payFirmOwners(investors,firm,8,(h,paid)=>{h.cash+=paid;h.income+=paid;});
assert.deepEqual(investors.map(h=>h.income),[5,3]);
assert.deepEqual(repayBusinessDebt(investors,firm,6),{bank:3,corporate:3});
assert.deepEqual(investors.map(h=>h.cash),[6,5]);
assert.deepEqual(investors.map(h=>h.income),[5,3]);

let maxFinanceResidual=0,maxSavingResidual=0,years=0;
function reconcile(rows) {
  for(let year=1;year<rows.length;year++) {
    const r=rows[year],previous=rows[year-1];
    const delta=key=>r[key]-previous[key];
    close(r.nationalSaving,r.householdSaving+r.firmSaving+r.bankSaving+r.publicSaving,'Sum of sector saving');
    close(r.nationalSaving-r.grossInvestment,r.currentAccount,'Saving less investment');
    close(r.currentAccount,r.nominalExports-r.nominalImports+r.foreignAssetIncome,'Current account and trade/income');
    close(delta('netForeignPosition'),r.currentAccount+r.foreignAssetValuation,'External transactions and valuation');
    close(delta('privateMoney'),delta('loans')+delta('bankPublicDebt')-delta('bankEquity')
      -delta('governmentDeposits')+delta('bankNetForeignPosition'),'Bank money and claims');
    close(delta('loans'),r.businessCreditIssued-r.businessLoanRepayments-r.exitLoanRepayments-r.loanWriteoffs,'Bank loans');
    close(delta('householdPublicDebt'),r.householdBondPurchases-r.publicBondRedemptionsToHouseholds,'Public bonds held by households');
    close(delta('householdCorporateBonds'),r.corporateBondsIssued-r.corporateBondRepayments-r.corporateBondWriteoffs,'Corporate bond face value');
    close(delta('householdVentureEquity'),r.ventureFunding-r.ventureEquityRetired,'Venture claims');
    close(delta('householdBusinessEquity'),r.businessEquityIssued-r.businessEquityRetired,'Existing business shares');
    close(delta('householdDeposits'),r.householdSaving-r.startupFunding-r.householdBondPurchases-r.businessEquityIssued
      -r.corporateBondsIssued-r.foreignAssetPurchases+r.publicBondRedemptionsToHouseholds+r.corporateBondRepayments+r.corporateBondRecoveries+r.liquidationDistributions,'Household deposits');
    close(r.marketPurchases,r.ventureFunding+r.businessEquityIssued+r.corporateBondsIssued+r.marketGovernmentFunding+r.foreignAssetPurchases,'Market orders executed');
    assert(r.marketPurchases<=r.marketBudget+1e-8);
    assert(r.corporateBondInterest<=(previous.householdCorporateBonds+r.corporateBondsIssued)*r.effectiveLoanRate/100+1e-8);
    maxFinanceResidual=Math.max(maxFinanceResidual,r.financeResidual);
    maxSavingResidual=Math.max(maxSavingResidual,Math.abs(r.savingIdentityResidual)/Math.max(1,r.nominalOutput));
    years++;
  }
}
const open=simulate(params,seed).rows;
const liquid=simulate({...params,marketDepositShare:0},seed).rows;
assert.deepEqual(open[0],liquid[0]);
assert(open[1].ventureFunding>0&&open[1].businessEquityIssued>0&&open[1].corporateBondsIssued>0&&open[1].marketGovernmentFunding>0);
assert(liquid.every(row=>row.marketPurchases===0&&row.householdBondPurchases===0&&row.startupFunding===0));
assert(liquid.some(row=>row.bankBondPurchases>0));

const timing=simulate({...params,financialMarket:0},seed,{paths:[{key:'financialMarket',start:1,end:2,target:1,mode:'pulse'}]}).rows;
assert.deepEqual(timing.slice(0,3),open.slice(0,3));
assert(timing.slice(3).every(r=>r.financialMarketActive===0&&r.marketPurchases===0));
assert(timing[3].householdCorporateBonds>0&&timing[3].corporateBondInterest>0);
for(const rows of [open,liquid,timing])reconcile(rows);

let writeoffs=0,recoveries=0,closures=0;
for(const profile of profiles)for(const stressSeed of [seed,9945]){
  const {rows}=simulate({...profile.params,periods:40,financialMarket:1,tradeEnabled:1,
    policyDynamics:1,currencyDynamics:1},stressSeed,
    {shocks:[{type:'credit',start:4,duration:4,magnitude:-90,recovery:.4}]});
  reconcile(rows);
  writeoffs+=rows.reduce((n,r)=>n+r.corporateBondWriteoffs,0);
  recoveries+=rows.reduce((n,r)=>n+r.corporateBondRecoveries,0);
  closures+=rows.reduce((n,r)=>n+r.businessEquityRetired+r.ventureEquityRetired,0);
}
assert(writeoffs>0&&recoveries>0&&closures>0);
assert(maxFinanceResidual<1e-8&&maxSavingResidual<1e-8);
const result=runEnsemble({params,reference:{...params,financialMarket:0}});
assert(simulationFindings(result).findings.some(line=>line.includes('venture capital')));
assert(simulationFindings(result).findings.some(line=>line.includes('corporate bonds')));
console.log(JSON.stringify({status:'PASS',profileStressPaths:56,years,maxFinanceResidual,maxSavingResidual}));

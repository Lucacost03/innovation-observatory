import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {simulate} from '../dist/engine.mjs';
import {DEFAULTS} from '../dist/parameters.mjs';
import {validateShocks,shockValues} from '../dist/shocks.mjs';

const profiles=JSON.parse(readFileSync(new URL('../research/frozen_engine_v1_16/profiles.json',import.meta.url)));
const italy=profiles.find(p=>p.code==='ITA').params;
const seed=2026;
const params={...italy,periods:8};
const close=(a,b,label)=>assert(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} versus ${b}`);
for(const key of ['policyDynamics','currencyDynamics','tradeEnabled','financialMarket'])assert.equal(DEFAULTS[key],1);
const baseline=simulate(params,seed).rows;
for(const key of ['policyDynamicsActive','currencyDynamicsActive','tradeActive','financialMarketActive'])assert.equal(baseline[1][key],1);
assert(baseline.slice(1).every(r=>r.exports>0&&r.imports>0));

const shock=(type,magnitude,start=3,duration=2,recovery=0)=>({type,magnitude,start,duration,recovery});
const scheduled=validateShocks([shock('policyRate',1,3,2,.5)]);
assert.deepEqual([2,3,4,5,6].map(t=>shockValues(t,scheduled).policyRate),[0,1,1,.5,.25]);
assert.throws(()=>validateShocks([shock('policyRate',16)]),/Invalid shock/);
const fixed={...params,policyDynamics:0,currencyDynamics:0};
const fixedPath=simulate(fixed,seed,{shocks:scheduled}).rows;
close(fixedPath[3].policyRate,fixed.initialPolicyRate+1,'Policy shock starts in year 3');
close(fixedPath[4].policyRate,fixedPath[3].policyRate,'Policy shock is constant during its duration');
close(fixedPath[5].policyRate,fixed.initialPolicyRate+.5,'Policy shock decays without compounding');
const fx=simulate(fixed,seed,{shocks:[shock('exchangeRate',-10)]}).rows;
assert(fx[3].currencyStrength<100);
assert.equal(fx[5].currencyStrength,100);
const positive=simulate(params,seed,{shocks:[shock('foreignDemand',40)]}).rows;
const negative=simulate(params,seed,{shocks:[shock('foreignDemand',-40)]}).rows;
assert.deepEqual(positive.slice(0,3),baseline.slice(0,3));
assert.deepEqual(negative.slice(0,3),baseline.slice(0,3));
assert(positive[3].exportOrders>baseline[3].exportOrders&&negative[3].exportOrders<baseline[3].exportOrders);

const withTaxes={...params,financialIncomeTax:18,wealthTax:1.25,foreignPortfolioWeight:20,
  initialHouseholdForeignAssets:5};
const rows=simulate(withTaxes,seed,{shocks:[shock('exchangeRate',-10)]}).rows;
for(let year=1;year<rows.length;year++){
  const r=rows[year],prev=rows[year-1];
  const taxableIncome=r.householdDepositInterest+r.governmentInterestToHouseholds+r.corporateBondInterest+
    r.firmDividends+r.bankDividends+r.foreignAssetIncome;
  const taxableWealth=prev.householdDeposits+prev.householdPublicDebt+prev.householdCorporateBonds+
    prev.householdVentureEquity+prev.householdBusinessEquity+prev.householdForeignAssets;
  close(r.householdDepositInterest,prev.householdDeposits*r.householdDepositRate/100,'Household interest on opening deposits');
  close(r.firmDepositInterest,prev.firmDeposits*r.firmDepositRate/100,'Business interest on opening deposits');
  close(r.financialIncomeTaxPaid,taxableIncome*withTaxes.financialIncomeTax/100,'Financial income withholding');
  assert(r.wealthTaxPaid>0&&r.wealthTaxPaid<=taxableWealth*withTaxes.wealthTax/100+1e-8);
  close(r.wageWithholding,r.wages*withTaxes.incomeTax/100,'Worker income tax');
  close(r.bankSaving,r.loanInterest+r.governmentInterestToBank-r.bankDividends-
    r.householdDepositInterest-r.firmDepositInterest,'Bank saving');
  close(r.nationalSaving-r.grossInvestment,r.currentAccount,'Saving less investment');
  close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+
    r.nominalExports-r.nominalImports,'Nominal expenditure');
  assert(r.exports>0&&r.imports>0&&r.financeResidual<1e-8);
}
console.log('PASS: all four default rules, signed shocks and recovery, deposit interest, tax bases and combined accounting.');

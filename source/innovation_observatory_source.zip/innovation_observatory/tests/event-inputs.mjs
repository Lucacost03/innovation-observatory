import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {simulate as archived} from '../research/frozen_engine_v1_18_1/engine.mjs';
import {simulate,validateTimeline,effectiveParameters} from '../dist/engine.mjs';
import {validateShocks,shockValues,SHOCK_TYPES} from '../dist/shocks.mjs';
import {openingEventDraft,selectEventExample,newEvent,EFFECT_DEFAULTS,shocksFromEvents,effectDescription} from '../dist/event-schedule.mjs';
import {experimentInputs,pathDetails,effectSummary} from '../dist/scenario-inputs.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';
import {MODEL_VERSION,sanitize} from '../dist/parameters.mjs';

const read=name=>JSON.parse(fs.readFileSync(new URL('../'+name,import.meta.url)));
const profiles=read('dist/data/profiles.json'),italy=sanitize(profiles.find(x=>x.code==='ITA').params);
const close=(a,b,label)=>assert(Math.abs(a-b)<=1e-9*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} vs ${b}`);

// Missing values must not silently become a zero intervention.
const shock={type:'demand',start:4,duration:2,magnitude:10,recovery:.5};
const path={key:'netMigrationRate',start:4,end:4,target:0,mode:'step'};
let invalidCases=0;
for(const value of ['', '  ', null, false, true, NaN, Infinity, -Infinity, [], {}]){
 for(const field of ['magnitude','recovery']){assert.throws(()=>validateShocks([{...shock,[field]:value}]));invalidCases++;}
 assert.throws(()=>validateTimeline([{...path,target:value}]));invalidCases++;
}
assert.equal(validateShocks([{...shock,magnitude:0,recovery:0}])[0].magnitude,0);
assert.equal(validateShocks([{...shock,magnitude:'0',recovery:'0'}])[0].recovery,0);
assert.equal(validateTimeline([path])[0].target,0);
assert.equal(validateTimeline([{...path,target:'0'}])[0].target,0);
assert(effectDescription('demand','').includes('Enter a numerical'));
assert(pathDetails({...path,target:''},italy).effects.includes('—'));

// A named parameter-based example opens its real assumptions, without an unrelated shock.
const education=[{key:'publicEducationQuality',start:4,end:4,target:1.5,mode:'step'},
 {key:'privateEducationQuality',start:4,end:4,target:1.5,mode:'step'}];
const draft=openingEventDraft([],40,true);assert.deepEqual(draft,{events:[],exampleLoaded:false});
const descriptions=experimentInputs(italy,education,[]);assert.equal(descriptions.length,2);
assert(descriptions.every(x=>x.effects.includes('1.5')&&x.timing.includes('4')&&x.assumption.length>20));
assert.equal(effectiveParameters(italy,3,education).publicEducationQuality,1);
assert.equal(effectiveParameters(italy,4,education).publicEducationQuality,1.5);

// Selecting a positive example replaces the untouched negative example draft.
const empty=openingEventDraft([],40);assert(empty.exampleLoaded);
const production=selectEventExample(empty.events,40,'production',true);
assert.equal(production.length,1);assert.equal(production[0].name,'Production boost');
const selected=shocksFromEvents(production),active=shockValues(4,selected);
assert.equal(active.supply,1.1);assert.equal(active.demand,1);assert.equal(active.credit,1);
assert(effectSummary(production[0]).includes('+10 %'));
const explicitCombination=selectEventExample(empty.events,40,'production',false);
assert.equal(explicitCombination.length,2); // Explicitly kept/edited events still combine.
assert.equal(shockValues(4,shocksFromEvents(explicitCombination)).demand,.8);

// Saved zero values remain intentional; restoring an example is an explicit action.
const zero=[{...shock,magnitude:0,eventId:'saved',eventName:'Economic downturn'}];
assert.equal(openingEventDraft(zero,40).events[0].effects[0].magnitude,0);
for(const example of ['custom','downturn','production','exports','innovation']){
 const event=newEvent([],40,example);
 assert(event.effects.every(effect=>Number.isFinite(effect.magnitude)&&effect.magnitude!==0));
 assert(effectSummary(event).length>10);
 assert(experimentInputs(italy,[],shocksFromEvents([event])).every(input=>input.effects&&input.timing&&input.assumption));
}
for(const [type,definition] of Object.entries(SHOCK_TYPES)){
 assert(EFFECT_DEFAULTS[type]!==0&&EFFECT_DEFAULTS[type]>=definition.min&&EFFECT_DEFAULTS[type]<=definition.max);
}

const saved={modelVersion:'1.18.0',country:'ITA',params:{...italy,governmentShare:12,periods:24},reference:italy,
 paths:education,shocks:selected,preset:'custom',referenceLabel:'My pinned reference'};
const restored=restoreConfiguration(saved,profiles);
assert(restored.migrated&&!restored.rebuildPreset);
assert.equal(restored.state.params.governmentShare,12);assert.equal(restored.state.referenceLabel,'My pinned reference');
assert.deepEqual(restored.state.paths,education);assert.deepEqual(restored.state.shocks,selected);

// Executed pre-change fingerprints distinguish faithful input fixes from economic tuning.
const before=read('research/event_inputs_before.json');
let paths=0,years=0,maxResidual=0;
for(const entry of before.cases){
 const run=simulate(entry.params,entry.seed,entry.options);paths++;years+=run.rows.length-1;
 const hash=crypto.createHash('sha256').update(JSON.stringify(archived(entry.params,entry.seed,entry.options).rows)).digest('hex');
 assert.equal(hash,entry.rows,entry.country+' valid inputs keep every numerical output');
 for(const row of run.rows.slice(1)){
  close(row.nationalSaving-row.grossInvestment,row.currentAccount,'S-I=CA');
  close(row.netForeignAssetChange,row.currentAccount,'NFA=CA');
  close(row.labourIncome+row.grossCapitalIncome+row.netProductionTaxes,row.nominalOutput,'income GDP');
  maxResidual=Math.max(maxResidual,row.relativeResidual);
 }
}
const comparison=[];
for(const code of ['ITA','DEU','EU27'])for(const seed of [2026,9945]){
 const params={...profiles.find(x=>x.code===code).params,periods:20};
 const correct=simulate(params,seed,{shocks:selected});
 const unintended=simulate(params,seed,{shocks:shocksFromEvents(explicitCombination)});
 paths+=2;years+=40;
 comparison.push({country:code,seed,selectedSupplyOnlyGDP:correct.rows.at(-1).output,
  unintendedDownturnPlusSupplyGDP:unintended.rows.at(-1).output});
 for(const run of [correct,unintended])for(const row of run.rows.slice(1))maxResidual=Math.max(maxResidual,row.relativeResidual);
}
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,maxResidual,
 fingerprintEngine:'1.18.1 archived: current engine intentionally changes monetary policy and CPI',unchangedPaths:before.cases.length,invalidCasesRejected:invalidCases,comparison,
 checks:['Blank/null/boolean values are rejected; explicit numerical zero remains valid.',
 'Parameter-only presets show actual target values and timing without an unrelated default downturn.',
 'Selecting a positive example replaces an untouched default example; explicitly combined events still combine.',
 'All examples and added channels have nonzero initial values and readable effect/assumption descriptions.',
 '1.18.0 edited settings, parameter paths, named events and pinned references survive patch migration.',
 'All 56 valid pre-change paths retain exactly the same complete numerical rows; current accounting identities reconcile.'],
 scope:'Input accuracy and presentation correction. The comparison measures unintended versus intended assumptions, not empirical forecast error. No behavioral coefficient changed and no forecasting accuracy gain is established.'};
fs.writeFileSync(new URL('../dist/data/event_input_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));

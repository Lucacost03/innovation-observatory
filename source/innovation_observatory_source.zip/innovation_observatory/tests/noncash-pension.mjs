import fs from'node:fs';import assert from'node:assert/strict';import{Economy}from'../dist/engine.mjs';
const p={...JSON.parse(fs.readFileSync(new URL('../dist/data/profiles.json',import.meta.url))).find(p=>p.code==='USA').params,wealthTax:1};
const a=new Economy(p,2026),b=new Economy(p,2026);b.gov.pensionLiability=100;b.households[0].publicPensionClaim=100;
const ar=a.step(1,1),br=b.step(1,1);assert(Math.abs(ar.wealthTaxPaid-br.wealthTaxPaid)<1e-10);assert(Math.abs(ar.output-br.output)<1e-10);assert(Math.abs(b.households.reduce((s,h)=>s+(h.publicPensionClaim??0),0)-b.gov.pensionLiability)<1e-8);
console.log('PASS: matched noncash public pension claims are excluded from the wealth-tax cash base, consistently with funded pension claims.');

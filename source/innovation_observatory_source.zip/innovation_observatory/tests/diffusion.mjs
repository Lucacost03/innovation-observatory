import fs from 'node:fs';
import assert from 'node:assert/strict';
import {simulate,runEnsemble,runSensitivity,adoptKnowledge,comparisonSettings,decomposeTechnology,uniform,quantile} from '../dist/engine.mjs';
import {DEFAULTS, MODEL_VERSION} from '../dist/parameters.mjs';
const root=new URL('../',import.meta.url),ps=JSON.parse(fs.readFileSync(new URL('dist/data/profiles.json',root)));
const close=(a,b)=>assert(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(a),Math.abs(b)),`${a} != ${b}`);
let currentRuns=0;
const run=(p,seed,o={})=>{currentRuns++;return simulate(p,seed,o);};
for(let i=0;i<1000;i++){
 const a=.2+3*uniform(312,i,1),target=.2+3*uniform(312,i,2),low=uniform(312,i,3),high=low+(1-low)*uniform(312,i,4);
 assert(adoptKnowledge(a,target,high)>=adoptKnowledge(a,target,low)-1e-12);
 assert(adoptKnowledge(a,target,low)>=a);assert(adoptKnowledge(a,target,high)<=Math.max(a,target)+1e-12);
}
const composition=decomposeTechnology([{a:2,capital:9,initialWeight:.5},{a:1,capital:1,initialWeight:.5}],
 [{a:2.1,capital:1,initialWeight:.5},{a:1.5,capital:9,initialWeight:.5}]);
assert(composition.withinFirmPercent>0&&composition.reallocationPercent<0&&composition.totalPercent<0);
close(composition.totalPercent,100*(1.56/1.9-1));
const paths=[{key:'diffusion',start:8,end:16,target:.16,mode:'ramp'}];
for(const code of ['ITA','EU27','DEU']){
 const p={...DEFAULTS,...ps.find(p=>p.code===code).params,innovationEfficiency:0,firmDynamics:0,foreignContact:0};
 for(let i=0;i<10;i++){
  const seed=2026+i*7919,b=run(p,seed,{snapshots:true}),s=run(p,seed,{snapshots:true,paths});
  for(let t=0;t<b.rows.length;t++){assert(s.rows[t].knowledge>=b.rows[t].knowledge-1e-10);
   for(let j=0;j<p.firms;j++)assert(s.agents[t][j].a>=b.agents[t][j].a-1e-10);}
 }
}
const same={...DEFAULTS,...ps.find(p=>p.code==='EU27').params,replications:2};
assert.equal(comparisonSettings({...same,diffusion:.01},same,[{key:'diffusion',start:8,end:16,target:.02,mode:'ramp'}]).adoptionDirection,'lower');
assert(!comparisonSettings({...same,rdBusiness:0},same,paths).isolatedAdoptionComparison);
const matched=runEnsemble({params:same,reference:same,paths});currentRuns+=4;
for(const row of matched.diagnostics.localDirectEffect)assert(row.low>=-1e-10);
close(matched.diagnostics.firstSeed.totalPercent,matched.paired[0].technology);
const after={counts:{pairs:0,negativeGDP:0,negativeTechFinal:0,negativeTechAny:0,negativeFixedKnowledgeFinal:0},countries:[],negativeExample:null},sensitivity=[],all=[];
for(const pr of ps){
 const p={...DEFAULTS,...pr.params},effects=[];
 for(let i=0;i<5;i++){
  const seed=2026+i*7919,b=run(p,seed),s=run(p,seed,{paths});after.counts.pairs++;
  const z=b.rows.at(-1),x=s.rows.at(-1),effect={country:pr.code,seed,gdp:100*(x.output/z.output-1),technology:100*(x.technology/z.technology-1),knowledge:100*(x.knowledge/z.knowledge-1)};
  effects.push(effect);all.push(effect);
  if(effect.gdp<0)after.counts.negativeGDP++;if(effect.technology<0)after.counts.negativeTechFinal++;
  if(effect.knowledge<0)after.counts.negativeFixedKnowledgeFinal++;
  if(s.rows.some((x,t)=>x.technology<b.rows[t].technology-1e-10))after.counts.negativeTechAny++;
  if(!after.negativeExample&&effect.gdp<0){
   const contributions=Object.fromEntries(['consumption','government','investment','inventoryChange'].map(k=>[k,x[k]-z[k]]));
   contributions.netExports=(x.exports-x.imports)-(z.exports-z.imports);
   close(Object.values(contributions).reduce((a,b)=>a+b,0),x.output-z.output);
   after.negativeExample={...effect,baselineGDP:z.output,scenarioGDP:x.output,componentDifferences:contributions};
  }
 }
 after.countries.push({country:pr.code,negativeGDP:effects.filter(x=>x.gdp<0).length,negativeTechnology:effects.filter(x=>x.technology<0).length,
  gdpMedian:quantile(effects.map(x=>x.gdp),.5),technologyMedian:quantile(effects.map(x=>x.technology),.5),knowledgeMedian:quantile(effects.map(x=>x.knowledge),.5)});
 if(['ITA','EU27','DEU'].includes(pr.code)){
  const result=runSensitivity({params:{...p,replications:2},reference:p,paths});currentRuns+=result.simulations;
  sensitivity.push({country:pr.code,...result});
 }
}
const previous=JSON.parse(fs.readFileSync(new URL('research/frozen_v1_2/diffusion_audit.json',root)));
const audit={modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),status:'PASS: mechanical checks; empirical causal effects unvalidated',
 currentEngineRuns:currentRuns,previousEngineCompatibilityRuns:0,previousReproductionRuns:0,
 mechanicalChecks:['1000 same-state adoption comparisons are nonnegative, bounded and monotone.',
  'With innovation, turnover and foreign contact disabled, faster domestic diffusion weakly raises each firm’s knowledge in 30 paired paths.',
  'Technology decomposition includes surviving IDs, reallocation, entry and exit; the total matches the displayed technology difference.',
  'The effective-rate comparison detects lower adoption or other edits.',
  'Three representative presets retain every outcome of eight predeclared assumption specifications, with two paired seeds each.'],
 protocol:'28 presets × 5 common seeds × 40 steps; diffusion 0.08 → 0.16 over steps 8–16 with the new baseline mechanisms enabled. Not a historical forecast.',
 previousVersion:previous.updatedVersion,previousVersionNote:'Archived 1.2 audit used a different mechanism set and seed count; not a matched before/after performance comparison.',
 updatedVersion:after,allPairs:all,empiricalStatus:'No causal innovation/diffusion coefficient estimated. Original-cohort knowledge freezes at exit and excludes entrants. Active technology includes selection.'};
fs.writeFileSync(new URL('dist/data/diffusion_audit.json',root),JSON.stringify(audit,null,2));
fs.writeFileSync(new URL('dist/data/assumption_sensitivity.json',root),JSON.stringify({modelVersion:MODEL_VERSION,protocol:'Eight predeclared specifications × 2 paired seeds × Italy/EU27/Germany; illustrative values, not estimated bounds or model selection.',results:sensitivity},null,2));
console.log(JSON.stringify({status:audit.status,currentEngineRuns:currentRuns,counts:after.counts,negativeExample:after.negativeExample},null,2));

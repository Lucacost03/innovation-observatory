import fs from 'node:fs';
import assert from 'node:assert/strict';
import {Economy,simulate} from '../research/frozen_engine_v1_26/engine.mjs';
import {simulate as previousSimulate} from '../research/frozen_engine_v1_25/engine.mjs';
import {DEFAULTS,MODEL_VERSION,sanitize,metricValue} from '../research/frozen_engine_v1_26/parameters.mjs';
import {AgeCohorts} from '../dist/age-cohorts.mjs';
import {issueForeignSovereign,redeemForeignSovereign,sovereignForeignTotal} from '../dist/sovereign-foreign.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';
import {growthDiagnostics} from '../dist/dynamics-diagnostics.mjs';
import {sectorYear,sectorOverview} from '../dist/sector-view.mjs';
const read=p=>JSON.parse(fs.readFileSync(new URL('../'+p,import.meta.url)));
const profiles=read('research/frozen_engine_v1_26/profiles.json'),prior=read('research/dynamics_audit_1_26/prior_parameters_1_25.json'),age=read('dist/data/age_cohorts_2023.json').countries,foreign=read('dist/data/foreign_sovereign_2023.json').countries,fiscal=read('dist/data/fiscal_benchmarks.json').countries,macro=read('dist/data/macro_external_benchmarks.json').countries,gdp=read('research/source_snapshots/gdp_growth_2024_25.json'),extra=read('research/trade_bid_candidates/us_china_gdp_observations.json');
const sum=x=>x.reduce((s,x)=>s+x,0),close=(a,b,label,t=1e-8)=>assert(Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=t*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} / ${b}`);
let paths=0,years=0,maxResidual=0,replayedValues=0;const scores=[],longRuns=[],seeds=[2026,9945,17864];
function observedGDP(p,year){const a=extra.observations.find(x=>x.country===p.code&&x.year===year);if(a)return a.realGDPGrowthPct;const q={freq:'A',unit:'CLV_PCH_PRE',na_item:'B1GQ',geo:p.geo,time:String(year)};if(gdp.id.some(k=>gdp.dimension[k].category.index[q[k]]==null))return null;return gdp.value[gdp.id.reduce((n,k,i)=>n*gdp.size[i]+gdp.dimension[k].category.index[q[k]],0)]??null;}
function check(run,label){paths++;years+=run.rows.length-1;for(let t=0;t<run.rows.length;t++){
 const r=run.rows[t];assert(Object.values(r).every(Number.isFinite),label+' finite');maxResidual=Math.max(maxResidual,r.relativeResidual,r.financeResidual);assert(r.relativeResidual<1e-8&&r.financeResidual<1e-8,label+' accounts');
 close(r.publicDebt,r.householdPublicDebt+r.bankPublicDebt+r.centralBankBonds+r.foreignHeldGovernmentDebt,label+' sovereign holders');
 close(r.foreignHeldGovernmentDebt,r.foreignHeldGovernmentBonds+r.foreignHeldGovernmentOtherDebt+r.foreignHeldGovernmentUnallocatedDebt,label+' external debt instruments');
 close(r.nationalSaving-r.grossInvestment,r.currentAccount,label+' S-I=CA');close(r.currentAccount,r.nominalExports-r.nominalImports+r.foreignAssetIncome+r.bankForeignIncome+r.otherForeignIncome-r.governmentInterestToForeign,label+' CA components');
 close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+r.nominalExports-r.nominalImports,label+' GDP spending');
 close(r.childPopulation+r.workingAgePopulation+r.olderPopulation,r.populationIndex,label+' population groups');close(r.workingAgeShare,100*r.workingAgePopulation/r.populationIndex,label+' changing working-age share');
 if(r.factorIncomeSharesDefined)close(r.labourIncomeShare+r.capitalIncomeShare,100,label+' factor-income shares');
 assert(r.exports>0&&r.imports>0&&r.foreignAssetsAtCost>0&&r.foreignLiabilities>0,label+' gross foreign channels');
 if(t){const last=run.rows[t-1];close(r.netForeignAssets-last.netForeignAssets,r.currentAccount,label+' independent NFA transactions');close(r.populationIndex-last.populationIndex,r.births-r.deaths+r.netMigration,label+' population mass');close(r.publicCurrentRevenue-r.publicCurrentExpenditure,r.publicSaving,label+' public saving');
 const view=sectorYear({first:{scenario:run},context:{countryCode:label.split(':')[0]},paths:[]},'scenario',t),gov=sectorOverview(view,'government');close(gov.expenseTotal,r.publicCurrentExpenditure,label+' domestic/external government bridge');
 }
}growthDiagnostics(run);}
for(const profile of profiles){
 const p=sanitize({...profile.params,periods:40}),old=prior.find(x=>x.code===profile.code).params,opening=new Economy(p,2026).initialSnapshot(),f=foreign[profile.code];
 for(const[k,v]of Object.entries(profile.params))if(Object.hasOwn(DEFAULTS,k))close(p[k],v,profile.code+' source bounds '+k,1e-12);
 close(opening.populationMillions,age[profile.code].totalMillions,profile.code+' source population');close(opening.workingAgeShare,age[profile.code].workingAge15to64Share,profile.code+' source working age');close(opening.participationRate,p.initialParticipationRate,profile.code+' source participation');
 close(opening.publicTotalRevenue,fiscal[profile.code].opening.revenue-(fiscal[profile.code].opening.reportSalesNetting??0),profile.code+' complete source revenue');close(opening.publicTotalExpenditure,fiscal[profile.code].opening.expenditure-(fiscal[profile.code].opening.reportSalesNetting??0),profile.code+' complete source expense');
 if(f.totalForeignGovDebtGDP!=null)close(opening.foreignHeldGovernmentDebt,f.totalForeignGovDebtGDP,profile.code+' external public debt');else assert.equal(metricValue(opening,'foreignHeldGovernmentDebt'),null,'Missing EU27 external coverage is unavailable');
 // Legacy controls replay the independently saved published engine exactly.
 const legacy=simulate({...old,periods:3},2026,{snapshots:false}),saved=previousSimulate({...old,periods:3},2026,{snapshots:false});for(let t=0;t<4;t++)for(const[k,v]of Object.entries(saved.rows[t])){close(legacy.rows[t][k],v,profile.code+' frozen 1.25 '+k,1e-11);replayedValues++;}
 // The tax-denominator correction alone cannot alter wages, GDP or any later row.
 const measured=simulate({...old,incomeAccountingAlignment:1,periods:3},2026,{snapshots:false});close(measured.rows[0].wages,legacy.rows[0].wages,'Measurement leaves opening wages');close(measured.rows[0].output,legacy.rows[0].output,'Measurement leaves GDP');for(let t=1;t<4;t++)assert.deepEqual(measured.rows[t],legacy.rows[t]);
 const state={country:profile.code,modelVersion:'1.25.0',params:old,reference:old,paths:[{key:'retirementAge',target:70,start:5,end:5,mode:'step'}],shocks:[],preset:'custom'},restored=restoreConfiguration(state,profiles);assert.deepEqual(restored.state.paths,state.paths);close(restored.state.params.retirementAge,p.retirementAge,'New policy source default');assert.deepEqual(restoreConfiguration(restored.state,profiles).state,restored.state);
 const custom=restoreConfiguration({...state,params:{...old,retirementAge:63.25,rdBusiness:3.21,incomeTax:12.3}},profiles);close(custom.state.params.retirementAge,63.25,'Authored pension age');close(custom.state.params.rdBusiness,3.21,'Authored R&D');close(custom.state.params.incomeTax,12.3,'Authored tax');
 for(const seed of seeds){const a=previousSimulate({...old,periods:40},seed,{snapshots:false}),b=simulate(p,seed,{snapshots:false});paths++;years+=40;check(b,profile.code+':'+seed);
  longRuns.push({country:profile.code,seed,finalGDP:b.rows.at(-1).output,earlierFinalGDP:a.rows.at(-1).output,workingAgeShare0:b.rows[0].workingAgeShare,workingAgeShare40:b.rows.at(-1).workingAgeShare,foreignGovDebt40:b.rows.at(-1).foreignHeldGovernmentDebt,lowEmploymentYears:b.rows.filter(r=>r.employment<50).length,currencyBoundYears:b.rows.filter(r=>r.currencyStrength<=50.000001||r.currencyStrength>=199.999999).length,unpaidFiscalReceipts:sum(b.rows.map(r=>r.fiscalUnpaidRevenue)),unpaidForeignIncome:sum(b.rows.map(r=>r.unpaidForeignIncome)),...growthDiagnostics(b)});
  for(let t=1;t<=2;t++){const ga=observedGDP(profile,2024),gb=observedGDP(profile,2025),actual=t===1?ga:ga!=null&&gb!=null?100*(Math.sqrt((1+ga/100)*(1+gb/100))-1):null;scores.push({country:profile.code,seed,horizon:t,gdpObserved:actual,gdpEarlier:100*((a.rows[t].output/100)**(1/t)-1),gdpCandidate:100*((b.rows[t].output/100)**(1/t)-1),caObserved:macro[profile.code].recentCurrentAccountGDP[String(2023+t)]??null,caEarlier:a.rows[t].currentAccountGDP,caCandidate:b.rows[t].currentAccountGDP});}
 }
}
// Direct foreign principal operations are matched financial transactions, with no CA gift.
{
 const p=profiles.find(p=>p.code==='USA').params,e=new Economy(p,2026),nfa=()=>e.bank.netForeignPosition+sum(e.households.map(h=>h.foreignAssetCost))-sovereignForeignTotal(e),before=nfa(),cash=e.gov.cash;
 e.foreignFundingQuote={share:.4};close(issueForeignSovereign(e,10),4,'Foreign issue allocation');close(nfa(),before,'Issue NFA invariant');close(e.gov.cash,cash+4,'Issue cash');redeemForeignSovereign(e,2);close(nfa(),before,'Principal redemption NFA invariant');assert(e.check().relativeResidual<1e-8);
 const old=prior.find(p=>p.code==='USA').params,a=previousSimulate({...old,periods:2},2026,{snapshots:false}),b=simulate({...old,incomeAccountingAlignment:1,periods:2},2026,{snapshots:false});
 const correction=b.rows[0].labourIncomeShare-a.rows[0].labourIncomeShare;
 assert(correction>2.5&&correction<2.6,'Verified opening denominator contribution');
}
// A newborn stays below working age for 15 annual transitions; the oldest group remains open.
{
 const p=sanitize({...profiles.find(p=>p.code==='CHN').params,birthRate:0,deathRate:0,netMigrationRate:0}),c=new AgeCohorts(p);c.ages.fill(0);c.ages[0]=1;c.skills.fill(p.initialHumanCapital);c.update(p);
 for(let t=1;t<=14;t++)c.advance(p,[p.initialHumanCapital],{});close(c.working,0,'Newborn cannot work early');c.advance(p,[p.initialHumanCapital],{});close(c.working,1,'Age15 entry');
 c.ages.fill(0);c.ages[80]=1;c.advance(p,[p.initialHumanCapital],{});close(c.ages[80],1,'Observed China 80+ stays open');close(sum(c.ages.slice(81)),0,'No invented China age81-100 detail');
}
const policyExamples=[];
for(const code of ['USA','ITA','CHN','EU27','SWE']){
 const p=profiles.find(x=>x.code===code).params,a=simulate({...p,periods:12},2026,{snapshots:false}),path={key:'retirementAge',target:p.retirementAge+2,start:5,end:5,mode:'step'},b=simulate({...p,periods:12},2026,{snapshots:false,paths:[path]});check(b,code+':retirement');assert.deepEqual(a.rows.slice(0,5),b.rows.slice(0,5),'No future retirement-policy leakage');assert(b.rows[5].pensionEligiblePopulation<a.rows[5].pensionEligiblePopulation);assert(b.rows[5].laborForce>a.rows[5].laborForce);
 const fixed=simulate({...p,periods:6,populationDynamics:0},2026,{snapshots:false});fixed.rows.forEach(r=>close(r.populationIndex,100,'Fixed-population switch'));
 policyExamples.push({country:code,sourcePensionAge:p.retirementAge,year5ReferenceEligible:a.rows[5].pensionEligibleShare,year5ScenarioEligible:b.rows[5].pensionEligibleShare,year5ReferenceLabor:a.rows[5].laborForce,year5ScenarioLabor:b.rows[5].laborForce});
}
const error=(rows,m,key)=>{const x=rows.filter(r=>r[m+'Observed']!=null);return{independentCountryYears:new Set(x.map(r=>r.country+':'+r.horizon)).size,modelObservationPairs:x.length,MAE:sum(x.map(r=>Math.abs(r[m+key]-r[m+'Observed'])))/x.length,RMSE:Math.sqrt(sum(x.map(r=>(r[m+key]-r[m+'Observed'])**2))/x.length)}};
const score=rs=>Object.fromEntries(['gdp','ca'].map(m=>[m,{earlier:error(rs,m,'Earlier'),candidate:error(rs,m,'Candidate')}]));
const usaOld=previousSimulate({...prior.find(p=>p.code==='USA').params,periods:40},2026,{snapshots:false});
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,maxResidual,replayedValues,scoreCountries:score(scores.filter(r=>r.country!=='EU27')),scoreEU:score(scores.filter(r=>r.country==='EU27')),byCountry:Object.fromEntries(profiles.map(p=>[p.code,score(scores.filter(r=>r.country===p.code))])),policyExamples,priorUSA: growthDiagnostics(usaOld),longRuns,scores,rejectedTrial:read('research/dynamics_audit_1_26/opening_alignment_trial.json'),protocol:'All30 presets,3 paired seeds,40 annual steps. Published1.25 independent engine and inputs; GDP2024/25 and CA2024/25 retrospective diagnostics, previously examined revised observations, not holdout. No parameter fitted to future data. Individual countries pooled; overlapping EU27 reported separately.',checks:['All30 source population/working-age profiles, fiscal totals, foreign public debt coverage and source bounds checked.','Independently frozen1.25 replay and income-denominator-only ablation leave GDP and wages unchanged.','Population ages annually and balances births minus deaths plus migration; newborns do not work early; China80+ remains open.','Pension-age interventions preserve earlier rows and separate eligibility from activity. Empirical European older activity and retained ILOSTAT USA/China age-band estimates.','Foreign issuance/redemption preserve NFA; coupons enter CA once; domestic/external public-holder and expense bridges reconcile.','Independent annual NFA changes equal CA; national S-I=CA, GDP, income shares and all financial accounts reconcile.'],limitations:['The model is not an empirically validated forecast or business-cycle model. Long-run declines and extreme paths remain in the full report.','Mortality within broad age groups, future migration allocation, pension participation response and investor demand elasticities are unestimated assumptions. Statutory ages are dated representative references, not actual individual retirement ages or automatic reform forecasts.','EU27 opening extra-EU public holdings are unavailable; zero execution stock is labelled missing. USA observed Treasury subset and broad government debt have different scopes. No complete national IIP or capital-account transfers.','Accounting/definition corrections and requested structural mechanisms are supported separately from forecast accuracy. The unrelated opening-market-share trial was rejected because its retrospective GDP error worsened.']};
fs.writeFileSync(new URL('../dist/data/revision126_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,byCountry:undefined,longRuns:undefined,scores:undefined,rejectedTrial:undefined,priorUSA:undefined},null,2));

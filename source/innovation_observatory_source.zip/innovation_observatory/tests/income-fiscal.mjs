import assert from 'node:assert/strict';
import fs from 'node:fs';
import {simulate,Economy,quantile} from '../dist/engine.mjs';
import {simulate as previous} from '../research/frozen_engine_v1_15/engine.mjs';
import {redeemPublicBonds} from '../dist/fiscal.mjs';
import {incomeAccount} from '../dist/income-account.mjs';
import {issueClaim,payFirmOwners,publicEquityValue} from '../dist/finance.mjs';
import {transition} from '../dist/demography.mjs';
import {MODEL_VERSION} from '../dist/parameters.mjs';
const read=path=>JSON.parse(fs.readFileSync(new URL('../'+path,import.meta.url)));
const profiles=read('research/frozen_engine_v1_16/profiles.json'),benchmarks=read('dist/data/government_asset_benchmarks.json');
const oldProfiles=read('research/frozen_engine_v1_15/profiles.json');
const observations=read('dist/data/finance_validation.json').recent.legacy.predictions;
const close=(a,b,label='identity')=>assert(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} vs ${b}`);
const sum=(rows,key)=>rows.reduce((s,r)=>s+r[key],0),italy=profiles.find(p=>p.code==='ITA');

const gov={cash:25},bank={bonds:20,equity:12},hh=[{cash:5,bonds:10,income:3},{cash:5,bonds:20,income:4}];
const redemption=redeemPublicBonds(gov,bank,hh,10);
close(redemption.publicBondRedemptions,15);close(bank.bonds,14);close(hh[0].bonds,7);close(hh[1].bonds,14);
assert.deepEqual(hh.map(h=>h.income),[3,4]);close(hh[0].cash+hh[0].bonds,15);close(gov.cash,10);close(bank.equity,12);
const paidOff=redeemPublicBonds({cash:50},{bonds:5},[{cash:0,bonds:5,income:0}],0);close(paidOff.publicBondRedemptions,10);
const firm={capital:20,inventory:0,cash:10,loan:10,publicOwnership:.5,founderEquity:20};
close(publicEquityValue([firm]),10);
issueClaim(firm,'businessEquity',{amount:20,buyers:[20,0]});firm.cash+=20;
close(publicEquityValue([firm]),10,'Dilution preserves existing public claim at issue');
let publicPaid=0;const owners=[{cash:0,ownership:.5},{cash:0,ownership:.5}];
payFirmOwners(owners,firm,8,undefined,paid=>{publicPaid+=paid;});close(publicPaid,2);close(sum(owners,'cash')+publicPaid,8);
const income=incomeAccount(90,50,10,3,100);close(income.grossCapitalIncome,43);close(income.netProductionTaxes,7);
assert(incomeAccount(90,110,10,0,100).grossCapitalIncome<0);

// A floor-blocked failed firm is restructured once, then its exit flag clears.
const floor=new Economy({...italy.params,initialPublicEquity:0,entryRate:0,exitRate:0},2026);
floor.firms=floor.firms.slice(0,2);floor.links=[[1],[0]];
for(const f of floor.firms){f.forcedExit=true;f.cash=0;f.openingTechnology=f.a;}
const firstFloor=transition(floor,{...floor.p,entryRate:0,exitRate:0},1,1,()=>.99,1);
assert.equal(firstFloor.debtRestructurings,2);assert(floor.firms.every(f=>f.forcedExit===false));
const secondFloor=transition(floor,{...floor.p,entryRate:0,exitRate:0},2,2,()=>.99,1);
assert.equal(secondFloor.debtRestructurings,0);

let paths=0,years=0,maxResidual=0,maxIncomeResidual=0,redemptionYears=0;
function run(params,seed,options={}){
 const run=simulate(params,seed,options);paths++;
 for(let t=0;t<run.rows.length;t++){
  const r=run.rows[t];close(r.labourIncome+r.grossCapitalIncome+r.netProductionTaxes,r.nominalOutput,'Income GDP');
  close(r.labourIncome,r.wages,'Gross labour income');close(r.tfpLevel,100*r.productivity,'TFP level');
  assert(Number.isFinite(r.governmentPublicEquity+r.governmentEquityInLiquidation));
  assert(r.tfpLevel>=0&&r.governmentPublicEquity>=0&&r.governmentEquityInLiquidation>=0);
  maxIncomeResidual=Math.max(maxIncomeResidual,Math.abs(r.incomeGDPResidual));
  if(!t)continue;
  const before=run.rows[t-1];years++;
  close(r.publicDebt-before.publicDebt,r.bankBondPurchases+r.householdBondPurchases-r.publicBondRedemptions,'Public debt stock/flow');
  close(r.householdPublicDebt-before.householdPublicDebt,r.householdBondPurchases-r.publicBondRedemptionsToHouseholds,'Household bond stock');
  close(r.bankPublicDebt-before.bankPublicDebt,r.bankBondPurchases-r.publicBondRedemptionsToBank,'Bank bond stock');
  close(r.publicBondRedemptions,r.publicBondRedemptionsToBank+r.publicBondRedemptionsToHouseholds,'Redemption recipients');
  close(r.governmentDeposits-before.governmentDeposits,r.publicSaving+r.bankBondPurchases+r.householdBondPurchases-r.publicBondRedemptions-r.recap+r.governmentLiquidationProceeds,'Treasury ledger');
  close(r.nationalSaving-r.grossInvestment,r.currentAccount,'S-I=CA');close(r.netForeignAssetChange,r.currentAccount,'NFA transactions');
  close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+r.nominalExports-r.nominalImports,'Expenditure GDP');
  assert(r.publicDebt<1e-7||r.governmentDeposits<=r.treasuryCashTarget+1e-7);
  assert(r.publicBondRedemptions>=0&&r.governmentDeposits>=0);
  assert(r.financialExits+r.debtRestructurings===r.defaults,'Each formal default must close or restructure a firm');
  maxResidual=Math.max(maxResidual,r.relativeResidual,r.financeResidual,Math.abs(r.savingIdentityResidual)/Math.max(1,r.nominalOutput));
  redemptionYears+=Number(r.publicBondRedemptions>0);
 }
 return run;
}

const seeds=[2026,9945,17864];
const outcomes=[];
for(const profile of profiles){
 const opening=run({...profile.params,periods:8},2026).rows[0];
 close(opening.governmentDeposits,benchmarks[profile.code].governmentCashGDP,'Observed government cash');
 close(opening.governmentPublicEquity,benchmarks[profile.code].governmentEquityGDP,'Observed opening equity');
 for(const seed of seeds)for(const name of ['baseline','events']){
  const rows=run({...profile.params,periods:40},seed,name==='baseline'?{}:{paths:[{key:'importTariff',start:4,end:4,target:20,mode:'step'}],shocks:[{type:'demand',start:7,duration:4,magnitude:-40,recovery:.5},{type:'policyRate',start:9,duration:3,magnitude:6,recovery:.3}]}).rows;
  outcomes.push({code:profile.code,seed,name,defaults:sum(rows,'defaults'),restructurings:sum(rows,'debtRestructurings'),financialExits:sum(rows,'financialExits'),writeoffs:sum(rows,'loanWriteoffs'),bondsRepaid:sum(rows,'publicBondRedemptions'),dividends:sum(rows,'governmentFirmDividends'),finalGDP:rows.at(-1).output,finalDebtGDP:rows.at(-1).publicDebtGDP});
 }
}
const surplus=run({...italy.params,periods:12,incomeTax:75,profitTax:45,wealthTax:2,governmentShare:5,incomeSupport:2,unemploymentReplacement:0,publicResearch:0},2026).rows;
assert(surplus.some(r=>r.publicSaving>0&&r.publicBondRedemptions>0));assert(surplus.at(-1).publicDebt<surplus[0].publicDebt);
const distress=[];
for(const firmDynamics of [0,1])for(const seed of seeds){
 const result=run({...italy.params,periods:12,firmDynamics,loanSpread:20,defaultAfter:1,creditAvailability:.1},seed,{shocks:[{type:'demand',start:2,duration:10,magnitude:-90,recovery:0}]});
 const rows=result.rows;
 assert(sum(rows,'defaults')>0);assert(sum(rows,'loanWriteoffs')>0);
 if(firmDynamics===0)assert(sum(rows,'debtRestructurings')>0);else assert(sum(rows,'financialExits')>0);
 close(result.events.filter(e=>e.type==='restructuring').length,sum(rows,'debtRestructurings'),'Event log');
 distress.push({firmDynamics,seed,defaults:sum(rows,'defaults'),restructurings:sum(rows,'debtRestructurings'),financialExits:sum(rows,'financialExits'),lastYearDefaults:rows.at(-1).defaults});
}
const predictions=profiles.map(profile=>{
 const result={code:profile.code,observed:observations.find(r=>r.code===profile.code).observed};
 for(const [mode,fn,params]of [['before',previous,oldProfiles.find(p=>p.code===profile.code).params],['after',simulate,profile.params]]){
  const rows=seeds.map(seed=>fn({...params,periods:8},seed).rows[2]);paths+=seeds.length;years+=seeds.length*8;
  result[mode]={gdp:quantile(rows.map(r=>100*(Math.sqrt(r.output/100)-1)),.5),unemployment:quantile(rows.map(r=>r.unemployment),.5),inflation:quantile(rows.map(r=>r.inflation),.5)};
 }
 return result;
});
const errors=mode=>Object.fromEntries(['gdp','unemployment','inflation'].map(key=>{const a=predictions.filter(p=>p.code!=='EU27').map(p=>p[mode][key]-p.observed[key]);return[key,{rmse:Math.sqrt(a.reduce((s,v)=>s+v*v,0)/a.length),mae:a.reduce((s,v)=>s+Math.abs(v),0)/a.length}];}));
assert(maxResidual<1e-8);
const report={status:'PASS',modelVersion:MODEL_VERSION,featureScope:'Legacy fiscal-income mechanisms with new society channels off; current full-coverage checks are in society_validation.json',executedAt:new Date().toISOString(),paths,years,maxResidual,maxIncomeResidual,redemptionYears,
 openingPresets:profiles.length,checks:['Income and expenditure GDP reconcile, including taxes and subsidies; negative capital income is retained.','TFP level equals 100 times the existing normalized residual, not the firms’ latent knowledge index.','Opening treasury cash and equity match all 28 official source selections.','Surplus cash retires bonds pro rata without taxing principal or creating household income. Debt, treasury, household and bank ledgers reconcile.','Each formal default either closes or restructures a firm. Severe tests produce both channels and cumulative counts match event logs.','A failed firm kept by the population floor clears its exit flag after restructuring.'],
 surplusExample:{openingDebt:surplus[0].publicDebt,finalDebt:surplus.at(-1).publicDebt,bondsRepaid:sum(surplus,'publicBondRedemptions'),finalCash:surplus.at(-1).governmentDeposits},
 stress:{paths:outcomes.length,years:outcomes.length*40,pathsWithDefaults:outcomes.filter(r=>r.defaults>0).length,pathsWithRestructurings:outcomes.filter(r=>r.restructurings>0).length,pathsWithBondRedemption:outcomes.filter(r=>r.bondsRepaid>0).length,outcomes},distress,
 benchmark:{protocol:'Frozen engine 1.15 and current engine, original 2023 country inputs, three common seeds per preset, equal weights across 27 countries, previously examined 2025 observations. No coefficient selection from these scores. GDP growth annualized 2023-2025.',before:errors('before'),after:errors('after'),predictions},
 limitations:['The treasury liquidity target is a model cash-management assumption, calibrated to an observed opening stock ratio.','Government equity includes a broader observed portfolio than domestic public companies. It is mapped to firm book claims, with simulated dividends and valuation.','GDP income shares are accounting composition, not causal growth contributions. TFP is a within-economy model residual, not a comparable absolute PWT level.','Default probabilities and restructuring frequencies remain unestimated. Numerical floor restructurings are identified explicitly.']};
fs.writeFileSync(new URL('../dist/data/income_fiscal_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,stress:{...report.stress,outcomes:undefined},benchmark:{...report.benchmark,predictions:undefined}}));

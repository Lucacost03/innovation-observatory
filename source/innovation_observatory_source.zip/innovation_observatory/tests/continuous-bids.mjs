import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {simulate} from '../dist/engine.mjs';
import {MODEL_VERSION,sanitize} from '../dist/parameters.mjs';
import {clearGoodsMarket,tradeConditions} from '../dist/trade.mjs';
import {clearGoodsMarket as earlierMarket} from '../research/trade_bid_candidates/trade_v1_23.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';
const read=p=>JSON.parse(fs.readFileSync(new URL('../'+p,import.meta.url)));
const profiles=read('dist/data/profiles.json'),bench=read('dist/data/macro_external_benchmarks.json'),gdp=read('research/source_snapshots/gdp_growth_2024_25.json'),extra=read('research/trade_bid_candidates/us_china_gdp_observations.json');
const sum=x=>x.reduce((a,b)=>a+b,0),close=(a,b,label,t=1e-8)=>assert(Math.abs(a-b)<t*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} != ${b}`);
for(const f of read('research/trade_bid_candidates/manifest.json'))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(new URL('../research/trade_bid_candidates/'+f.file,import.meta.url))).digest('hex'),f.sha256);
function market(fn,bid,continuous=1,domesticDemand=100,stock=100,orders=100){const firms=[{inventory:.2*stock,share:.5},{inventory:.8*stock,share:.5}],r=fn(firms,domesticDemand,1,{exportBid:bid,exportOrders:orders,continuousForeignBids:continuous});close(sum(r.domesticSales)+sum(r.exportSales)+sum(firms.map(f=>f.inventory)),stock,'Market stock conservation');assert(firms.every(f=>f.inventory>=0));return{exports:sum(r.exportSales),domestic:sum(r.domesticSales),receipts:sum(r.exportReceipts)};}
// The old path is preserved against a separate frozen module, not itself.
for(const bid of [.65,.9,1,1.3])for(const stock of [0,1,100,1000])assert.deepEqual(market(clearGoodsMarket,bid,0,100,stock),market(earlierMarket,bid,0,100,stock));
const boundary=1/1.03,epsilon=1e-8,oldLow=market(earlierMarket,boundary-epsilon),oldHigh=market(earlierMarket,boundary+epsilon),newLow=market(clearGoodsMarket,boundary-epsilon),newHigh=market(clearGoodsMarket,boundary+epsilon);
const continuity={bidBoundary:boundary,perturbationEachSide:epsilon,oldExportJump:oldHigh.exports-oldLow.exports,newExportChange:newHigh.exports-newLow.exports};close(continuity.oldExportJump,22.5,'Old bracket jump');assert(Math.abs(continuity.newExportChange)<.0001);
for(const bid of [.65,1,1.3]){const r=market(clearGoodsMarket,bid,1,20,1000);close(r.exports,100,'Complete foreign order volume');close(r.receipts,100*(.1*Math.max(1.01,bid)+.9*bid),'Unrationed mean bid retained');}
// Independent dense buyer list verifies the continuous integral and priority.
const quadrature=[];
for(const [bid,demand,stock]of [[.9,100,100],[1,200,100],[1.3,100,10],[1.1,15,100],[.65,100,50],[1,0,60]]){
 const buyers=[{q:.1*100,bid:Math.max(1.01,bid),exported:true},{q:demand,bid:1,exported:false}];
 for(let i=0;i<20000;i++)buyers.push({q:.9*100/20000,bid:bid*(.865+.27*(i+.5)/20000),exported:true});buyers.sort((a,b)=>b.bid-a.bid);
 let remaining=stock,x=0,receipts=0;for(const buyer of buyers){const q=Math.min(buyer.q,remaining);if(buyer.exported){x+=q;receipts+=q*buyer.bid;}remaining-=q;}
 const r=market(clearGoodsMarket,bid,1,demand,stock);assert(Math.abs(r.exports-x)<.005);assert(Math.abs(r.receipts-receipts)<.008);quadrature.push({bid,demand,stock,quantityError:r.exports-x,receiptError:r.receipts-receipts});
}
function observedGDP(profile,year){const external=extra.observations.find(r=>r.country===profile.code&&r.year===year);if(external)return external.realGDPGrowthPct;const select={freq:'A',unit:'CLV_PCH_PRE',na_item:'B1GQ',geo:profile.geo,time:String(year)};if(gdp.id.some(k=>gdp.dimension[k].category.index[select[k]]==null))return null;const i=gdp.id.reduce((n,k,j)=>n*gdp.size[j]+gdp.dimension[k].category.index[select[k]],0);return gdp.value[i]??null;}
const seeds=[2026,9945,17864,25783,33702],scores=[],longRuns=[];let paths=0,years=0,maxResidual=0;
function check(run){paths++;years+=run.rows.length-1;for(let t=0;t<run.rows.length;t++){const r=run.rows[t];assert(Object.values(r).every(Number.isFinite));assert(r.relativeResidual<1e-8);maxResidual=Math.max(maxResidual,r.relativeResidual);assert(r.exports>0&&r.imports>0&&r.foreignAssetsAtCost>0&&r.foreignLiabilities>0);close(r.nationalSaving-r.grossInvestment,r.currentAccount,'S-I=CA');if(t){close(r.netForeignAssets-run.rows[t-1].netForeignAssets,r.currentAccount,'Independent NFA change');close(r.nominalExports,r.exports*r.exportPrice,'Exports quantity/receipts');}}}
for(const profile of profiles){
 assert.equal(profile.params.continuousForeignBids,1);assert.equal(profile.provenance.continuousForeignBids.status,'assumed');
 const p=sanitize(profile.params);assert.equal(tradeConditions(100,1,1,p).continuousForeignBids,1);
 for(const seed of seeds){const earlier=simulate({...p,periods:40,continuousForeignBids:0},seed,{snapshots:false}),candidate=simulate({...p,periods:40,continuousForeignBids:1},seed,{snapshots:false});check(earlier);check(candidate);
  const summary=run=>({finalGDP:run.rows.at(-1).output,finalCA:run.rows.at(-1).currentAccountGDP,lowEmploymentYears:run.rows.filter(r=>r.employment<50).length,currencyBoundYears:run.rows.filter(r=>r.currencyStrength<=50.000001||r.currencyStrength>=199.999999).length,foreignIncomeCashShortfall:sum(run.rows.map(r=>r.unpaidForeignIncome??0))});
  longRuns.push({country:profile.code,seed,earlier:summary(earlier),candidate:summary(candidate)});
  for(let t=1;t<=2;t++){const ga=observedGDP(profile,2024),gb=observedGDP(profile,2025),actual=t===1?ga:ga!=null&&gb!=null?100*(Math.sqrt((1+ga/100)*(1+gb/100))-1):null;const a=earlier.rows[t],b=candidate.rows[t];scores.push({country:profile.code,seed,horizon:t,caObserved:bench.countries[profile.code].recentCurrentAccountGDP[String(2023+t)],caEarlier:a.currentAccountGDP,caCandidate:b.currentAccountGDP,gdpObserved:actual,gdpEarlier:100*((a.output/100)**(1/t)-1),gdpCandidate:100*((b.output/100)**(1/t)-1)});}
 }
}
const errors=(rs,metric,kind)=>{const x=rs.filter(r=>r[metric+'Observed']!=null);return {modelObservationPairs:x.length,independentCountryYears:new Set(x.map(r=>r.country+':'+r.horizon)).size,MAE:sum(x.map(r=>Math.abs(r[metric+kind]-r[metric+'Observed'])))/x.length,RMSE:Math.sqrt(sum(x.map(r=>(r[metric+kind]-r[metric+'Observed'])**2))/x.length)};};
const score=rs=>Object.fromEntries(['ca','gdp'].map(metric=>[metric,{earlier:errors(rs,metric,'Earlier'),candidate:errors(rs,metric,'Candidate')}]));
const countries=score(scores.filter(r=>r.country!=='EU27')),aggregate=score(scores.filter(r=>r.country==='EU27'));
assert(countries.ca.candidate.MAE<countries.ca.earlier.MAE);assert(countries.gdp.candidate.RMSE<=countries.gdp.earlier.RMSE+.25);
// Source update preserves authored settings and timing; scheduled bid changes cannot leak.
{
 const profile=profiles.find(p=>p.code==='USA'),params={...profile.params,continuousForeignBids:0,rdBusiness:3.21,periods:12};
 const a=simulate(params,2026,{snapshots:false}),b=simulate(params,2026,{paths:[{key:'continuousForeignBids',target:1,start:5,end:5,mode:'step'}],snapshots:false});check(a);check(b);assert.deepEqual(a.rows.slice(0,5),b.rows.slice(0,5));
 const saved={country:'USA',modelVersion:'1.23.0',params,reference:params,paths:[{key:'importTariff',target:10,start:6,end:6,mode:'step'}],shocks:[],preset:'custom'},m=restoreConfiguration(saved,profiles);assert(!m.rebuildPreset);close(m.state.params.rdBusiness,3.21,'Authored RD retained');assert.deepEqual(m.state.paths,saved.paths);assert.equal(m.state.params.continuousForeignBids,0);assert.deepEqual(restoreConfiguration(m.state,profiles).state,m.state);
}
const longRunTotals=Object.fromEntries(['earlier','candidate'].map(k=>[k,{lowEmploymentYears:sum(longRuns.map(r=>r[k].lowEmploymentYears)),currencyBoundYears:sum(longRuns.map(r=>r[k].currencyBoundYears)),foreignIncomeCashShortfall:sum(longRuns.map(r=>r[k].foreignIncomeCashShortfall))}]));
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,maxResidual,continuity,quadrature,scoreCountries:countries,scoreEU:aggregate,byCountry:Object.fromEntries(profiles.map(p=>[p.code,score(scores.filter(r=>r.country===p.code))])),longRunTotals,longRuns,scores,
 decision:'Enabled for source presets. Continuous market clearing removes a large arbitrary bracket jump, modestly lowers retrospective CA error, and leaves near-term GDP accuracy effectively unchanged. Legacy brackets remain an explicit comparison setting. No coefficients or bid range were searched against future outcomes.',
 protocol:read('research/trade_bid_candidates/protocol.json'),
 limitations:['Revised2024/2025 observations and these comparisons have already been examined. This is not an untouched forecast test. Seed repeats are not independent historical observations.','Some individual-country errors increase. Long-run outcomes are mixed; low-employment years can increase and currency bounds remain. Neither version has validated long-run accuracy.','Bid dispersion, the uniform distribution and the10% repeat-customer block are assumptions. The bid interval extends half a typical old grid gap past the outer bracket centers; total orders and mean bids are unchanged.','USA/China GDP supplements use official web-table extractions with dates and coordinates; raw HTML was not retained. Current-account and GDP source vintages need not match exactly. No missing observation is invented.'],
 checks:['Frozen legacy-market comparison, goods conservation, full-order mean/volume preservation and independent dense buyer integration passed.','Continuity removes an arbitrary22.5-unit export jump from a100-unit order book under a tiny price perturbation.','All30presets x5seeds x2rules x40annual steps keep independent S-I=CA and annual transaction NFA identities, positive gross channels and finite accounting results.','Older authored controls/references and intervention timing are retained; future bid changes cannot affect prior periods.']};
fs.writeFileSync(new URL('../dist/data/trade_bid_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({...report,byCountry:undefined,longRuns:undefined,scores:undefined,quadrature:undefined,protocol:undefined}));

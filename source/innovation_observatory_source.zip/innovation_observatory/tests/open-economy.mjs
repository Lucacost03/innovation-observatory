import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {simulate, runEnsemble, uniform} from '../dist/engine.mjs';
import {learnForeign} from '../dist/foreign.mjs';
import {advanceMonetary, initializeMonetary} from '../dist/monetary.mjs';
import {sanitize} from '../dist/parameters.mjs';
import {simulationFindings} from '../dist/findings.mjs';

const root = new URL('../', import.meta.url);
const read = path => JSON.parse(readFileSync(new URL(path, root)));
const profiles = read('research/frozen_engine_v1_16/profiles.json');
const italy = profiles.find(profile => profile.code === 'ITA').params;
const params = sanitize({...italy, tradeEnabled:0,policyDynamics:0,currencyDynamics:0, periods:8, replications:2, seed:2026, foreignContact:.6, foreignTechDispersion:.3});
const close = (a,b) => assert(Math.abs(a-b) < 1e-9*Math.max(1,Math.abs(a),Math.abs(b)), `${a} differs from ${b}`);
for (const name of ['ecb_deposit_rate','bis_policy_rates','hicp_annual']) {
  const source = read('dist/data/official_data_manifest.json').find(entry => entry.name === name);
  assert.equal(createHash('sha256').update(readFileSync(new URL(source.path,root))).digest('hex'),source.sha256);
}
assert.equal(params.initialPolicyRate,4);
assert.equal(params.initialPolicyInflation,5.4);
assert.equal(profiles.find(profile => profile.code === 'SWE').params.initialPolicyRate,4);
assert.equal(profiles.find(profile => profile.code === 'HUN').params.initialPolicyRate,10.75);
assert.equal(profiles.find(profile => profile.code === 'BGR').provenance.initialPolicyRate.status,'proxy');

const adoption = {...params, foreignContact:1};
const samples = 20000;
function matches(benchmark) {
  const lagged = {USA:benchmark, CHN:benchmark, ROW:benchmark};
  let improvements=0, opportunity=0;
  for (let id=0;id<samples;id++) {
    const result = learnForeign(1,lagged,adoption,2026,1,id,uniform);
    opportunity += result.target;
    improvements += Number(result.gain>0);
    assert(result.gain>=0 && result.a>=1);
    assert.equal(result.tail,result.gain>0&&benchmark<=1);
  }
  assert(Math.abs(opportunity/samples-benchmark)<.01);
  return improvements;
}
const lower=matches(.85), higher=matches(1.15);
assert(lower>0 && lower<higher);

const on = {...params, policyDynamics:1, initialPolicyInflation:2, neutralPolicyRate:params.initialPolicyRate};
const opening = initializeMonetary(on);
const tight = advanceMonetary(opening,on,6), easy = advanceMonetary(opening,on,0);
assert(tight.policyRate>opening.policyRate && easy.policyRate<opening.policyRate);
assert(tight.effectiveLoanRate>opening.effectiveLoanRate && easy.effectiveLoanRate<opening.effectiveLoanRate);
assert(tight.investmentRateMultiplier<1 && easy.investmentRateMultiplier>1);
assert.equal(advanceMonetary(tight,{...on,policyDynamics:0},0).policyRate,tight.policyRate);

// A VAT increase raises this year's headline inflation. The rate can respond the following year.
const rule = {...on,priceDynamics:0};
const vat = {key:'consumptionTax',start:2,end:2,target:params.consumptionTax+5,mode:'step'};
const noVat = simulate(rule,2026).rows;
const withVat = simulate(rule,2026,{paths:[vat]}).rows;
assert.equal(withVat[2].policyRate,noVat[2].policyRate);
assert(withVat[3].policyRate>noVat[3].policyRate);
assert.equal(withVat[3].policyInflationSignal,withVat[2].inflation);

const fx = {...params,priceDynamics:0,currencyDynamics:1,currencyAdjustment:1,currencyRateResponse:0};
const shock = target => [{key:'currencyPressure',start:2,end:2,target,mode:'step'}];
const flat = simulate(fx,2026).rows;
const weak = simulate(fx,2026,{paths:shock(-20)}).rows;
const strong = simulate(fx,2026,{paths:shock(20)}).rows;
assert.deepEqual(weak.slice(0,2),flat.slice(0,2));
assert(weak[2].currencyStrength<100 && strong[2].currencyStrength>100);
assert(weak[2].inflation>flat[2].inflation && strong[2].inflation<flat[2].inflation);
assert(weak[2].effectiveForeignContact<flat[2].effectiveForeignContact && flat[2].effectiveForeignContact<strong[2].effectiveForeignContact);
const contacts = row => row.foreignContactsUSA + row.foreignContactsCHN + row.foreignContactsROW;
assert(contacts(weak[2])<=contacts(flat[2]) && contacts(flat[2])<=contacts(strong[2]));
close(weak[3].inflation,0);
assert(weak[3].effectiveForeignContact<flat[3].effectiveForeignContact);

let maxResidual=0;
let tailAdoptions=0;
for (const profile of profiles) for (const seed of [2026,9945]) {
  const config = {...profile.params,periods:40,priceDynamics:1,policyDynamics:1,currencyDynamics:1};
  const {rows} = simulate(config,seed,{paths:[{key:'currencyPressure',start:4,end:6,target:-10,mode:'pulse'}]});
  for (const row of rows) {
    const residual = Math.max(row.relativeResidual,Math.abs(row.nominalGDPResidual)/Math.max(1,row.nominalOutput));
    maxResidual = Math.max(maxResidual,residual);
    assert(residual<1e-8 && row.employment<100 && row.unemployment>0);
    assert(row.policyRate>=-.5 && row.policyRate<=20);
    assert(row.currencyStrength>=50-1e-9 && row.currencyStrength<=200+1e-9);
    assert(row.foreignTailAdopters<=row.foreignAdopters && row.foreignFromLowerMean<=row.foreignAdopters);
    assert(row.foreignAdopters<=contacts(row));
    tailAdoptions += row.foreignTailAdopters;
  }
}
assert(tailAdoptions>0);
const weakResult = runEnsemble({params:fx,reference:params,paths:shock(-20)});
const strongResult = runEnsemble({params:fx,reference:params,paths:shock(20)});
const weakNotes = simulationFindings(weakResult), strongNotes = simulationFindings(strongResult);
assert(weakNotes.findings.some(text => text.includes('currency lost value')));
assert(strongNotes.findings.some(text => text.includes('currency gained value')));
assert(weakNotes.policy.some(text => text.includes('targeted support')));
assert.notDeepEqual(weakNotes.policy,strongNotes.policy);
console.log(JSON.stringify({status:'PASS',simulationPaths:56,annualStepsPerPath:40,maxResidual,tailAdoptions,
  opportunitiesPerBenchmark:samples,lowerBenchmarkAdoptionFrequency:lower/samples,higherBenchmarkAdoptionFrequency:higher/samples}));

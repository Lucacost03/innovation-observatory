import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runEnsemble,simulate} from '../dist/engine.mjs';
import {HouseholdMarket} from '../dist/finance.mjs';
import {DEFAULTS,metricValue} from '../dist/parameters.mjs';

const read = path => JSON.parse(readFileSync(new URL('../'+path,import.meta.url)));
const profiles = read('research/frozen_engine_v1_16/profiles.json');
const hicp = read('research/source_snapshots/hicp_annual.json');
const italy = profiles.find(p=>p.code==='ITA').params;
const seed = 2026;
const close = (a,b,label) => assert(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} versus ${b}`);
for (const profile of profiles) {
  const selection = {freq:'A',unit:'RCH_A_AVG',coicop:'CP00',geo:profile.geo,time:'2023'};
  const index = hicp.id.reduce((n,key,i)=>n*hicp.size[i]+hicp.dimension[key].category.index[selection[key]],0);
  assert.equal(profile.params.initialInflation,hicp.value[index]);
}
const result=runEnsemble({params:{...italy,periods:8,replications:1},reference:italy});
assert.equal(result.scenario[0].inflation.median,5.9);
assert.equal(result.scenario[0].consumerPriceIndex.median,100);
assert.equal(result.scenario[0].entries.median,null);
assert.equal(result.scenario[0].currentAccount.median,null);
assert.equal(result.first.scenario.rows[1].policyInflationSignal,italy.initialPolicyInflation);
assert.equal(metricValue({initialObservation:0,entries:2},'entries'),2);

const marketParams={...DEFAULTS,marketDepositShare:100,foreignPortfolioWeight:20,ventureWeight:80,
  businessEquityWeight:0,corporateBondWeight:0,governmentBondWeight:0};
const sample=ca=>{
  const h={cash:10,foreignAssets:0};
  const market=new HouseholdMarket([h],[0],marketParams);
  const flow=market.closeForeignOrders(ca,2);
  close(h.foreignAssets*2,flow.foreignAssetPurchases,'Foreign asset cost');
  close(10-h.cash,flow.foreignAssetPurchases,'Foreign deposit payment');
  return flow;
};
assert.deepEqual(sample(-1),{foreignAssetPurchases:2,foreignAssetSurplusPurchases:0});
assert.deepEqual(sample(4),{foreignAssetPurchases:4,foreignAssetSurplusPurchases:2});

let years=0, maxResidual=0, withIncome=0, withValuation=0, withSurplus=0;
function check(rows) {
  for(let year=1;year<rows.length;year++){
    const r=rows[year],prior=rows[year-1],delta=key=>r[key]-prior[key];
    const netGoods=r.nominalExports-r.nominalImports;
    close(r.currentAccount,netGoods+r.foreignAssetIncome,'Current account');
    close(r.nationalSaving-r.grossInvestment,r.currentAccount,'Saving less investment');
    close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+netGoods,'Nominal GDP');
    close(delta('bankNetForeignPosition'),r.currentAccount-r.foreignAssetPurchases,'Bank external settlement');
    close(delta('householdForeignAssets'),r.foreignAssetPurchases+r.foreignAssetValuation,'Household foreign assets');
    close(delta('netForeignPosition'),r.currentAccount+r.foreignAssetValuation,'Net international position');
    close(r.foreignAssetIncome,prior.householdForeignAssets*prior.currencyStrength/r.currencyStrength*r.foreignAssetYield/100,'Cash yield on opening assets');
    close(delta('privateMoney'),delta('loans')+delta('bankPublicDebt')-delta('bankEquity')-delta('governmentDeposits')
      +delta('bankNetForeignPosition'),'Bank money');
    close(delta('householdDeposits'),r.householdSaving-r.startupFunding-r.householdBondPurchases-r.businessEquityIssued
      -r.corporateBondsIssued-r.foreignAssetPurchases+r.publicBondRedemptionsToHouseholds+r.corporateBondRepayments+r.corporateBondRecoveries+r.liquidationDistributions,'Household deposits');
    assert(r.publicCreditWeight>=.2&&r.publicCreditWeight<=.4);
    assert(r.marketPurchases<=r.marketBudget+1e-8);
    assert(r.foreignAssetSurplusPurchases<=Math.max(0,r.currentAccount)+1e-8);
    maxResidual=Math.max(maxResidual,Math.abs(r.savingIdentityResidual)/Math.max(1,r.nominalOutput),r.financeResidual);
    withIncome+=Number(r.foreignAssetIncome>0);
    withValuation+=Number(Math.abs(r.foreignAssetValuation)>1e-8);
    withSurplus+=Number(r.foreignAssetSurplusPurchases>0);
    years++;
  }
}
const invested={...italy,periods:8,financialMarket:1,tradeEnabled:0,foreignPortfolioWeight:20};
const rows=simulate(invested,seed).rows;
assert.equal(rows[1].foreignAssetIncome,0);
assert(rows[1].foreignAssetPurchases>0&&rows[2].foreignAssetIncome>0);
assert(rows[2].currentAccount>0);
check(rows);
const noOrders=simulate({...invested,financialMarket:0,initialHouseholdForeignAssets:10},seed).rows;
close(noOrders[0].householdForeignAssets,10,'Opening asset choice');
assert(noOrders[1].foreignAssetIncome>0&&noOrders[1].foreignAssetPurchases===0);
check(noOrders);

for(const profile of profiles)for(const stressSeed of [seed,9945]){
  check(simulate({...profile.params,periods:40,financialMarket:1,tradeEnabled:1,
    foreignPortfolioWeight:20,policyDynamics:1,currencyDynamics:1},stressSeed).rows);
}
assert(withIncome>0&&withValuation>0&&withSurplus>0&&maxResidual<1e-8);
console.log(JSON.stringify({status:'PASS',paths:58,years,maxResidual,withIncome,withValuation,withSurplus}));

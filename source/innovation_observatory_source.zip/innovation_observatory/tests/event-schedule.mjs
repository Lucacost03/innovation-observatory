import assert from 'node:assert/strict';
import fs from 'node:fs';
import {eventsFromShocks,shocksFromEvents,eventPreview,newEvent,effectDescription} from '../dist/event-schedule.mjs';
import {simulate,runEnsemble} from '../dist/engine.mjs';
import {validateShocks,shockValues} from '../dist/shocks.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';
import {MODEL_VERSION} from '../dist/parameters.mjs';

const profiles=JSON.parse(fs.readFileSync(new URL('../research/frozen_engine_v1_16/profiles.json',import.meta.url)));
const italy=profiles.find(p=>p.code==='ITA').params;
const close=(a,b)=>assert(Math.abs(a-b)<1e-10*Math.max(1,Math.abs(a),Math.abs(b)),`${a} vs ${b}`);
const event={id:'event-1',name:'Combined downturn',start:3,duration:2,recovery:.5,
  effects:[{type:'demand',magnitude:-20},{type:'credit',magnitude:-30}]};
const flat=shocksFromEvents([event]);
assert.deepEqual(eventsFromShocks(flat),[event]);
assert.deepEqual(eventsFromShocks(JSON.parse(JSON.stringify(flat))),[event]);
assert.equal(flat.length,2);
for(const year of [0,1,2]){
  const preview=eventPreview([event],year);
  assert(preview.every(row=>row.change===0));
}
for(const [year,change]of [[3,-20],[4,-20],[5,-10],[6,-5]])
  close(eventPreview([event],year).find(row=>row.type==='demand').change,change);
const ends={...event,recovery:0};
close(shockValues(4,shocksFromEvents([ends])).demand,.8);
close(shockValues(5,shocksFromEvents([ends])).demand,1);
const permanent={...event,recovery:1};
close(shockValues(120,shocksFromEvents([permanent])).demand,.8);
const second={...event,id:'event-2',name:'Stimulus',effects:[{type:'demand',magnitude:25},{type:'policyRate',magnitude:1}]};
const third={...second,id:'event-3',name:'Rate cut',effects:[{type:'policyRate',magnitude:-.25}]};
const combined=eventPreview([event,second,third],3);
close(combined.find(row=>row.type==='demand').change,0);
close(combined.find(row=>row.type==='policyRate').change,.75);
assert(effectDescription('exchangeRate',-10).includes('depreciation'));
assert(effectDescription('supply',10).includes('does not directly change'));
assert.equal(newEvent([event],8).id,'event-2');
assert.equal(newEvent([],8,'production').effects[0].magnitude,10);

const legacy=[{type:'demand',start:4,duration:2,magnitude:-25,recovery:.5},
  {type:'demand',start:7,duration:2,magnitude:10,recovery:0}];
const upgraded=shocksFromEvents(eventsFromShocks(legacy));
assert.equal(eventsFromShocks(legacy).length,2);
for(let year=0;year<=40;year++)assert.deepEqual(shockValues(year,legacy),shockValues(year,upgraded));
assert.deepEqual(shocksFromEvents([]),[]);
for(const invalid of [{...event,name:''},{...event,name:'x'.repeat(81)},{...event,start:0},
  {...event,duration:0},{...event,recovery:1.1},{...event,start:''},{...event,effects:[]},
  {...event,effects:[{type:'demand',magnitude:''}]},{...event,effects:[...event.effects,event.effects[0]]},
  {...event,effects:[{type:'output',magnitude:10}]}])assert.throws(()=>shocksFromEvents([invalid]));
assert.throws(()=>shocksFromEvents([event,event]));
assert.throws(()=>validateShocks([{...flat[0],eventId:'<bad>'}]));
assert.throws(()=>validateShocks([flat[0],{...flat[1],start:4}]),/share/);
assert.throws(()=>shocksFromEvents(Array.from({length:11},(_,i)=>({...event,id:'event-'+i}))));

let paths=0,checkedYears=0;
for(const country of ['ITA','DEU','EU27'])for(const seed of [2026,9945]) {
  const params={...profiles.find(p=>p.code===country).params,periods:12};
  const named=simulate(params,seed,{shocks:flat});
  const plain=simulate(params,seed,{shocks:flat.map(({eventId,eventName,...shock})=>shock)});
  assert.deepEqual(named.rows,plain.rows);
  const baseline=simulate(params,seed);
  assert.deepEqual(named.rows.slice(0,3),baseline.rows.slice(0,3));
  paths+=3;checkedYears+=36;
}
const params={...italy,periods:8,replications:2};
const saved={modelVersion:'1.14.0',country:'ITA',params,reference:params,referenceLabel:'Pinned reference',paths:[],shocks:legacy,preset:'custom'};
const restored=restoreConfiguration(saved,profiles);
assert(restored.migrated&&!restored.rebuildPreset);
assert.equal(restored.state.params.periods,8);
assert.equal(restored.state.referenceLabel,'Pinned reference');
assert.deepEqual(restored.state.shocks,legacy);
const replay=restoreConfiguration({...restored.state,modelVersion:MODEL_VERSION,shocks:flat},profiles);
assert.deepEqual(replay.state.shocks,flat);
const run=runEnsemble({params,reference:params,shocks:flat});
assert.deepEqual(run.shocks,flat);
assert.deepEqual(run.raw.baseline[0].rows.slice(0,3),run.raw.scenario[0].rows.slice(0,3));
assert(run.residuals.maxRelative<1e-8);
paths+=4;checkedYears+=32;
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,checkedYears,
  checks:['Named multi-effect events survive JSON and saved-setting replay.',
    'Existing shocks preserve their timing and numerical effects when opened and reapplied.',
    'Start years, inclusive durations, fading, permanent effects and overlapping channels match the simulator.',
    'Invalid timing, duplicate effects and the 20-effect limit are rejected.',
    'Event names and grouping do not change economic row outputs. No event has an effect before its start.',
    'Existing 1.14 settings and pinned references are preserved. Saving and financial accounts reconcile.'],
  scope:'Editor and scheduling verification; the economic shock equations are unchanged.'};
fs.writeFileSync(new URL('../dist/data/event_editor_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));

import assert from 'node:assert/strict';import fs from 'node:fs';import {restoreConfiguration,restoreTimeline,resetEconomyParameters,inputStatus,MODEL_VERSION} from '../dist/configuration.mjs';import {DEFAULTS,PARAMETERS} from '../dist/parameters.mjs';
const profiles=JSON.parse(fs.readFileSync(new URL('../dist/data/profiles.json',import.meta.url))),p=profiles.find(p=>p.code==='ITA');
const old={country:'ITA',params:{...DEFAULTS,employmentRate:92,burnIn:12,initialPublicDebt:0,rdBusiness:6,firms:30,replications:4},reference:{...DEFAULTS},paths:[{key:'rdBusiness',start:8,end:8,target:6,mode:'step'}],shocks:[],preset:'research'};
const migrated=restoreConfiguration(old,profiles);assert(migrated.migrated);assert.equal(migrated.state.params.burnIn,0);assert.equal(migrated.state.params.initialPublicDebt,p.params.initialPublicDebt);assert.equal(migrated.state.params.rdBusiness,p.params.rdBusiness);assert.equal(migrated.state.params.firms,30);assert.equal(migrated.state.params.replications,4);assert.equal(migrated.state.modelVersion,MODEL_VERSION);
const current={...migrated.state,params:{...migrated.state.params,rdBusiness:2.75},paths:[{key:'rdBusiness',start:8,end:8,target:6,mode:'step'}]};const restored=restoreConfiguration(current,profiles);assert(!restored.migrated);assert.equal(restored.state.params.rdBusiness,2.75);assert.deepEqual(restored.state.paths,current.paths);
const d=PARAMETERS.find(d=>d.key==='rdBusiness');assert.equal(inputStatus(d,{...DEFAULTS,...p.params},p).status,'proxy');assert.equal(inputStatus(d,current.params,p).status,'edited');assert.equal(inputStatus(PARAMETERS.find(d=>d.key==='loanSpread'),{...DEFAULTS,...profiles.find(p=>p.code==='EU27').params},profiles.find(p=>p.code==='EU27')).status,'assumed');
assert.equal(restoreConfiguration({...old,country:'UNKNOWN'},profiles),null);console.log('PASS: legacy data migration, current settings replay, source/edited labels and unknown-profile handling.');

const v11={...current,modelVersion:"1.1.0",params:{...current.params,rdLaborShare:100}};const upgrade=restoreConfiguration(v11,profiles);assert(upgrade.migrated&&!upgrade.rebuildPreset);assert.equal(upgrade.state.params.rdBusiness,2.75);assert.equal(upgrade.state.params.rdLaborShare,p.params.rdLaborShare);assert.deepEqual(upgrade.state.paths,v11.paths);console.log("PASS: 1.1 upgrade preserves edited settings and paths while adding matched labor shares to both economies.");

const priorPolicy={...v11,params:{...v11.params,fiscalAdjustment:.04,publicResearchReturn:.15},reference:{...v11.reference,fiscalAdjustment:.04,publicResearchReturn:.15}};const neutral=restoreConfiguration(priorPolicy,profiles);assert.equal(neutral.state.params.fiscalAdjustment,0);assert.equal(neutral.state.reference.publicResearchReturn,0);priorPolicy.params.fiscalAdjustment=.08;assert.equal(restoreConfiguration(priorPolicy,profiles).state.params.fiscalAdjustment,.08);console.log("PASS: previously default policy multipliers are switched off; nondefault custom policy settings are retained.");

const v12={...current,modelVersion:'1.2.0',params:{...current.params},reference:{...current.reference},shocks:[{type:'demand',start:10,duration:2,magnitude:-20,recovery:0}]};
for(const key of ['firmDynamics','entryRate','exitRate','foreignContact','usTechnology']){delete v12.params[key];delete v12.reference[key];}
const updated=restoreConfiguration(v12,profiles);assert(updated.migrated&&!updated.rebuildPreset);assert.equal(updated.state.params.rdBusiness,2.75);assert.equal(updated.state.params.firmDynamics,1);assert.equal(updated.state.params.foreignContact,DEFAULTS.foreignContact);assert.equal(updated.state.params.entryRate,p.params.entryRate);assert.equal(updated.state.reference.usTechnology,p.params.usTechnology);assert.deepEqual(updated.state.paths,v12.paths);assert.deepEqual(updated.state.shocks,v12.shocks);console.log('PASS: 1.2 edits, pinned reference and interventions survive migration; new matched inputs apply to both economies.');

const koreaPath={key:'koreaGrowth',start:8,end:8,target:2,mode:'step'};
const v13={...current,modelVersion:'1.3.0',params:{...current.params,employmentRate:100,koreaTechnology:2},paths:[...current.paths,koreaPath]};
delete v13.params.rowTechnology;delete v13.params.jobFindingRate;
const upgraded=restoreConfiguration(v13,profiles);
assert.equal(upgraded.state.params.employmentRate,99.9);
assert.equal(upgraded.state.params.rowTechnology,p.params.rowTechnology);
assert.equal(upgraded.state.params.jobFindingRate,p.params.jobFindingRate);
assert.equal(upgraded.state.params.koreaTechnology,undefined);
assert(upgraded.employmentAdjusted);assert.equal(upgraded.retiredKoreaPaths,1);
assert.deepEqual(upgraded.state.paths,current.paths);
assert.deepEqual(restoreTimeline(v13.paths,v13.modelVersion),{paths:current.paths,retiredKoreaPaths:1,retiredPricePaths:0,retiredLoanPaths:0,retiredCreditPaths:0});
assert.throws(()=>restoreTimeline([koreaPath],MODEL_VERSION));
console.log('PASS: 1.3 employment bounds, rest-of-world defaults, retired Korea path and preserved interventions.');

const v14={...current,modelVersion:'1.4.0',params:{...current.params},reference:{...current.reference,rdBusiness:1.25},shocks:v12.shocks};
for(const key of ['priceDynamics','inflationAnchor','priceDemandResponse','priceCostResponse']){
 delete v14.params[key];
 delete v14.reference[key];
}
const withPrices=restoreConfiguration(v14,profiles);
assert(withPrices.migrated&&!withPrices.rebuildPreset);
assert.equal(withPrices.state.params.priceDynamics,0);
assert.equal(withPrices.state.reference.priceDynamics,0);
assert.equal(withPrices.state.params.rdBusiness,2.75);
assert.equal(withPrices.state.reference.rdBusiness,1.25);
assert.deepEqual(withPrices.state.paths,v14.paths);
assert.deepEqual(withPrices.state.shocks,v14.shocks);
console.log('PASS: 1.4 prices remain fixed and scenario, pinned reference and interventions survive migration.');

const v15={...v14,modelVersion:'1.5.0',params:{...v14.params,priceDynamics:1},reference:{...v14.reference}};
for(const side of ['params','reference'])for(const key of ['foreignTechDispersion','policyDynamics','currencyDynamics'])delete v15[side][key];
const open=restoreConfiguration(v15,profiles).state;
assert.equal(open.params.priceDynamics,1);
for(const side of ['params','reference']){
 assert.equal(open[side].foreignTechDispersion,0);
 assert.equal(open[side].policyDynamics,0);
 assert.equal(open[side].currencyDynamics,0);
 assert.equal(open[side].initialPolicyRate,p.params.initialPolicyRate);
}
assert.deepEqual(open.paths,v15.paths);
assert.deepEqual(open.shocks,v15.shocks);
console.log('PASS: 1.5 migration preserves the earlier matching, price rule and interventions.');

const retired={key:'inflationAnchor',start:2,end:2,target:3,mode:'step'};
const v16={...v15,modelVersion:'1.6.0',params:{...v15.params,inflationAnchor:3},paths:[...v15.paths,retired]};
const quantity=restoreConfiguration(v16,profiles);
assert.equal(quantity.retiredPricePaths,1);
assert.equal(quantity.state.params.inflationAnchor,undefined);
assert.equal(quantity.state.params.priceDynamics,1);
assert.deepEqual(quantity.state.paths,v15.paths);
assert.deepEqual(quantity.state.shocks,v15.shocks);
assert.throws(()=>restoreTimeline([retired],MODEL_VERSION));
console.log('PASS: 1.6 imports retire obsolete price paths and preserve other settings.');

const v17={...v16,modelVersion:'1.7.0',paths:v15.paths,params:{...v15.params,governmentShare:12}};
for(const key of ['initialGovernmentShare','publicBudgetStability','publicTrendGrowth'])delete v17.params[key];
const budget=restoreConfiguration(v17,profiles).state;
assert.equal(budget.params.governmentShare,12);
assert.equal(budget.params.initialGovernmentShare,p.params.initialGovernmentShare);
assert.equal(budget.params.publicBudgetStability,1);
assert.deepEqual(budget.paths,v17.paths);
console.log('PASS: 1.7 imports preserve the public spending plan and add the preset opening share.');

const edited = {...current.params, policyDynamics:1, currencyDynamics:1, replications:7, governmentShare:10};
const reset = resetEconomyParameters({...p.params, policyDynamics:1, currencyDynamics:1},edited);
assert.equal(reset.policyDynamics,1);
assert.equal(reset.currencyDynamics,1);
assert.equal(reset.tradeEnabled,1);
assert.equal(reset.financialMarket,1);
assert.equal(reset.replications,7);
assert.equal(reset.governmentShare,p.params.governmentShare);

const oldLoanPath = {key:'loanRate',start:3,end:3,target:9,mode:'step'};
const v18 = {...current,modelVersion:'1.8.0',
 params:{...edited,initialPolicyRate:5,loanRate:8},reference:{...current.reference,loanRate:6},
 paths:[...current.paths,oldLoanPath]};
delete v18.params.loanSpread;
delete v18.reference.loanSpread;
const credit = restoreConfiguration(v18,profiles);
assert.equal(credit.state.params.loanSpread,3);
assert.equal(credit.state.reference.loanSpread,6-credit.state.reference.initialPolicyRate);
assert.equal(credit.retiredLoanPaths,1);
assert.deepEqual(credit.state.paths,current.paths);
assert.equal(credit.state.params.policyDynamics,1);
assert.equal(credit.state.params.currencyDynamics,1);
assert(!PARAMETERS.some(d=>d.key==='loanRate'));
assert(PARAMETERS.find(d=>d.key==='loanSpread').readOnly);
assert(!PARAMETERS.find(d=>d.key==='loanSpread').dynamic);
console.log('PASS: economy reset enables policy, currency, trade and markets and legacy opening business quotes migrate into calibrated spreads.');

const previousMarketVersion = {...current,modelVersion:'1.9.0',preset:'trade',paths:[
 {key:'tradeEnabled',start:1,end:1,target:1,mode:'step'},
],params:{...current.params,policyDynamics:1,financialMarket:0},reference:current.reference};
const withMarket = restoreConfiguration(previousMarketVersion,profiles);
assert(withMarket.migrated&&!withMarket.rebuildPreset);
assert.equal(withMarket.state.params.financialMarket,0);
assert.equal(withMarket.state.params.policyDynamics,1);
assert.deepEqual(withMarket.state.paths,[]);
console.log('PASS: prior experiments retain saved settings, retire the website trade switch and get an optional investment market.');

// The new floor and revised denominator migrate without changing authored school assumptions.
const preMacro=JSON.parse(fs.readFileSync(new URL('../research/frozen_engine_v1_18_1/profiles.json',import.meta.url))).find(x=>x.code==='ITA');
const beforeMacro={country:'ITA',modelVersion:'1.18.1',params:{...preMacro.params,initialPolicyRate:-.5,neutralPolicyRate:-.25,educationElasticity:.35,publicEducationQuality:1.4},reference:preMacro.params,paths:[{key:'neutralPolicyRate',start:4,end:4,target:-.25,mode:'step'}],shocks:[],preset:'custom'};
const macroUpgrade=restoreConfiguration(beforeMacro,profiles);
assert(!macroUpgrade.rebuildPreset);assert.equal(macroUpgrade.state.params.initialPolicyRate,0);assert.equal(macroUpgrade.state.params.neutralPolicyRate,0);assert.equal(macroUpgrade.state.paths[0].target,0);assert.equal(macroUpgrade.state.params.educationElasticity,.35);assert(Math.abs(macroUpgrade.state.params.publicEducationQuality/(p.params.initialEducationQuality??1)-1.4)<1e-12);assert.equal(macroUpgrade.state.params.employmentRate,p.params.employmentRate);assert.equal(macroUpgrade.state.params.initialParticipationRate,p.params.initialParticipationRate);assert(macroUpgrade.employmentDefinitionUpdated);
console.log('PASS: zero-rate floor and matched age15–64 defaults migrate while edited education effects and timing paths survive.');

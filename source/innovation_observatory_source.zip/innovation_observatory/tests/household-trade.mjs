import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {Economy,simulate} from '../dist/engine.mjs';
import {Economy as PriorEconomy} from '../research/frozen_engine_v1_12/engine.mjs';
import {tradeConditions} from '../dist/trade.mjs';
import {MODEL_VERSION,metricValue,sanitize} from '../dist/parameters.mjs';

const read=path=>JSON.parse(fs.readFileSync(new URL('../'+path,import.meta.url)));
const profiles=read('research/frozen_engine_v1_16/profiles.json'),benchmarks=read('dist/data/household_benchmarks.json');
const manifest=read('research/source_snapshots/HOUSEHOLD_TRADE_MANIFEST.json');
const close=(a,b,label)=>assert(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} vs ${b}`);
for(const file of manifest)assert.equal(createHash('sha256').update(fs.readFileSync(new URL('../'+file.path,import.meta.url))).digest('hex'),file.sha256);
let maxIncomeFitError=0,maxWealthFitError=0,oldIncomeError=0,oldWealthError=0,openingStates=0;
for(const profile of profiles)for(const households of [50,200,500])for(const seed of [2026,9945]) {
  const params={...profile.params,households},r=new Economy(params,seed).initialSnapshot(),b=benchmarks[profile.code];
  close(r.incomeGini,b.incomeGini,'Empirical income moment');
  close(r.wealthGini,b.financialWealthGini,'Empirical financial wealth moment');
  close(r.output,r.consumption+r.government+r.investment+r.exports-r.imports,'Opening real expenditure');
  close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+r.nominalExports-r.nominalImports,'Opening nominal expenditure');
  assert(r.exports>0&&r.imports>0&&r.foreignAssetsAtCost>0&&r.foreignLiabilities>0);
  maxIncomeFitError=Math.max(maxIncomeFitError,Math.abs(r.incomeGini-b.incomeGini));
  maxWealthFitError=Math.max(maxWealthFitError,Math.abs(r.wealthGini-b.financialWealthGini));
  const old=new PriorEconomy(params,seed).initialSnapshot();
  oldWealthError+=Math.abs(old.gini-b.financialWealthGini);
  openingStates++;
}
// The earlier income initialization is equal across households, hence Gini 0.
oldIncomeError=profiles.reduce((s,p)=>s+benchmarks[p.code].incomeGini,0)/profiles.length;
oldWealthError/=openingStates;

const italy=profiles.find(p=>p.code==='ITA').params,seed=2026;
const opening=tradeConditions(100,1,1,{...sanitize(italy),importTariff:0});
const withDuty=tradeConditions(100,1,1,{...sanitize(italy),importTariff:25});
close(withDuty.importPrice,opening.importPrice,'Tariff is not a foreign price');
close(withDuty.landedImportPrice,1.25*opening.importPrice,'Landed price includes duty');
close(withDuty.realExchangeRate,opening.realExchangeRate,'Border real exchange rate');
assert(withDuty.importBudgetShare<opening.importBudgetShare);
close(withDuty.exportOrders,opening.exportOrders,'No direct export-demand tariff override');
for(const importTariff of [10,50,100]) {
  const p=sanitize({...italy,importTariff}),r=new Economy(p,seed).initialSnapshot();
  close(r.nominalImports*(1+importTariff/100)*(1+p.consumptionTax/100)/r.nominalConsumption,
    r.importBudgetShare,'Opening imports reflect the initial tariff');
  close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+r.nominalExports-r.nominalImports,'Initial tariff expenditure identity');
  for(const row of simulate({...p,periods:8},seed).rows) {
    close(row.output,row.goodsOutput+row.consumptionTax+row.realImportDuties,'Initial tariff volume basis');
  }
}
const base=simulate({...italy,periods:12},seed).rows;
const zero=simulate({...italy,periods:12},seed,{paths:[{key:'importTariff',start:4,end:4,target:0,mode:'step'}]}).rows;
assert.deepEqual(zero,base);
const tariff=simulate({...italy,periods:12},seed,{paths:[{key:'importTariff',start:4,end:4,target:20,mode:'step'}]}).rows;
assert.deepEqual(tariff.slice(0,4),base.slice(0,4));
assert(tariff[4].importConsumerPrice>base[4].importConsumerPrice);
assert(tariff[4].imports<base[4].imports&&tariff[4].importTariffRevenue>0);
assert.equal(metricValue(tariff[0],'exports'),tariff[0].exports);

let paths=0,years=0,surplusYears=0,deficitYears=0,maxResidual=0,minExports=Infinity,minImports=Infinity,minAssets=Infinity,minLiabilities=Infinity;
const cases=[];
function inspect(run,country,mode) {
  paths++;
  for(let year=0;year<run.rows.length;year++) {
    const r=run.rows[year];
    assert(Object.values(r).every(Number.isFinite));
    assert(r.exports>0&&r.imports>0&&r.foreignAssetsAtCost>0&&r.foreignLiabilities>0,`${country} ${mode} year ${year} positive gross flows/stocks`);
    minExports=Math.min(minExports,r.exports);minImports=Math.min(minImports,r.imports);
    minAssets=Math.min(minAssets,r.foreignAssetsAtCost);minLiabilities=Math.min(minLiabilities,r.foreignLiabilities);
    close(r.foreignAssetsAtCost-r.foreignLiabilities,r.netForeignAssets,'Gross less liabilities');
    close(r.bankForeignAssets-r.bankForeignLiabilities,r.bankNetForeignPosition,'Financial gross positions');
    close(r.importTariffRevenue,r.nominalImports*r.importTariff/100,'Duty on border value');
    close(r.output,r.goodsOutput+r.consumptionTax+r.realImportDuties,'Real GDP at opening tax rates');
    close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+r.nominalExports-r.nominalImports,'Nominal GDP expenditure');
    const baseVat=run.params.consumptionTax/100,baseDuty=run.params.importTariff/100;
    close(r.consumptionTax,r.consumptionGoods*baseVat+r.imports*(1+baseDuty)*baseVat,'Constant-price VAT');
    close(r.realImportDuties,r.imports*baseDuty,'Constant-price import duty');
    if(!year)continue;
    const prior=run.rows[year-1];
    close(r.currentAccount,r.nominalExports-r.nominalImports+r.foreignAssetIncome,'Current account excludes domestic duty');
    close(r.nationalSaving-r.grossInvestment,r.currentAccount,'S minus I');
    close(r.netForeignAssets-prior.netForeignAssets,r.currentAccount,'NFA change');
    close(r.governmentDeposits-prior.governmentDeposits,
      r.wageWithholding+r.profitTaxPaid+r.nominalConsumptionTax+r.financialIncomeTaxPaid+r.wealthTaxPaid+r.importTariffRevenue
      +r.householdBondPurchases+r.bankBondPurchases+r.governmentFirmDividends+r.governmentLiquidationProceeds-r.publicBondRedemptions-r.nominalGovernment-r.publicRDGrants-r.cashSupport-r.unemploymentBenefits
      -r.publicResearchNonBusiness-r.governmentInterest-r.recap,'Public cash including tariff');
    maxResidual=Math.max(maxResidual,r.relativeResidual,r.financeResidual,
      Math.abs(r.nominalGDPResidual)/Math.max(1,r.nominalOutput),Math.abs(r.netForeignAssetResidual)/Math.max(1,Math.abs(r.netForeignAssets)),
      Math.abs(r.savingIdentityResidual)/Math.max(1,r.nominalOutput));
    surplusYears+=Number(r.currentAccount>1e-8);deficitYears+=Number(r.currentAccount< -1e-8);years++;
  }
  const last=run.rows.at(-1);
  cases.push({country,mode,seed:run.seed,incomeGini:last.incomeGini,wealthGini:last.wealthGini,realGDP:last.output,
    inflation:last.inflation,publicDebtGDP:last.publicDebtGDP,netForeignAssets:last.netForeignAssets});
}
for(const profile of profiles)for(const seed of [2026,9945])for(const mode of ['default','tariff']) {
  const params={...profile.params,periods:40,...(mode==='tariff'?{foreignPortfolioWeight:20,initialHouseholdForeignAssets:10}:{})};
  inspect(simulate(params,seed,mode==='tariff'?{paths:[{key:'importTariff',start:4,end:4,target:50,mode:'step'}],shocks:[
    {type:'exchangeRate',start:5,duration:2,magnitude:-30,recovery:.5},
    {type:'demand',start:8,duration:3,magnitude:-30,recovery:.5},
  ]}:{}),profile.code,mode);
}
for(const profile of profiles)inspect(simulate({...profile.params,periods:40,importShare:60,exportDemand:.1},2026),profile.code,'deficit');
assert(surplusYears>0&&deficitYears>0&&maxResidual<1e-8);
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,openingStates,
  coverage:{incomeCountries:28,wealthMatched:22,wealthProxies:6},maxIncomeFitError,maxWealthFitError,
  previousOpeningIncomeMAE:oldIncomeError,previousOpeningWealthMAE:oldWealthError,
  surplusYears,deficitYears,minExports,minImports,minAssets,minLiabilities,maxResidual,
  italyTariff:{year:4,baselineInflation:base[4].inflation,tariffInflation:tariff[4].inflation,
    baselineImports:base[4].imports,tariffImports:tariff[4].imports,revenue:tariff[4].importTariffRevenue,
    baselineRealGDP:base[4].output,tariffRealGDP:tariff[4].output},cases,
  limitations:'Opening moment fit is calibration, not a forecast validation. Financial wealth Gini is reconstructed from HFCS financial assets, not the published total net-wealth Gini. Wage ranks, their correlation with wealth, portfolio coverage and rollover are assumptions. Gross trade tests cover active economies, not a zero-production disaster. No forecast-accuracy gain is claimed.'};
fs.writeFileSync(new URL('../dist/data/household_trade_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,cases:report.cases.length}));

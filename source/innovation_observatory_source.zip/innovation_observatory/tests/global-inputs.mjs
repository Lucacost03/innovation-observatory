import fs from 'node:fs';
import assert from 'node:assert/strict';
import {DEFAULTS,PARAMETERS,MODEL_VERSION,sanitize,metricValue} from '../dist/parameters.mjs';
import {Economy,simulate,uniform,runEnsemble} from '../dist/engine.mjs';
import {FOREIGN_POOLS,foreignProviders,foreignContext,foreignGrowthRates,learnForeign} from '../dist/foreign.mjs';
import {startupCapitalTarget,startupCashRequired} from '../dist/demography.mjs';
import {newEvent,shocksFromEvents} from '../dist/event-schedule.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';
import {simulationFindings} from '../dist/findings.mjs';
import {sectorYear} from '../dist/sector-view.mjs';
import {SOCIAL_FLOWS} from '../dist/society.mjs';
const read=f=>JSON.parse(fs.readFileSync(new URL('../'+f,import.meta.url)));
const profiles=read('dist/data/profiles.json'),coverage=read('dist/data/global_input_coverage.json');
const close=(a,b,t=1e-9)=>assert(Math.abs(a-b)<=t*Math.max(1,Math.abs(a),Math.abs(b)),`${a} != ${b}`);
assert.equal(profiles.length,30);assert.equal(new Set(profiles.map(p=>p.code)).size,30);
assert.equal(coverage.countries.length,30);
const checks=[];let paths=0,years=0,maxResidual=0,positiveTradeYears=0;
for(const p of profiles){
 const config=sanitize({...DEFAULTS,...p.params}),ctx=foreignContext(config);
 for(const [key,value]of Object.entries(p.params))if(Object.hasOwn(DEFAULTS,key))close(config[key],value); // A source value must never silently clip to a bound.
 assert.equal(ctx.home,p.code);assert.equal(foreignProviders(config).length,3);
 const seen=new Set(ctx.homeMembers);
 for(const donor of foreignProviders(config)){
  const pool=ctx.providers[donor.code];assert(pool.members.length>0);
  for(const code of pool.members){assert(!seen.has(code),p.code+' duplicate/home donor '+code);seen.add(code);}
  close(config[donor.relative],pool.relativeTFP/ctx.homeTFP);
  for(const values of Object.values(pool.multipliers)){close(values[0],1);assert.equal(values.length,78);assert(values.every(x=>Number.isFinite(x)&&x>0));}
 }
 const e=new Economy(config,2026);const r=e.initialRow?.()??null;
 // The cash required at purchase is discounted only for available estate assets.
 close(startupCashRequired(10,4,{liquidationPrice:.5,startupLiquidity:.3},2),22);
 close(startupCashRequired(10,0,{liquidationPrice:.5,startupLiquidity:.3},2),26);
 const a=startupCapitalTarget(e,{...config,startupSizeHeterogeneity:0},1,1,uniform,10000,2);
 const b=startupCapitalTarget(e,{...config,startupSizeHeterogeneity:0},1,1,uniform,10,100);
 close(a,b);close(a,e.openingStartupCapital*config.entrantSize);
 for(const [key,source] of Object.entries(p.provenance)){
  assert(['observed','derived','proxy','assumed','design'].includes(source.status),p.code+' '+key);
  if(source.parameterValue!=null)close(source.parameterValue,p.params[key]);
 }
 if(['USA','CHN'].includes(p.code))for(const key of Object.keys(DEFAULTS))assert(p.provenance[key],p.code+' missing status '+key);
}
assert.deepEqual(foreignProviders(profiles.find(p=>p.code==='USA').params).map(s=>s.code),['EUR','CHN','ROW']);
assert.deepEqual(foreignProviders(profiles.find(p=>p.code==='CHN').params).map(s=>s.code),['USA','EUR','ROW']);
for(const fix of coverage.unemploymentBenefitCorrections){
 const p=profiles.find(p=>p.code===fix.country),x=p.params;
 close(x.unemploymentReplacement,fix.candidateValue);
 close(x.unemploymentReplacement/100*(x.laborShare/x.employmentRate)*(100-x.employmentRate),fix.sourceBenefitGDPpct);
}
const us=profiles.find(p=>p.code==='USA'),cn=profiles.find(p=>p.code==='CHN');
// An underwater property cannot be sold by overdrawing its owner's deposit.
{
 const e=new Economy({...DEFAULTS,...profiles.find(p=>p.code==='ROU').params},2026),[seller,buyer]=e.households;
 for(const h of e.households){h.cash=0;h.housing=0;h.mortgage=0;h.prefersOwnership=false;}
 seller.housing=10;seller.mortgage=20;buyer.cash=10;e.bank.housing=0;e.society.housingPrice=1;
 const p={...e.p,housingTurnover:25,housingInvestorDemand:100,creditAvailability:0},flow={...SOCIAL_FLOWS};
 e.society.tradeExistingHousing(e,p,4,{publicCreditWeight:.3},flow);
 close(seller.housing,10);close(seller.mortgage,20);close(buyer.cash,10);
 seller.cash=1;e.society.tradeExistingHousing(e,p,4,{publicCreditWeight:.3},flow);
 close(seller.housing,9);close(seller.mortgage,18);close(seller.cash,0);close(buyer.cash,9);close(flow.mortgageRepayments,2);
 assert(e.households.every(h=>h.cash>=-1e-12));
}
close(us.params.initialPolicyRate,5.375);close(us.params.initialInflation,4.1);
close(us.params.initialIncomeGini,.3944025);close(us.params.mortgageOpeningRate,4);close(us.params.mortgageSpread,1.625);
close(cn.params.rdBusiness,100*2592.22/126058.2);
close(cn.params.initialPolicyRate,1.8);close(cn.params.initialInflation,.2);close(cn.params.depositInterestTaxableShare,0);
close(cn.params.initialMortgageGDP,38170/129427.17*100);close(cn.params.publicPensionGDP,6522.23/129427.17*100);
assert(cn.provenance.employmentRate.status==='assumed');assert(cn.labourAge.includes('15+'));
for(const p of [us,cn]){
 const config=sanitize({...DEFAULTS,...p.params,replications:2,periods:12});
 const event=newEvent([],40,'innovation',config);
 assert.deepEqual(event.effects.map(e=>e.type),foreignProviders(config).map(s=>'foreignTFP'+s.code));
 const inactive=p.code;
 const own=simulate(config,2026,{shocks:[{type:'foreignTFP'+inactive,start:4,duration:3,magnitude:1,recovery:0}],snapshots:false});
 const baseline=simulate(config,2026,{snapshots:false});paths+=2;years+=24;
 assert.deepEqual(own.rows,baseline.rows,'Own country is not a foreign innovation channel.');
 for(const row of own.rows)assert.equal(metricValue(row,'foreignTFPIndex'+inactive),null);
 const result=runEnsemble({params:config,reference:config,shocks:shocksFromEvents([event])});paths+=4;years+=48;
 assert(simulationFindings(result).findings.length>0);
 // Saving a previous-version scenario keeps authored events and reference edits.
 const saved={modelVersion:'1.19.1',country:p.code,params:{...config,rdBusiness:3.2},reference:config,paths:[],shocks:shocksFromEvents([event])};
 const restored=restoreConfiguration(saved,profiles);assert(!restored.rebuildPreset);close(restored.state.params.rdBusiness,3.2);assert.deepEqual(restored.state.shocks,saved.shocks);
}
checks.push('All30sourcecontexts exclude the home economy and have disjoint donor memberships. USA/China replace self donors with EU27. Own-country foreign shocks have no effect.');
checks.push('Matched primary inputs,20benefit recalibrations,source/parameter metadata,missing-data labels and preserved saved settings checked.');
checks.push('Startup opening-scale invariance and exact discounted asset cash requirements checked. Cash, capital and financial claims reconcile in full simulations.');
const cases=[];
for(const profile of profiles)for(const seed of [2026,9945])for(const mode of ['baseline','stress']){
 const p=sanitize({...DEFAULTS,...profile.params,periods:40});
 const shocks=mode==='stress'?[{type:'demand',start:8,duration:3,magnitude:-20,recovery:.5},{type:'credit',start:8,duration:3,magnitude:-50,recovery:.5},{type:'exchangeRate',start:8,duration:3,magnitude:-15,recovery:.5},{type:'foreignTFP'+foreignProviders(p)[0].code,start:12,duration:5,magnitude:.5,recovery:0}]:[];
 const result=simulate(p,seed,{shocks,snapshots:false});paths++;years+=p.periods;
 for(const row of result.rows){
  for(const [key,value]of Object.entries(row))if(typeof value==='number')assert(Number.isFinite(value),profile.code+' '+key);
  assert(row.policyRate>=0);assert(row.employment<100);maxResidual=Math.max(maxResidual,row.relativeResidual);assert(row.relativeResidual<1e-9);
  if(row.t){
   close(row.entryAttempts,row.entries+row.unfundedEntries+row.capBlockedEntries);
   close(row.unfundedEntries,row.financeBlockedEntries+row.capitalBlockedEntries);
   close(row.netForeignAssetChange,row.currentAccount,1e-8);
   close(row.nationalSaving-row.grossInvestment,row.currentAccount,1e-8);
   if(row.exports>0&&row.imports>0&&row.foreignAssetsAtCost>0&&row.foreignLiabilities>0)positiveTradeYears++;
   assert(row.ventureFunding<=row.ventureAvailableAtEntry+1e-7);
  }
 }
 const last=result.rows.at(-1),late=result.rows.slice(-10);
 cases.push({country:profile.code,mode,seed,finalRealGDP:last.output,finalUnemployment:100-last.employment,finalFirms:last.firmCount,entries:result.rows.reduce((s,x)=>s+x.entries,0),lateEntries:late.reduce((s,x)=>s+x.entries,0),lateVentureFunding:late.reduce((s,x)=>s+x.ventureFunding,0),floorYears:result.rows.filter(x=>x.floorBlockedExits>0).length,capYears:result.rows.filter(x=>x.capBlockedEntries>0).length});
}
checks.push('All30presets ×2seeds ×baseline/stress tested for40annualsteps, including S−I=CA, ΔNFA=CA, nonnegative policy rates and finite outcomes.');
const it=profiles.find(p=>p.code==='ITA'),config=sanitize({...DEFAULTS,...it.params,periods:12});
const plain=simulate(config,2026,{snapshots:false}),future=simulate(config,2026,{shocks:[{type:'foreignTFPUSA',start:8,duration:2,magnitude:1,recovery:0}],snapshots:false});paths+=2;years+=24;
assert.deepEqual(plain.rows.slice(0,8),future.rows.slice(0,8));assert.deepEqual(plain.rows,simulate(config,2026,{snapshots:false}).rows);paths++;years+=12;
const sigma=config.firmSizeDispersion,e=new Economy(config,2026),draws=Array.from({length:50000},(_,i)=>startupCapitalTarget(e,config,3,i,uniform,10,2));
assert(Math.abs((draws.reduce((s,x)=>s+x,0)/draws.length)/(e.openingStartupCapital*config.entrantSize)-1)<.05);assert(Math.min(...draws)<e.openingStartupCapital*config.entrantSize/5);
checks.push('Underwater house sales require mortgage repayment funding; no overdraft or negative pension contribution is created.');
checks.push('Seeded repeatability, no future-event leakage and the startup distribution mean checked. No forced upward venture trend or minimum entry count.');
const output={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,maxResidual,positiveTradeYears,allCountryCases:cases,checks,forecastAccuracy:'Not established. These checks verify source mappings, accounting, timing and removal of an entry-size artifact; no untouched historical forecast comparison.',limitations:['US/China many behavioural,portfolio,size,housing and pension inputs remain assumptions; comparable data gaps are visible.','Enterprise births cover all enterprises,while this model funds entrants through household equity.','Capital-size distribution uses employment size as a proxy; innovation and exit causal coefficients remain unestimated.','Long-horizon floor/cap and macro path concerns remain visible in every case.']};
fs.writeFileSync(new URL('../dist/data/global_model_validation.json',import.meta.url),JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({status:output.status,paths,years,maxResidual,positiveTradeYears,checks:checks.length}));

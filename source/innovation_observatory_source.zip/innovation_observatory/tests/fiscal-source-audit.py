"""Audit retained primary extracts, source scope and category sums offline."""
from pathlib import Path
import hashlib,json,math
R=Path(__file__).resolve().parents[1];S=R/'research/fiscal_reconciliation';read=lambda p:json.loads(p.read_text())
verified=[];optionalMissing=[]
for part,mfile in [('eu','download_manifest.json'),('usa','manifest.json'),('china','manifest.json')]:
 for m in read(S/part/mfile):
  if not m.get('sha256'):continue
  p=S/part/m['file']
  if not p.exists()and part=='usa'and p.suffix=='.xlsx':optionalMissing.append(str(p.relative_to(R)));continue
  assert p.exists(),str(p)
  assert hashlib.sha256(p.read_bytes()).hexdigest()==m['sha256'],str(p)
  verified.append(str(p.relative_to(R)))
eu=read(S/'eu/engine_inputs.json');us=read(S/'usa/USA_fiscal_anchors.json');cn=read(S/'china/china_engine_ready_2023.json');b=read(R/'dist/data/fiscal_benchmarks.json');maxResidual=0
rev=['salesIncludingOwnAccount','taxesProductionImports','subsidiesReceived','propertyIncomeReceived','currentIncomeWealthTaxes','netSocialContributions','currentTransfersReceived','capitalTransfersReceived'];exp=['publicWagesCompensation','intermediateConsumption','otherProductionTaxesPaid','subsidiesPaid','propertyIncomePaid','currentTaxesPaid','cashSocialBenefits','inKindPurchasedBenefits','currentTransfersPaid','pensionEntitlementAdjustment','capitalTransfersPaid','grossCapitalFormation','netNonProducedAssets']
for code,c in eu['countries'].items():
 y=c['years']['2023'];v=y['resolvedValuesPctGDP'];assert all(v[k]is not None for k in ['revenue','expenditure','balance','governmentConsumption','corporateIncomeTaxes','householdIncomeTaxes'])
 assert abs(v['revenue']-v['expenditure']-v['balance'])*y['GDPmillionEUR']/100<1
 for keys,total in [(rev,'revenue'),(exp,'expenditure')]:
  if all(v[k]is not None for k in keys):
   err=abs(sum(v[k]for k in keys)-v[total]);assert err*y['GDPmillionEUR']/100<1,(code,total,err);maxResidual=max(maxResidual,err)
 assert abs(b['countries'][code]['opening']['revenue']-v['revenue'])<1e-10
assert eu['countries']['DNK']['years']['2025']['valuesPctGDP']['revenue']is None
for yr,y in us['anchors'].items():
 v=y['summary'];rv=sum(x['percentGDP']for x in y['revenueItems']);ev=sum(x['percentGDP']for x in y['expenseItems']);assert abs(rv-v['currentRevenue']['percentGDP'])<.0001;assert abs(ev-v['currentExpenditure']['percentGDP'])<.0001
 cap=y['capitalBridgeItems'];rv+=sum(x['percentGDP']for x in cap if x['label']=='Capital transfers received');ev+=sum((-1 if 'subtract'in x['label']else 1)*x['percentGDP']for x in cap if x['label']!='Capital transfers received');assert abs(rv-v['totalRevenue']['percentGDP'])<.0001;assert abs(ev-v['totalExpenditure']['percentGDP'])<.0001
 if yr=='2023':assert abs(v['MedicareBenefits']['percentGDP']+v['MedicaidBenefits']['percentGDP']-6.8427830115)<1e-8
br=cn['consolidationBridgeUnchanged'];assert abs(br['derivedConsolidatedRevenue']-br['publishedConsolidatedRevenue'])<.004;assert abs(br['derivedConsolidatedExpenditure']-br['publishedConsolidatedExpenditure'])<.004
report=dict(status='PASS',presets=len(b['countries']),openingYear=2023,verifiedRawFiles=len(verified),optionalBEAWorkbooksNotBundled=optionalMissing,maxCompleteCategoryResidualPctGDP=maxResidual,checks=['All30 opening fiscal totals match retained primary extracts.','Economic classifications sum without adding memo/functional totals twice; rounding is explicit.','Denmark2025 revenue remains missing; latest references are not opening2023 inputs.','China four-budget consolidation removes internal transfers/land flows; missing current/capital splits remain source nulls.','BEA native total expenditure subtracts consumption of fixed capital. Health benefits and pension interest definitions are distinct.'],limitations=['Hashes check file integrity, not statistical truth. Official statistics can be revised.','Some category observations remain unavailable. Cash-equivalent model counterparts and future behavior are assumptions.'])
(R/'dist/data/fiscal_source_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {runEnsemble, simulate} from '../dist/engine.mjs';
import {simulationFindings} from '../dist/findings.mjs';
import {sanitize} from '../dist/parameters.mjs';
import {addImportPrices, clearGoodsMarket, tradeConditions} from '../dist/trade.mjs';

const root = new URL('../', import.meta.url);
const read = path => JSON.parse(readFileSync(new URL(path, root)));
const profiles = read('research/frozen_engine_v1_16/profiles.json');
const italy = profiles.find(profile => profile.code === 'ITA').params;
const seed = 2026;
const params = sanitize({...italy, policyDynamics:0,currencyDynamics:0,tradeEnabled:1,
  foreignPortfolioWeight:0,initialHouseholdForeignAssets:0,periods:8,replications:2,seed});
const close = (a,b) => assert(Math.abs(a-b)<1e-8*Math.max(1,Math.abs(a),Math.abs(b)), `${a} differs from ${b}`);
const opening = tradeConditions(100,1,1,params);
close(opening.realExchangeRate,100);
close(opening.importBudgetShare,params.importShare/100);
close(opening.exportOrders,params.exportDemand);
const weak = tradeConditions(90,1,1,params);
const reversed = tradeConditions(90,1.2,1,params);
close(weak.realExchangeRate,90);
close(reversed.realExchangeRate,108);
assert(weak.importPrice>opening.importPrice);
assert(weak.importBudgetShare<opening.importBudgetShare && opening.importBudgetShare<reversed.importBudgetShare);
assert(weak.exportOrders>opening.exportOrders && opening.exportOrders>reversed.exportOrders);
close(tradeConditions(100,1,1,params,1.05).exportOrders,1.05*opening.exportOrders);
const high = clearGoodsMarket([{inventory:1,share:1}],1,1,{exportOrders:2,exportBid:1.3});
const low = clearGoodsMarket([{inventory:1,share:1}],1,1,{exportOrders:2,exportBid:.65});
close(high.domesticSales[0],0);
close(high.exportSales[0],1);
close(low.domesticSales[0],.8);
close(low.exportSales[0],.2);
assert(high.exportReceipts[0]>high.exportSales[0]);
const moreCompetitive=tradeConditions(100,1,1,params,1,1.2);
assert(moreCompetitive.exportOrders>opening.exportOrders);
assert(moreCompetitive.importBudgetShare<opening.importBudgetShare);


const manifest = read('dist/data/official_data_manifest.json');
for (const name of ['trade_nominal','bis_real_exchange_rates']) {
  const entry = manifest.find(source=>source.name===name);
  assert.equal(createHash('sha256').update(readFileSync(new URL(entry.path,root))).digest('hex'),entry.sha256);
}

let maxResidual = 0, settledYears = 0;
function reconcile(rows) {
  for (let year=1; year<rows.length; year++) {
    const r = rows[year], prior = rows[year-1];
    const delta = key => r[key]-prior[key];
    close(r.householdGoods,r.consumptionGoods+r.imports);
    close(r.nominalImports,r.imports*r.importPrice);
    close(r.nominalExports,r.exports*r.exportPrice);
    assert(r.exports>=0 && r.exports<=r.exportOrders+1e-8 && r.imports>=0);
    close(r.currentAccount,r.nominalExports-r.nominalImports+r.foreignAssetIncome);
    close(r.nationalSaving-r.grossInvestment,r.currentAccount);
    close(delta('netForeignPosition'),r.currentAccount+r.foreignAssetValuation);
    close(delta('privateMoney'),delta('loans')+delta('bankPublicDebt')-delta('bankEquity')
      -delta('governmentDeposits')+delta('bankNetForeignPosition'));
    close(r.nominalOutput,r.nominalConsumption+r.nominalGovernment+r.grossInvestment+r.nominalExports-r.nominalImports);
    close(r.output,r.consumption+r.government+r.investment+r.inventoryChange+r.exports-r.imports);
    close(r.goodsOutput,r.consumptionGoods+r.government+r.investment+r.inventoryChange+r.exports);
    close(r.inflation,100*(r.consumerPriceIndex/prior.consumerPriceIndex-1));
    maxResidual = Math.max(maxResidual,r.relativeResidual,Math.abs(r.savingIdentityResidual)/Math.max(1,r.nominalOutput));
    assert(r.relativeResidual<1e-8);
    settledYears++;
  }
}

const closed = simulate({...params,tradeEnabled:0},seed).rows;
const open = simulate(params,seed).rows;
close(open[0].output,closed[0].output);
assert(open[0].exports>0&&open[0].imports>0);
for(const opening of [open[0],closed[0]])close(opening.nominalOutput,
 opening.nominalConsumption+opening.nominalGovernment+opening.grossInvestment+opening.nominalExports-opening.nominalImports);
assert(open.some(row=>row.exports>0) && open.some(row=>row.imports>0));
assert(open.some(row=>row.realExchangeRate!==row.currencyStrength));
assert(closed.every(row=>row.exports===0 && row.imports===0 && row.netForeignPosition===0));
const imports = simulate({...params,exportDemand:0},seed).rows;
const exports = simulate({...params,importShare:0},seed).rows;
assert(imports.slice(1).every(row=>row.exports>0 && row.imports>0 && row.currentAccount<0));
assert(exports.every(row=>row.imports>0 && row.exports>0 && (row.initialObservation||row.currentAccount>=0)));
assert(exports.some(row=>row.currentAccount>0));
const stop = simulate(params,seed,{paths:[{key:'tradeEnabled',start:4,end:4,target:0,mode:'step'}]}).rows;
assert.deepEqual(stop.slice(0,4),open.slice(0,4));
assert(stop.slice(4).every(row=>row.exports===0 && row.imports===0 && row.netForeignPosition===stop[3].netForeignPosition));
const switched = addImportPrices({consumerPrice:2,inflation:0},{consumerPrice:2,consumerPriceIndex:105,importConsumerPrice:1},1.2,0,true);
assert.equal(switched.consumerPriceIndex,105);
assert.equal(switched.inflation,0);
for (const rows of [closed,open,imports,exports,stop]) reconcile(rows);

const exchange = {...params,currencyDynamics:1,currencyAdjustment:1,currencyRateResponse:0};
const path = target => [{key:'currencyPressure',start:3,end:4,target,mode:'pulse'}];
const neutral = simulate(exchange,seed).rows;
const depreciation = simulate(exchange,seed,{paths:path(-10)}).rows;
const appreciation = simulate(exchange,seed,{paths:path(10)}).rows;
assert.deepEqual(depreciation.slice(0,3),neutral.slice(0,3));
assert(depreciation[3].realExchangeRate<neutral[3].realExchangeRate);
assert(depreciation[3].importPrice>neutral[3].importPrice);
assert(depreciation[3].importBudgetShare<neutral[3].importBudgetShare);
assert(depreciation[3].exportOrders>neutral[3].exportOrders);
assert(depreciation[3].inflation>neutral[3].inflation && neutral[3].inflation>appreciation[3].inflation);
for (const rows of [neutral,depreciation,appreciation]) reconcile(rows);

const result = runEnsemble({params,reference:{...params,tradeEnabled:0}});
assert(simulationFindings(result).findings.some(line=>line.includes('Foreign customers')));
for (const profile of profiles) for (const stressSeed of [seed,9945]) {
  const p = {...profile.params, tradeEnabled:1, policyDynamics:1, currencyDynamics:1, periods:40};
  reconcile(simulate(p,stressSeed,{paths:path(-20)}).rows);
}
console.log(JSON.stringify({status:'PASS',profileStressPaths:56,settledYears,maxResidual}));

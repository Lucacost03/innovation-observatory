import fs from'node:fs';import assert from'node:assert/strict';
import {studentTwoSidedP,studentCritical95,pairedMeanInference}from'../dist/inference.mjs';
import {inferenceHTML}from'../dist/inference-view.mjs';import {runEnsemble,summarize}from'../dist/engine.mjs';import {metricValue}from'../dist/parameters.mjs';
const read=p=>JSON.parse(fs.readFileSync(new URL('../'+p,import.meta.url))),fixture=read('research/growth_audit_1_27/student_t_reference.json'),profile=read('dist/data/profiles.json').find(p=>p.code==='USA');
const close=(a,b,label)=>assert(Math.abs(a-b)<1e-9*Math.max(1,Math.abs(b)),label+': '+a+'/'+b);
for(const[df,value]of Object.entries(fixture.critical95))close(studentCritical95(+df),value,'t critical '+df);
for(const x of fixture.tailProbabilities)close(studentTwoSidedP(x.t,x.df),x.p,'t p-value');
const a=pairedMeanInference([1,2,3,4,5]);close(a.mean,3,'mean');close(a.standardError,Math.sqrt(.5),'paired SE');close(a.low,1.036756838522439,'95% lower');close(a.high,4.9632431614775605,'95% upper');assert(a.significant);assert.equal(pairedMeanInference([-2,-1,0,1,2]).significant,false);assert.equal(pairedMeanInference([1]).low,null);assert.equal(pairedMeanInference([0,0,0]).pValue,null);assert.equal(pairedMeanInference([2,2,2]).status,'zeroVariance');assert.equal(pairedMeanInference([null,NaN,1]).n,1);
const p={...profile.params,periods:8,replications:10},control=runEnsemble({params:p,reference:p});
assert(control.paired.every(x=>x.output===0&&x.realGDPPerCapitaGrowth===0),'Identical treatment/control');assert.equal(control.inference.effects.output.status,'identicalPairs');assert(inferenceHTML(control).includes('Identical paired GDP outcomes'));
// The exogenous-effect schema is validated by the same engine as the UI.
const treated=runEnsemble({params:{...p,consumptionIncome:p.consumptionIncome*.9},reference:p});const expected=pairedMeanInference(treated.raw.scenario.map((r,i)=>100*(r.rows.at(-1).output/treated.raw.baseline[i].rows.at(-1).output-1)));close(treated.inference.effects.output.low,expected.low,'Paired endpoint CI');close(treated.inference.effects.output.pValue,expected.pValue,'Paired endpoint test');assert.equal(treated.inference.effects.output.n,10,'One sample per seed, not per year');
for(const r of [...treated.raw.scenario,...treated.raw.baseline]){assert.equal(metricValue(r.rows[0],'realGDPPerCapitaGrowth'),null);for(let t=1;t<r.rows.length;t++)close(r.rows[t].realGDPPerCapitaGrowth,100*((r.rows[t].output/r.rows[t].populationIndex)/(r.rows[t-1].output/r.rows[t-1].populationIndex)-1),'GDP/population annual growth');}
const s=summarize(Array.from({length:101},(_,i)=>({rows:[{t:0,output:i}]})));close(s[0].output.low,2.5,'2.5th percentile');close(s[0].output.high,97.5,'97.5th percentile');
const one=runEnsemble({params:{...p,replications:1},reference:p});assert.equal(one.inference.effects.output.status,'insufficientSeeds');assert(inferenceHTML(one).includes('single seed cannot estimate'));
console.log('PASS:199 Student-t critical values,49 independent tail-probability references, paired/degenerate/single-seed cases,42 experiment paths,95% seed quantiles and exact annual per-capita growth.');

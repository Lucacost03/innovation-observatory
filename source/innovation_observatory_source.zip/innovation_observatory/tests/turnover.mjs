import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {Economy, simulate, runEnsemble, decomposeTechnology, quantile} from '../dist/engine.mjs';
import {DEFAULTS, MODEL_VERSION} from '../dist/parameters.mjs';
import {exitHazards} from '../dist/demography.mjs';
import {learnForeign} from '../dist/foreign.mjs';
import {simulate as legacy} from '../research/frozen_v1_2/engine.mjs';
import {simulate as prior} from '../research/frozen_v1_3/engine.mjs';
import {DEFAULTS as oldDefaults} from '../research/frozen_v1_2/parameters.mjs';
const root = new URL('../', import.meta.url);
const read = name => JSON.parse(fs.readFileSync(new URL(name, root)));
const profiles = read('research/frozen_engine_v1_16/profiles.json');
const close = (a,b) => assert(Math.abs(a-b) < 1e-8*Math.max(1,Math.abs(a),Math.abs(b)), `${a} != ${b}`);
let runs = 0, previousRuns = 0, observations = 0, maxCapitalResidual = 0, maxAccountingResidual = 0;
const checks = [];
function run(p, seed, options = {}) {
  runs++;
  const r = simulate(p,seed,options);
  for (let t=0;t<r.rows.length;t++) {
    const x=r.rows[t]; observations++;
    maxCapitalResidual=Math.max(maxCapitalResidual,Math.abs(x.capitalResidual));
    maxAccountingResidual=Math.max(maxAccountingResidual,x.relativeResidual);
    assert(Object.values(x).every(Number.isFinite));
    assert(x.firmCount>=2 && x.firmCount<=Math.max(r.params.firms,r.params.maxFirms));
    if (t) {
      const before=r.rows[t-1];
      assert.equal(x.firmCount,before.firmCount+x.entries-x.exits);
      assert.equal(x.entryAttempts,x.entries+x.unfundedEntries+x.capBlockedEntries);
      close(x.knowledge-before.knowledge,x.ownKnowledgeGain+x.diffusionGain+x.foreignGainFixed);
      close(x.capital+x.dormantCapital,(before.capital+before.dormantCapital)*(1-r.params.depreciation/100)+x.investment);
    }
    if (!options.snapshots) continue;
    const active=r.agents[t], ids=new Set(active.map(f=>f.id));
    assert.equal(ids.size,active.length); assert.equal(active.length,x.firmCount);
    const degree=Math.min(r.params.networkDegree,active.length-1);
    active.forEach((f,i)=>{
      assert(f.birthTime<=t); assert(f.a>0 && f.cash>=-1e-8 && f.capital>=-1e-8);
      const links=r.networks[t][i]; assert.equal(links.length,degree);
      assert.equal(new Set(links).size,links.length);
      assert(links.every(j=>j>=0&&j<active.length&&j!==i));
    });
    if (t) {
      const prev=new Set(r.agents[t-1].map(f=>f.id));
      assert.equal(active.filter(f=>!prev.has(f.id)).length,x.entries);
      assert.equal(r.agents[t-1].filter(f=>!ids.has(f.id)).length,x.exits);
    }
  }
  return r;
}

const p={...DEFAULTS,firms:30,households:100,periods:40,replications:1};
const hazards=exitHazards([{a:.5,arrears:0},{a:1,arrears:0},{a:2,arrears:0}],p);
assert(hazards[0]>hazards[1]&&hazards[1]>=hazards[2]);
close(hazards.reduce((a,b)=>a+b,0)/3,p.exitRate/100);
const equal=exitHazards([{a:.5},{a:1},{a:2}],{...p,exitSelection:0,exitDistress:0});
equal.forEach(x=>close(x,p.exitRate/100));
const sized=exitHazards([{a:1,capital:.2},{a:1,capital:1},{a:1,capital:5}],{...p,exitSizeSensitivity:1});
assert(sized[0]>sized[1]&&sized[1]>sized[2]);close(sized.reduce((a,b)=>a+b,0)/3,p.exitRate/100);
assert.deepEqual(exitHazards([{a:.2},{a:2}],{...p,firmDynamics:0}),[0,0]);
assert.deepEqual(exitHazards([{a:.2},{a:2}],{...p,exitRate:0}),[0,0]);
checks.push('At equal arrears, worse opening technology raises relative exit risk; mean nonfinancial risk matches the chosen aggregate proxy. Selection can be disabled.');

for(const m of read('research/source_snapshots/TURNOVER_MANIFEST.json'))
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(new URL(m.path,root))).digest('hex'),m.sha256);
const front=read('dist/data/foreign_frontiers.json');
for(const pr of profiles) {
  for(const [code,prefix] of [['USA','us'],['CHN','china'],['ROW','row']]) {
    close(pr.params[prefix+'Technology'],front.nationalCTFP[code]/front.nationalCTFP[pr.code]);
    close(pr.params[prefix+'Growth'],front.historicalGrowthPct[code]);
  }
  assert.equal(pr.provenance.entryRate.year,2023);assert.equal(pr.provenance.exitRate.year,2023);
}
checks.push('All three new official source files match their frozen SHA256; all 28 presets have 2023 birth/death observations and reproducible national TFP ratios. Future growth and firm leader premiums are explicitly proxy/assumption mappings.');

for(const pr of profiles.filter(p=>['ITA','EU27','DEU'].includes(p.code)))for(let seed=1;seed<=3;seed++) {
  const config={...oldDefaults,...pr.params,firmSizeDispersion:oldDefaults.heterogeneity,capacityCompetition:0,firmDynamics:0,foreignContact:0,priceDynamics:0,publicBudgetStability:0};
  const old=legacy(config,seed);previousRuns++;
  const now=prior(config,seed);previousRuns++;
  for(let t=0;t<old.rows.length;t++)for(const [key,value]of Object.entries(old.rows[t]))close(value,now.rows[t][key]);
}
checks.push('Archived 1.3 reproduces all shared 1.2 row fields for nine paired comparisons when both channels and the capacity weighting are disabled.');

const capacityCase=new Economy({...p,entryRate:0,exitRate:0,shareAdjustment:1,marketSelection:0},60);
capacityCase.firms[0].capital*=10;const desiredShare=capacityCase.firms[0].capital/capacityCase.firms.reduce((s,f)=>s+f.capital,0);capacityCase.step(1,1);close(capacityCase.firms[0].share,desiredShare);
checks.push('Demand shares account for productive capacity, preventing tiny startups from receiving the same target demand as large incumbents at equal technology.');
const a=run(p,2026,{snapshots:true}),b=run(p,2026,{snapshots:true});assert.deepEqual(a,b);
assert(a.events.some(x=>x.type==='entry')&&a.events.some(x=>x.type==='exit'));
const seen=new Set(a.agents[0].map(f=>f.id)),dead=new Set();
for(let t=1;t<a.agents.length;t++) {
  const ids=new Set(a.agents[t].map(f=>f.id));
  for(const f of a.agents[t-1])if(!ids.has(f.id))dead.add(f.id);
  for(const f of a.agents[t]){assert(!dead.has(f.id));if(!seen.has(f.id)){assert.equal(f.birthTime,t);seen.add(f.id);}}
}
const future=run(p,2026,{paths:[{key:'exitSelection',start:20,end:20,target:10,mode:'step'},
  {key:'foreignContact',start:20,end:20,target:1,mode:'step'}]});
assert.deepEqual(a.rows.slice(0,20),future.rows.slice(0,20));
checks.push('Exact repeatability, no future intervention leakage, permanent non-reused IDs, changing firm counts, entry/exit event logs and valid repaired network snapshots pass.');

const lower=learnForeign(2,{USA:1,CHN:1,ROW:1},{...p,foreignTechDispersion:0,foreignContact:1},1,1,1,()=>.1);
assert.equal(lower.gain,0);assert.equal(lower.a,2);
const direct=learnForeign(1,{USA:2,CHN:2,ROW:2},{...p,foreignTechDispersion:0,foreignContact:1,foreignAdoption:.2,absorptiveCapacity:.5,humanCapital:1},1,1,1,()=>.1);
close(direct.a,1.1);
for(let seed=1;seed<=10;seed++) {
  const pure={...p,firmDynamics:0,innovationEfficiency:0,diffusion:0,foreignTechDispersion:0,foreignContact:1,foreignAdoption:.2,usTechnology:2,chinaTechnology:.1,rowTechnology:.1,foreignLeaderPremium:1,usGrowth:0,chinaGrowth:0,rowGrowth:0};
  const r=run(pure,seed,{snapshots:true});
  for(let t=1;t<r.agents.length;t++)r.agents[t].forEach((f,i)=>{
    assert(f.a>=r.agents[t-1][i].a-1e-12);
    if(f.foreignGain)assert.equal(f.foreignSource,'USA');
  });
}
const disabled={...p,firmDynamics:0,innovationEfficiency:0,diffusion:0,foreignContact:0};
const none=run(disabled,77,{snapshots:true});
for(let t=1;t<none.agents.length;t++)none.agents[t].forEach((f,i)=>close(f.a,none.agents[0][i].a));
// Isolate delayed learning from the immediate foreign-competition channel.
const donorLagParams={...p,firmDynamics:0,tradeEnabled:0};
const donorFuture=run(donorLagParams,77,{paths:[{key:'usGrowth',start:8,end:8,target:4,mode:'step'}]});
const donorBase=run(donorLagParams,77);assert.deepEqual(donorFuture.rows.slice(0,8),donorBase.rows.slice(0,8));
assert(donorFuture.rows[8].foreignTFPIndexUSA>donorBase.rows[8].foreignTFPIndexUSA);
for(const t of [8,9])close(donorFuture.rows[t].technology,donorBase.rows[t].technology);
checks.push('Foreign adoption is nonnegative, gap-bounded, delayed and independently switchable. Inferior foreign donors never lower technology. Future donor growth does not enter an earlier adoption decision.');

const dormant=run({...p,entryRate:0,exitRate:30,liquidationBidShare:0,foreignContact:0},88,{snapshots:true});
assert(dormant.rows.some(x=>x.dormantCapital>0));assert(dormant.rows.some(x=>x.floorBlockedExits>0));
const cap=run({...p,firms:120,maxFirms:120,entryRate:30,exitRate:0,householdWealth:1000},99);
assert(cap.rows.some(x=>x.capBlockedEntries>0));
for(const blockedFunding of [{financialMarket:0,entryFinanceShare:0},{financialMarket:1,ventureWeight:0}]){
 const unfunded=run({...p,entryRate:30,exitRate:0,...blockedFunding},99);
 assert(unfunded.rows.some(x=>x.unfundedEntries>0));assert.equal(unfunded.rows.at(-1).cumulativeEntries,0);
}
checks.push('No startup gets unfunded equity or free assets; common owners fund their own pro-rata equity contributions; all opportunities reconcile. Unsold assets remain dormant. Population floor/cap interventions are counted explicitly. Capital and inventories reconcile across transfers and depreciation.');

const changed=runEnsemble({params:{...p,replications:2},reference:{...p,firmDynamics:0,foreignContact:0}});runs+=4;
for(const side of ['baseline','scenario'])for(const r of changed.raw[side])for(const x of r.rows){observations++;maxAccountingResidual=Math.max(maxAccountingResidual,x.relativeResidual);}
const d=changed.diagnostics.firstSeed;
close(d.totalPercent,changed.paired[0].technology);
close(d.totalPercent,d.withinFirmPercent+d.reallocationPercent+d.entryPercent+d.exitPercent);
assert(d.scenarioOnlyFirms+d.referenceOnlyFirms>0);
checks.push('Technology comparisons match permanent IDs and reconcile surviving-firm learning, reallocation and unmatched population contributions even when the two populations differ.');

// Predeclared factorial comparison. No coefficients are selected on outcomes.
const cases=[],modes=[['legacy_fixed',{firmDynamics:0,foreignContact:0}],['turnover_only',{foreignContact:0}],
  ['foreign_only',{firmDynamics:0}],['both',{}]];
for(const pr of profiles)for(let k=0;k<5;k++)for(const [mode,changes]of modes) {
  const seed=31001+k*7919,r=run({...DEFAULTS,...pr.params,...changes,replications:1},seed),z=r.rows[0],last=r.rows.at(-1);
  cases.push({country:pr.code,seed,mode,steps:40,finalGDP:last.output,finalTechnology:last.technology,
    finalEmployment:last.employment,finalDebtGDP:last.publicDebt/Math.max(1e-9,last.output),
    finalFirms:last.firmCount,entries:last.cumulativeEntries,exits:last.cumulativeExits,
    foreignAdoptions:r.rows.reduce((s,x)=>s+x.foreignAdopters,0),
    floorBound:r.rows.some(x=>x.floorBlockedExits>0),capBound:r.rows.some(x=>x.capBlockedEntries>0),
    employmentBelow50:r.rows.some(x=>x.employment<50),debtAbove300GDP:r.rows.some(x=>x.publicDebt>3*Math.max(1e-9,x.output)),
    firstStepGrowth:100*(r.rows[1].output/z.output-1),unfundedEntryAttempts:r.rows.reduce((s,x)=>s+x.unfundedEntries,0)});
}
const summary=modes.map(([mode])=>{const rows=cases.filter(x=>x.mode===mode);return {mode,runs:rows.length,
  employmentBelow50:rows.filter(x=>x.employmentBelow50).length,debtAbove300GDP:rows.filter(x=>x.debtAbove300GDP).length,
  floorBound:rows.filter(x=>x.floorBound).length,capBound:rows.filter(x=>x.capBound).length,
  medianFinalGDP:quantile(rows.map(x=>x.finalGDP),.5),medianFinalEmployment:quantile(rows.map(x=>x.finalEmployment),.5),
  medianFinalDebtGDP:quantile(rows.map(x=>x.finalDebtGDP),.5),medianFinalFirms:quantile(rows.map(x=>x.finalFirms),.5)};});
const paired=cases.filter(x=>x.mode==='both').map(s=>{const b=cases.find(x=>x.country===s.country&&x.seed===s.seed&&x.mode==='legacy_fixed');return {country:s.country,seed:s.seed,gdpGap:100*(s.finalGDP/b.finalGDP-1),technologyGap:100*(s.finalTechnology/b.finalTechnology-1),employmentGap:s.finalEmployment-b.finalEmployment};});
checks.push('Executed a predeclared 2×2 mechanism comparison: all 28 presets × five common seeds × four channel combinations, 40 steps. All outcomes are retained; plausibility flags are not forecast scores.');
const report={modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),status:'PASS: numerical and accounting tests; empirical dynamics NOT VALIDATED',
  currentEngineRuns:runs,frozenEngineRuns:previousRuns,checkedObservations:observations,maxCapitalResidual,maxAccountingResidual,
  checks,coverage:front.coverage,protocol:'28 presets × 5 common seeds × 4 channel combinations × 40 annual steps. No parameter selection, no holdout or forecast-accuracy claim.',
  factorial:summary,pairedSummary:{pairs:paired.length,negativeGDP:paired.filter(x=>x.gdpGap<0).length,negativeTechnology:paired.filter(x=>x.technologyGap<0).length},
  limitations:['No firm-level estimation of selection, leader premiums, adoption speed, entry finance or liquidation prices.',
    'Annual 2023 enterprise rates and 2013–2023 donor growth are extrapolated as scenarios; not verified future rates.',
    'Extreme debt/employment and population-bound cases remain visible. Aggregate source alignment is not validation.',
    'No goods trade, FX, FDI, foreign finance, full R&D capitalization or multi-sector firm data.']};
fs.writeFileSync(new URL('dist/data/turnover_validation.json',root),JSON.stringify(report,null,2));
fs.writeFileSync(new URL('research/turnover_experiments.json',root),JSON.stringify({report,cases,paired},null,2));
const fields=Object.keys(cases[0]);
fs.writeFileSync(new URL('dist/data/turnover_experiments.csv',root),fields.join(',')+'\n'+cases.map(x=>fields.map(k=>x[k]).join(',')).join('\n')+'\n');
console.log(JSON.stringify(report,null,2));

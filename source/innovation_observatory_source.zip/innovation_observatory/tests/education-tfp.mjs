import fs from 'node:fs';
import assert from 'node:assert/strict';
import {simulate,Economy} from '../dist/engine.mjs';
import {educationTransmission} from '../dist/education-transmission.mjs';
import {DEFAULTS,MODEL_VERSION} from '../dist/parameters.mjs';
import {restoreConfiguration} from '../dist/configuration.mjs';
const profiles=JSON.parse(fs.readFileSync(new URL('../dist/data/profiles.json',import.meta.url)));
const close=(a,b,label,t=1e-9)=>assert(Math.abs(a-b)<t*Math.max(1,Math.abs(a),Math.abs(b)),`${label}: ${a} != ${b}`);
let paths=0,years=0,maxResidual=0,monotonicFirms=0;
function check(r){paths++;years+=r.rows.length-1;for(const x of r.rows){assert(Object.values(x).every(Number.isFinite));assert(x.relativeResidual<1e-8);maxResidual=Math.max(maxResidual,x.relativeResidual);close(x.labourIncomeShare+x.capitalIncomeShare,100,'Income shares');}}
// Isolate the research/adoption channel at the same skills, funding and production.
// A change in skills transmission cannot manufacture opening assets or output.
for(const p of profiles){
 const params={...p.params,populationDynamics:0,firmDynamics:0,educationTFPResponse:1};
 const a=new Economy(params,2026),b=new Economy({...params,educationTFPResponse:2},2026);
 a.society.human*=1.1;b.society.human*=1.1;
 // Cohort skills are now the underlying stock; change those in this controlled state too.
 for(const e of [a,b])if(e.society.ageCohorts)e.society.ageCohorts.skills=e.society.ageCohorts.skills.map(x=>1.1*x);
 const ar=a.step(1,1),br=b.step(1,1);
 close(ar.output,br.output,'Same-period goods unchanged');
 assert(br.educationTFPMultiplier>ar.educationTFPMultiplier);
 for(let i=0;i<a.firms.length;i++){assert(b.firms[i].a+1e-12>=a.firms[i].a,'More skilled learning cannot lower a firm’s technology in the controlled state');monotonicFirms++;}
 close(ar.humanCapitalIndex,br.humanCapitalIndex,'No duplicate skill accumulation');
}
const results=[];
for(const p of profiles)for(const seed of [2026,9945])for(const strength of [1,2]){
 const params={...p.params,periods:40,educationTFPResponse:strength};
 const pathsIn=['publicEducationQuality','privateEducationQuality'].map(key=>({key,start:4,end:4,target:1.5*p.params[key],mode:'step'}));
 const r=simulate(params,seed,{paths:pathsIn,snapshots:false});check(r);
 results.push({country:p.code,seed,strength,finalGDP:r.rows.at(-1).output,finalTFP:r.rows.at(-1).tfpLevel,finalTechnology:r.rows.at(-1).technology,finalSkills:r.rows.at(-1).humanCapitalIndex,finalMultiplier:r.rows.at(-1).educationTFPMultiplier});
}
const p=profiles.find(p=>p.code==='ITA'),base={...p.params,periods:25};
const before=simulate(base,2026),after=simulate(base,2026,{paths:[{key:'educationTFPResponse',start:15,end:15,target:2,mode:'step'}]});check(before);check(after);
for(let t=0;t<15;t++)assert.deepEqual(before.rows[t],after.rows[t],'Future transmission changes cannot affect prior years');
for(const strength of [0,1,3]){const r=simulate({...base,educationEnabled:0,educationTFPResponse:strength},2026);check(r);for(const row of r.rows)close(row.educationTFPMultiplier,1,'Disabled education has no transmission');}
// Source updates preserve authored changes relative to the former anchor.
const oldAnchor=.788781,raw={...p.params,initialEducationQuality:oldAnchor,publicEducationQuality:oldAnchor*1.4,privateEducationQuality:oldAnchor};
const saved={country:'ITA',modelVersion:'1.21.0',params:raw,reference:{...raw,publicEducationQuality:oldAnchor},paths:[{key:'publicEducationQuality',target:oldAnchor*1.5,start:4,end:4,mode:'step'}],shocks:[],preset:'custom'};
const migrated=restoreConfiguration(saved,profiles);assert(!migrated.rebuildPreset);close(migrated.state.params.publicEducationQuality/p.params.initialEducationQuality,1.4,'Relative edit preserved');close(migrated.state.paths[0].target/p.params.initialEducationQuality,1.5,'Relative path preserved');assert.deepEqual(restoreConfiguration(migrated.state,profiles).state,migrated.state);
assert.equal(DEFAULTS.educationTFPResponse,1,'Unestimated stronger magnitude is an explicit experiment');
const paired=[];
for(let i=0;i<results.length;i+=2){const a=results[i],b=results[i+1];paired.push({country:a.country,seed:a.seed,GDPgap:b.finalGDP/a.finalGDP-1,TFPgap:b.finalTFP/a.finalTFP-1,technologyGap:b.finalTechnology/a.finalTechnology-1});}
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),paths,years,maxResidual,monotonicFirms,results,paired,
 checks:['All 30 presets and two common seeds tested at the old and stronger skills-transmission strengths, with a year-4 education-quality reform. All outcomes retained.','At identical skills, funding and production, stronger learning did not lower firm technology or create same-period goods.','Skills influence innovation probabilities and domestic/foreign adoption, subject to existing bounds; they do not multiply GDP directly.','Transmission changes have no effect before their scheduled year; disabling education gives a neutral multiplier.','The 1.21 source-anchor update preserves relative settings, references and intervention targets, and migrates once.'],
 interpretation:'This is a mechanism and accounting sensitivity study, not an empirical estimate of the education elasticity. Strength 2 is available in Education & innovation; national data presets retain strength 1. A stronger relationship can amplify gains and losses from skills changes. GDP and TFP comparisons are conditional outcomes, not proof of higher forecasting accuracy.'};
fs.writeFileSync(new URL('../dist/data/education_tfp_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,results:undefined,paired:undefined}));

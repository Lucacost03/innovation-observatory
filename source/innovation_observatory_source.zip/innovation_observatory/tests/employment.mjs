import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import {simulate, quantile} from '../dist/engine.mjs';
import {matchEmployment} from '../dist/labor.mjs';
import {DEFAULTS, MODEL_VERSION, sanitize} from '../dist/parameters.mjs';
import {simulate as previous} from '../research/frozen_v1_3/engine.mjs';

const root = new URL('../', import.meta.url);
const read = name => JSON.parse(fs.readFileSync(new URL(name, root)));
const profiles = read('research/frozen_engine_v1_16/profiles.json');
const oldProfiles = read('research/frozen_v1_3/profiles.json');
const evidence = read('dist/data/evidence.json');
const frontiers = read('dist/data/foreign_frontiers.json');
const close = (a, b) => assert(Math.abs(a - b) < 1e-8 * Math.max(1, Math.abs(a), Math.abs(b)), `${a} != ${b}`);

const manifest = read('research/source_snapshots/LABOUR_MANIFEST.json');
const sourceBytes = fs.readFileSync(new URL(manifest.path, root));
assert.equal(crypto.createHash('sha256').update(sourceBytes).digest('hex'), manifest.sha256);
const source = JSON.parse(sourceBytes);
for (const profile of profiles) {
  for (const key of ['employmentSeparation', 'jobFindingRate']) {
    const provenance = profile.provenance[key];
    const [flow, stay] = provenance.components;
    const expectedGeo = provenance.status === 'proxy' ? profile.geo : 'EU27_2020';
    for (const row of [flow, stay]) {
      assert.equal(row.geo, expectedGeo);
      const index = source.id.reduce((i, dim, j) => i * source.size[j] + source.dimension[dim].category.index[row[dim]], 0);
      close(row.value, source.value[index]);
    }
    close(profile.params[key], 100 * flow.value / (flow.value + stay.value));
  }
  assert.equal(sanitize(profile.params).employmentRate, profile.params.employmentRate);
}
assert.equal(evidence.laborTransitionCoverage.employmentSeparation, 25);
assert.equal(evidence.laborTransitionCoverage.jobFindingRate, 27);

const weights = fs.readFileSync(new URL('dist/data/pwt_rest_of_world_weights.csv', root), 'utf8');
// Split the numeric tail so country names containing commas retain their quotes.
const donors = weights.trim().split(/\r?\n/).slice(1).map(line => {
  const code = line.split(',')[0];
  const [ctfp, gdp, end, start, weight, growth] = line.split(',').slice(-6).map(Number);
  assert(!['USA', 'CHN'].includes(code));
  close(growth, 100 * ((end / start) ** .1 - 1));
  return {code, ctfp, gdp, weight, growth};
});
assert.equal(donors.length, frontiers.restOfWorld.coveredEconomies);
assert.equal(new Set(donors.map(x => x.code)).size, donors.length);
const totalGDP = donors.reduce((sum, x) => sum + x.gdp, 0);
donors.forEach(x => close(x.weight, x.gdp / totalGDP));
close(donors.reduce((sum, x) => sum + x.weight * x.ctfp, 0), frontiers.nationalCTFP.ROW);
close(donors.reduce((sum, x) => sum + x.weight * x.growth, 0), frontiers.historicalGrowthPct.ROW);

const allocation = matchEmployment([80, 0], [0, 100], 5, 50);
close(allocation.allocations[1].transferred, 76);
close(allocation.allocations[1].hired, 10);
close(allocation.searchCapacity, 10);
assert.equal(sanitize({employmentRate: 100}).employmentRate, 99.9);

let maxEmployment = 0, minUnemployment = 100, maxEmploymentResidual = 0, currentRuns = 0, frozenRuns = 0;
function checkRun(params, seed, options) {
  const result = simulate(params, seed, options);
  currentRuns++;
  assert.equal(result.stepYears, 1);
  for (const [i, row] of result.rows.entries()) {
    maxEmployment = Math.max(maxEmployment, row.employment);
    minUnemployment = Math.min(minUnemployment, row.unemployment);
    maxEmploymentResidual = Math.max(maxEmploymentResidual, Math.abs(row.employmentResidual));
    assert(row.employment >= 0 && row.employment <= 99.9 + 1e-8);
    assert(row.unemployment > 0);
    close(row.employment + row.unemployment, 100);
    assert.equal(row.foreignAdopters, row.foreignUSA + row.foreignCHN + row.foreignROW);
    if (i > 0) {
      const last = result.rows[i - 1];
      close(row.openingEmployment, last.employment - last.exitsEmployment);
      close(row.employment, row.openingEmployment - row.employmentToUnemployment + row.hiresFromUnemployment);
      assert(row.hiresFromUnemployment <= (100 - row.openingEmployment) * params.jobFindingRate / 100 + 1e-8);
    }
  }
  return result;
}

const italy = profiles.find(x => x.code === 'ITA').params;
const priorItaly = oldProfiles.find(x => x.code === 'ITA').params;
const oldWarm = previous({...priorItaly, burnIn: 40}, 2026).rows[0];
frozenRuns++;
assert(oldWarm.employment >= 100 - 1e-8);
const newWarm = checkRun({...DEFAULTS, ...italy, burnIn: 40}, 2026).rows[0];
assert(newWarm.employment < 100);
const extreme = checkRun({...DEFAULTS, employmentRate: 100, employmentSeparation: .1, jobFindingRate: 99}, 2026,
  {shocks: [{type: 'demand', start: 1, duration: 40, magnitude: 100, recovery: 0}]});
close(extreme.rows[0].employment, 99.9);

// With only public purchases and no taxes or opening debt, new borrowing must
// equal purchases actually supplied, even when a shock prevents delivery.
const procurement = {...DEFAULTS, policyDynamics:0, currencyDynamics:0, tradeEnabled:0, financialMarket:0,
  householdDepositPassThrough:0, firmDepositPassThrough:0, periods: 8, governmentDeposit: 0, initialPublicDebt: 0,
  governmentShare: 45, investmentShare: 0, inventoryTarget: 0, householdWealth: 600,
  initialIncome: 0, consumptionIncome: 0, consumptionWealth: 0, incomeSupport: 0,
  unemploymentReplacement: 0, publicResearch: 0, consumptionTax: 0, incomeTax: 0,
  profitTax: 0, financialIncomeTax:0, wealthTax:0, firmDynamics: 0, loanRate: 0, loanSpread: -DEFAULTS.initialPolicyRate, bondRate: 0};
const shock = {shocks: [{type: 'supply', start: 1, duration: 1, magnitude: -95, recovery: 0}]};
const oldPurchase = previous(procurement, 2026, shock).rows[1];
frozenRuns++;
const newPurchase = checkRun(procurement, 2026, shock).rows[1];
assert(oldPurchase.publicDebt > oldPurchase.government + 1);
close(newPurchase.publicDebt, newPurchase.government);
close(newPurchase.governmentDeposits, 0);

const modes = ['previous', 'labor_and_settlement', 'current'];
const cases = [];
for (const profile of profiles) for (let k = 0; k < 5; k++) {
  const seed = 1201 + k * 7919;
  const old = oldProfiles.find(x => x.code === profile.code).params;
  for (const mode of modes) {
    const params = {...DEFAULTS, ...profile.params};
    if (mode === 'labor_and_settlement') {
      params.rowTechnology = old.koreaTechnology;
      params.rowGrowth = old.koreaGrowth;
    }
    const run = mode === 'previous' ? previous(old, seed) : checkRun(params, seed);
    if (mode === 'previous') frozenRuns++;
    const last = run.rows.at(-1);
    cases.push({country: profile.code, seed, mode, openingEmployment: run.rows[0].employment,
      maxEmployment: Math.max(...run.rows.map(x => x.employment)), finalEmployment: last.employment,
      hit100: run.rows.some(x => x.employment >= 100 - 1e-8),
      employmentBelow50: run.rows.some(x => x.employment < 50),
      debtAbove300GDP: run.rows.some(x => x.publicDebt > 3 * Math.max(1e-9, x.output)),
      finalDebtGDP: last.publicDebt / Math.max(1e-9, last.output)});
  }
}
const comparison = modes.map(mode => {
  const runs = cases.filter(x => x.mode === mode);
  return {mode, runs: runs.length, hit100: runs.filter(x => x.hit100).length,
    maxEmployment: Math.max(...runs.map(x => x.maxEmployment)),
    medianFinalEmployment: quantile(runs.map(x => x.finalEmployment), .5),
    employmentBelow50: runs.filter(x => x.employmentBelow50).length,
    debtAbove300GDP: runs.filter(x => x.debtAbove300GDP).length};
});
const audit = {modelVersion: MODEL_VERSION, executedAt: new Date().toISOString(), stepYears: 1,
  status: 'PASS', currentRuns, frozenRuns, maxEmployment, minUnemployment, maxEmploymentResidual,
  matchedLaborRates: evidence.laborTransitionCoverage, restOfWorld: frontiers.restOfWorld,
  protocol: '28 presets × 5 common seeds × 3 configurations × 40 years. The intermediate configuration uses the old Korea values solely to isolate the donor replacement. The 100% threshold uses a 1e-8 tolerance.',
  comparison, example: {oldSettledEmployment: oldWarm.employment, newSettledEmployment: newWarm.employment,
    oldProcurementDebt: oldPurchase.publicDebt, newProcurementDebt: newPurchase.publicDebt, executedPurchases: newPurchase.government},
  cases};
fs.writeFileSync(new URL('dist/data/employment_audit.json', root), JSON.stringify(audit, null, 2));
console.log(JSON.stringify({...audit, cases: undefined, restOfWorld: undefined}, null, 2));

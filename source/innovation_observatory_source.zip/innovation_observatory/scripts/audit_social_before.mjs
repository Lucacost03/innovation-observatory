import fs from 'node:fs';import crypto from 'node:crypto';import {simulate} from '../dist/engine.mjs';
const profiles=JSON.parse(fs.readFileSync(new URL('../dist/data/profiles.json',import.meta.url))),cases=[];let openingKeys,annualKeys;
for(const p of profiles)for(const seed of [2026,9945,17864])for(const variant of ['baseline','stress']){
 const options=variant==='stress'?{shocks:[{type:'demand',start:4,duration:4,magnitude:-30,recovery:.5},{type:'government',start:8,duration:3,magnitude:-25,recovery:.5}],paths:[{key:'publicEducationQuality',start:4,end:4,target:1.5,mode:'step'}]}:{};
 const rows=simulate({...p.params,periods:40},seed,options).rows;openingKeys??=Object.keys(rows[0]);annualKeys??=Object.keys(rows[1]);const hash=crypto.createHash('sha256').update(JSON.stringify(rows)).digest('hex');cases.push({country:p.code,seed,variant,hash,finalGDP:rows.at(-1).output});
}
fs.writeFileSync(new URL('../research/social_spending/before.json',import.meta.url),JSON.stringify({version:'1.19.0',sourceCommit:'0a8e265d9c202f95c788c7a194911be7b18f42aa',profiles,openingKeys,annualKeys,cases},null,2));console.log('Captured',cases.length,'complete40-yearrow fingerprints before reporting changes.');

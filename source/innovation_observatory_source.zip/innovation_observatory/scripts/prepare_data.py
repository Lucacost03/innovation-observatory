import json,hashlib,sys,shutil
from pathlib import Path
import pandas as pd
import numpy as np
R=Path(__file__).resolve().parents[1];S=Path(sys.argv[1]);D=R/'dist/data';D.mkdir(parents=True,exist_ok=True)
countries={'AUT':('Austria','AT'),'BEL':('Belgium','BE'),'BGR':('Bulgaria','BG'),'HRV':('Croatia','HR'),'CYP':('Cyprus','CY'),'CZE':('Czechia','CZ'),'DNK':('Denmark','DK'),'EST':('Estonia','EE'),'FIN':('Finland','FI'),'FRA':('France','FR'),'DEU':('Germany','DE'),'GRC':('Greece','EL'),'HUN':('Hungary','HU'),'IRL':('Ireland','IE'),'ITA':('Italy','IT'),'LVA':('Latvia','LV'),'LTU':('Lithuania','LT'),'LUX':('Luxembourg','LU'),'MLT':('Malta','MT'),'NLD':('Netherlands','NL'),'POL':('Poland','PL'),'PRT':('Portugal','PT'),'ROU':('Romania','RO'),'SVK':('Slovakia','SK'),'SVN':('Slovenia','SI'),'ESP':('Spain','ES'),'SWE':('Sweden','SE')}
pwt=pd.read_excel(S/'data/external/pwt110.xlsx',sheet_name='Data');rd=pd.read_csv(S/'data/eurostat_processed/rd_e_gerdtot_long.csv');rd=rd[(rd.freq=='A')&(rd.unit=='PC_GDP')&rd.value.notna()]
assert not rd.duplicated(['geo','period','sectperf']).any();profiles=[];observations=[]
for code,(name,geo) in countries.items():
 obs=pwt[pwt.countrycode==code].sort_values('year');good=obs.dropna(subset=['rgdpna','rnna','labsh','delta','csh_i','csh_g','csh_c']);year=int(max(set(good.year)&set(rd[(rd.geo==geo)&(rd.sectperf=='BES')].period)));a=good[good.year==year].iloc[0];b=rd[(rd.geo==geo)&(rd.period==year)].set_index('sectperf');v=lambda k:float(b.loc[k,'value']) if k in b.index else None;den=a.csh_c+a.csh_i+a.csh_g
 params={'capitalOutputRatio':float(a.rnna/a.rgdpna),'laborShare':100*float(a.labsh),'tfpCapitalShare':100*(1-float(a.labsh)),'depreciation':100*float(a.delta),'investmentShare':100*float(a.csh_i/den),'governmentShare':100*float(a.csh_g/den),'rdBusiness':v('BES'),'publicResearch':v('GOV')+v('HES')}
 flags={k:'' if pd.isna(b.loc[k,'flag']) else str(b.loc[k,'flag']) for k in b.index}
 profiles.append({'code':code,'name':name,'geo':geo,'year':year,'params':params,'rdTotal':v('TOTAL'),'rdNonProfit':v('PNP'),'flags':flags,'sourceValues':{k:float(a[k]) for k in ['rnna','rgdpna','labsh','delta','csh_i','csh_g','csh_c']}})
 for k in b.index:observations.append({'country':code,'year':year,'sector':k,'value':v(k),'flag':flags[k],'unit':'PC_GDP'})

# One representative EU27 economy. Official Eurostat EU aggregate R&D shares
# must not be replaced by an unweighted average of national percentages.
# Other starting scales are transparent weighted aggregates of the 27 PWT rows;
# this does not turn the closed-economy engine into a cross-country trade model.
eu_year=min(p['year'] for p in profiles)
members=pwt[pwt.countrycode.isin(countries)&pwt.year.eq(eu_year)].copy()
required=['rnna','rgdpna','labsh','delta','cgdpe','csh_c','csh_i','csh_g']
assert len(members)==27 and members.countrycode.nunique()==27
assert members[required].notna().all().all()
assert members[['rnna','rgdpna','cgdpe']].gt(0).all().all()
eu_rd=rd[(rd.geo=='EU27_2020')&rd.period.eq(eu_year)].set_index('sectperf')
assert {'BES','GOV','HES','PNP','TOTAL'}.issubset(eu_rd.index)
eu_values={k:float(eu_rd.loc[k,'value']) for k in ['BES','GOV','HES','PNP','TOTAL']}
eu_flags={k:'' if pd.isna(eu_rd.loc[k,'flag']) else str(eu_rd.loc[k,'flag']) for k in eu_rd.index}
total_capital=float(members.rnna.sum());total_output=float(members.rgdpna.sum());total_expenditure=float(members.cgdpe.sum())
labor_share=float((members.labsh*members.rgdpna).sum()/total_output)
depreciation=float((members.delta*members.rnna).sum()/total_capital)
domestic={k:float((members[k]*members.cgdpe).sum()) for k in ['csh_c','csh_i','csh_g']}
total_domestic=sum(domestic.values())
eu_params={'capitalOutputRatio':total_capital/total_output,'laborShare':100*labor_share,'tfpCapitalShare':100*(1-labor_share),'depreciation':100*depreciation,'investmentShare':100*domestic['csh_i']/total_domestic,'governmentShare':100*domestic['csh_g']/total_domestic,'rdBusiness':eu_values['BES'],'publicResearch':eu_values['GOV']+eu_values['HES']}
eu_aggregation={'type':'representative EU27 aggregate','members':sorted(countries),'year':eu_year,'rd':'Official Eurostat EU27_2020 / PC_GDP, with original source flags.','capitalOutputRatio':'Sum national rnna / sum national rgdpna.','laborShare':'National labsh weighted by rgdpna; TFP capital weight is one minus this share.','depreciation':'National delta weighted by rnna capital stocks.','domesticShares':'Sum national csh_i or csh_g times cgdpe, divided by the sum of csh_c+csh_i+csh_g times cgdpe.','interpretation':'One synthetic representative EU economy. Other macro scales are PWT-based aggregate proxies, not official EU national accounts. No country-to-country trade, financial transfers or separate national agents are added.','weights':[{'country':str(x.countrycode),'gdpWeight':float(x.rgdpna/total_output),'capitalWeight':float(x.rnna/total_capital),'expenditureWeight':float(x.cgdpe/total_expenditure)} for x in members.sort_values('countrycode').itertuples()]}
for key in ['gdpWeight','capitalWeight','expenditureWeight']:assert abs(sum(x[key] for x in eu_aggregation['weights'])-1)<1e-12
profiles.append({'code':'EU27','name':'European Union (EU27)','geo':'EU27_2020','year':eu_year,'params':eu_params,'rdTotal':eu_values['TOTAL'],'rdNonProfit':eu_values['PNP'],'flags':eu_flags,'sourceValues':{'rnna':total_capital,'rgdpna':total_output,'labsh':labor_share,'delta':depreciation,**{k:v/total_expenditure for k,v in domestic.items()}},'aggregation':eu_aggregation})
for k,v in eu_values.items():observations.append({'country':'EU27','year':eu_year,'sector':k,'value':v,'flag':eu_flags[k],'unit':'PC_GDP'})
(D/'profiles.json').write_text(json.dumps(profiles,indent=2,allow_nan=False));pd.DataFrame(observations).to_csv(D/'country_rd_observations.csv',index=False)
bank=pd.read_csv(S/'results_phase25/CANDIDATE_PREDICTIONS.csv');m=pd.read_csv(S/'results_phase25/METRICS.csv');scored=bank[bank.year.between(2015,2023)&bank.model.isin(['frozen24','legacy21'])];scored.to_csv(D/'archived_forecast_predictions.csv',index=False);metrics=[]
for (h,n),z in scored.groupby(['horizon','model']):
 assert len(z)==243 and z.country.nunique()==27 and z.year.nunique()==9 and (z.train_end<=z.year-2).all();err=z.prediction-z.actual;name={'frozen24':'frozen24_reference','legacy21':'active_legacy21'}[n];rmse=float(np.sqrt(np.mean(err**2)));mae=float(np.mean(abs(err)));old=m[(m.horizon==h)&(m.method==name)].iloc[0];assert abs(old.RMSE_pp-rmse)<1e-10 and abs(old.MAE_pp-mae)<1e-10;metrics.append({'horizon':h,'model':name,'n':len(z),'rmse':rmse,'mae':mae})
sourcefiles=['data/external/pwt110.xlsx','data/eurostat_processed/rd_e_gerdtot_long.csv','results_phase25/CANDIDATE_PREDICTIONS.csv'];e={'snapshot':'User-supplied Phase25 archive','prepared':'2026-11-02','countries':27,'targetEnd':2023,'sources':[{'file':f,'sha256':hashlib.sha256((S/f).read_bytes()).hexdigest()} for f in sourcefiles],'recomputedArchivedMetrics':metrics,'mapping':{'capitalOutputRatio':'PWT rnna / rgdpna, not the rkna capital-services index.','laborShare':'100 × PWT labsh, initializes wage scale.','tfpCapitalShare':'100 × (1 − initial labsh), fixed measurement exponent.','depreciation':'100 × PWT delta; annual rate mapped to a model period by assumption.','governmentShare':'100 × csh_g / (csh_c+csh_i+csh_g). PPP shares rescaled to closed domestic uses.','investmentShare':'100 × csh_i / (csh_c+csh_i+csh_g). PPP shares rescaled to closed domestic uses.','rdBusiness':'rd_e_gerdtot / A / BES / PC_GDP.','publicResearch':'GOV + HES / PC_GDP scale proxy; fiscal funding and frontier response are additional assumptions.','otherParameters':'Explicit synthetic structural, initial and financial assumptions; no causal innovation coefficient is identified.'},'limitations':['Revised source snapshots, not a complete real-time vintage panel.','Previously examined 2015–2023 forecast years are not an untouched holdout.','Archived forecast RMSE is not an accuracy score for this new ABM.','Synthetic firms and households; no microdata validation of behavioral laws.','Closed economy, fixed producer price, no trade, FX or inflation.','R&D pay is a monetary flow; R&D is not separately capitalized in the goods identity.','A public bank rescue transfers losses to government debt. Equity can remain negative when the backstop is disabled.','The mapping of annual data to model periods has no validated calendar interpretation.'],'officialSources':[{'title':'Eurostat R&D metadata','url':'https://ec.europa.eu/eurostat/cache/metadata/en/rd_esms.htm'},{'title':'Eurostat R&D by sector of performance','url':'https://ec.europa.eu/eurostat/databrowser/view/rd_e_gerdtot/default/table'},{'title':'Penn World Table 11.0','url':'https://www.rug.nl/ggdc/productivity/pwt/'}],'attribution':'Feenstra, Robert C., Robert Inklaar and Marcel P. Timmer (2015), The Next Generation of the Penn World Table, American Economic Review 105(10), 3150–3182. PWT 11.0: CC BY 4.0. Eurostat source acknowledged.'}
e['profiles']=len(profiles);e['euAggregate']=eu_aggregation
(D/'evidence.json').write_text(json.dumps(e,indent=2));shutil.copy2(S/'results_phase25/METRICS.csv',D/'archived_metrics.csv');shutil.copy2(S/'results_phase25/TEST_RESULTS.json',D/'original_test_results.json')
for f in ['PHASE25_VALIDATION.md','README_PHASE25.md']:shutil.copy2(S/f,D/f)
print('27 country presets + one EU27 aggregate; source year',sorted({p['year'] for p in profiles}),'6 independently recomputed metric rows')

# Apply the audited frozen 2023 official mappings after rebuilding base extracts.
from enrich_profiles import enrich
enrich()
from build_benchmarks import summary

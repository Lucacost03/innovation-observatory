import fs from 'node:fs';const root=new URL('../',import.meta.url),r=JSON.parse(fs.readFileSync(new URL('dist/data/revision130_validation.json',root)));
const {scores,fiscalScores,longRuns,tariffCases,...summary}=r;
fs.writeFileSync(new URL('dist/revision130-data.mjs',root),'export const REVISION130='+JSON.stringify(summary)+';\n');
const m=r.scoreCountries,v={...r,deficitBefore:m.deficit.earlier.RMSE,deficitAfter:m.deficit.candidate.RMSE,deficitMAEBefore:m.deficit.earlier.MAE,deficitMAEAfter:m.deficit.candidate.MAE,gdpBefore:m.gdp.earlier.RMSE,gdpAfter:m.gdp.candidate.RMSE,caBefore:m.ca.earlier.RMSE,caAfter:m.ca.candidate.RMSE};
const text=fs.readFileSync(new URL('research/TARIFF_FISCAL_TEMPLATE_1_30.md',root),'utf8').replace(/\{\{(\w+)\}\}/g,(_,k)=>typeof v[k]==='number'?String(v[k]):String(v[k]));fs.writeFileSync(new URL('research/TARIFF_FISCAL_METHODS_1_30.md',root),text);
console.log('Built 1.30 evidence summary from executed comparisons.');

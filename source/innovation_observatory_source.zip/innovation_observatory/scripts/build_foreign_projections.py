"""Compile frozen OECD EO117 annual paths into browser-safe projection data.

No forecast fitting or network access occurs here. OECD labour efficiency is
converted with its published labour share, then linked to PWT as an explicit
cross-source proxy. Uncovered ROW countries are represented by the covered
sample's evolution, never assigned fabricated country forecasts.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ROOT / "research/forecast_source_candidates"
BASE, LAST, LABOUR_SHARE = 2023, 2100, 0.67
SCENARIOS = ["BAU1", "BAU2", "ET1", "ET2", "ET3", "ET4"]
SHORT_LABELS = ["Business as usual · median damage", "Business as usual · high damage",
                "Energy transition · median damage · slow cost decline",
                "Energy transition · median damage · fast cost decline",
                "Energy transition · high damage · slow cost decline",
                "Energy transition · high damage · fast cost decline"]
manifest = json.loads((CANDIDATES / "candidate_manifest.json").read_text())
for name in ["oecd_eo117_structure.xml", "oecd_eo117_efflabs_gdp.csv"]:
    assert hashlib.sha256((CANDIDATES / name).read_bytes()).hexdigest() == manifest["files"][name]["sha256"]

raw = {}
with (CANDIDATES / "oecd_eo117_efflabs_gdp.csv").open(newline="") as handle:
    for row in csv.DictReader(handle):
        if row["MEASURE"] != "EFFLABS":
            continue
        assert row["FREQ"] == "A" and row["UNIT_MEASURE"] == "XDC_SAL" and row["UNIT_MULT"] == "0"
        value = float(row["OBS_VALUE"])
        assert math.isfinite(value) and value > 0
        raw.setdefault(row["REF_AREA"], {}).setdefault(row["SCENARIO"], {})[int(row["TIME_PERIOD"])] = value
labels = {}
xml = ET.parse(CANDIDATES / "oecd_eo117_structure.xml")
for element in xml.iter():
    if element.tag.endswith("}Code") and element.attrib.get("id") in SCENARIOS:
        names = [x.text for x in element if x.tag.endswith("}Name") and x.attrib.get("{http://www.w3.org/XML/1998/namespace}lang") == "en"]
        if names:
            labels[element.attrib["id"]] = names[0]

with (ROOT / "dist/data/pwt_rest_of_world_weights.csv").open(newline="") as handle:
    pool = list(csv.DictReader(handle))
assert not {"USA", "CHN"}.intersection(x["countrycode"] for x in pool)
covered = [x for x in pool if x["countrycode"] in raw]
coverage = sum(float(x["cgdpo"]) for x in covered) / sum(float(x["cgdpo"]) for x in pool)
base_weighted_tfp = sum(float(x["cgdpo"]) * float(x["ctfp"]) for x in covered)
series = {}
for scenario in SCENARIOS:
    for area in ["USA", "CHN"] + [x["countrycode"] for x in covered]:
        assert set(raw[area][scenario]) == set(range(BASE, LAST + 1)), (area, scenario, "incomplete years")
    multipliers = {area: [(raw[area][scenario][year] / raw[area][scenario][BASE]) ** LABOUR_SHARE
                          for year in range(BASE, LAST + 1)]
                   for area in ["USA", "CHN"]}
    multipliers["ROW"] = [sum(float(x["cgdpo"]) * float(x["ctfp"]) *
                                  (raw[x["countrycode"]][scenario][year] / raw[x["countrycode"]][scenario][BASE]) ** LABOUR_SHARE
                                  for x in covered) / base_weighted_tfp
                          for year in range(BASE, LAST + 1)]
    for area, values in multipliers.items():
        assert abs(values[0] - 1) < 1e-12
        assert all(math.isfinite(v) and v > 0 for v in values)
    series[scenario] = multipliers
data = {
    "source": "OECD Economic Outlook 117 long-term scenarios (2025 update)",
    "sourceUpdated": "2026-01-06", "retrievedAt": manifest["retrievedAt"],
    "baseYear": BASE, "lastYear": LAST, "labourShare": LABOUR_SHARE,
    "transformation": "A_t / A_2023 = (EFFLABS_t / EFFLABS_2023)^0.67",
    "status": "Published conditional projection; OECD-implied TFP proxy linked to PWT opening levels",
    "scenarios": [{"code": code, "label": SHORT_LABELS[i], "sourceLabel": labels[code]} for i, code in enumerate(SCENARIOS)],
    "row": {"coveredCountries": len(covered), "poolCountries": len(pool), "outputCoverage": coverage,
            "codes": [x["countrycode"] for x in covered],
            "aggregation": "Fixed 2023 PWT PPP-output weights times opening ctfp; renormalized to 2023=1. Covered-sample evolution proxies uncovered members of the full opening pool."},
    "tail": "After 2100, repeat each source's final published annual growth rate; this is an extrapolation assumption.",
    "vintageLimit": "This 2025/2026 vintage was unavailable in 2023. It cannot establish leakage-safe historical forecast improvements.",
    "sources": {"data": manifest["files"]["oecd_eo117_efflabs_gdp.csv"], "structure": manifest["files"]["oecd_eo117_structure.xml"],
                "method": manifest["files"]["oecd_2025_methods.html"]["url"], "annex": manifest["files"]["oecd_2025_annex_b.html"]["url"]},
    "multipliers": series,
}
serialized = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
(ROOT / "dist/data/foreign_projections.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
(ROOT / "dist/foreign-projection-data.mjs").write_text("// Generated by scripts/build_foreign_projections.py from frozen official inputs.\nexport const FOREIGN_PROJECTIONS=" + serialized + ";\n")
print(json.dumps({"scenarios": len(series), "years": LAST-BASE+1, "providers": 3,
                  "rowCountries": len(covered), "rowOutputCoverage": coverage}))

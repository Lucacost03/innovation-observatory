"""Restore two optional historical fixtures from the lossless source bundle."""
from pathlib import Path
import tarfile
root=Path(__file__).resolve().parents[1]
expected={'research/macro_policy/baseline.json','research/social_spending/before.json'}
with tarfile.open(root/'research/historical_runs.tar.xz','r:xz')as archive:
    assert set(archive.getnames())==expected
    for name in expected:
        member=archive.getmember(name);assert member.isfile()
        target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(archive.extractfile(member).read())
print('Restored optional historical fixtures.')

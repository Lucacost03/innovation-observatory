"""Source age shapes, opening-scope correction and transparent price mechanism."""
from pathlib import Path
from collections import Counter
import json
R=Path(__file__).resolve().parents[1];D=R/'dist/data';e=json.loads((R/'research/participation_1_29/participation_age_rates_2023.json').read_text())
ps=json.loads((D/'profiles.json').read_text());changes={}
for p in ps:
 c=p['code'];source=e['countries'][c];params=p['params'];params.setdefault('currencyPricePassThrough',.1);prior=p.setdefault('revision129PriorDefaults',{})
 for k in ['initialParticipationRate','postRetirementParticipation']:prior.setdefault(k,params[k])
 if c=='CHN':
  params['initialParticipationRate']=source['sourceAggregate15to64']['rate'];p['labourAge']='15–64'
  p['sourceLabel']='NBS · UN · PBOC · MOF · PWT · ILOSTAT'
  p['provenance']['initialParticipationRate']={'status':'proxy','dataset':'ILOSTAT EAP_2WAP_SEX_AGE_RT_A; published provider estimate','year':2023,'url':source['sourceURL'],'parameterValue':params['initialParticipationRate'],'sourceValue':params['initialParticipationRate'],'sourceUnit':'% population15–64','note':'Published total-sex age15–64 estimate, source '+source['sourceCode']+'. Replaces the previous66.1028% national15+ proxy. Not recast as a direct survey observation. The opening employment-within-labour-force rate remains a separately labelled assumption.'}
  p['provenance']['employmentRate']['note']='Opening employment within the labour force remains an explicit95% scenario assumption. The participation denominator is now the matched15–64ILOSTAT estimate; the old national15+ employment/population proxy no longer determines this opening measure.'
 params['postRetirementParticipation']=100*source['bands'][-1]['rate']/params['initialParticipationRate']
 p['provenance']['postRetirementParticipation']={'status':'derived'if c not in ['USA','CHN']else'proxy','year':2023,'url':source['sourceURL'],'dataset':source['sourceProvider'],'parameterValue':params['postRetirementParticipation'],'note':'Source65+ activity '+str(source['bands'][-1]['rate'])+'% divided by this preset opening15–64 participation. A mapping across source/model population weights; USA mixes OECD opening aggregate with ILO age shape. Thus older activity is not inadvertently scaled twice. Future fixed age-band rates and pension reform response remain assumptions.'}
 for k in ['ageParticipation','importCostFeedback']:params[k]=1
 p['provenance']['ageParticipation']={'status':'proxy','year':2023,'url':source['sourceURL'],'dataset':source['sourceProvider'],'parameterValue':1,'note':'15–24/25–54/55–64 source rates define a country age shape; a common logit intercept reconciles annual source and model cohort weights to the chosen opening aggregate. Adjusted rates are proxies, bounded0–100%. Ageing and migration change aggregate participation. Future within-band rates are held fixed; future behavioural trends and reform effects are not estimated.'}
 p['provenance']['importCostFeedback']={'status':'assumed','year':None,'url':'https://www.imf.org/-/media/files/publications/esr/2019/english/ch2.pdf','dataset':'Imported-input price feedback; mechanism assumption','parameterValue':1,'note':'Replaces the old nominal FX-only producer-price term with the log change in foreign border prices converted to domestic currency. Uses the existing common pass-through coefficient, not invented national import-input shares. Direction has research support; strength is unestimated. Pricing proxy only; no separate intermediate-input transactions or extra GDP. Consumer import taxes are not assumed to tax firm inputs.'}
 p['provenance']['currencyPricePassThrough']={'status':'assumed','year':None,'url':'https://www.imf.org/-/media/files/publications/esr/2019/english/ch2.pdf','dataset':'Imported-cost pass-through sensitivity','parameterValue':params['currencyPricePassThrough'],'note':'Common scenario coefficient multiplying log changes in the import border-cost basket, distinct from direct imported-consumer-price exposure. Not a measured national imported-input/gross-output ratio or an identified elasticity. Zero removes the producer cost response. No country exposure coefficients could be verified from the accessed OECD source.'}
 p['dataSummary']=dict(Counter(x['status']for x in p['provenance'].values()))
 if 'coverageSummary'in p:p['coverageSummary'].update(observedOrMapped=sum(x['status']in['observed','derived','proxy']for x in p['provenance'].values()),assumedOrDesign=sum(x['status']in['assumed','design']for x in p['provenance'].values()))
 changes[c]={'before':prior,'after':{k:params[k]for k in prior},'sourceAgeRates':source['bands']}
(D/'profiles.json').write_text(json.dumps(ps,ensure_ascii=False,indent=2)+'\n')
(D/'participation_age_rates_2023.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
(R/'dist/participation-data.mjs').write_text('export const PARTICIPATION_AGE_DATA='+json.dumps({str(x['poolId']):[{k:b[k]for k in ['minAge','maxAgeExclusive','rate']}for b in x['bands']]for x in e['countries'].values()},separators=(',',':'))+';\n')
(R/'research/participation_1_29/opening_mapping.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
cov=D/'global_input_coverage.json'
if cov.exists():x=json.loads(cov.read_text());x['modelVersion']='1.29.0';x['countries']=[{k:p[k]for k in ['code','name','sourceLabel','labourAge','dataSummary','coverageSummary']}for p in ps];cov.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print('All30 age profiles, China same-age estimate, older-rate mappings and explicit imported-cost mechanism configured.')

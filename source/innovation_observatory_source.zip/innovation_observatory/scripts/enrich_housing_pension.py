"""Reproduce housing and pension input proxies from frozen primary-source files.

This script writes only its own benchmark and source manifest. It never edits
the simulator or its presets. Run with --refresh to retrieve the named sources.
"""
from pathlib import Path
import csv
import datetime as dt
import hashlib
import json
import sys
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'research/source_snapshots'
API = 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/'
ECB = 'https://data-api.ecb.europa.eu/service/data/'
SPECS = {
    'oldage': ('housing_pension_public_oldage_2023.json', API+'gov_10a_exp?lang=en&time=2023&unit=PC_GDP&cofog99=GF1002&sector=S13&na_item=D62'),
    'dwellings': ('housing_pension_dwellings_2023.json', API+'nama_10_nfa_bs?lang=en&time=2023&sector=S14_S15&unit=CP_MEUR'),
    'gdp': ('housing_pension_gdp_2023.json', API+'nama_10_gdp?lang=en&time=2023&unit=CP_MEUR&na_item=B1GQ'),
    'gdp2021': ('housing_pension_gdp_2021.json', API+'nama_10_gdp?lang=en&time=2021&unit=CP_MEUR&na_item=B1GQ'),
    'construction': ('housing_pension_housing_investment_2023.json', API+'nama_10_an6?lang=en&time=2023&unit=PC_GDP&asset10=N111G&asset10=N11G'),
    'ownership': ('housing_pension_ownership_all_2023.json', API+'ilc_lvho02?lang=en&time=2023&unit=PC&hhcomp=TOTAL&rskpovth=TOTAL'),
    'private': ('housing_pension_pension_private_2021.json', API+'nasa_10_pens1?lang=en&time=2021&unit=MIO_EUR&penscheme=S12P&penscheme=S12PC&penscheme=S12PB'),
    'funds': ('housing_pension_pension_funds_2023.json', API+'nasa_10_f_bs?lang=en&time=2023&unit=PC_GDP&co_nco=NCO&sector=S129&finpos=ASS&na_item=F'),
    'mortgages': ('housing_pension_mortgages_2023.csv', ECB+'BSI/M..N.A.A22.A.1.U6.2250.Z01.E?startPeriod=2023-12&endPeriod=2023-12&format=csvdata'),
    'newrate': ('housing_pension_mortgage_rate_new_2023.csv', ECB+'MIR/M..B.A2C.A.R.A.2250.EUR.N?startPeriod=2023-01&endPeriod=2023-12&format=csvdata'),
    'stockrate': ('housing_pension_mortgage_rate_stock_2023.csv', ECB+'MIR/M..B.A22.A.R.A.2250.EUR.O?startPeriod=2023-01&endPeriod=2023-12&format=csvdata'),
    'estonia': ('housing_pension_estonia_fsa_extract_2023.json', 'https://www.fi.ee/sites/default/files/fi_eft_1_2024_eng.pdf'),
}
if '--refresh' in sys.argv:
    for key, (filename, url) in SPECS.items():
        if key=='estonia':
            continue  # Primary PDF figure is transcribed in the named frozen extraction.
        with urllib.request.urlopen(url, timeout=60) as response:
            (RAW/filename).write_bytes(response.read())

sources, datasets = {}, {}
for key, (filename, url) in SPECS.items():
    path = RAW/filename
    content = path.read_bytes()
    datasets[key] = json.loads(content) if filename.endswith('.json') else list(csv.DictReader(content.decode().splitlines()))
    sources[key] = {'name':'housing_pension_'+key, 'url':url, 'path':str(path.relative_to(ROOT)),
        'bytes':len(content), 'sha256':hashlib.sha256(content).hexdigest(),
        'retrievedAt':dt.datetime.fromtimestamp(path.stat().st_mtime,dt.timezone.utc).isoformat()}
    if isinstance(datasets[key], dict):
        sources[key]['sourceUpdatedAt'] = datasets[key].get('updated')
    if key=='estonia':
        sources[key]['format']='Derived manual extraction from a primary PDF figure; not a raw API response.'
        sources[key]['reproduction']='Check Figure30,page21; sum4970 and616 million EUR, then divide by Eurostat2023 GDP.'

def observation(key, **selection):
    data = datasets[key]
    offset, complete = 0, {}
    for dim, size in zip(data['id'],data['size']):
        index = data['dimension'][dim]['category']['index']
        code = selection.get(dim)
        if code is None:
            if len(index) != 1:
                raise ValueError('An explicit '+dim+' selection is required for '+key)
            code = next(iter(index))
        if code not in index:
            return None
        offset = offset*size+index[code]
        complete[dim] = code
    value = data.get('value',{}).get(str(offset))
    if value is None:
        return None
    return {'source':key, 'selection':complete, 'value':value,
        'flag':data.get('status',{}).get(str(offset),'')}

def record(value, year, unit, note, components=(), status='proxy', **extra):
    return {'value':value, 'year':year, 'unit':unit, 'status':status, 'note':note,
        'components':list(components), **extra}

profiles = json.loads((ROOT/'dist/data/profiles.json').read_text())
members = [p for p in profiles if p['code']!='EU27']
countries = {}
gdp = {p['code']:observation('gdp',geo=p['geo']) for p in profiles}
ea2023 = {'AT','BE','CY','DE','EE','ES','FI','FR','EL','HR','IE','IT','LT','LU','LV','MT','NL','PT','SI','SK'}

def weighted(values, weight_year='gdp'):
    supplied = [(p,values[p['code']]) for p in members if values.get(p['code']) is not None]
    weights = {p['code']:observation(weight_year,geo=p['geo'])['value'] for p,_ in supplied}
    return sum(v*weights[p['code']] for p,v in supplied)/sum(weights.values()), [p['code'] for p,_ in supplied]

private_maps = {key:{} for key in ['stock','dc','db','employer','household','benefits']}
private_obs = {}
for p in members:
    geo,code = p['geo'],p['code']
    denominator = observation('gdp2021',geo=geo)
    private_obs[code] = {}
    for key,scheme,item in [('stock','S12P','F63_LE'),('dc','S12PC','F63_LE'),('db','S12PB','F63_LE'),
            ('employer','S12P','D6111'),('household','S12P','D6131'),('benefits','S12P','D62_P')]:
        obs = observation('private',geo=geo,penscheme=scheme,na_item=item)
        private_maps[key][code] = None if obs is None else 100*obs['value']/denominator['value']
        private_obs[code][key] = [] if obs is None else [obs,denominator]

private_means = {key:weighted(values) for key,values in private_maps.items() if key not in ['dc','db']}
stock_values = dict(private_maps['stock'])
stock_components = {code:private_obs[code]['stock'] for code in private_obs}
stock_scope = {code:'2021 private pension scheme closing entitlements / same-year GDP. Includes defined benefit and defined contribution employment-related schemes.' for code in stock_values}
for p in members:
    code=p['code']
    if stock_values[code] is None:
        fund=observation('funds',geo=p['geo'])
        if fund is not None:
            stock_values[code]=fund['value'];stock_components[code]=[fund]
            stock_scope[code]='2023 pension-fund-sector (S129) total financial assets proxy; includes DB/DC and differs from household entitlements and insurance-managed pensions.'
estonia=datasets['estonia']
stock_values['EST']=100*sum(row['value'] for row in estonia['observations'])/gdp['EST']['value']
stock_components['EST']=[{'source':'estonia','period':'2023-12-31','unit':'million EUR','value':sum(row['value'] for row in estonia['observations']),'observations':estonia['observations']},gdp['EST']]
stock_scope['EST']='2023 Estonian FSA second-pillar plus third-pillar pension-fund assets (4970+616 million EUR) / same-year GDP. Excludes individual pension investment accounts. Publicly offered funds are not government-owned funds.'
stock_mean, stock_donors = weighted(stock_values)

for p in profiles:
    code,geo = p['code'],p['geo']
    country={}
    old=observation('oldage',geo=geo)
    country['publicOldAgeCashGDP']=record(old['value'],2023,'% GDP',
        'Government old-age cash social benefits (COFOG GF1002, D62), not all pension types or purely contributory old-age pensions. Carve out of existing public cash social benefits; do not add twice.',[old])
    dw=observation('dwellings',geo=geo,asset10='N111N')
    dwelling_geo=geo
    if dw is None:
        dwelling_geo='EU27_2020';dw=observation('dwellings',geo=dwelling_geo,asset10='N111N')
    dw_gdp=observation('gdp',geo=dwelling_geo)
    housing=100*dw['value']/dw_gdp['value']
    country['housingStructuresGDP']=record(housing,2023,'% GDP',
        'Household+NPISH net dwelling structures, excluding land. Split out of opening total capital rather than duplicating it. '+('EU27 stock/GDP ratio used because Ireland is missing.' if dwelling_geo!=geo else 'Current-price net structures / same-year GDP.'),[dw,dw_gdp],fallback=dwelling_geo!=geo)
    country['productiveCapitalAfterHousingGDP']=record(100*p['params']['capitalOutputRatio']-housing,2023,'% GDP',
        'Compatibility calculation: opening PWT total capital/GDP less mapped household dwelling structures/GDP. Not an observed business-sector capital stock.',[dw,dw_gdp])
    construction=observation('construction',geo=geo,asset10='N111G')
    total_gfcf=observation('construction',geo=geo,asset10='N11G')
    country['housingInvestmentGDP']=record(construction['value'],2023,'% GDP',
        'Total-economy dwelling GFCF, N111G. Model allocation to household construction is a proxy; carve from total fixed investment. Existing-home and land transfers do not add GDP.',[construction])
    country['totalFixedInvestmentGDP']=record(total_gfcf['value'],2023,'% GDP',
        'Total-economy gross fixed capital formation by asset type, N11G. Same dataset, prices and year as dwelling investment.',[total_gfcf])
    country['housingInvestmentShareOfGFCF']=record(construction['value']/total_gfcf['value'],2023,'fraction of total GFCF',
        'Dwelling GFCF divided by total GFCF, both 2023 current-price GDP shares from nama_10_an6. Apply this fraction to the model fixed-investment envelope rather than adding dwelling investment on top.',[construction,total_gfcf])
    for key,tenure in [('ownerOccupiedPopulationShare','OWN'),('mortgagedOwnerPopulationShare','OWN_L')]:
        own=observation('ownership',geo=geo,tenure=tenure)
        country[key]=record(None if own is None else own['value'],2023,'% population',
            'EU-SILC population living in this tenure status; it is not a household-count share or an asset-value share. Mapping to equal-sized synthetic households is a proxy.',[] if own is None else [own],status='proxy' if own else 'missing')
    areas=[p['geo'] if p['geo']!='EL' else 'GR'] if code!='EU27' else [x['geo'] if x['geo']!='EL' else 'GR' for x in members]
    rows=[r for r in datasets['mortgages'] if r['REF_AREA'] in areas]
    assert len(rows)==len(areas)
    mortgage=sum(float(r['OBS_VALUE']) for r in rows)
    country['mortgageDebtGDP']=record(100*mortgage/gdp[code]['value'],2023,'% GDP',
        'December domestic-MFI loans to domestic households/NPISH for house purchase, all currencies combined in EUR million / annual nominal GDP. Not all household debt and not only collateralised mortgages. '+('EU27 derived from the 27 member stocks.' if code=='EU27' else ''),
        [{'source':'mortgages','key':r['KEY'],'period':r['TIME_PERIOD'],'value':float(r['OBS_VALUE']),'unit':r['UNIT'],'multiplier':int(r['UNIT_MULT']),'flag':r['OBS_STATUS']} for r in rows]+[gdp[code]])
    if code=='EU27':
        stock=stock_mean;components=[];note='GDP-weighted member ratio proxy, combining 2021 private entitlements with 2023 S129 assets and Estonia\'s FSA fund assets where private entitlements are absent. Not an observed EU total.';stock_year='2021/2023'
    else:
        stock=stock_values[code];components=stock_components[code];note=stock_scope[code];stock_year=2021 if private_maps['stock'][code] is not None else 2023
        if not components:
            note='Covered-EU GDP-weighted ratio used because no comparable national private entitlement/pension-fund stock is available.';stock_year='2021/2023'
    country['privatePensionGDP']=record(stock,stock_year,'% GDP',note+' Mapping to a fully funded account without DB guarantees is a model simplification, not a measured DC balance.',components,fallback=(code=='EU27' or private_maps['stock'].get(code) is None),donorCountries=stock_donors if code=='EU27' or not components else [])
    for key,label in [('employer','privateEmployerContributionsGDP'),('household','privateHouseholdContributionsGDP'),('benefits','privatePensionBenefitsGDP')]:
        value=private_maps[key].get(code)
        fallback=value is None
        if fallback:value=private_means[key][0]
        country[label]=record(value,2021,'% GDP',
            '2021 private pension scheme actual '+('employer contributions' if key=='employer' else 'household contributions' if key=='household' else 'cash benefits')+' / same-year GDP; retained as an older benchmark ratio for the opening model. '+('Covered-member GDP-weighted fallback; not a national observation.' if fallback else 'Employer imputed contributions and attributed property income are excluded from cash contributions.'),
            private_obs.get(code,{}).get(key,[]),fallback=fallback,donorCountries=private_means[key][1] if fallback else [])
    country['privatePensionContributionsGDP']=record(country['privateEmployerContributionsGDP']['value']+country['privateHouseholdContributionsGDP']['value'],2021,'% GDP',
        'Sum of actual employer and household pension contributions, excluding imputed contributions and investment-income supplements. A model uniform wage deduction combines two economically distinct payers.',country['privateEmployerContributionsGDP']['components']+country['privateHouseholdContributionsGDP']['components'])
    for scheme,key in [('dc','privateDCPensionGDP'),('db','privateDBPensionGDP')]:
        value=private_maps[scheme].get(code)
        country[key]=record(value,2021,'% GDP','Separate private '+scheme.upper()+' entitlement stock / same-year GDP. Missing observations stay null; zero observations remain zero.',private_obs.get(code,{}).get(scheme,[]),status='derived' if value is not None else 'missing')
    for source,key in [('newrate','mortgageNewRate'),('stockrate','mortgageStockRate')]:
        area=geo if geo!='EL' else 'GR'
        national=geo in ea2023 and len([r for r in datasets[source] if r['REF_AREA']==area and r['OBS_VALUE']!=''])==12
        selected=[r for r in datasets[source] if r['REF_AREA']==(area if national else 'U2')]
        assert len(selected)==12
        quote=sum(float(r['OBS_VALUE']) for r in selected)/12
        policy=p['params']['initialPolicyRate']
        value=quote if national else policy+(quote-4)
        country[key]=record(value,2023,'% per year',
            'Mean of 12 already-annualised monthly '+('new-business' if source=='newrate' else 'outstanding-stock')+' EUR house-purchase quotes; do not multiply by 12. '+('National euro-area series.' if national else 'A complete comparable national quote is missing or only foreign-currency lending is covered. Assumed national quote = opening national policy rate + euro-area mean quote minus the ECB 4% opening rate. EU27 uses the same euro-area spread proxy, not an observed EU rate.'),
            [{'source':source,'key':r['KEY'],'period':r['TIME_PERIOD'],'value':float(r['OBS_VALUE']),'flag':r['OBS_STATUS']} for r in selected],fallback=not national,openingPolicySpread=value-policy)
    assert country['housingStructuresGDP']['value']>0
    assert country['productiveCapitalAfterHousingGDP']['value']>0
    assert country['mortgageDebtGDP']['value']>0
    assert 0<country['housingInvestmentShareOfGFCF']['value']<1
    countries[code]=country

report={'title':'Housing and pension opening benchmarks and mappings','generatedAt':dt.datetime.now(dt.timezone.utc).isoformat(),
    'sources':sources,'countries':countries,'checks':{'countryPresets':len(countries),'publicOldAgeCoverage':28,'mortgageCoverage':28,'nationalDwellingStockCoverage':27,'housingInvestmentCoverage':28,'privateEntitlements2021Coverage':sum(v is not None for v in private_maps['stock'].values()),'mortgageNationalEURNewRateCoverage':sum(not v['mortgageNewRate']['fallback'] for v in countries.values()),'mortgageNationalEURStockRateCoverage':sum(not v['mortgageStockRate']['fallback'] for v in countries.values())},
    'limitations':[
        'Opening private-pension and housing asset claims need matching counterpart assets/liabilities; never create cash from an existing claim.',
        'Public old-age cash benefits and earmarked public pension contributions overlap current government social benefits and wage/social tax proxies. Split rather than add the same amounts again.',
        'Private pensions are private employment-related schemes. Insurance-managed personal products and DB guarantees are not reproduced by a uniform funded-account model.',
        '2021 private stocks/flows are retained ratio benchmarks, not described as observed2023 values. The mixed-year EU aggregate is a model proxy.',
        'Dwelling stocks exclude land. Housing turnover is a transfer of existing assets; construction is investment. Imputed owner-occupier housing services need explicit GDP treatment or an explicit coverage exclusion.',
        'Mortgage loans cover house-purchase lending, not all household debt. Outstanding-loan and new-business rates differ; fixed-rate vintages need gradual repricing rather than instant application of a new quote to every old contract.',
        'LTV, debt-service limits, mortgage maturity, price adjustment, pension investment returns and DB risk-sharing require separately identified estimates or explicit assumptions.'
    ]}
(ROOT/'dist/data/housing_pension_benchmarks.json').write_text(json.dumps(report,indent=2)+'\n')
(ROOT/'research/housing_pension_sources.json').write_text(json.dumps(list(sources.values()),indent=2)+'\n')
print(json.dumps({'checks':report['checks'],'Italy':{k:v['value'] for k,v in countries['ITA'].items()},'EU27':{k:v['value'] for k,v in countries['EU27'].items()}},indent=2))

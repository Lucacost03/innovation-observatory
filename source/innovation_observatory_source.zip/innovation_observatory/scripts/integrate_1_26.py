"""Source-specific demographics, pension references and external public claims."""
from pathlib import Path
from collections import Counter
import json
R=Path(__file__).resolve().parents[1];D=R/'dist/data';read=lambda p:json.loads(p.read_text());ps=read(D/'profiles.json');prior={x['code']:x['params']for x in read(R/'research/dynamics_audit_1_26/prior_parameters_1_25.json')};pop=read(R/'research/demography_1_26/age_cohorts_2023.json');ret=read(R/'research/demography_1_26/retirement_ages_2023.json');ext=read(R/'research/sovereign_foreign_1_26/opening_foreign_sovereign_2023.json');inc=read(R/'research/dynamics_audit_1_26/income_evidence/income_anchors_2023.json');participation=read(R/'research/demography_1_26/post_eligibility_participation_2023.json');cohorts={}
for p in ps:
 c=p['code'];x=p['params'];old=prior[c];a=pop['countries'][c];r=ret['countries'][c];f=ext['countries'][c];i=inc[c]
 x.update(ageCohorts=1,retirementAge=r['representativeAge'],initialRetirementAge=r['representativeAge'],postRetirementParticipation=participation['countries'][c]['relativePercent'] if participation['countries'][c]['relativePercent'] is not None else 15,retirementParticipationResponse=.5,incomeAccountingAlignment=1,initialPopulationMillions=a['totalMillions'],initialChildShare=a['childShare'],initialOldShare=a['older65plusShare'],foreignGovBondMarket=1,foreignGovMarketSensitivity=.05)
 for k in ['birthRate','deathRate','netMigrationRate']:x[k]=old[k]*old['initialPopulationMillions']/a['totalMillions']
 total=f['totalForeignGovDebtGDP'];bonds=f['foreignGovSecuritiesGDP'];other=f['foreignGovOtherDebtGDP'];known=f.get('governmentDebtSecuritiesKnownSubsetGDP')
 x['foreignGovOpeningKnown']=int(total is not None)
 x['initialForeignGovDebt']=total if total is not None else 0;x['initialForeignGovBonds']=bonds if bonds is not None else known or 0;x['initialForeignGovOtherDebt']=other if other is not None else 0
 share=f.get('foreignShareOfGovDebtSecurities')
 if share is None:share=f.get('foreignShareOfGovDebtSecuritiesProxy')
 if share is None:share=f.get('observedForeignDebtSharePct')
 x['foreignGovDemandShare']=min(95,share if share is not None else 20)
 assert x['initialForeignGovDebt']<=x['initialPublicDebt']+1e-8
 cohorts[str(x['foreignPoolId'])]=dict(country=c,weights=a['percentages'],terminalAge=a['terminalAge'])
 p['revision126PriorDefaults']={k:old.get(k)for k in ['initialPopulationMillions','initialChildShare','initialOldShare','birthRate','deathRate','netMigrationRate']}
 def provenance(key,status,dataset,url,note,year=2023):p['provenance'][key]=dict(status=status,dataset=dataset,url=url,year=year,parameterValue=x[key],note=note)
 for k in ['initialPopulationMillions','initialChildShare','initialOldShare','ageCohorts']:provenance(k,'proxy'if c=='CHN'or k=='ageCohorts'else'derived',a['source'],a['url'],a['ageResolution']+'. Annual ageing uses observed age composition; within-five-year allocation and future age-specific mortality/migrant profiles are assumptions. Source reference date: '+a['referenceDate'])
 for k in ['birthRate','deathRate','netMigrationRate']:
  p['provenance'][k].update(parameterValue=x[k]);p['provenance'][k]['note']=p['provenance'][k]['note'].split(' Re-expressed on the new same-year population denominator')[0]+' Re-expressed on the new same-year population denominator while retaining the prior source annual count or labelled scenario assumption.'
 for k in ['retirementAge','initialRetirementAge']:provenance(k,'proxy',r['source'],r['url'],r['representativeMethod']+' Source male/female references: '+str(r['maleAge'])+'/'+str(r['femaleAge'])+'. Eligibility is not actual labour-force exit. Future statutory changes are not automatically predicted.')
 provenance('postRetirementParticipation','proxy','Eurostat lfsa_argan2023 age65+/15–64 activity ratio' if c not in ['USA','CHN']else'ILOSTAT published2023 age65+/15–64 participation estimates',participation['countries'][c]['sourceURL'],'Source age-band activity ratio mapped to a simple age profile; not an estimated pension-reform elasticity. USA/China provider source codes and status flags are retained. Baseline15–64 activity remains separately source-calibrated.')
 provenance('retirementParticipationResponse','assumed','Unestimated retirement-policy response',None,'Illustrative0.5year shift in age activity profile per policy-year change. No effect on baseline where the policy age equals its reference; compare0and1in sensitivity.',None)
 provenance('incomeAccountingAlignment','derived','Matched model income-account coverage',None,'Opening income shares use the same additional production-tax coverage as later model years. No wage, GDP or TFP path is changed by this measurement correction.')
 provenance('foreignGovOpeningKnown','derived',f['source'],f['url'],'Coverage flag: unavailable extra-EU aggregate remains missing rather than an observation of zero debt.')
 for k in ['initialForeignGovDebt','initialForeignGovBonds','initialForeignGovOtherDebt']:
  status='proxy'if c=='USA'else'derived'
  if total is None or k=='initialForeignGovBonds'and bonds is None or k=='initialForeignGovOtherDebt'and other is None:status='assumed'if c!='USA'else'proxy'
  provenance(k,status,f['source'],f['url'],'Source scope: '+f['mappingStatus']+'. Identified foreign bonds, other external debt and unallocated instruments remain separate. An execution0for an unavailable instrument is not an observation of no debt. The represented international balance sheet is partial.')
 provenance('foreignGovDemandShare','proxy'if share is not None else'assumed',f['source'],f['url'],'Stock ownership maps to new-issue investor participation, an unestimated flow proxy. Instrument/issuer gaps remain explicit; EU27extra-EU holdings are not the sum of nationalS2 positions.')
 provenance('foreignGovBondMarket','assumed','Enabled model financing channel',None,'Foreign purchases are financial-account transactions; coupons abroad enter current-account primary-income debits. Government debt need not move one-for-one with the current account.',None)
 provenance('foreignGovMarketSensitivity','assumed','Unestimated portfolio response',None,'Response to policy-linked return, currency, lagged external-funding risk and debt. No coefficient was fitted to future GDP or current-account outcomes.',None)
 p['provenance']['bankGovernmentShare']['note']='Assumed bank allocation within the DOMESTIC public-debt remainder, after externally held claims. Banks cover domestic financing not taken by household market orders.'
 if 'laborShare'in p['provenance']:
  p['provenance']['laborShare'].update(status='proxy',pwtMethod=i.get('method'),pwtObservationStatus=i.get('status'));p['provenance']['laborShare']['note']='PWTlabsh basic-price labour-compensation share, with its method/self-employment adjustment: '+str(i.get('method'))+'; source status: '+str(i.get('status'))+'. Used as an opening model labour-income/payroll scale proxy, not directly observed employee wages or a factor-cost share. Its denominator differs from the displayed two-factor split.'
 p['dataSummary']=dict(Counter(z['status']for z in p['provenance'].values()));p['coverageSummary'].update(observedOrMapped=sum(z['status']in['observed','derived','proxy']for z in p['provenance'].values()),assumedOrDesign=sum(z['status']in['assumed','design']for z in p['provenance'].values()))
(D/'profiles.json').write_text(json.dumps(ps,ensure_ascii=False,indent=2)+'\n');(R/'dist/cohort-data.mjs').write_text('export const AGE_COHORT_DATA='+json.dumps(cohorts,separators=(',',':'))+';\n')
for name,source in [('age_cohorts',pop),('retirement_ages',ret),('foreign_sovereign',ext),('income_share_sources',inc),('older_participation',participation)]:(D/(name+'_2023.json')).write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
# Compact combined source references for the browser; raw files stay in research.
refs={c:dict(retirement=ret['countries'][c],population={k:v for k,v in pop['countries'][c].items()if k not in ['counts','weights','percentages','maleCounts','femaleCounts','maleWeights','femaleWeights']},foreign=ext['countries'][c],income=inc[c])for c in inc};(R/'dist/revision126-data.mjs').write_text('export const REVISION126_SOURCES='+json.dumps(refs,ensure_ascii=False,separators=(',',':'))+';\n')
cov=read(D/'global_input_coverage.json');cov['modelVersion']='1.26.0';cov['countries']=[{k:p[k]for k in ['code','name','sourceLabel','labourAge','dataSummary','coverageSummary']}for p in ps];(D/'global_input_coverage.json').write_text(json.dumps(cov,ensure_ascii=False,indent=2)+'\n');print('Integrated2023source contexts for',len(ps),'economies')

import assert from 'node:assert/strict';
import {readFileSync, writeFileSync} from 'node:fs';
import {simulate, quantile} from '../dist/engine.mjs';
import {MODEL_VERSION} from '../dist/parameters.mjs';

const root = new URL('../', import.meta.url);
const read = path => JSON.parse(readFileSync(new URL(path,root)));
const source = name => read('research/source_snapshots/'+name+'.json');
const profiles = read('dist/data/profiles.json');
const prices = source('hicp_annual');
const growth = source('gdp_growth_2024_25');
const labor = source('unemployment_2024_25');
const trade = source('trade_nominal_2023_25');
const monthlyRates = readFileSync(new URL('research/source_snapshots/bis_real_exchange_rates.csv',root),'utf8').trim().split(/\r?\n/);
const columns = monthlyRates.shift().split(',');
const realRates = new Map(monthlyRates.map(line=>{
  const cells = line.split(',');
  const value = key => cells[columns.indexOf(key)];
  return [value('REF_AREA')+' '+value('TIME_PERIOD'),Number(value('OBS_VALUE'))];
}));
const seeds = Array.from({length:20},(_,i)=>2026+7919*i);
const stressSeeds = seeds.slice(0,5);
const mean = values => values.reduce((sum,value)=>sum+value,0)/values.length;
const median = values => quantile(values,.5);
const changes = (rows,key) => rows.map(row=>row[key]-row.observed[key]);
const errors = (rows,key) => {
  const valid = rows.filter(row=>Number.isFinite(row.observed[key]));
  const gaps = changes(valid,key);
  return {countries:gaps.length,mae:mean(gaps.map(Math.abs)),rmse:Math.sqrt(mean(gaps.map(gap=>gap**2)))};
};
function observation(table,geo,year,selection) {
  const dimensions = {geo,time:String(year),...selection};
  const key = table.id.reduce((index,name,i)=>index*table.size[i]+table.dimension[name].category.index[dimensions[name]],0);
  return table.value[key]??null;
}
function realRateChange(geo,year) {
  const country = geo==='EL'?'GR':geo;
  const average = period => {
    const values = Array.from({length:12},(_,i)=>realRates.get(country+' '+period+'-'+String(i+1).padStart(2,'0')));
    return values.every(Number.isFinite)?mean(values):null;
  };
  const base = average(2023), current = average(year);
  return base&&current ? 100*(current/base-1) : null;
}
function observed(geo,horizon) {
  const year=2023+horizon;
  const gdpGrowth = y=>observation(growth,geo,y,{freq:'A',unit:'CLV_PCH_PRE',na_item:'B1GQ'});
  const first = 1+gdpGrowth(2024)/100;
  const gdp = 100*((horizon===1 ? first : Math.sqrt(first*(1+gdpGrowth(2025)/100)))-1);
  const national = item => observation(trade,geo,year,{freq:'A',unit:'CP_MEUR',na_item:item});
  const nominal = national('B1GQ'), exports = national('P6'), imports = national('P7');
  return {gdp,unemployment:observation(labor,geo,year,{freq:'A',unit:'PC_ACT',sex:'T',age:'Y15-74'}),
    inflation:observation(prices,geo,year,{freq:'A',unit:'RCH_A_AVG',coicop:'CP00'}),
    netExports:[nominal,exports,imports].every(Number.isFinite)?100*(exports-imports)/nominal:null,
    realCurrency:realRateChange(geo,year)};
}
const conditions = {
  closed: () => ({tradeEnabled:0}),
  open: () => ({tradeEnabled:1}),
  staticMarket: () => ({tradeEnabled:1,foreignDemandGrowth:0}),
  broad: profile => {
    const p = profile.params;
    const grossImports = profile.observations.national_accounts_pct_gdp.P7;
    const openingConsumption = 100-p.initialGovernmentShare-p.investmentShare;
    return {tradeEnabled:1,importShare:Math.min(35,15*grossImports*(1+p.consumptionTax/100)/openingConsumption),
      exportDemand:.15*profile.observations.national_accounts_pct_gdp.P6};
  },
  floating: () => ({tradeEnabled:1,policyDynamics:1,currencyDynamics:1}),
  importOnly: () => ({tradeEnabled:1,exportDemand:0}),
  exportOnly: () => ({tradeEnabled:1,importShare:0}),
};
let maxResidual = 0, annualSteps = 0, paths = 0;
function simulateRows(p,seed,options) {
  const {rows} = simulate(p,seed,options);
  paths++;
  annualSteps+=p.periods;
  for (const row of rows) {
    const scale = Math.max(1,row.nominalOutput);
    maxResidual = Math.max(maxResidual,row.relativeResidual,Math.abs(row.savingIdentityResidual)/scale,Math.abs(row.nominalGDPResidual)/scale);
  }
  return rows;
}
const scores = {};
for (const name of ['closed','open','staticMarket','broad','floating']) {
  const predictions = [];
  for (const profile of profiles) {
    const rows = seeds.map(seed=>simulateRows({...profile.params,...conditions[name](profile),periods:8},seed));
    for (const horizon of [1,2]) {
      const med = value => median(rows.map(path=>value(path[horizon])));
      predictions.push({code:profile.code,horizon,observed:observed(profile.geo,horizon),
        gdp:med(row=>100*((row.output/100)**(1/horizon)-1)),unemployment:med(row=>row.unemployment),
        inflation:med(row=>row.inflation),netExports:med(row=>100*row.currentAccount/row.nominalOutput),
        realCurrency:med(row=>row.realExchangeRate-100)});
    }
  }
  const memberCountries = Object.fromEntries([1,2].map(horizon=>{
    const rows = predictions.filter(row=>row.code!=='EU27'&&row.horizon===horizon);
    return [horizon,Object.fromEntries(['gdp','unemployment','inflation','netExports','realCurrency'].map(key=>[key,errors(rows,key)]))];
  }));
  scores[name] = {memberCountries,predictions};
}

const stress = {}, baselines = new Map();
for (const [name, settings] of Object.entries(conditions)) {
  const outcomes = [];
  for (const profile of profiles) for (const seed of stressSeeds) {
    const rows = simulateRows({...profile.params,...settings(profile),periods:40},seed);
    const end = rows.at(-1), key = profile.code+' '+seed;
    if(name==='closed')baselines.set(key,rows[4]);
    const baseline = baselines.get(key);
    outcomes.push({code:profile.code,seed,year4OutputGap:rows[4].output-baseline.output,
      year4HouseholdGoodsGap:rows[4].householdGoods-baseline.householdGoods,
      year40Output:end.output,year40DebtGDP:100*end.publicDebt/end.nominalOutput});
  }
  stress[name] = {paths:outcomes.length,belowHalfOutput:outcomes.filter(r=>r.year40Output<50).length,
    debtAbove300:outcomes.filter(r=>r.year40DebtGDP>300).length,
    medianEarlyOutputGap:median(outcomes.map(r=>r.year4OutputGap)),
    medianEarlyHouseholdGoodsGap:median(outcomes.map(r=>r.year4HouseholdGoodsGap)),outcomes};
}

const exchangeCases = [];
const keys = ['currencyStrength','realExchangeRate','importPrice','exports','imports','exportOrders',
  'importBudgetShare','currentAccount','inflation','output','employment','householdGoods'];
for (const profile of profiles) for (const seed of stressSeeds) {
  const p = {...profile.params,tradeEnabled:1,currencyDynamics:1,currencyRateResponse:0,currencyAdjustment:1,periods:12};
  const outcomes = [0,-10,10].map(target=>simulateRows(p,seed,{paths:[{key:'currencyPressure',start:4,end:6,target,mode:'pulse'}]}));
  assert.deepEqual(outcomes[0].slice(0,4),outcomes[1].slice(0,4));
  assert.deepEqual(outcomes[0].slice(0,4),outcomes[2].slice(0,4));
  const [reference,weak,strong] = outcomes.map(rows=>rows[4]);
  assert(weak.realExchangeRate<reference.realExchangeRate&&reference.realExchangeRate<strong.realExchangeRate);
  assert(weak.exportOrders>reference.exportOrders&&reference.exportOrders>strong.exportOrders);
  assert(weak.importBudgetShare<reference.importBudgetShare&&reference.importBudgetShare<strong.importBudgetShare);
  const gap = row=>Object.fromEntries(keys.map(key=>[key,row[key]-reference[key]]));
  exchangeCases.push({code:profile.code,seed,weak:gap(weak),strong:gap(strong)});
}
const exchange = Object.fromEntries(['weak','strong'].map(side=>[side,Object.fromEntries(keys.map(key=>{
  const values = exchangeCases.map(row=>row[side][key]);
  return [key,{medianGap:median(values),higher:values.filter(gap=>gap>1e-8).length,
    lower:values.filter(gap=>gap<-1e-8).length}];
}))]));
assert(maxResidual<1e-8);
const report = {modelVersion:MODEL_VERSION,
  protocol:'2023 opening presets, compared with 2024 and 2025 revised observations. Medians of 20 common seeds per preset, with equal weight across the 27 member countries. The EU27 model preset is included in simulations and excluded from member scores.',
  measurement:'GDP growth is annualized from 2023. Inflation and unemployment use the year’s value. External benchmarks are Eurostat net exports of goods and services as a share of GDP and the BIS annual-average broad real currency index, rebased to 2023. The model uses a partial final-goods market and a producer-price currency index against one foreign basket.',
  decision:'Offer trade as an experiment. The narrower 5% scale and an assumed 2% annual expansion of foreign real demand contain some of the extreme outcomes of the broader market. The historical growth and employment fit improved, but the external benchmarks and long-run fiscal outcomes give mixed results.',
  exchangeProtocol:'A temporary currency target change of ±10 log points from year 4 to year 6, with unchanged policy settings and the exchange rate response to interest differentials disabled to isolate the shock. Gaps are for the first affected year against matched unshocked paths.',
  exchangePairs:exchangeCases.length,exchange,exchangeCases,stress,scores,paths,annualSteps,maxResidual,seeds,stressSeeds};
writeFileSync(new URL('dist/data/trade_validation.json',root),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({paths,annualSteps,maxResidual,open:scores.open.memberCountries[2],closed:scores.closed.memberCountries[2],
  stress:Object.fromEntries(Object.entries(stress).map(([name,run])=>[name,{belowHalf:run.belowHalfOutput,highDebt:run.debtAbove300}])),
  exchange},null,2));

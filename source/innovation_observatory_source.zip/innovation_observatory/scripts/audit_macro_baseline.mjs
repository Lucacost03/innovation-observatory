import fs from 'node:fs';
import {simulate,quantile} from '../research/frozen_engine_v1_18_1/engine.mjs';
import {DEFAULTS} from '../research/frozen_engine_v1_18_1/parameters.mjs';
const profiles=JSON.parse(fs.readFileSync(new URL('../research/frozen_engine_v1_18_1/profiles.json',import.meta.url)));
const selected=['output','goodsOutput','nominalOutput','inflation','producerInflation','consumerPriceIndex','producerPrice','priceMoney','privateMoney','moneyVelocity','realizedVelocity','quantityPriceGap','humanCapitalIndex','educationResourcesIndex','publicEducationSpending','policyRate','capital','technology','publicDebtGDP','householdDeposits','firmDeposits','bankReserves','householdBusinessEquity','householdPublicDebt','householdForeignAssets'];
const runs=[];for(const p of profiles)for(const seed of [2026,9945,17864]){
 const r=simulate({...p.params,periods:40},seed);runs.push({code:p.code,seed,rows:r.rows.map(x=>Object.fromEntries(['t',...selected].map(k=>[k,x[k]])))});
}
const italy=profiles.find(x=>x.code==='ITA'),education=[];for(const seed of [2026,9945,17864,25783,33702])for(const [name,change,paths] of [['base',{},[]],['educationOff',{educationEnabled:0},[]],['halfElasticity',{educationElasticity:(italy.params.educationElasticity??DEFAULTS.educationElasticity)/2},[]],['betterQuality',{},[{key:'publicEducationQuality',start:4,end:4,target:1.5,mode:'step'},{key:'privateEducationQuality',start:4,end:4,target:1.5,mode:'step'}]]]){
 const r=simulate({...italy.params,...change,periods:40},seed,{paths});education.push({name,seed,rows:r.rows.map(x=>({t:x.t,output:x.output,humanCapitalIndex:x.humanCapitalIndex,technology:x.technology}))});
}
const final=runs.map(x=>x.rows.at(-1)),stats={paths:runs.length,medianFinalGDP:quantile(final.map(x=>x.output),.5),medianAnnualInflation:quantile(runs.map(r=>100*((r.rows.at(-1).consumerPriceIndex/100)**(1/40)-1)),.5),yearsDeflation:runs.reduce((s,r)=>s+r.rows.slice(1).filter(x=>x.inflation<0).length,0),minRate:Math.min(...runs.flatMap(r=>r.rows.map(x=>x.policyRate)))};
fs.writeFileSync(new URL('../research/macro_policy/baseline.json',import.meta.url),JSON.stringify({version:'1.18.1',stats,runs,education},null,2));console.log(JSON.stringify(stats));console.log('Italy',runs.find(r=>r.code==='ITA'&&r.seed===2026).rows.filter(r=>[0,1,5,10,20,40].includes(r.t)));console.log('Education',education.filter(x=>x.seed===2026).map(x=>({name:x.name,...x.rows.at(-1)})));

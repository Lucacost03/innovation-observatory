"""Map frozen official observations to inputs, preserving uncertainty and units."""
from pathlib import Path
import csv,hashlib,json,math,statistics

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'dist/data';RAW=ROOT/'research/source_snapshots'

def decode(name):
 d=json.loads((RAW/(name+'.json')).read_text());cats=[]
 for dim in d['id']:
  ix=d['dimension'][dim]['category']['index'];cats.append([k for k,_ in sorted(ix.items(),key=lambda x:x[1])])
 rows=[]
 for key,value in d.get('value',{}).items():
  if value is None:continue
  n=int(key);indices=[]
  for size in reversed(d['size']):indices.append(n%size);n//=size
  row={dim:cats[i][j] for i,(dim,j) in enumerate(zip(d['id'],reversed(indices)))}
  row.update(value=float(value),flag=d.get('status',{}).get(key,''),_dataset=name);rows.append(row)
 return rows

def enrich():
 profiles=json.loads((DATA/'profiles.json').read_text());old={x['code']:x for x in json.loads((ROOT/'research/frozen_v1/profiles.json').read_text())}
 manifest=json.loads((RAW/'MANIFEST.json').read_text());sources={x['name']:x for x in manifest if x['status']=='ok'}
 tables={name:decode(name) for name in sources if (RAW/(name+'.json')).exists()}
 rates=list(csv.DictReader((RAW/'corporate_loan_rates.csv').open()))
 old_defaults=json.loads((ROOT/'research/frozen_v1/defaults.json').read_text())
 changes=[];coverage={};used=[]
 def one(name,geo,**filters):
  q=[x for x in tables[name] if x.get('geo')==geo and all(x.get(k)==v for k,v in filters.items())]
  if len(q)>1:raise ValueError('Ambiguous source selection '+name+' '+str(filters))
  return q[0] if q else None
 def series(name,geo,**filters):return [x for x in tables[name] if x.get('geo')==geo and all(x.get(k)==v for k,v in filters.items())]
 for p in profiles:
  geo=p['geo'];code=p['code'];p['params']=dict(old[code]['params']);p['provenance']={};p['observations']={};p['sourceYear']=2023;p['modelVersion']='1.2.0'
  def put(key,value,status,dataset,note,selection=None,rawrows=None):
   assert math.isfinite(value),(code,key,value)
   previous=old[code]['params'].get(key,old_defaults.get(key))
   p['params'][key]=value;p['provenance'][key]={'status':status,'dataset':dataset,'year':2023,'note':note,'selection':selection or {},'url':sources[dataset]['url'] if dataset in sources else None,'flags':sorted({r.get('flag','') for r in (rawrows or []) if r.get('flag','')})}
   if previous!=value:changes.append({'economy':code,'parameter':key,'previousPreset':previous,'newValue':value,'status':status,'dataset':dataset})
   if dataset in sources:
    used.extend({'economy':code,'parameter':key,**r,'dataset':r.get('_dataset',dataset)} for r in (rawrows or []))
    p['provenance'][key]['components']=[{'dataset':r.get('_dataset',dataset),**{k:v for k,v in r.items() if k!='_dataset'}} for r in (rawrows or [])]
  # Existing PWT levels remain; their use as model wage/measurement scales is a proxy.
  for key in ['capitalOutputRatio','laborShare','tfpCapitalShare','depreciation']:
   p['provenance'][key]={'status':'proxy' if key!='depreciation' else 'observed','dataset':'PWT 11.0','year':2023,'note':{'capitalOutputRatio':'National-price capital stock/output; one representative production sector.','laborShare':'Adjusted labor-income share sets the wage scale; not an estimated permanent wage rule.','tfpCapitalShare':'One minus initial labor share is a fixed accounting exponent; not identified technology.','depreciation':'PWT annual aggregate capital depreciation rate.'}[key],'flags':[]}
  unemployment=one('unemployment',geo)
  assert unemployment is not None,('Missing unemployment',geo)
  u=unemployment['value'];p['observations']['unemployment_pct_labor_force']=u
  put('employmentRate',100-u,'derived','unemployment','100 minus unemployment, ages 15–74, total sex, % active labor force. Not employment/population.',{'freq':'A','age':'Y15-74','sex':'T','unit':'PC_ACT'},[unemployment])
  debt=one('public_debt',geo);assert debt is not None
  put('initialPublicDebt',debt['value'],'observed','public_debt','General government consolidated gross debt at end-2023, % GDP. Modeled as a generic public-debt claim; actual instrument mix is condensed.',{'sector':'S13','na_item':'GD','unit':'PC_GDP'},[debt])
  for key,sector in [('householdWealth','S14_S15'),('firmLiquidity','S11'),('governmentDeposit','S13')]:
   r=one('financial_stocks',geo,sector=sector,finpos='ASS');assert r is not None,(geo,sector)
   put(key,r['value'],'proxy','financial_stocks','Observed currency and deposits, % GDP, mapped to a single model-bank deposit. Foreign-bank counterparties and currency are condensed; existing loans do not add a second cash endowment.',{'sector':sector,'finpos':'ASS','na_item':'F2','co_nco':'NCO','unit':'PC_GDP'},[r])
  accounts={k:one('national_accounts',geo,na_item=k) for k in ['B1GQ','P31_S14_S15','P3_S13','P51G','P6','P7']}
  assert all(accounts[k] is not None for k in ['B1GQ','P31_S14_S15','P3_S13','P51G'])
  gdp=accounts['B1GQ']['value'];domestic=sum(accounts[k]['value'] for k in ['P31_S14_S15','P3_S13','P51G'])
  p['observations']['national_accounts_pct_gdp']={k:100*r['value']/gdp for k,r in accounts.items() if r is not None and k!='B1GQ'}
  for key,item in [('governmentShare','P3_S13'),('investmentShare','P51G')]:
   put(key,100*accounts[item]['value']/domestic,'proxy','national_accounts','Current-price national accounts replace the PWT PPP spending-share proxy. Domestic-use normalization excludes trade and inventories; government consumption is represented as goods demand, so this is not a literal GDP expenditure share.',{'unit':'CP_MEUR','numerator':item,'denominator':'P31_S14_S15 + P3_S13 + P51G'},[accounts[k] for k in ['B1GQ','P31_S14_S15','P3_S13','P51G']])
  capacity=series('capacity',geo)
  if len(capacity)==4:
   put('initialUtilization',statistics.mean(r['value'] for r in capacity),'proxy','capacity','Mean of four seasonally adjusted 2023 industry-survey capacity-use observations. Industry is a proxy for the model production sector, not the whole economy.',{'indic':'BS-ICU-PC','s_adj':'SA','freq':'Q'},capacity)
  else:p['provenance']['initialUtilization']={'status':'assumed','year':None,'note':'No complete four-quarter capacity-use record; illustrative 80% retained.'}
  income=one('household_income',geo,unit='CP_MEUR',direct='RECV')
  if income:
   put('initialIncome',100*income['value']/gdp,'proxy','household_income','Gross disposable income of households and NPISH, % GDP, initializes lagged household income. Its distribution across synthetic households is assumed.',{'sector':'S14_S15','na_item':'B6G','direct':'RECV','unit':'CP_MEUR'},[income,accounts['B1GQ']])
  else:put('initialIncome',60,'assumed','assumption','No aligned gross-disposable-income observation; explicit 60-unit assumption.')
  personal_tax=one('government_accounts',geo,na_item='D51A_C1REC')
  government_social=one('government_accounts',geo,na_item='D61REC')
  tax_fallback=False
  if personal_tax is None:
   personal_tax=one('household_deductions',geo,na_item='D5');tax_fallback=True
  if personal_tax and government_social:
   deductions=personal_tax['value']+government_social['value']
   note='Government individual-income/holding-gain tax and net social-contribution receipts / initial model gross labor income. A budget calibration scale, not an individual tax rate. Private pension contributions are not all assigned to government.'
   if tax_fallback:note+=' Individual-income tax detail is unavailable; household current income/wealth taxes D5 are an explicit broader fallback.'
   put('incomeTax',100*(100*deductions/gdp)/p['params']['laborShare'],'proxy','government_accounts',note,{'na_item':('household D5' if tax_fallback else 'D51A_C1REC')+' + government D61REC','denominator':'GDP × PWT labor share','fallback_dataset':'household_deductions' if tax_fallback else None},[government_social]+([] if tax_fallback else [personal_tax]))
   if tax_fallback:used.append({'economy':code,'parameter':'incomeTax','dataset':'household_deductions',**personal_tax})
  else:put('incomeTax',20,'assumed','assumption','No aligned household fiscal receipts; illustrative 20% deduction scale retained.')
  vat=one('government_accounts',geo,na_item='D211REC')
  if vat and 0<vat['value']<accounts['P31_S14_S15']['value']:
   put('consumptionTax',100*vat['value']/(accounts['P31_S14_S15']['value']-vat['value']),'proxy','government_accounts','Total government VAT receipts / household consumption excluding those receipts. A uniform consumption-tax proxy, not a statutory VAT rate; actual tax bases include other final uses.',{'na_item':'D211REC','denominator':'P31_S14_S15 − D211REC'},[vat,accounts['P31_S14_S15']])
  # Observed cash benefits are used once: unemployment benefits are removed
  # from flat support whenever the functional breakdown is available.
  cash=one('government_accounts',geo,na_item='D62PAY');unemp=one('government_accounts',geo,na_item='D62PAY_GF1005')
  assert cash is not None
  if unemp and u>0 and unemp['value']<=cash['value']:
   replacement=(100*unemp['value']/gdp)/(p['params']['laborShare']/p['params']['employmentRate']*u)*100
   put('unemploymentReplacement',replacement,'proxy','government_accounts','Aggregate unemployment cash spending divided by model unemployed labor and initial wage. Not a statutory or individual replacement rate.',{'na_item':'D62PAY_GF1005','unit':'MIO_EUR'},[unemp,unemployment])
   flat=cash['value']-unemp['value']
   note='Cash social benefits excluding separately modeled unemployment cash benefits; % GDP. Recipient allocation is simplified.'
  else:
   flat=cash['value'];put('unemploymentReplacement',0,'assumed','assumption','Separate unemployment-benefit breakdown unavailable. All observed cash benefits enter flat support; no extra payment is added, avoiding double counting.')
   note='Total cash social benefits / GDP, including unemployment benefits. No separate extra unemployment payment is added; response to unemployment is not identified.'
  put('incomeSupport',100*flat/gdp,'proxy','government_accounts',note,{'na_item':'D62PAY','unit':'MIO_EUR'},[cash]+([unemp] if unemp else []))
  interest=one('government_accounts',geo,na_item='D41PAY')
  if interest and debt['value']>0:
   put('bondRate',100*interest['value']/(gdp*debt['value']/100),'proxy','government_accounts','Accrued government interest expenditure divided by end-year gross debt. A stock-cost proxy, not a market yield.',{'na_item':'D41PAY','denominator':'2023 GDP × 2023 gross debt/GDP'},[interest,debt])
  # Fiscal R&D uses source OF FUNDING, not GOV+HES performers. Government-funded
  # business research is explicitly transferred to firms and never paid twice.
  rd_total=one('public_rd_funding',geo,sectperf='TOTAL')
  rd_bes=one('public_rd_funding',geo,sectperf='BES')
  if code=='EU27' and rd_bes is None:
   components=[one('public_rd_funding',x['geo'],sectperf='BES') for x in profiles if x['code']!='EU27']
   if len(components)==27 and all(r is not None for r in components):
    rd_bes={'value':sum(r['value'] for r in components),'flag':'derived from 27 member observations','geo':geo,'sectperf':'BES','sectfund':'GOV','unit':'MIO_EUR','time':'2023'}
    p['observations']['public_rd_business_aggregation']='Sum of all 27 available member-country government-funded business R&D expenditures.'
  if rd_total:
   put('publicResearch',100*rd_total['value']/gdp,'proxy','public_rd_funding','Observed government-funded GERD / GDP replaces the old GOV+HES performer proxy. Its modeled payroll/transfer allocation remains simplified.',{'sectfund':'GOV','sectperf':'TOTAL','unit':'MIO_EUR'},[rd_total])
   if rd_bes and 0<=rd_bes['value']<=rd_total['value']:
    put('publicGrantShare',100*rd_bes['value']/rd_total['value'],'derived','public_rd_funding','Share of government-funded R&D performed by businesses. Grants finance part of the business R&D payroll, not an additional duplicate research payment.',{'sectfund':'GOV','numerator':'BES','denominator':'TOTAL'},[rd_bes,rd_total])
   else:put('publicGrantShare',0,'assumed','assumption','No matched business-funded-by-government detail. No business grant is imputed; allocation remains uncertain.')
  else:
   put('publicGrantShare',0,'assumed','assumption','No aligned government-funding breakdown; old non-business performer scale retained as an explicit proxy.')
   p['provenance']['publicResearch']={'status':'proxy','year':2023,'dataset':'Eurostat rd_e_gerdtot','note':'Government funding unavailable; original GOV+HES performer scale is retained and is not labeled actual government funding.'}
  p['provenance']['rdBusiness']={'status':'proxy','dataset':'Eurostat rd_e_gerdtot','year':2023,'note':'Business-performed GERD / GDP from the bundled snapshot. Its labor-cost share scales payroll; non-labor GERD is not explicitly financed. No causal R&D return is inferred.','flags':[p['flags']['BES']] if p['flags'].get('BES') else []}
  if 'rd_performance' in tables:
   rd=one('rd_performance',geo,sectperf='BES')
   if rd:put('rdBusiness',100*rd['value']/gdp,'proxy','rd_performance','Observed business-performed GERD / aligned nominal GDP. Refreshed 2023 source replaces the earlier rounded snapshot. Converted to a payroll target with the business labor-cost share. Non-labor costs remain outside the explicit model account; innovation returns remain assumed.',{'sectperf':'BES','unit':'MIO_EUR','denominator':'nama_10_gdp B1GQ'},[rd,accounts['B1GQ']])
   for sector in ['TOTAL','GOV','HES','PNP']:
    obs=one('rd_performance',geo,sectperf=sector)
    p['observations']['rd_'+sector+'_pct_gdp']=100*obs['value']/gdp if obs else None
   p['rdTotal']=p['observations']['rd_TOTAL_pct_gdp'];p['rdNonProfit']=p['observations']['rd_PNP_pct_gdp']
   p['archivedRDSnapshot']={'rdTotal':old[code]['rdTotal'],'rdBusiness':old[code]['params']['rdBusiness'],'flags':old[code]['flags']}
   p['flags']={sector:(one_row.get('flag','') if one_row else None) for sector in ['BES','GOV','HES','PNP','TOTAL'] for one_row in [one('rd_performance',geo,sectperf=sector)]}
  cost_total=one('business_rd_costs',geo,expend='TOTAL');cost_labor=one('business_rd_costs',geo,expend='CUR_LC')
  if cost_total and cost_labor and 0<=cost_labor['value']<=cost_total['value'] and cost_total['value']>0:
   put('rdLaborShare',100*cost_labor['value']/cost_total['value'],'derived','business_rd_costs','Business GERD labor cost / total GERD. Corrects the earlier 100%-payroll mapping. Only funded payroll uses research hours and drives innovation here; non-labor GERD is not explicitly financed or capitalized.',{'sectperf':'BES','numerator':'CUR_LC','denominator':'TOTAL','unit':'MIO_EUR'},[cost_labor,cost_total])
  else:put('rdLaborShare',60,'assumed','assumption','No matched 2023 business GERD labor-cost split. Explicit illustrative 60% share; not imputed as an observation or estimated causal coefficient.')
  area='GR' if geo=='EL' else geo
  r=[x for x in rates if x['REF_AREA']==area and x.get('OBS_VALUE') and x['TIME_PERIOD'].startswith('2023-')]
  if len(r)==12 and code!='EU27':
   put('loanRate',statistics.mean(float(x['OBS_VALUE']) for x in r),'proxy','corporate_loan_rates','Mean of 12 monthly annualized rates on outstanding euro-denominated NFC loans. One uniform model rate replaces the synthetic 4%; not a new-business rate.',{'BS_ITEM':'A20','IR_BUS_COV':'O','BS_COUNT_SECTOR':'2240','CURRENCY_TRANS':'EUR'},[{'value':float(x['OBS_VALUE']),'time':x['TIME_PERIOD'],'geo':area,'flag':x.get('OBS_STATUS','')} for x in r])
  else:p['provenance']['loanRate']={'status':'assumed','dataset':'assumption','year':None,'note':'No matched economy-wide corporate loan rate from this euro-area source. Explicit 4% assumption retained; the euro area is not substituted for EU27 or non-euro members.'}
  for key in ['fiscalAdjustment','publicResearchReturn']:
   put(key,0,'assumed','assumption','Disabled in the baseline because its policy/causal response is not identified. Zero is a neutral scenario convention, not an empirical zero-effect estimate. Optional nonzero settings remain experiments.')
  for key,value,note in [('burnIn',0,'No automatic settling before the observed baseline; optional settling makes period-zero stocks simulated, not source-year data.'),('initialLeverage',.1,'Illustrative business loan/capital ratio. Total NFC debt is not misrepresented as domestic bank lending.'),('bankGovernmentShare',20,'Assumed bank share of initial public debt and new public financing; the remaining initial claim is held by model households.')]:
   put(key,value,'assumed','assumption',note)
  # Full source table is explicit even for remaining initial assumptions.
  for key,meta in p['provenance'].items():coverage.setdefault(key,{}).setdefault(meta['status'],0);coverage[key][meta['status']]+=1
  p['dataSummary']={'observed':sum(x['status']=='observed' for x in p['provenance'].values()),'derived':sum(x['status']=='derived' for x in p['provenance'].values()),'proxy':sum(x['status']=='proxy' for x in p['provenance'].values())}
  if code=='EU27':
   p['aggregation']['domesticShares']='Official Eurostat EU27_2020 current-price P3_S13 and P51G / (P31_S14_S15 + P3_S13 + P51G). Replaces PWT PPP expenditure weighting.'
   p['aggregation']['interpretation']='One representative EU27 economy. PWT capital/output, labor and depreciation aggregation is retained; other mapped inputs use official Eurostat EU aggregates. No internal country trade or financial flows.'
   p['aggregation']['legacyExpenditureWeights']='expenditureWeight is retained for audit of the superseded PPP spending mapping; it does not set the revised spending shares.'
  opening=p['params']['householdWealth']+p['params']['firmLiquidity']+p['params']['governmentDeposit']+20-100*p['params']['capitalOutputRatio']*.1-p['params']['initialPublicDebt']*.2
  assert opening>=0,(code,'Opening balance-sheet gap',opening)
 (DATA/'profiles.json').write_text(json.dumps(profiles,indent=2,allow_nan=False))
 e=json.loads((DATA/'evidence.json').read_text());e.update(modelVersion='1.2.0',officialSourcesAdded=manifest,inputCoverage=coverage,profiles=len(profiles),newDataSnapshotYear=2023)
 e['mapping'].update({'employmentRate':'100 − Eurostat unemployment, 15–74, total sex, PC_ACT.','initialPublicDebt':'Eurostat GD / PC_GDP at end-2023.','householdWealth':'Eurostat F2 assets / GDP, S14_S15, mapped to model deposits.','firmLiquidity':'Eurostat F2 assets / GDP, S11; total initial cash, not cash plus initial loans.','governmentDeposit':'Eurostat F2 assets / GDP, S13.','initialUtilization':'Average of all four 2023 industry-survey observations, BS-ICU-PC / SA; proxy.','initialIncome':'Household gross disposable income / GDP, B6G / RECV / S14_S15.','governmentShare':'Eurostat P3_S13 / (P31_S14_S15 + P3_S13 + P51G), CP_MEUR; closed-economy proxy.','investmentShare':'Eurostat P51G / same domestic denominator; closed-economy proxy.','publicResearch':'Government-funded TOTAL GERD / GDP; no longer assumed equal to GOV+HES performers.','publicGrantShare':'Government-funded business GERD / government-funded TOTAL GERD, where available.','loanRate':'12-month mean, outstanding NFC euro loan rate, ECB MIR; unmatched economies retain an explicit assumption.','bondRate':'Government interest expense / end-year gross public debt; stock-cost proxy.','incomeSupport':'Observed cash social benefits / GDP, excluding separately modeled unemployment payments where the breakdown exists.'})
 e['officialSources'] += [{'title':'Eurostat '+x['dataset'],'url':x['url']} for x in manifest if x['status']=='ok' and x['dataset']!='ECB MIR']+[{'title':'ECB outstanding corporate loan interest rates','url':'https://data.ecb.europa.eu/data/datasets/MIR/MIR.M.U2.B.A20.A.R.A.2240.EUR.O'}]
 e['officialSources']=list({x['url']:x for x in e['officialSources']}.values())
 e['limitations'] += ['New source observations are 2023 values retrieved in November 2026. Revisions are retained; this is not a historical vintage backtest.','Currency and deposit assets are condensed into a single model bank, including simplified foreign counterparties.','Business GERD is split using observed labor-cost shares where matched; only payroll is explicitly financed and affects innovation. Non-labor GERD is a benchmark outside the modeled production account. Non-business R&D remains reduced form.']
 e['limitations']=list(dict.fromkeys(e['limitations']))
 e['euAggregate']=next(x['aggregation'] for x in profiles if x['code']=='EU27')
 e['limitations']=[x for x in e['limitations'] if x!='The mapping of annual data to model periods has no validated calendar interpretation.']
 e['limitations']+=['Annual rates are used per step; dynamic paths have not been validated as calendar-year forecasts.'] if 'Annual rates are used per step; dynamic paths have not been validated as calendar-year forecasts.' not in e['limitations'] else []
 e['mapping']['rdLaborShare']='Eurostat rd_e_gerdcost / BES / CUR_LC divided by TOTAL; 24 observations, four explicit 60% assumptions.'
 e['mapping'].update({'rdBusiness':'2023 business-performed GERD in MIO_EUR / aligned nominal GDP, replacing rounded original snapshot.','incomeTax':'Government individual-income taxes plus net social receipts / initial model gross labor income. Household D5 substitutes where individual-tax detail is unavailable; explicit broader proxy.','consumptionTax':'Government VAT receipts / household consumption excluding those receipts; uniform model tax proxy.'})
 (DATA/'evidence.json').write_text(json.dumps(e,indent=2,allow_nan=False));(DATA/'empirical_changes.json').write_text(json.dumps({'modelVersion':'1.2.0','coverage':coverage,'changes':changes},indent=2,allow_nan=False))
 (DATA/'official_data_manifest.json').write_text(json.dumps(manifest,indent=2))
 with (DATA/'new_empirical_observations.csv').open('w',newline='') as f:
  cols=['economy','parameter','dataset','geo','time','value','flag'];w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore',lineterminator='\n');w.writeheader();w.writerows(used)
 print(json.dumps({'profiles':len(profiles),'coverage':coverage,'changes':len(changes)},indent=2))

if __name__=='__main__':enrich()

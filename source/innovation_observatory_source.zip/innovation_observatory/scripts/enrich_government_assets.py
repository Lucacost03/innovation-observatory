"""Map frozen Eurostat 2023 government liquidity and equity, without zeroing assets."""
from pathlib import Path
import datetime,hashlib,json

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'research/source_snapshots/government_cash_equity_2023.json'
URL='https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_f_bs?lang=en&freq=A&unit=PC_GDP&co_nco=NCO&sector=S13&finpos=ASS&na_item=F2&na_item=F5&time=2023'
data=json.loads(RAW.read_text())
profiles=json.loads((ROOT/'dist/data/profiles.json').read_text())
def observation(geo,item):
    selection={'freq':'A','unit':'PC_GDP','co_nco':'NCO','sector':'S13','finpos':'ASS','na_item':item,'geo':geo,'time':'2023'}
    offset=0
    for key,size in zip(data['id'],data['size']):offset=offset*size+data['dimension'][key]['category']['index'][selection[key]]
    return {'dataset':'government_cash_equity',**selection,'value':data['value'][str(offset)],'flag':data.get('status',{}).get(str(offset),'')}
benchmarks={}
for p in profiles:
    cash_obs,equity_obs=observation(p['geo'],'F2'),observation(p['geo'],'F5')
    cash,equity=cash_obs['value'],equity_obs['value']
    p['params']['governmentDeposit']=cash
    p['params']['initialPublicEquity']=equity
    p['provenance']['governmentDeposit']={'status':'proxy','dataset':'Eurostat nasa_10_f_bs S13 F2 assets','year':2023,'url':URL,
        'note':'Observed general-government currency and deposits (% GDP), condensed into treasury liquidity. The opening ratio also anchors a cash-management target against lagged real GDP at the current producer price. Cash above the target redeems outstanding bonds. The target rule is assumed; real governments hold deposits and cash reserves.'}
    p['provenance']['initialPublicEquity']={'status':'proxy','dataset':'Eurostat nasa_10_f_bs S13 F5 assets','year':2023,'url':URL,
        'note':'Observed general-government equity and investment fund shares (% GDP), including financial corporations and social-security fund portfolios. Mapped to opening domestic-firm ownership at model book value. It is not a direct measure of only non-financial public companies. Later valuation and dividends follow modeled firms rather than observed security prices.'}
    for key,obs in [('governmentDeposit',cash_obs),('initialPublicEquity',equity_obs)]:
        p['provenance'][key].update({'selection':{k:v for k,v in obs.items() if k not in ['dataset','value','flag']},'flags':[obs['flag']] if obs['flag'] else [],'components':[obs]})
    benchmarks[p['code']]={'year':2023,'governmentCashGDP':cash,'governmentEquityGDP':equity,'url':URL,'sourceUpdatedAt':data['updated'],'observations':[cash_obs,equity_obs],'scope':'General government, non-consolidated financial assets; F2 and F5. The model maps the broader equity portfolio to domestic firms and values it at residual book value.'}
(ROOT/'dist/data/profiles.json').write_text(json.dumps(profiles,indent=2)+'\n')
(ROOT/'dist/data/government_asset_benchmarks.json').write_text(json.dumps(benchmarks,indent=2)+'\n')
manifest=json.loads((ROOT/'dist/data/official_data_manifest.json').read_text())
manifest=[row for row in manifest if row['name']!='government_cash_equity']
manifest.append({'name':'government_cash_equity','dataset':'Eurostat nasa_10_f_bs S13 F2/F5 assets, 2023','url':URL,'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'path':str(RAW.relative_to(ROOT)),'status':'ok','bytes':RAW.stat().st_size,'sha256':hashlib.sha256(RAW.read_bytes()).hexdigest()})
(ROOT/'dist/data/official_data_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
evidence=json.loads((ROOT/'dist/data/evidence.json').read_text());evidence['officialSourcesAdded']=manifest
evidence['mapping']['initialPublicEquity']='2023 Eurostat government F5 assets / GDP. Broader portfolio mapped to domestic firm book equity and its dividends; initialization proxy, not an estimated ownership policy.'
evidence['mapping']['governmentDeposit']='2023 Eurostat government F2 assets / GDP, condensed into treasury liquidity. Excess cash repays bonds pro rata. The liquidity-target rule is an assumption.'
(ROOT/'dist/data/evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps({'presets':len(profiles),'Italy':benchmarks['ITA'],'EU27':benchmarks['EU27']},indent=2))

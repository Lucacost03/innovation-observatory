"""Restore optional compressed fixtures without replacing changed local files."""
from pathlib import Path,PurePosixPath
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[1];M=R/'research/archived_fixtures_manifest.json'
if M.exists():
 manifest=json.loads(M.read_text());missing=[k for k in manifest if not(R/k).exists()]
 if missing:
  with tarfile.open(R/'research/archived_fixtures.tar.xz')as a:
   for k in missing:
    assert k in manifest and not PurePosixPath(k).is_absolute()and'..'not in PurePosixPath(k).parts
    m=a.getmember(k);assert m.isfile();data=a.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==manifest[k];p=R/k;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  print('Restored',len(missing),'historical fixtures with verified hashes.')

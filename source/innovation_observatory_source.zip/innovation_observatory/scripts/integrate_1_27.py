"""Source-year hours envelope. Uses PWT2013–2023, never future GDP targets."""
from pathlib import Path
from collections import Counter
import json,hashlib
import pandas as pd
R=Path(__file__).resolve().parents[1];D=R/'dist/data';A=R/'research/growth_audit_1_27';A.mkdir(exist_ok=True)
source=R/'research/source_snapshots/pwt110.xlsx';data=pd.read_excel(source,sheet_name='Data');profiles=json.loads((D/'profiles.json').read_text());prior=json.loads((R/'research/frozen_engine_v1_26/profiles.json').read_text());countries={}
for profile in profiles:
 if 'replications'in profile['provenance']:profile['provenance']['replications']['note']=profile['provenance']['replications']['note'].replace('P10–P90 is simulated variation, not a real policy confidence interval.','Central95% seed variation is distinct from the95% paired-mean confidence interval within this model.')
 code=profile['code'];members=[x['code']for x in profiles if x['code']not in['EU27','USA','CHN']]if code=='EU27'else[code]
 rows=data[data.countrycode.isin(members)&data.year.between(2013,2023)].copy();rows=rows[rows.avh.notna()&rows.emp.notna()]
 hours=rows.groupby('year').apply(lambda q:(q.avh*q.emp).sum()/q.emp.sum(),include_groups=False)
 if 2023 not in hours.index:countries[code]={'known':False};continue
 ratio=100*float(hours.max()/hours.loc[2023]);assert 100<=ratio<=160
 note='PWT11.0 avh, annual hours per person engaged. Employment-weighted member average for EU27. Historical2013–2023 maximum /2023 hours maps to the model hours ceiling. This workforce/age-scope mapping and treating a past range as a future constraint are proxy assumptions, not an estimated response or a physical limit. No2024+ GDP or hours target is used.'
 countries[code]={'known':True,'hours2023':float(hours.loc[2023]),'maximumHours2013to2023':float(hours.max()),'maximumRatioPct':ratio,'annualHours':{str(k):float(v)for k,v in hours.items()},'note':note,'url':'https://www.rug.nl/ggdc/productivity/pwt/'}
 old=next(x for x in prior if x['code']==code);profile['revision127PriorDefaults']={'maximumHours':old['params'].get('maximumHours',115)};profile['params']['maximumHours']=ratio
 profile['provenance']['maximumHours']={'status':'proxy','dataset':'PWT11.0 avh,2013–2023 historical range','year':2023,'sourceValue':float(hours.loc[2023]),'sourceUnit':'annual hours/person engaged','parameterValue':ratio,'parameterUnit':'% starting-year hours','url':countries[code]['url'],'note':note}
 profile['dataSummary']=dict(Counter(x['status']for x in profile['provenance'].values()))
 if 'coverageSummary'in profile:profile['coverageSummary'].update(observedOrMapped=sum(x['status']in['observed','derived','proxy']for x in profile['provenance'].values()),assumedOrDesign=sum(x['status']in['assumed','design']for x in profile['provenance'].values()))
(A/'hours_envelope.json').write_text(json.dumps({'sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'window':'2013–2023 only;2024+ not used','countries':countries},indent=2)+'\n');(A/'prior_parameters_1_26.json').write_text(json.dumps([{'code':p['code'],'params':p['params']}for p in prior],indent=2)+'\n')
(D/'profiles.json').write_text(json.dumps(profiles,ensure_ascii=False,indent=2)+'\n');pkg=R/'package.json';j=json.loads(pkg.read_text());j['version']='1.27.0';pkg.write_text(json.dumps(j,indent=2)+'\n')
coverage=D/'global_input_coverage.json'
if coverage.exists():
 c=json.loads(coverage.read_text());c['modelVersion']='1.27.0';c['countries']=[{k:p[k]for k in['code','name','sourceLabel','labourAge','dataSummary','coverageSummary']}for p in profiles];coverage.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print('Mapped source hours envelopes:',sum(x['known']for x in countries.values()),'of',len(profiles))

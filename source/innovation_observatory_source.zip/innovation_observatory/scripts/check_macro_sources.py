"""Independent coordinate, unit and historical-growth checks against frozen primary data."""
from pathlib import Path
import json,csv,math,hashlib
import pandas as pd
R=Path(__file__).resolve().parents[1];S=R/'research/macro_external_tfp';D=R/'dist/data'
read=lambda p:json.loads(p.read_text())
b=read(D/'macro_external_benchmarks.json');profiles=read(D/'profiles.json');manifest=read(S/'source_manifest.json')
for f in manifest:assert hashlib.sha256((S/f['file']).read_bytes()).hexdigest()==f['sha256']
load=lambda key:{(r['countryiso3code'],int(r['date'])):r['value']for r in read(S/(key+'.json'))[1]}
ca=load('BN.CAB.XOKA.GD.ZS');gd=load('NY.GDP.MKTP.CD');ex=load('BX.GSR.GNFS.CD');im=load('BM.GSR.GNFS.CD')
wdi={(r['countryiso3code'],int(r['date']),r['indicator']['id']):r['value']for r in read(S/'national_expenditure_ratios.json')[1]}
book=pd.read_excel(R/'research/source_snapshots/pwt110.xlsx',sheet_name='Data').set_index(['countrycode','year']);history=list(csv.DictReader((S/'pwt_tfp_history.csv').open()))
fields=0
for r in history:
    row=book.loc[r['countrycode'],int(r['year'])]
    for k,v in r.items():
        if k in ['countrycode','year']:continue
        assert math.isclose(float(v),float(row[k]),rel_tol=1e-12,abs_tol=1e-12),(r['countrycode'],r['year'],k)
        fields+=1
members=[p['code']for p in profiles if p['code']not in ['EU27','USA','CHN']];g={c:100*((book.loc[(c,2023),'rtfpna']/book.loc[(c,2013),'rtfpna'])**.1-1)for c in members+['USA','CHN']}
g['EU27']=sum(book.loc[(c,2023),'cgdpo']*g[c]for c in members)/sum(book.loc[(c,2023),'cgdpo']for c in members)
checks=0
for p in profiles:
    c=p['code'];n=b['countries'][c];x=p['params'];code='EUU'if c=='EU27'else c
    GDP=sum(gd[m,2023]for m in members)if c=='EU27'else gd[c,2023]
    CA=sum(ca[m,2023]*gd[m,2023]for m in members)/GDP if c=='EU27'else ca[c,2023]
    X=100*sum(ex[m,2023]for m in members)/GDP if c=='EU27'else 100*ex[c,2023]/GDP
    M=100*sum(im[m,2023]for m in members)/GDP if c=='EU27'else 100*im[c,2023]/GDP
    expected={'currentAccountGDP':CA,'observedExportsGDP':X,'observedImportsGDP':M,'goodsServicesBalanceGDP':X-M,'otherForeignIncomeGDP':CA-X+M,'observedTFPGrowth':g[c],'governmentConsumptionGDP':wdi[code,2023,'NE.CON.GOVT.ZS'],'fixedInvestmentGDP':wdi[code,2023,'NE.GDI.FTOT.ZS'],'inventoryInvestmentGDP':wdi[code,2023,'NE.GDI.TOTL.ZS']-wdi[code,2023,'NE.GDI.FTOT.ZS']}
    for k,v in expected.items():assert math.isclose(n[k],v,rel_tol=1e-10,abs_tol=1e-10),(c,k);checks+=1
    assert math.isclose(n['modelExportsGDP']-n['modelImportsGDP'],X-M,abs_tol=1e-12)
    assert math.isclose(x['observedCurrentAccount'],CA,abs_tol=1e-12)
    assert math.isclose(x['frontierGrowth'],g[c],abs_tol=1e-12)
    assert math.isclose(x['investmentShare'],expected['fixedInvestmentGDP'],abs_tol=1e-12)
cn=next(p for p in profiles if p['code']=='CHN');assert math.isclose(cn['params']['rdBusiness'],2592.22/126058.2*100,abs_tol=1e-12)
result=dict(status='PASS',sourceFilesHashed=len(manifest),PWTExtractFields=fields,countryMacroCoordinatesChecked=checks,countries=len(profiles),ChinaBERDPercentGDP=cn['params']['rdBusiness'],limitations='Source consistency and arithmetic checks, not a forecast validation. EU CA and historical TFP are constructed member aggregates; source vintages and covered definitions differ from consolidated published aggregates.')
(D/'macro_external_source_validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

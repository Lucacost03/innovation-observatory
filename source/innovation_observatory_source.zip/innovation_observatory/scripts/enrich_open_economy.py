"""Map frozen policy, price, fiscal and trade observations to the 2023 presets."""
import csv
import hashlib
import json
from math import prod
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'dist/data'
SNAPSHOTS = ROOT / 'research/source_snapshots'
YEAR = '2023'
TRADE_COVERAGE = .05
SOURCES = {
    'ecb_deposit_rate': ('ECB FM.D.U2.EUR.4F.KR.DFR.LEV',
                         'https://data-api.ecb.europa.eu/service/data/FM/D.U2.EUR.4F.KR.DFR.LEV?startPeriod=2023-12-29&endPeriod=2025-12-31&format=csvdata',
                         'ecb_deposit_rate.csv'),
    'bis_policy_rates': ('BIS WS_CBPOL',
                         'https://stats.bis.org/api/v1/data/BIS,WS_CBPOL,1.0/M.XM+CZ+DK+HU+PL+RO+SE+US+CN?startPeriod=2023-12&endPeriod=2025-12&format=csv',
                         'bis_policy_rates.csv'),
    'hicp_annual': ('Eurostat prc_hicp_aind',
                    'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/prc_hicp_aind?lang=en&freq=A&unit=RCH_A_AVG&coicop=CP00&sinceTimePeriod=2010&untilTimePeriod=2025',
                    'hicp_annual.json'),
    'gdp_growth_2024_25': ('Eurostat nama_10_gdp',
                          'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&freq=A&unit=CLV_PCH_PRE&na_item=B1GQ&sinceTimePeriod=2024&untilTimePeriod=2025',
                          'gdp_growth_2024_25.json'),
    'unemployment_2024_25': ('Eurostat une_rt_a',
                            'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/une_rt_a?lang=en&freq=A&unit=PC_ACT&sex=T&age=Y15-74&sinceTimePeriod=2024&untilTimePeriod=2025',
                            'unemployment_2024_25.json'),
    'trade_nominal': ('Eurostat nama_10_gdp, B1GQ, P6 and P7',
                      'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&freq=A&unit=CP_MEUR&na_item=B1GQ&na_item=P6&na_item=P7&sinceTimePeriod=2023&untilTimePeriod=2025',
                      'trade_nominal_2023_25.json'),
    'bis_real_exchange_rates': ('BIS WS_EER monthly broad real exchange rates',
                               'https://stats.bis.org/api/v1/data/BIS,WS_EER,1.0/M.R.B.?startPeriod=2023-01&endPeriod=2025-12&format=csv',
                               'bis_real_exchange_rates.csv'),
    'public_investment_growth': ('Eurostat nama_10_gdp, P3_S13 and P51G',
                                 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&freq=A&unit=CLV_PCH_PRE&na_item=P3_S13&na_item=P51G&sinceTimePeriod=2010&untilTimePeriod=2025',
                                 'public_investment_growth.json'),
}
NATIONAL = {'CZ': 'Czech National Bank', 'DK': 'Danmarks Nationalbank', 'HU': 'Magyar Nemzeti Bank',
            'PL': 'Narodowy Bank Polski', 'RO': 'National Bank of Romania', 'SE': 'Sveriges Riksbank'}


def read_json(path):
    return json.loads(path.read_text())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False))


def jsonstat_index(table, selection):
    offset = 0
    for key, size in zip(table['id'], table['size']):
        offset = offset * size + table['dimension'][key]['category']['index'][selection[key]]
    return str(offset)


def read_csv(name):
    with (SNAPSHOTS / name).open(newline='') as file:
        return list(csv.DictReader(file))


def provenance(source, status, note, flag):
    dataset, url, _ = SOURCES[source]
    return {'status': status, 'dataset': dataset, 'year': int(YEAR), 'url': url,
            'note': note, 'flags': [flag] if flag else []}


def main():
    profiles = read_json(DATA / 'profiles.json')
    hicp = read_json(SNAPSHOTS / 'hicp_annual.json')
    spending = read_json(SNAPSHOTS / 'public_investment_growth.json')
    ecb = [row for row in read_csv('ecb_deposit_rate.csv') if row['TIME_PERIOD'].startswith(YEAR)]
    ecb_open = max(ecb, key=lambda row: row['TIME_PERIOD'])
    bis_open = {row['REF_AREA']: row for row in read_csv('bis_policy_rates.csv') if row['TIME_PERIOD'] == YEAR + '-12'}
    for profile in profiles:
        geo = profile['geo']
        policy = ecb_open
        authority = 'European Central Bank'
        instrument = 'deposit facility rate'
        rate_status = 'observed'
        signal_geo = 'EA20'
        source = 'ecb_deposit_rate'
        if geo in NATIONAL:
            policy, authority, instrument, signal_geo = bis_open[geo], NATIONAL[geo], 'BIS policy rate', geo
            source = 'bis_policy_rates'
        if geo == 'BG':
            rate_status = 'proxy'
            authority = 'ECB anchor for Bulgaria’s 2023 currency board'
        if geo == 'EU27_2020':
            rate_status = 'proxy'
            signal_geo = geo
            authority = 'ECB proxy for the representative EU27 economy'
        selection = {'freq': 'A', 'unit': 'RCH_A_AVG', 'coicop': 'CP00', 'geo': signal_geo, 'time': YEAR}
        offset = jsonstat_index(hicp, selection)
        profile['params']['initialPolicyRate'] = float(policy['OBS_VALUE'])
        profile['params']['initialPolicyInflation'] = hicp['value'][offset]
        params = profile['params']
        legacy_loan_source = profile['provenance'].get('loanRate')
        if legacy_loan_source:
            spread = params.get('loanRate', 4) - params['initialPolicyRate']
            params = profile['params'] = {
                ('loanSpread' if key == 'loanRate' else key): (spread if key == 'loanRate' else value)
                for key, value in params.items()
            }
            params.setdefault('loanSpread', spread)
            profile['provenance'] = {
                ('loanSpread' if key == 'loanRate' else key): {
                    **value,
                    'note': (value['note'] + ' The opening business quote minus the opening central bank rate sets the spread. '
                             'The model applies policy pass-through in subsequent years.'),
                } if key == 'loanRate' else value
                for key, value in profile['provenance'].items()
            }
        params['priceDynamics'] = 1
        params['initialGovernmentShare'] = params['governmentShare']
        params['publicBudgetStability'] = 1
        profile['provenance']['initialGovernmentShare'] = {
            **profile['provenance']['governmentShare'],
            'note': 'Eurostat public final consumption as a share of domestic final uses. This fixes the opening snapshot. The public demand control changes subsequent planned purchases.',
        }
        growth_keys = [jsonstat_index(spending, {'freq': 'A', 'unit': 'CLV_PCH_PRE', 'na_item': 'P3_S13',
                                                'geo': geo, 'time': str(year)}) for year in range(2014, int(YEAR) + 1)]
        params['publicTrendGrowth'] = 100 * (prod(1 + spending['value'][key] / 100 for key in growth_keys)**.1 - 1)
        profile['provenance']['publicTrendGrowth'] = {
            'status': 'proxy', 'dataset': 'Eurostat nama_10_gdp P3_S13', 'year': '2014–2023',
            'url': SOURCES['public_investment_growth'][1],
            'note': 'Compound annual growth of government final consumption in volume over the ten years ending in 2023. The public budget rule uses this as a forward trend assumption.',
            'flags': sorted({spending.get('status', {}).get(key) for key in growth_keys if spending.get('status', {}).get(key)}),
        }
        consumption = 100 - params['initialGovernmentShare'] - params['investmentShare']
        opening_goods = 100 - consumption + consumption / (1 + params['consumptionTax'] / 100)
        trade = profile['observations']['national_accounts_pct_gdp']
        params['importShare'] = min(35, 100 * TRADE_COVERAGE * trade['P7'] * (1 + params['consumptionTax'] / 100) / consumption)
        params['exportDemand'] = TRADE_COVERAGE * trade['P6']
        for key, component, note in [
            ('importShare','P7','Five percent of observed gross imports expressed as a share of opening household spending, with VAT and a 35% cap.'),
            ('exportDemand','P6','Five percent of observed gross exports relative to GDP sets potential orders in opening real units.'),
        ]:
            observed = profile['provenance']['governmentShare']
            profile['provenance'][key] = {
                'status': 'proxy', 'dataset': f'Eurostat nama_10_gdp {component}', 'year': int(YEAR),
                'url': observed['url'], 'note': note + ' The 5% coverage is illustrative. The model settles final-goods trade.',
                'flags': [],
            }
        private_money = params['householdWealth'] + params['firmLiquidity']
        params['initialMoneyVelocity'] = opening_goods / private_money
        deposits = profile['provenance']['householdWealth']
        profile['provenance']['initialMoneyVelocity'] = {
            'status': 'derived', 'dataset': deposits['dataset'], 'year': int(YEAR), 'url': deposits['url'],
            'note': 'Opening model goods at producer prices divided by household and firm currency and deposits. The goods scale uses opening GDP and modeled VAT. Subsequent turnover is behavioral.',
            'flags': sorted(set(deposits.get('flags', []) + profile['provenance']['firmLiquidity'].get('flags', []))),
        }
        profile['provenance']['initialPolicyRate'] = provenance(
            source, rate_status, f'{authority} {instrument}. End-of-period observation {policy["TIME_PERIOD"]}.', policy['OBS_STATUS'])
        signal_label = 'Euro-area HICP' if signal_geo == 'EA20' else 'HICP for this economy'
        local_offset = jsonstat_index(hicp, {**selection, 'geo': geo})
        params['initialInflation'] = hicp['value'][local_offset]
        profile['provenance']['initialInflation'] = provenance(
            'hicp_annual', 'observed', 'Annual average all-items HICP for this economy. Displayed at year 0.',
            hicp.get('status', {}).get(local_offset, ''))
        profile['provenance']['initialPolicyInflation'] = provenance(
            'hicp_annual', 'observed', f'{signal_label}. Annual average all-items change used for the first model decision.',
            hicp.get('status', {}).get(offset, ''))
        profile['policyAuthority'] = {'name': authority, 'instrument': instrument, 'openingSignal': signal_label}
    write_json(DATA / 'profiles.json', profiles)

    manifest = [row for row in read_json(DATA / 'official_data_manifest.json') if row['name'] not in SOURCES]
    for name, (dataset, url, file) in SOURCES.items():
        path = SNAPSHOTS / file
        manifest.append({'name': name, 'dataset': dataset, 'url': url, 'retrievedAt': '2026-11-06', 'status': 'ok',
                         'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                         'bytes': path.stat().st_size})
    write_json(DATA / 'official_data_manifest.json', manifest)
    evidence = read_json(DATA / 'evidence.json')
    evidence['officialSourcesAdded'] = manifest
    evidence['mapping'].pop('loanRate', None)
    evidence['mapping']['loanSpread'] = (
        'ECB annual average outstanding business loan quote minus the opening policy rate where matched. '
        'Elsewhere, the difference from the earlier assumed 4% opening quote sets the spread.')
    evidence['limitations'] = [
        'With goods trade off, the model settles domestic purchases and uses the foreign sector for currency and knowledge inputs.'
        if item == 'Closed economy, fixed producer price, no trade, FX or inflation.' else
        'The optional final-goods trade channel uses a synthetic partner basket. It excludes imported intermediate inputs, '
        'foreign investment income and market valuation of foreign positions.'
        if item == 'Foreign knowledge can diffuse, but goods trade, FX, FDI and international financial accounts are absent.'
        else item for item in evidence['limitations']
    ]
    write_json(DATA / 'evidence.json', evidence)


if __name__ == '__main__':
    main()

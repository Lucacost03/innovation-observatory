from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];v=json.loads((R/'dist/data/fiscal_reconciliation_validation.json').read_text());u=[r for r in v['longRuns']if r['country']=='USA'];median=lambda x:sorted(x)[len(x)//2]
s={k:v[k]for k in ['modelVersion','paths','years','maxResidual','scoreCountries','scoreEU']};s['USA']=v['byCountry']['USA'];s['USAYear10']={k:median([r[k]['realGDP'][3]for r in u])for k in ['earlier','candidate']};s['countriesWithWorseGDPError']=sum(x['gdp']['candidate']['RMSE']>x['gdp']['earlier']['RMSE']for c,x in v['byCountry'].items()if c!='EU27');(R/'dist/fiscal-validation-summary.mjs').write_text('export const FISCAL_VALIDATION='+json.dumps(s,separators=(',',':'))+';\n')

"""Map frozen World Bank learning measures without inventing GDP coefficients.

Offline extraction checks two official formats and retains assessment vintages.
National learning outcomes do not identify public/private teaching efficiency.
"""
from pathlib import Path
from collections import Counter
import csv,hashlib,io,json,math,re,zipfile
import pandas as pd
R=Path(__file__).resolve().parents[1];S=R/'research/education_quality_candidates';D=R/'dist/data'
read=lambda p:json.loads(p.read_text())
manifest=read(S/'source_manifest.json')
for source in manifest:
    if 'sha256' in source:assert hashlib.sha256((S/source['file']).read_bytes()).hexdigest()==source['sha256']
book=pd.read_excel(S/'hci_data_september_2020.xlsx',sheet_name='HCI 2020 - MaleFemale')
book=book.set_index('WB Code')
z=zipfile.ZipFile(S/'hci_csv.zip')
rows=list(csv.DictReader(io.StringIO(z.read('HCIData.csv').decode('utf-8-sig'))))
foot=list(csv.DictReader(io.StringIO(z.read('HCIFootNote.csv').decode('utf-8-sig'))))
lookup={(x['Country Code'],x['Indicator Code']):x for x in rows}
notes={(x['CountryCode'],x['SeriesCode']):x['DESCRIPTION'] for x in foot if x['Year']=='YR2020'}
profiles=read(D/'profiles.json');countries={};checks=[]
url=next(s['url'] for s in manifest if s['file'].endswith('.xlsx'))
for p in profiles:
    code=p['code']
    if code=='EU27':continue
    record=book.loc[code];score=float(record['Harmonized Test Scores']);years=float(record['Expected Years of School']);lays=float(record['Learning-Adjusted Years of School'])
    for indicator,value in [('HD.HCI.HLOS',score),('HD.HCI.EYRS',years),('HD.HCI.LAYS',lays)]:
        assert math.isclose(float(lookup[(code,indicator)]['2020']),value,abs_tol=1e-8,rel_tol=1e-10),(code,indicator)
        checks.append({'country':code,'indicator':indicator,'xlsx':value,'csv':float(lookup[(code,indicator)]['2020'])})
    assert abs(years*score/625-lays)<2e-6,(code,'LAYS rounding')
    note=notes[(code,'HD.HCI.HLOS')];year=int(re.search(r'data for (\d{4})',note).group(1))
    countries[code]={'code':code,'name':p['name'],'harmonizedScore':score,'learningQuality':score/625,'expectedSchoolYears':years,'learningAdjustedSchoolYears':lays,'releaseYear':2020,'assessmentYear':year,'sourceNote':note,'status':'proxy','coverage':'World Bank extrapolated national estimate; not a nationwide PISA sample' if code=='CHN' else 'National harmonized learning-outcome estimate','sourceURL':url,'scoreInterval':None,'intervalNote':'The workbook gives overall HCI bounds, not test-score confidence bounds. No score interval is inferred from them.'}
# A pupil-cohort proxy supplies weights, not GDP: a representative EU economy
# is not itself an observed World Bank HCI country or a school system.
eu=[p for p in profiles if p['code'] not in ['USA','CHN','EU27']]
weights={p['code']:p['params']['initialPopulationMillions']*p['params']['initialChildShare']/100 for p in eu}
total=sum(weights.values());weights={k:v/total for k,v in weights.items()}
score=sum(weights[c]*countries[c]['harmonizedScore'] for c in weights)
countries['EU27']={'code':'EU27','name':'European Union (EU27)','harmonizedScore':score,'learningQuality':score/625,'expectedSchoolYears':sum(weights[c]*countries[c]['expectedSchoolYears'] for c in weights),'learningAdjustedSchoolYears':sum(weights[c]*countries[c]['learningAdjustedSchoolYears'] for c in weights),'releaseYear':2020,'assessmentYear':'2015–2018, member-specific','sourceNote':'Member estimates weighted by each country’s2023population aged0–14, a pupil-cohort proxy. Cohort composition and source dates differ. This is not an official EU score. Aggregate LAYS is the weighted member total, not mean EYS times mean score.','status':'proxy','coverage':'Synthetic EU aggregate from27national estimates','sourceURL':url,'weights':weights,'scoreInterval':None}
assert len(countries)==30
for p in profiles:
    e=countries[p['code']];q=e['learningQuality'];x=p['params'];prov=p['provenance']
    previous=p.setdefault('educationQualityPrior',{'publicEducationQuality':x.get('publicEducationQuality',1),'privateEducationQuality':x.get('privateEducationQuality',1),'normalization':1})
    # This is a source preset, not an update of a user's authored scenario.
    x.update(initialLearningScore=e['harmonizedScore'],initialEducationQuality=q,publicEducationQuality=q,privateEducationQuality=q)
    common={'status':'proxy','dataset':'World Bank HCI2020, Harmonized Test Scores','year':2020,'assessmentYear':e['assessmentYear'],'url':url,'sourceNote':e['sourceNote']}
    prov['initialLearningScore']={**common,'note':'TIMSS-equivalent harmonized learning outcome. Release 2020; the underlying assessment year is separate. This is an outcome proxy, not school quality isolated from family background or per-currency spending efficiency. '+e['coverage']+'.'}
    prov['initialEducationQuality']={**common,'note':'Harmonized test score /625, following the World Bank LAYS quality adjustment. Advanced-learning reference = 1; not a literal fraction of curriculum mastered or a GDP multiplier. EU27 is a pupil-cohort-weighted proxy. PWT adult human capital remains separate.'}
    for key,sector in [('publicEducationQuality','Public'),('privateEducationQuality','Household-funded')]:
        prov[key]={**common,'sectorAssignment':'assumed national-anchor fallback','note':sector+' learning-outcome proxy anchored to this country’s national score/625. Separate sector quality is not identified: both sectors share the national anchor as an explicit allocation fallback, not evidence that public and private schools are equal. Future edits are scenario assumptions. Funding is counted once and the opening national anchor normalizes the resource rule; no new causal GDP coefficient is introduced.'}
    p['dataSummary']=dict(Counter(s['status'] for s in prov.values()))
    if 'coverageSummary' in p:
        p['coverageSummary']['observedOrMapped']=sum(s.get('status') in ['observed','derived','proxy'] for s in prov.values())
        p['coverageSummary']['assumedOrDesign']=sum(s.get('status') in ['assumed','design'] for s in prov.values())
        p['coverageSummary']['sectorQualityFallback']=True
data={'source':'World Bank Human Capital Index2020','benchmarkScore':625,'releaseYear':2020,'retrievedAt':next(s['retrievedAt'] for s in manifest if s['file'].endswith('.xlsx')),'methodURL':'https://documents1.worldbank.org/curated/en/456901600111156873/pdf/The-Human-Capital-Index-2020-Update-HumanCapital-in-the-Time-of-covid-19.pdf','sourceManifest':manifest,'countries':countries,'formatChecks':checks,'mapping':'National quality anchor=harmonized score/625, the quality factor in learning-adjusted schooling. Quality-weighted funding uses changes relative to this opening country anchor. Existing adult skills, education elasticity and lag are retained.','limitations':['The 2020 release is not 2023 test data; most assessments are 2018, some 2015. It predates the pandemic learning shock.','Harmonization and sample coverage introduce uncertainty. China 441 is an official extrapolated national estimate with 2015 source metadata, not the high-performing PISA provinces substituted for China.','National means do not identify causal teaching efficiency, public/private gaps or wage/GDP returns. Sector assignment is a visible fallback.','EU27 weights use 2023 children aged 0–14 as a proxy for pupil cohorts, not observed assessment sample weights.','A better source-data match is not evidence of improved out-of-sample GDP forecasts.']}
(D/'education_quality_benchmarks.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(R/'dist/education-quality-data.mjs').write_text('// Generated by scripts/integrate_education_quality.py from frozen primary data.\nexport const EDUCATION_QUALITY='+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n')
(D/'profiles.json').write_text(json.dumps(profiles,ensure_ascii=False,indent=2)+'\n')
coverage=read(D/'global_input_coverage.json')
coverage['countries']=[{k:p[k] for k in ['code','name','sourceLabel','labourAge','dataSummary','coverageSummary']} for p in profiles]
coverage['modelVersion']='1.21.0'
coverage['educationQuality']={'source':data['source'],'nationalEstimates':29,'EUaggregate':'pupil-cohort proxy','publicPrivateSplit':'not identified; national-anchor allocation fallback'}
(D/'global_input_coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'nationalEstimates':29,'EUaggregate':1,'matchedFormatValues':len(checks),'scoreMin':min(c['harmonizedScore'] for c in countries.values()),'scoreMax':max(c['harmonizedScore'] for c in countries.values())}))

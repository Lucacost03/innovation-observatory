import fs from 'node:fs';
const root=new URL('../',import.meta.url),r=JSON.parse(fs.readFileSync(new URL('dist/data/revision126_validation.json',root)));
const summary={modelVersion:r.modelVersion,paths:r.paths,years:r.years,maxResidual:r.maxResidual,countries:r.scoreCountries,EU:r.scoreEU};
fs.writeFileSync(new URL('dist/revision126-validation-data.mjs',root),'export const REVISION126_CHECKS='+JSON.stringify(summary)+';\n');

import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {simulate,quantile} from '../dist/engine.mjs';
import {MODEL_VERSION} from '../dist/parameters.mjs';

const read = path=>JSON.parse(readFileSync(new URL('../dist/data/'+path,import.meta.url)));
const profiles=read('profiles.json');
const archived=read('finance_validation.json');
const observations=archived.recent.legacy.predictions;
const seeds=Array.from({length:20},(_,i)=>2026+7919*i);
const median=values=>quantile(values,.5);
const mean=values=>values.reduce((n,value)=>n+value,0)/values.length;
let paths=0,years=0,maxAccountingResidual=0,minWeight=Infinity,maxWeight=-Infinity;
function run(profile,params,seed,options){
  const rows=simulate({...profile.params,...params},seed,options).rows;
  paths++;
  for(const r of rows.slice(1)){
    years++;
    maxAccountingResidual=Math.max(maxAccountingResidual,r.financeResidual,r.relativeResidual,
      Math.abs(r.savingIdentityResidual)/Math.max(1,r.nominalOutput));
    minWeight=Math.min(minWeight,r.publicCreditWeight);
    maxWeight=Math.max(maxWeight,r.publicCreditWeight);
  }
  return rows;
}
const predictions=profiles.map(profile=>{
  const result=seeds.map(seed=>run(profile,{periods:8},seed)[2]);
  const observed=observations.find(row=>row.code===profile.code).observed;
  return {code:profile.code,observed,gdp:median(result.map(r=>100*(Math.sqrt(r.output/100)-1))),
    unemployment:median(result.map(r=>r.unemployment)),inflation:median(result.map(r=>r.inflation))};
});
const currentErrors=Object.fromEntries(['gdp','unemployment','inflation'].map(key=>{
  const gaps=predictions.filter(r=>r.code!=='EU27').map(r=>r[key]-r.observed[key]);
  return [key,{rmse:Math.sqrt(mean(gaps.map(d=>d*d))),mae:mean(gaps.map(Math.abs))}];
}));

const scenarios={
  default:{params:{}},
  combined:{params:{foreignPortfolioWeight:20,financialIncomeTax:15,wealthTax:1},options:{shocks:[
    {type:'foreignDemand',start:4,duration:3,magnitude:25,recovery:.5},
    {type:'supply',start:10,duration:2,magnitude:-35,recovery:0},
    {type:'policyRate',start:18,duration:2,magnitude:1.5,recovery:.4},
    {type:'exchangeRate',start:24,duration:2,magnitude:-12,recovery:.25},
  ]}},
};
const stress={};
for(const [name,{params,options}] of Object.entries(scenarios)){
  const outcomes=[];
  for(const profile of profiles)for(const seed of seeds.slice(0,5)){
    const rows=run(profile,{...params,periods:40},seed,options).slice(1);
    const last=rows.at(-1);
    outcomes.push({code:profile.code,seed,years:rows.length,
      yearsWithBothTradeFlows:rows.filter(r=>r.exports>0&&r.imports>0).length,
      highDebt:last.publicDebt>3*last.nominalOutput,belowHalfGDP:last.output<50,
      minExports:Math.min(...rows.map(r=>r.exports)),minImports:Math.min(...rows.map(r=>r.imports)),
      yearsWithSurplusFunding:rows.filter(r=>r.foreignAssetSurplusPurchases>0).length});
  }
  stress[name]={paths:outcomes.length,years:outcomes.reduce((n,r)=>n+r.years,0),
    yearsWithBothTradeFlows:outcomes.reduce((n,r)=>n+r.yearsWithBothTradeFlows,0),
    highDebt:outcomes.filter(r=>r.highDebt).length,belowHalfGDP:outcomes.filter(r=>r.belowHalfGDP).length,
    pathsWithSurplusFunding:outcomes.filter(r=>r.yearsWithSurplusFunding>0).length,outcomes};
}
assert(minWeight>=.2&&maxWeight<=.4);
assert(maxAccountingResidual<1e-8);
assert(stress.default.yearsWithBothTradeFlows===stress.default.years);
assert(stress.combined.pathsWithSurplusFunding>0);
const report={modelVersion:MODEL_VERSION,paths,years,maxAccountingResidual,minWeight,maxWeight,
  benchmark:{protocol:'2023 starting points, 20 paired seeds per preset and equal country weights. Compare 2025 GDP growth annualized from 2023, annual inflation and unemployment with the previously examined Eurostat observations.',
    priorErrors:archived.recent.legacy.errors,currentErrors,predictions},
  stress,combinedSettings:scenarios.combined,seeds};
writeFileSync(new URL('../dist/data/live_economy_validation.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({paths,years,maxAccountingResidual,minWeight,maxWeight,currentErrors,
  stress:Object.fromEntries(Object.entries(stress).map(([key,{outcomes,...stats}])=>[key,stats]))}));

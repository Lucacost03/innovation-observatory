"""Historical descriptive comparisons, never treated as holdout forecast errors."""
import csv,json,statistics
from enrich_profiles import decode,ROOT,DATA
profiles=json.loads((DATA/'profiles.json').read_text());countries={p['geo']:p['code'] for p in profiles}
growth=decode('historical_gdp_growth');unemployment=decode('historical_unemployment')
records={}
for name,rows in [('realGDPGrowthPct',growth),('unemploymentPctLaborForce',unemployment)]:
 for x in rows:
  if x['geo'] not in countries:continue
  key=(countries[x['geo']],int(x['time']));r=records.setdefault(key,{'economy':key[0],'year':key[1]});r[name]=x['value'];r[name+'Flag']=x['flag']
for (country,year),r in records.items():
 previous=records.get((country,year-1),{})
 if 'unemploymentPctLaborForce' in r and 'unemploymentPctLaborForce' in previous:r['employmentChangePP']=previous['unemploymentPctLaborForce']-r['unemploymentPctLaborForce']
def quantile(xs,q):
 a=sorted(xs);v=(len(a)-1)*q;i=int(v);return a[i]+(a[min(i+1,len(a)-1)]-a[i])*(v-i)
summary=[]
for key,label in [('realGDPGrowthPct','Observed real GDP growth (%)'),('employmentChangePP','Observed employment change (pp labor force)')]:
 xs=[r[key] for r in records.values() if r['economy']!='EU27' and key in r];assert len(xs)>300
 summary.append({'key':key,'label':label,'n':len(xs),'p10':quantile(xs,.1),'median':statistics.median(xs),'p90':quantile(xs,.9),'min':min(xs),'max':max(xs)})
e=json.loads((DATA/'evidence.json').read_text());e['historicalBenchmark']={'years':'2010–2023','summary':summary,'purpose':'Descriptive historical context, not matched forecast errors or an untouched holdout. Pooled member countries exclude the EU aggregate.'};(DATA/'evidence.json').write_text(json.dumps(e,indent=2))
with (DATA/'historical_benchmark.csv').open('w',newline='') as f:
 cols=['economy','year','realGDPGrowthPct','realGDPGrowthPctFlag','unemploymentPctLaborForce','unemploymentPctLaborForceFlag','employmentChangePP'];w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(records[k] for k in sorted(records))
print(json.dumps(e['historicalBenchmark'],indent=2))

"""Map frozen HCI+ 2026 national data without imposing a country ranking."""
from pathlib import Path
from collections import Counter
import csv, hashlib, json, math, tarfile, lzma
R=Path(__file__).resolve().parents[1];S=R/'research/education_2026';D=R/'dist/data'
read=lambda p:json.loads(p.read_text())
manifest=read(S/'source_manifest.json')
for source in manifest:
    f=S/source['file']
    if f.exists():
        assert hashlib.sha256(f.read_bytes()).hexdigest()==source['sha256'],source['file']
        if 'rawSha256'in source:
            if 'member'in source:
                with tarfile.open(f,'r:xz')as archive:assert hashlib.sha256(archive.extractfile(source['member']).read()).hexdigest()==source['rawSha256']
            else:assert hashlib.sha256(lzma.decompress(f.read_bytes())).hexdigest()==source['rawSha256']
def panel(name):
    with tarfile.open(S/'education_panels.tar.xz','r:xz')as archive:text=archive.extractfile(name).read().decode('utf-8-sig').lstrip('\ufeff')
    return {(x['iso3c'],int(x['year'])):x for x in csv.DictReader(text.splitlines())}
catalog=panel('catalog_hci_plus_index_panel.csv');github=panel('hci_plus_index_panel.csv')
sources={x['wbcode']:x for x in csv.DictReader((S/'learning_source_metadata.csv').open())}
profiles=read(D/'profiles.json');countries={};checks=[]
url=next(s['url'] for s in manifest if s.get('rawFile',s['file'])=='catalog_hci_plus_index_panel.csv')
for p in profiles:
    code=p['code']
    if code=='EU27':continue
    record,meta=catalog[(code,2025)],sources[code]
    for field in ['hlo_mf','eys_mf','eys_pp_mf','lays_mf','ter_ya_mf','hcip_schooling_component_mf']:
        a,b=float(record[field]),float(github[(code,2025)][field])
        assert math.isclose(a,b,abs_tol=1e-9,rel_tol=1e-12),(code,field)
        checks.append({'country':code,'indicator':field,'catalog':a,'repository':b})
    score,years,lays=[float(record[f])for f in ['hlo_mf','eys_mf','lays_mf']]
    assert math.isclose(score,float(meta['hlo_mf_fill_2025']),abs_tol=1e-7)
    assert math.isclose((years+float(record['eys_pp_mf']))*score/625,lays,abs_tol=2e-6)
    assert math.isclose(12*lays+64*min(.5,float(record['ter_ya_mf'])),float(record['hcip_schooling_component_mf']),abs_tol=2e-5)
    assessment=int(float(meta['hlo_mf_year_2025']));program=meta['hlo_mf_source_2025']
    note=f'HCI+ 2026 release, 2025 estimate. Learning source: {program}, {assessment}. The estimate year is not the assessment year.'
    if code=='CHN':note+=' The national score carries forward the 2015 extrapolation; it is not a fresh nationwide test or the PISA provincial sample.'
    countries[code]=dict(code=code,name=p['name'],harmonizedScore=score,learningQuality=score/625,expectedSchoolYears=years,
        learningAdjustedSchoolYears=lays,expectedPrePrimaryYears=float(record['eys_pp_mf']),tertiaryCompletion=float(record['ter_ya_mf']),educationPillar=float(record['hcip_schooling_component_mf']),
        releaseYear=2026,estimateYear=2025,assessmentYear=assessment,assessmentProgram=program,sourceNote=note,status='proxy',
        coverage='Extrapolated national estimate' if 'extrapolated' in program.lower() else 'National harmonized learning-outcome estimate',
        sourceURL=url,scoreInterval=None,intervalNote='No comparable test-score confidence bounds are supplied.')
eu=[p for p in profiles if p['code']not in ['USA','CHN','EU27']]
weights={p['code']:p['params']['initialPopulationMillions']*p['params']['initialChildShare']/100 for p in eu}
total=sum(weights.values());weights={k:v/total for k,v in weights.items()}
weighted=lambda key:sum(weights[c]*countries[c][key]for c in weights)
countries['EU27']=dict(code='EU27',name='European Union (EU27)',harmonizedScore=weighted('harmonizedScore'),learningQuality=weighted('learningQuality'),
    expectedSchoolYears=weighted('expectedSchoolYears'),expectedPrePrimaryYears=weighted('expectedPrePrimaryYears'),learningAdjustedSchoolYears=weighted('learningAdjustedSchoolYears'),releaseYear=2026,estimateYear=2025,
    assessmentYear='2018–2023, member-specific',assessmentProgram='Member-specific PISA / TIMSS / PIRLS',
    sourceNote='Member estimates weighted by 2023 population aged 0–14, a pupil-cohort proxy. This is not an official EU score. Aggregate LAYS is the weighted member total.',
    status='proxy',coverage='Synthetic EU aggregate from 27 national estimates',sourceURL=url,weights=weights,scoreInterval=None)
assert len(countries)==30
for p in profiles:
    e=countries[p['code']];q=e['learningQuality'];x=p['params'];prov=p['provenance']
    p.setdefault('educationQualityPrior',dict(publicEducationQuality=x.get('publicEducationQuality',1),privateEducationQuality=x.get('privateEducationQuality',1),normalization=1))
    x.update(initialLearningScore=e['harmonizedScore'],initialEducationQuality=q,publicEducationQuality=q,privateEducationQuality=q,educationTFPResponse=1)
    common=dict(status='proxy',dataset='World Bank HCI+ 2026, Harmonized Learning Outcomes',year=2025,releaseYear=2026,assessmentYear=e['assessmentYear'],url=url,sourceNote=e['sourceNote'])
    prov['initialLearningScore']={**common,'note':e['sourceNote']+' TIMSS-equivalent outcome, not causal teaching efficiency. Later education data proxy the 2023 opening snapshot.'}
    prov['initialEducationQuality']={**common,'note':'Harmonized score /625. Advanced-learning reference = 1, not a percentage mastered or immediate GDP multiplier. EU27 uses pupil-cohort weights. Adult PWT human capital remains separate.'}
    for key,sector in [('publicEducationQuality','Public'),('privateEducationQuality','Household-funded')]:
        prov[key]={**common,'sectorAssignment':'assumed national-anchor fallback','note':sector+' learning outcome anchored to the national score /625. Public/private causal quality gaps are unidentified; equal sector allocation is an assumption. Funding and quality changes count once, relative to the opening anchor.'}
    prov['educationTFPResponse']=dict(status='assumed',dataset='Research mechanism / scenario assumption',year=None,
        note='Elasticity of the innovation/adoption skills multiplier to workforce human capital. 1 preserves the previous channel; 2 is a stronger education experiment. Direction has research support; ABM magnitude is unestimated. It does not multiply TFP directly.')
    p['dataSummary']=dict(Counter(s['status']for s in prov.values()))
    if 'coverageSummary'in p:p['coverageSummary'].update(observedOrMapped=sum(s.get('status')in ['observed','derived','proxy']for s in prov.values()),assumedOrDesign=sum(s.get('status')in ['assumed','design']for s in prov.values()),sectorQualityFallback=True)
data=dict(source='World Bank Human Capital Index Plus 2026',benchmarkScore=625,releaseYear=2026,estimateYear=2025,
    retrievedAt=next(s['retrievedAt']for s in manifest if s.get('rawFile',s['file'])=='catalog_hci_plus_index_panel.csv'),sourceManifest=manifest,countries=countries,formatChecks=checks,
    methodURL='https://github.com/worldbank/HCI-Plus/blob/main/00_documentation/Technical_Note.md',
    mapping='National quality = harmonized score /625. Real resources and quality changes remain relative to the opening anchor; adult skills are separate.',
    comparison={c:countries[c]['harmonizedScore']for c in ['USA','CHN','EU27']},
    regionalEvidence=dict(source='OECD PISA 2025',scope='Beijing, Shanghai, Jiangsu and Zhejiang (B-S-J-Z), not national China',assessmentYear=2025,
        science=597,mathematics=612,reading=527,url='https://www.oecd.org/en/publications/pisa-2025-results-volume-i_73451bc5-en/full-report/student-performance-in-pisa-2025_23e075c2.html',
        note='Different scale and population. These contextual regional PISA scores are not substituted for national harmonized scores.'),
    limitations=['2026 release, 2025 estimate labels; actual learning assessments range from 2015 to 2023 in these presets.',
        'China 441 carries forward a 2015 national extrapolation with substantial coverage and timeliness uncertainty. PISA provinces do not represent all China.',
        'The US is above the constructed EU27 average, not every EU member. No national China-above-EU ranking is imposed.',
        'Later education data proxy a 2023 opening economy. This is not a real-time historical forecasting vintage.',
        'Public/private teaching gaps and the quantitative education-to-innovation elasticity are unidentified. Stronger transmission is an assumption.',
        'EU27 uses child-population weights rather than assessment sample weights. Source fidelity is not forecasting accuracy.'])
(D/'education_quality_benchmarks.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(R/'dist/education-quality-data.mjs').write_text('// Generated from frozen World Bank HCI+ 2026 data.\nexport const EDUCATION_QUALITY='+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n')
(D/'profiles.json').write_text(json.dumps(profiles,ensure_ascii=False,indent=2)+'\n')
coverage=read(D/'global_input_coverage.json');coverage['countries']=[{k:p[k]for k in ['code','name','sourceLabel','labourAge','dataSummary','coverageSummary']}for p in profiles]
coverage.update(modelVersion='1.24.0',educationQuality=dict(source=data['source'],nationalEstimates=29,EUaggregate='pupil-cohort proxy',publicPrivateSplit='not identified; national-anchor allocation fallback'))
(D/'global_input_coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(nationalEstimates=29,EUaggregate=1,sourceChecks=len(checks),comparison=data['comparison'])))

"""Fetch small, frozen 2023 extracts from official Eurostat and ECB endpoints.

Missing or failed sources remain explicit. No fabricated values or silent retries.
"""
import concurrent.futures,datetime,hashlib,json,urllib.parse,urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'research/source_snapshots';OUT.mkdir(parents=True,exist_ok=True)
BASE='https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/'
SPECS={
 'unemployment':('une_rt_a',[('freq','A'),('unit','PC_ACT'),('sex','T'),('age','Y15-74'),('time','2023')]),
 'public_debt':('gov_10dd_edpt1',[('freq','A'),('unit','PC_GDP'),('sector','S13'),('na_item','GD'),('time','2023')]),
 'national_accounts':('nama_10_gdp',[('freq','A'),('unit','CP_MEUR'),('time','2023')]),
 'government_accounts':('gov_10a_main',[('freq','A'),('unit','MIO_EUR'),('sector','S13'),('time','2023')]),
 'capacity':('ei_bsin_q_r2',[('freq','Q'),('indic','BS-ICU-PC'),('s_adj','SA'),('sinceTimePeriod','2023-Q1'),('untilTimePeriod','2023-Q4')]),
 'financial_stocks':('nasa_10_f_bs',[('freq','A'),('unit','PC_GDP'),('co_nco','NCO'),('time','2023'),('na_item','F2')]),
 'public_rd_funding':('rd_e_gerdfund',[('freq','A'),('unit','MIO_EUR'),('sectfund','GOV'),('time','2023')]),
 'rd_performance':('rd_e_gerdtot',[('freq','A'),('unit','MIO_EUR'),('time','2023')]),
 'business_rd_costs':('rd_e_gerdcost',[('freq','A'),('unit','MIO_EUR'),('sectperf','BES'),('time','2023')]),
 'historical_gdp_growth':('nama_10_gdp',[('freq','A'),('unit','CLV_PCH_PRE'),('na_item','B1GQ'),('sinceTimePeriod','2010'),('untilTimePeriod','2023')]),
 'historical_unemployment':('une_rt_a',[('freq','A'),('unit','PC_ACT'),('sex','T'),('age','Y15-74'),('sinceTimePeriod','2010'),('untilTimePeriod','2023')]),
 'household_income':('nasa_10_nf_tr',[('freq','A'),('sector','S14_S15'),('na_item','B6G'),('time','2023')]),
 'household_deductions':('nasa_10_nf_tr',[('freq','A'),('sector','S14_S15'),('na_item','D5'),('na_item','D61'),('direct','PAID'),('unit','CP_MEUR'),('time','2023')]),
}

def fetch(name,spec):
 dataset,params=spec
 url=BASE+dataset+'?'+urllib.parse.urlencode([('lang','en')]+params)
 return download(name,url,'json',dataset)

def download(name,url,extension,dataset):
 stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'InnovationObservatory-research/1.1','Accept':'application/json' if extension=='json' else 'text/csv'})
  with urllib.request.urlopen(req,timeout=30) as response:raw=response.read();status=response.status
  if extension=='json':
   parsed=json.loads(raw)
   if parsed.get('class')!='dataset':raise ValueError('Not a JSON-stat dataset: '+str(parsed)[:200])
   extra={'updated':parsed.get('updated'),'dimensions':parsed.get('id'),'size':parsed.get('size'),'numericObservations':len(parsed.get('value',{})),'label':parsed.get('label')}
  else:extra={}
  path=OUT/(name+'.'+extension);path.write_bytes(raw)
  print(name,'OK',len(raw),'bytes',flush=True)
  return {'name':name,'dataset':dataset,'url':url,'retrievedAt':stamp,'status':'ok','httpStatus':status,'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),**extra}
 except Exception as exc:
  print(name,'FAILED',type(exc).__name__,str(exc)[:150],flush=True)
  return {'name':name,'dataset':dataset,'url':url,'retrievedAt':stamp,'status':'failed','error':type(exc).__name__+': '+str(exc)[:500]}

if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  results=list(pool.map(lambda item:fetch(*item),SPECS.items()))
 # Outstanding-stock corporate loan rates, not rates on new business.
 areas='AT+BE+HR+CY+EE+FI+FR+DE+GR+IE+IT+LV+LT+LU+MT+NL+PT+SK+SI+ES+U2'
 url='https://data-api.ecb.europa.eu/service/data/MIR/M.'+areas+'.B.A20.A.R.A.2240.EUR.O?startPeriod=2023-01&endPeriod=2023-12&format=csvdata'
 results.append(download('corporate_loan_rates',url,'csv','ECB MIR'))
 (OUT/'MANIFEST.json').write_text(json.dumps(results,indent=2))
 print('Saved official source manifest.',flush=True)

// Fit an unobserved order book to the observed opening export-sales proxy.
// Only the 2023 snapshot is used. No 2024/2025 outcomes enter this calibration.
import fs from 'node:fs';
import {Economy} from '../dist/engine.mjs';
const root=new URL('../',import.meta.url),read=n=>JSON.parse(fs.readFileSync(new URL(n,root)));
const profiles=read('dist/data/profiles.json'),benchmark=read('dist/data/macro_external_benchmarks.json');
const seeds=[2026,9945,17864],checks=[];
for(const p of profiles){
 const target=p.params.initialExportSales;
 const opening={...p.params,periods:1,populationDynamics:0,priceDynamics:0,policyDynamics:0,currencyDynamics:0,foreignPriceGrowth:0,foreignDemandGrowth:0,supplyVolatility:0};
 const sales=orders=>seeds.reduce((s,seed)=>s+new Economy({...opening,exportDemand:orders},seed).step(1,1).exports,0)/seeds.length;
 let low=0.1,high=120;
 if(sales(high)<target-1e-8)throw Error(p.code+' opening export sales exceed the available export-order range.');
 for(let i=0;i<20;i++){const mid=(low+high)/2;if(sales(mid)<target)low=mid;else high=mid;}
 const orders=(low+high)/2,fitted=sales(orders),error=fitted-target;
 if(Math.abs(error)>1e-3)throw Error(p.code+' opening export fit failed.');
 p.params.exportDemand=orders;
 p.provenance.exportDemand={...p.provenance.exportDemand,status:'proxy',parameterValue:orders,
  note:'Potential export orders calibrated to opening realized export sales in the frozen 2023 economy, with no price/policy/currency/population trend, no supply noise and three predeclared seeds. Order books are unobserved. This is an in-sample sales-moment calibration, not a causal demand estimate or a fit to future current accounts.'};
 const result={country:p.code,targetExportSales:target,orders,fittedExports:fitted,residual:error,calibrationSeeds:seeds};checks.push(result);
 benchmark.countries[p.code].potentialExportOrders=orders;
 benchmark.countries[p.code].openingExportCalibration=result;
}
benchmark.tradeMethod='Complete observed net goods/services balance plus5% of matched common gross trade. Potential orders calibrated to the opening realized-sales proxy with frozen 2023 conditions; no future current-account targets.';
fs.writeFileSync(new URL('dist/data/profiles.json',root),JSON.stringify(profiles,null,2)+'\n');
fs.writeFileSync(new URL('dist/data/macro_external_benchmarks.json',root),JSON.stringify(benchmark,null,2)+'\n');
fs.writeFileSync(new URL('dist/macro-benchmarks-data.mjs',root),'export const MACRO_BENCHMARKS='+JSON.stringify(benchmark)+';\n');
fs.writeFileSync(new URL('research/macro_external_tfp/export_calibration.json',root),JSON.stringify({status:'PASS',checks},null,2)+'\n');
console.log(JSON.stringify({status:'PASS',countries:checks.length,maxAbsoluteResidual:Math.max(...checks.map(x=>Math.abs(x.residual)))}));

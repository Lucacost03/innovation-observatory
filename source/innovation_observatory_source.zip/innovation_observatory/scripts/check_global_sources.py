"""Offline source-integrity and arithmetic checks, separate from forecasting."""
from pathlib import Path
import hashlib,json,math
import pandas as pd
R=Path(__file__).resolve().parents[1];D=R/'dist/data'
read=lambda p:json.loads(p.read_text())
count=0
for area in ['usa','china']:
    folder=R/f'research/{area}_profile_candidates'
    manifest=read(folder/'manifest.json')
    for f in manifest['files']:
        path=folder/f['file']
        if path.suffix not in ['.html','.pdf','.xlsx','.csv'] or not path.exists():continue
        assert hashlib.sha256(path.read_bytes()).hexdigest()==f['sha256'],str(path)
        count+=1
pools=read(D/'foreign_pools.json')
for path,expected in pools['sourceHashes'].items():
    assert hashlib.sha256((R/path).read_bytes()).hexdigest()==expected,path
    count+=1
profiles=read(D/'profiles.json');book=pd.read_excel(R/'research/source_snapshots/pwt110.xlsx',sheet_name='Data');pwt=0
for p in profiles:
    if p['code']=='EU27':continue
    row=book[(book.countrycode==p['code'])&(book.year==2023)].iloc[0]
    for key,value in p['sourceValues'].items():
        assert math.isclose(float(row[key]),value,rel_tol=1e-12,abs_tol=1e-12),(p['code'],key)
        pwt+=1
after=read(R/'research/data_quality_candidates/european_input_audit_after.json')
assert after['summary']['mappingChecks']=={'matches_mapping':1731}
assert after['summary']['provenanceValueMetadataDifferences']==0
u=read(R/'research/usa_profile_candidates/candidate.json')['nominal_macro_billion_USD']
assert abs(u['GDP']-u['PCE']-u['governmentConsumption']-u['GFCF']-u['inventoryChange']-u['exports']+u['imports'])<.11
cn={x['key']:x['value'] for x in read(R/'research/china_profile_candidates/candidate_observations.json')['observations']}
assert abs(cn['gdp']-(cn['householdConsumption']+cn['governmentFinalConsumption']+cn['grossCapitalFormation']+cn['exports']-cn['imports'])-cn['nationalAccountsDiscrepancy'])<1e-8
out={'status':'PASS','sourceFilesHashed':count,'PWTFieldsChecked':pwt,'ArchivedEuropeanSourceAndMappingChecks':after['summary'],'currentMacroSourceChecks':'See macro_external_source_validation.json for the changed current-account, GDP-share and TFP mappings.','nationalAccounts':'USA rounding difference0.1bnUSD retained; China statistical discrepancy−57.982669bnCNY retained. Different GDP vintages/definitions remain explicit.','limitations':'Hashes prove snapshot integrity, not that every underlying official statistic is error-free. Partial gap-fill rows preserve source metadata/definitions; complete raw bytes are not retained for every web-only source. These checks do not establish forecast accuracy.'}
(D/'global_source_validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

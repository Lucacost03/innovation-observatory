import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {simulate,quantile} from '../dist/engine.mjs';
import {MODEL_VERSION} from '../dist/parameters.mjs';

const root = new URL('../',import.meta.url);
const read = path => JSON.parse(readFileSync(new URL(path,root)));
const profiles = read('dist/data/profiles.json');
const benchmarks = read('dist/data/trade_validation.json').scores.closed.predictions;
const seeds = Array.from({length:20},(_,i)=>2026+i*7919);
const stressSeeds = seeds.slice(0,5);
const regimes = {
  legacy:{},
  market:{financialMarket:1},
  smallerBudget:{financialMarket:1,marketDepositShare:25},
  liquid:{financialMarket:1,marketDepositShare:0},
  openEconomy:{financialMarket:1,tradeEnabled:1,policyDynamics:1,currencyDynamics:1},
};
const median = values => quantile(values,.5);
const sum = values => values.reduce((total,value)=>total+value,0);
const flows = ['ventureFunding','businessEquityIssued','corporateBondsIssued','householdBondPurchases','bankBondPurchases',
  'corporateBondRepayments','corporateBondWriteoffs','corporateBondRecoveries','entries','exits'];
let paths=0, annualSteps=0, maxFinanceResidual=0, maxSavingResidual=0;
function run(profile,settings,periods,seed) {
  const rows = simulate({...profile.params,...settings,periods},seed).rows;
  paths++;
  annualSteps+=periods;
  for (const r of rows) {
    maxFinanceResidual=Math.max(maxFinanceResidual,r.financeResidual);
    maxSavingResidual=Math.max(maxSavingResidual,Math.abs(r.savingIdentityResidual)/Math.max(1,r.nominalOutput));
  }
  return rows;
}
const recent = {};
for (const name of ['legacy','market','smallerBudget']) {
  const predictions = profiles.map(profile=>{
    const rows = seeds.map(seed=>run(profile,regimes[name],8,seed)[2]);
    const med = read => median(rows.map(read));
    const observed = benchmarks.find(row=>row.code===profile.code&&row.horizon===2).observed;
    return {code:profile.code,observed:{gdp:observed.gdp,unemployment:observed.unemployment,inflation:observed.inflation},
      gdp:med(r=>100*(Math.sqrt(r.output/100)-1)),unemployment:med(r=>r.unemployment),inflation:med(r=>r.inflation)};
  });
  const members = predictions.filter(row=>row.code!=='EU27');
  const errors = Object.fromEntries(['gdp','unemployment','inflation'].map(key=>{
    const gaps = members.map(row=>row[key]-row.observed[key]);
    return [key,{rmse:Math.sqrt(sum(gaps.map(gap=>gap**2))/gaps.length),mae:sum(gaps.map(Math.abs))/gaps.length}];
  }));
  recent[name] = {errors,predictions};
}
const stress = {};
for (const [name,settings] of Object.entries(regimes)) {
  const outcomes = [];
  for (const profile of profiles) for (const seed of stressSeeds) {
    const rows = run(profile,settings,40,seed);
    const end = rows.at(-1);
    outcomes.push({code:profile.code,seed,year40GDP:end.output,year40DebtGDP:100*end.publicDebt/end.nominalOutput,
      finalDeposits:end.householdDeposits,marketBudget:sum(rows.map(row=>row.marketBudget)),
      marketPurchases:sum(rows.map(row=>row.marketPurchases)),
      ...Object.fromEntries(flows.map(key=>[key,sum(rows.map(row=>row[key]))]))});
  }
  stress[name] = {paths:outcomes.length,belowHalfGDP:outcomes.filter(row=>row.year40GDP<50).length,
    debtAbove300:outcomes.filter(row=>row.year40DebtGDP>300).length,
    medianFinalGDP:median(outcomes.map(row=>row.year40GDP)),
    withFunding:Object.fromEntries(flows.slice(0,4).map(key=>[key,outcomes.filter(row=>row[key]>1e-8).length])),
    medians:Object.fromEntries(flows.map(key=>[key,median(outcomes.map(row=>row[key]))])),
    outcomes};
}
const italy = profiles.find(p=>p.code==='ITA');
const firstYear = run(italy,regimes.market,8,seeds[0])[1];
const italyExample = Object.fromEntries(['marketBudget','marketPurchases','householdDeposits',...flows.slice(0,4)]
  .map(key=>[key,firstYear[key]]));
assert(flows.slice(0,4).every(key=>italyExample[key]>0));
assert(stress.liquid.outcomes.every(row=>row.marketPurchases===0&&row.householdBondPurchases===0&&row.ventureFunding===0));
assert(maxFinanceResidual<1e-8&&maxSavingResidual<1e-8);
const report = {modelVersion:MODEL_VERSION,paths,annualSteps,maxFinanceResidual,maxSavingResidual,
  recentProtocol:'Start from the 2023 presets. Compare the median of 20 matched seeds with revised 2025 Eurostat outcomes. Each of the 27 member countries has equal weight. GDP growth is annualized from opening.',
  stressProtocol:'Five matched seeds for all 28 starting presets over 40 years. Test the earlier finance rules, the market preset, a smaller deposit commitment, all deposits kept liquid, and the market with trade and monetary rules active.',
  recent,stress,italyExample,seeds,stressSeeds};
writeFileSync(new URL('dist/data/finance_validation.json',root),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({paths,annualSteps,maxFinanceResidual,maxSavingResidual,italyExample,
  recent:Object.fromEntries(Object.entries(recent).map(([key,data])=>[key,data.errors])),
  stress:Object.fromEntries(Object.entries(stress).map(([key,{outcomes,...data}])=>[key,data]))},null,2));

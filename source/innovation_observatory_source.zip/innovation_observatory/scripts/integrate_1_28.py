"""Decision-instrument conventions and explicit finance mechanisms; no future GDP fit."""
from pathlib import Path
from collections import Counter
import json
R=Path(__file__).resolve().parents[1];D=R/'dist/data';ps=json.loads((D/'profiles.json').read_text());notes={}
for p in ps:
 c=p['code'];values={'policyRateIncrement':.1 if c=='CHN'else .25,'policyRateRangeWidth':.25 if c=='USA'else 0,'businessCapitalMarket':1,'housingFinanceMix':1}
 for k,v in values.items():
  p['params'][k]=v
  if k=='policyRateIncrement':
   url='https://www.pbc.gov.cn/zhengcehuobisi/125207/125227/125957/4883187/1f14dbe28ec4408cbf45cee06f86808a/2023112817393565251.pdf'if c=='CHN'else'https://www.federalreserve.gov/newsevents/pressreleases/monetary20231213a.htm'if c=='USA'else'https://www.ecb.europa.eu/stats/policy_and_exchange_rates/key_ecb_interest_rates/html/index.en.html'
   note='Instrument decision convention, not a universal empirical law or forecast. China7-day reverse repo moved10bps in2023; US target bounds/ECB deposit decisions commonly move25bps. Other national instruments use an explicit25bps scenario convention anchored to their observed opening quote, preserving off-grid levels. Annual decisions can span multiple increments; the underlying rule remains unestimated. Source-year opening quotes are unchanged.'
   status='proxy'if c in ['CHN','USA','EU27','ITA','AUT','BEL','CYP','EST','FIN','FRA','DEU','GRC','HRV','IRL','LVA','LTU','LUX','MLT','NLD','PRT','SVK','SVN','ESP']else'assumed'
  elif k=='policyRateRangeWidth':url='https://www.federalreserve.gov/newsevents/pressreleases/monetary20231213a.htm'if c=='USA'else p['provenance']['initialPolicyRate'].get('url','https://data.bis.org/topics/CBPOL');note='US2023 observed target bounds5.25–5.50 have width0.25percentage points. The unchanged initial rate5.375 is their midpoint. A positive range uses nonnegative lower and upper bounds, with the midpoint in transmission. Other instruments remain single policy quotes.';status='derived'if c=='USA'else'proxy'
  elif k=='businessCapitalMarket':url='https://www.ecb.europa.eu/stats/ecb_surveys/safe/html/ecb.safe202504~3839a2deca.en.html';note='Explicit transaction and financing mechanism: capital buyers pay producers from available cash, equity, bonds or bank loans; no capital is awarded to unfunded orders. Survey evidence supports investment as a use of finance, but does not estimate this model, its timing, allocation or effects. No automatic debt/GDP target.';status='assumed'
  else:url='https://www.ecb.europa.eu/stats/money_credit_banking/financial_accounts/html/index.en.html';note='Borrowers may preserve liquidity rather than always exhaust cash before a mortgage. Opening mortgage debt and the synthetic mortgaged-owner structure collateral imply a financing-share proxy, bounded by the existing LTV limit. A stock-to-new-loan mapping, not an observed new-mortgage LTV or an estimated preference. Policy-linked rates, income, collateral, cash down payments and bank capital still restrict borrowing; no guaranteed debt floor.';status='assumed'
  p['provenance'][k]={'status':status,'dataset':'Policy instrument/source convention'if k.startswith('policyRate')else'Explicit financing mechanism; source stock proxy','year':2023 if k.startswith('policyRate')else None,'url':url,'parameterValue':v,'note':note}
 if p['params'].get('ageCohorts')and p['provenance'].get('populationDynamics'):
  p['provenance']['populationDynamics']['note']='Single-year age cohorts advance through births, mortality and migration; China retains a disclosed five-year source approximation and an open oldest group. Synthetic household count is a numerical sample.'
  p['provenance']['initialParticipationRate']['note']=p['provenance']['initialParticipationRate']['note'].replace('The model holds this participation share fixed within its changing working-age cohort.','The observed rate anchors the opening age-dependent activity profile; pension eligibility is separate.')
 p['dataSummary']=dict(Counter(v['status']for v in p['provenance'].values()))
 if 'coverageSummary'in p:p['coverageSummary'].update(observedOrMapped=sum(v['status']in['observed','derived','proxy']for v in p['provenance'].values()),assumedOrDesign=sum(v['status']in['assumed','design']for v in p['provenance'].values()))
 notes[c]={k:p['provenance'][k]for k in values}
(D/'profiles.json').write_text(json.dumps(ps,ensure_ascii=False,indent=2)+'\n');A=R/'research/credit_audit_1_28';(A/'conventions.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
cov=D/'global_input_coverage.json'
if cov.exists():x=json.loads(cov.read_text());x['modelVersion']='1.28.0';x['countries']=[{k:p[k]for k in['code','name','sourceLabel','labourAge','dataSummary','coverageSummary']}for p in ps];cov.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print('Configured all30 presets; opening source rates, debt stocks and fiscal totals preserved.')

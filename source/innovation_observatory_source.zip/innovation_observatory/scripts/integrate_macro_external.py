"""Rebuild source-calibrated opening BOP and home knowledge-frontier inputs."""
from pathlib import Path
from collections import Counter
import csv,json,math,hashlib,sys
R=Path(__file__).resolve().parents[1];S=R/'research/macro_external_tfp';D=R/'dist/data'
read=lambda p:json.loads(p.read_text())
profiles=read(D/'profiles.json');prior={p['code']:p['params']for p in read(S/'prior_parameters.json')}
manifest=read(S/'source_manifest.json')
for e in manifest:assert hashlib.sha256((S/e['file']).read_bytes()).hexdigest()==e['sha256']
def series(n):return {(r['countryiso3code'],int(r['date'])):r['value']for r in read(S/(n+'.json'))[1]}
ca=series('BN.CAB.XOKA.GD.ZS');gd=series('NY.GDP.MKTP.CD');ex=series('BX.GSR.GNFS.CD');im=series('BM.GSR.GNFS.CD')
spend={(r['countryiso3code'],int(r['date']),r['indicator']['id']):r['value']for r in read(S/'national_expenditure_ratios.json')[1]}
history=list(csv.DictReader((S/'pwt_tfp_history.csv').open()))
pwt={(r['countrycode'],int(r['year'])):{k:float(v)for k,v in r.items()if k not in ['countrycode','year']}for r in history}
members=[p['code']for p in profiles if p['code']not in ['USA','CHN','EU27']]
weights={c:pwt[c,2023]['cgdpo']for c in members};tot=sum(weights.values());weights={c:w/tot for c,w in weights.items()}
growth={p['code']:100*((pwt[p['code'],2023]['rtfpna']/pwt[p['code'],2013]['rtfpna'])**.1-1)for p in profiles if p['code']!='EU27'}
growth['EU27']=sum(weights[c]*growth[c]for c in members)
raw=read(R/'research/forecast_source_candidates/oecd_candidate_extraction.json')['rawLevels']
pools=read(D/'foreign_pools.json')['contexts'];eu=pools['29']['providers']['EUR']
home={};bench={}
url='https://data.worldbank.org/indicator/BN.CAB.XOKA.GD.ZS'
for p in profiles:
    c=p['code'];code='EUU'if c=='EU27'else c;x=p['params']
    if c=='EU27':
        GDP=sum(gd[k,2023]for k in members);CA=sum(ca[k,2023]*gd[k,2023]for k in members)/GDP
        X=sum(ex[k,2023]for k in members)/GDP*100;M=sum(im[k,2023]for k in members)/GDP*100
    else:
        GDP=gd[c,2023];CA=ca[c,2023];X=100*ex[c,2023]/GDP;M=100*im[c,2023]/GDP
    G=spend[code,2023,'NE.CON.GOVT.ZS'];I=spend[code,2023,'NE.GDI.FTOT.ZS'];grossI=spend[code,2023,'NE.GDI.TOTL.ZS']
    assert all(v is not None and math.isfinite(v)for v in [GDP,CA,X,M,G,I,grossI]),c
    net=X-M;common=.05*min(X,M);modelX=common+max(0,net);modelM=common+max(0,-net)
    housing=x['actualRentGDP']+x['imputedRentGDP']if x['housingEnabled']else 0
    cashC=100-G-grossI-housing-modelX+modelM
    share=100*modelM*(1+x['consumptionTax']/100)/cashC
    assert cashC>0 and 0<share<85 and modelX<.9*(100-G-grossI-housing),(c,cashC,share,modelX)
    p.setdefault('macroCalibrationPrior',{k:prior[c].get(k)for k in ['rdBusiness','governmentShare','initialGovernmentShare','investmentShare','exportDemand','importShare','frontierGrowth']})
    mapped=dict(governmentShare=G,initialGovernmentShare=G,investmentShare=I,initialInventoryChange=grossI-I,
        initialExportSales=modelX,exportDemand=modelX/.55,importShare=share,otherForeignIncomeGDP=CA-net,
        continuousForeignBids=1,currencyPPPAdjustment=.15,observedCurrentAccount=CA,observedTFPGrowth=growth[c],frontierGrowth=growth[c],domesticForecast=1,foreignSettlementInterest=1,openingMacroCalibration=1)
    x.update(mapped)
    note='2023 IMF BOP/WDI source vintage. Full net goods/services balance preserved; only the offsetting common gross trade is scaled to5%. This covers a composite final good, not all national gross trade.'
    for k in mapped:
        p['provenance'][k]=dict(status='proxy',dataset='IMF BOP / World Bank WDI, 2023',year=2023,url=url,parameterValue=x[k],note=note)
    for k in ['governmentShare','initialGovernmentShare','investmentShare','initialInventoryChange']:
        p['provenance'][k].update(dataset='World Bank national accounts, same 2023 GDP denominator',note='Government consumption and fixed investment are actual GDP shares, replacing domestic-use normalization. Inventory investment is gross capital formation less fixed capital formation. The opening residual includes national-accounts/BOP definition differences.')
    p['provenance']['continuousForeignBids'].update(status='assumed',dataset='Continuous export market-clearing rule',year=None,url='https://www.imf.org/en/Publications/WP/Issues/2017/03/15/Exchange-Rates-and-Trade-A-Disconnect-44746',note='Replaces four price point masses with a continuous bid distribution over 0.865–1.135 times the base bid. Preserves total orders and mean bid; the 10% repeat-customer block is retained. Dispersion and repeat share are assumed. Avoids artificial quarter-block export jumps; no universal forecast gain is established.')
    p['provenance']['exportDemand']['note']+=' Potential orders divide opening realized exports by0.55, the opening bid-ladder share above the domestic bid. Rationing, prices and capacity still determine actual future sales.'
    p['provenance']['otherForeignIncomeGDP']['note']='Observed CA less net BOP goods/services exports: net primary/secondary income combined. Condensed into the household sector as a source-allocation proxy, without adding GDP. Future share of lagged nominal GDP is assumed; outgoing payments require cash. Portfolio and settlement returns are separate.'
    p['provenance']['openingMacroCalibration']['note']='Annual opening source benchmarks are recorded without applying them a second time to the opening financial stocks. Year0 has no annual change in NFA.'
    p['provenance']['foreignSettlementInterest'].update(status='assumed',dataset='External funding/asset accounting rule',year=None,note='Foreign basket yield applies to the financial sector’s signed settlement position. Equal asset and funding yields are an assumption. Two-way matched positions cancel; debt-funded foreign portfolios have a funding cost.')
    p['provenance']['currencyPPPAdjustment'].update(status='assumed',dataset='Long-run exchange-rate price-reference rule',year=None,url='https://www.imf.org/en/publications/fandd/issues/series/back-to-basics/real-exchange-rates',note='A0.15 annual adjustment toward completed foreign/domestic price levels is an unestimated long-run PPP scenario. Real-rate premiums, policy responses and currency shocks remain. This is not exact short-run PPP or an estimated managed-currency rule.')
    for k in ['frontierGrowth','observedTFPGrowth']:
        p['provenance'][k].update(dataset='PWT11.0 rtfpna, 2013–2023',year='2013–2023',url='https://www.rug.nl/ggdc/productivity/pwt/',note='Annual compound growth of comparable national-price TFP. EU27 is a 2023 PPP-output-weighted mean of member growth rates. This is a historical benchmark/fallback for potential knowledge, not guaranteed future realized growth.')
    mult={s:[(raw[c][s]['EFFLABS'][str(y)]/raw[c][s]['EFFLABS']['2023'])**.67 for y in range(2023,2101)]for s in ['BAU1','BAU2','ET1','ET2','ET3','ET4']}if c in raw and c!='EU27' else eu['multipliers']
    scope='National OECD path'if c in raw and c!='EU27' else 'Covered-member OECD aggregate proxy'if c=='EU27'else 'EU27 projection fallback: no national OECD path'
    home[str(x['foreignPoolId'])]=dict(home=c,multipliers=mult,coverage=scope,historicalGrowth=growth[c])
    p['provenance']['domesticForecast'].update(dataset='OECD EO117 long-term scenarios, home-country mapping',year='2025/2026 vintage',url='https://www.oecd.org/en/publications/oecd-global-long-run-economic-scenarios_00353678-en.html',note=scope+'. EFFLABS ratio^0.67 advances available domestic knowledge with a one-step information delay; it is not an automatic GDP/TFP target. Matches the transformation used for foreign donors. Later information than the2023 origin; not a real-time backtest.')
    p['dataSummary']=dict(Counter(s['status']for s in p['provenance'].values()))
    if 'coverageSummary'in p:p['coverageSummary'].update(observedOrMapped=sum(s.get('status')in ['observed','derived','proxy']for s in p['provenance'].values()),assumedOrDesign=sum(s.get('status')in ['assumed','design']for s in p['provenance'].values()))
    recent={}
    for y in [2023,2024,2025]:
        vals=[(ca.get((m,y)),gd.get((m,y)))for m in members]if c=='EU27'else[(ca.get((c,y)),gd.get((c,y)))]
        recent[str(y)]=sum(a*g for a,g in vals)/sum(g for a,g in vals)if all(a is not None and g is not None for a,g in vals)else None
    bench[c]=dict(recentCurrentAccountGDP=recent,currentAccountGDP=CA,goodsServicesBalanceGDP=net,otherForeignIncomeGDP=CA-net,observedExportsGDP=X,observedImportsGDP=M,modelExportsGDP=modelX,modelImportsGDP=modelM,governmentConsumptionGDP=G,fixedInvestmentGDP=I,inventoryInvestmentGDP=grossI-I,modelImportBudgetShare=share,observedTFPGrowth=growth[c],homeProjectionCoverage=scope)
data=dict(baseYear=2023,TFPWindow=[2013,2023],countries=bench,EUweights=weights,sources=manifest,
    tradeMethod='Complete observed net balance plus5% of matched gross two-way trade; potential orders reflect the opening bid ladder.',
    EUCurrentAccount='GDP-weighted member current accounts; not an official consolidated EU BOP series. Intra-EU statistical discrepancies can remain.',
    limitations=['Source vintages are revised observations retrieved later, not data available in2023.','Net primary/secondary income is condensed into the household sector; sector attribution and future continuation are proxies.','OECD labour-efficiency paths converted to TFP are conditional projections, not observations.','The model’s output-based productivity residual has different coverage and input measures from national PWT TFP. Forecast accuracy is not established.'])
(D/'macro_external_benchmarks.json').write_text(json.dumps(data,indent=2)+'\n')
(R/'dist/macro-benchmarks-data.mjs').write_text('export const MACRO_BENCHMARKS='+json.dumps(data,separators=(',',':'))+';\n')
(R/'dist/home-frontier-data.mjs').write_text('// Generated from the same OECD source as the foreign donor paths.\nexport const HOME_FRONTIERS='+json.dumps(home,separators=(',',':'))+';\n')
if '--dry-run'not in sys.argv:
    (D/'profiles.json').write_text(json.dumps(profiles,ensure_ascii=False,indent=2)+'\n')
    coverage=read(D/'global_input_coverage.json');coverage['modelVersion']='1.24.0';coverage['countries']=[{k:p[k]for k in ['code','name','sourceLabel','labourAge','dataSummary','coverageSummary']}for p in profiles];coverage['externalCalibration']=dict(source='IMF BOP/WDI2023 and PWT11.0',countries=30)
    (D/'global_input_coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({c:bench[c]for c in ['USA','CHN','EU27']},indent=2))

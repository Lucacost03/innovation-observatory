"""Integrate audited observations; missing estimates stay explicit assumptions.

Offline/reproducible. Never treat foreign observations or projections as home
data. Preserve the original European source mappings and fix their denominators.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,subprocess
import pandas as pd
R=Path(__file__).resolve().parents[1];D=R/'dist/data'
read=lambda f:json.loads(f.read_text())
registry=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import {PARAMETERS} from './dist/parameters.mjs';process.stdout.write(JSON.stringify(PARAMETERS))"],cwd=R))
defaults={x['key']:x['value'] for x in registry};units={x['key']:x['unit'] for x in registry}
profiles=[p for p in read(D/'profiles.json') if p['code'] not in ['USA','CHN']]
audit=read(R/'research/data_quality_candidates/european_input_audit.json')
bycode={p['code']:p for p in profiles}
for fix in audit['candidateCorrections']:
    p=bycode[fix['country']];p['params'][fix['key']]=fix['candidateValue']
    p['provenance'][fix['key']]['note']=p['provenance'][fix['key']]['note'].split(' Recalibrated after')[0]+' Recalibrated after the age15–64 employment migration to preserve the same observed unemployment-cash-benefit/GDP benchmark.'
for p in profiles:
    for key in ['mortgageSpread','residentialInvestmentShare','privatePensionContributionRate','privatePensionWithdrawalRate']:
        s=p['provenance'][key]
        if 'value' in s:s['sourceValue']=s.pop('value');s['sourceUnit']=s.pop('unit',None)
        s['parameterValue']=p['params'][key];s['parameterUnit']=units[key]
    p['sourceLabel']='Eurostat · PWT · ECB/BIS where matched'
    p['labourAge']='15–64'
us=read(R/'research/usa_profile_candidates/candidate.json')
cn=read(R/'research/china_profile_candidates/candidate_observations.json')
cnobs={x['key']:x for x in cn['observations']}
book=pd.read_excel(R/'research/source_snapshots/pwt110.xlsx',sheet_name='Data')
def assume(p,key,value,note):
    p['params'][key]=value;p['provenance'][key]={'status':'assumed','dataset':'Missing comparable national observation / scenario rule','year':None,'note':note}
def mapped(p,key,value,dataset,url,note,status='proxy',year=2023,**extra):
    p['params'][key]=value;p['provenance'][key]={'status':status,'dataset':dataset,'year':year,'url':url,'note':note,'parameterValue':value,'parameterUnit':units[key],**extra}
for code,name in [('USA','United States'),('CHN','China')]:
    p={'code':code,'name':name,'geo':'US' if code=='USA' else 'CN','year':2023,'params':dict(defaults),'provenance':{},'sourceLabel':'Federal Reserve · OECD · BLS · PWT' if code=='USA' else 'NBS · UN · PBOC · MOF · PWT','labourAge':'15–64' if code=='USA' else '15+ national proxy; applied to working-age cohort'}
    for d in registry:
        p['provenance'][d['key']]={'status':'design' if d['design'] or d['key']=='initialTechnology' else 'assumed','dataset':'Simulation design' if d['design'] else 'Unestimated mechanism / missing matched input','note':d['help']+' No matching national estimate has been established for this control.'}
    row=book[(book.countrycode==code)&(book.year==2023)].iloc[0]
    p['sourceValues']={k:float(row[k]) for k in ['rnna','rgdpna','labsh','delta','ctfp','cgdpo','hc','pop']}
    for key,value in {'capitalOutputRatio':row.rnna/row.rgdpna,'laborShare':100*row.labsh,'tfpCapitalShare':100*(1-row.labsh),'depreciation':100*row.delta,'initialHumanCapital':row.hc,'initialPopulationMillions':row['pop']}.items():
        mapped(p,key,float(value),'PWT11.0, national2023','https://www.rug.nl/ggdc/productivity/pwt/','Frozen PWT11.0 workbook. National-price capital/output, adjusted income-share exponent and schooling-based human capital are mappings to a representative sector, not measured firm behavior.')
    # Missing-data scenarios are country-specific and never represented as observations.
    choices={'governmentDeposit':(3,5),'initialPublicEquity':(5,30),'initialWealthGini':(.85,.78),'firmSizeDispersion':(1.1,1.1),'entryRate':(10,10),'exitRate':(8.5,8.5),'entrantSize':(.2,.2),'initialUtilization':(78,75),'foreignPortfolioWeight':(25,5),'financialIncomeTax':(20,20),'wealthTax':(0,0),'incomeTax':(28,20),'profitTax':(21,25),'consumptionTax':(5,8),'initialHousingGDP':(100,160),'initialMortgageGDP':(47,30),'ownerOccupancy':(66,85),'mortgagedOwnerShare':(40,25),'actualRentGDP':(3.5,1),'imputedRentGDP':(7,4),'residentialInvestmentShare':(19,25),'mortgageOpeningRate':(4.1,4.3),'mortgageSpread':(1.4,2.2),'initialPrivatePensionGDP':(60,5),'privatePensionContributionRate':(5,2),'privatePensionWithdrawalRate':(5,5),'publicPensionGDP':(5,5),'incomeSupport':(8,7),'unemploymentReplacement':(0,0),'publicEducationGDP':(4.5,4),'privateEducationGDP':(1.5,.8),'initialChildShare':(18,16),'initialOldShare':(17.4,15.4),'birthRate':(1.07,.639),'deathRate':(.92,.787),'netMigrationRate':(.3,0),'initialIncomeGini':(.394,.465),'initialParticipationRate':(74.7,66),'employmentRate':(96.3,95),'initialPublicDebt':(119,83.6),'publicTrendGrowth':(1.5,4),'loanSpread':(2,2),'bondRate':(3,2.5),'initialLeverage':(.1,.15)}
    for key,pair in choices.items():
        value=pair[0 if code=='USA' else 1]
        assume(p,key,value,'No matched national observation with the model definition was available in this source bundle. '+('US home-bias portfolio scenario; foreign orders are 20% of total market allocation.' if key=='foreignPortfolioWeight' and code=='USA' else 'China capital-control/home-bias portfolio scenario; foreign orders are about4.8% of market allocation.' if key=='foreignPortfolioWeight' else 'Illustrative '+name+' fallback; inspect sensitivity rather than interpreting this as observed data.')+' '+next(d['help'] for d in registry if d['key']==key))
    for key in ['populationDynamics','educationEnabled','pensionEnabled','housingEnabled','foreignForecast','assetPurchasesEnabled','publicBudgetStability','priceDynamics','policyDynamics','currencyDynamics','tradeEnabled','financialMarket']:
        assume(p,key,1,'Enabled scenario mechanism; this switch is not an empirical measurement.')
    assume(p,'wealthTax',0,'No broad annual tax on recorded financial wealth is imposed in this fallback. US property/estate taxes and Chinese transaction/property taxes have different bases; a positive annual financial-wealth tax cannot be inferred from them.')
    if code=='USA':
        for key,item in us['candidate_parameters'].items():
            key='initialPolicyRate' if key=='policyRate' else key
            obs=[us['observations'][x] for x in item['observations'] if x in us['observations']]
            mapped(p,key,item['value'],'Federal Reserve/OECD/BLS/Eurostat/PWT, USA2023',obs[0].get('source','https://www.rug.nl/ggdc/productivity/pwt/') if obs else 'https://www.rug.nl/ggdc/productivity/pwt/',item['formula']+'. '+item['note'],item['status'],observations=obs)
        p['observations']={'national_accounts_billion':us['nominal_macro_billion_USD']}
        macro=us['nominal_macro_billion_USD'];GDP=macro['GDP'];C=macro['PCE'];G=macro['governmentConsumption'];I=macro['GFCF'];X=macro['exports'];M=macro['imports']
        p['coverageGaps']=us['coverage_gaps']
    else:
        def use(key,value,source,note,status='proxy'):
            mapped(p,key,value,'China '+source,cn['sources'][source]['url'],note,status,sourceVintage=cn['sources'][source].get('vintage'))
        val=lambda key:cnobs[key]['value']
        GDP=val('gdp');C=val('householdConsumption');G=val('governmentFinalConsumption');I=val('grossFixedCapitalFormation');X=val('exports');M=val('imports')
        for key,value in {'governmentShare':100*G/(C+G+I),'initialGovernmentShare':100*G/(C+G+I),'investmentShare':100*I/(C+G+I)}.items():use(key,value,'un','UN SNAAMA revised2023 current-CNY components; domestic final-use normalization excludes trade and inventories. Government capital is inside total fixed investment, not counted again in G.')
        p['observations']={'national_accounts_billion_CNY':{k:val(k) for k in ['gdp','householdConsumption','governmentFinalConsumption','grossFixedCapitalFormation','grossCapitalFormation','exports','imports','inventoryChange','nationalAccountsDiscrepancy']}}
        for key,value in {'householdWealth':100*val('householdDeposits')/val('gdpPreliminary'),'firmLiquidity':100*val('nonfinancialFirmDeposits')/val('gdpPreliminary'),'initialPopulationMillions':val('population'),'initialChildShare':val('childPopulationShare'),'initialOldShare':val('populationAge65plusShare'),'birthRate':val('birthRate')/10,'deathRate':val('deathRate')/10,'initialInflation':val('initialInflation'),'initialPolicyInflation':val('initialInflation'),'initialIncome':100*val('disposableIncomePerCapita')*val('population')/1000/val('gdpPreliminary')}.items():use(key,value,'nbs','NBS preliminary2023 release. Deposit and income ratios use the same-release preliminary GDP126058.2bnCNY; national demand shares use separately disclosed revised UN accounts.')
        use('initialPolicyRate',val('policyRate'),'rate','End2023 seven-day reverse-repo rate1.80%, not the loan prime rate. A simplified central-bank instrument mapping.')
        use('rdBusiness',val('businessPerformedRDGDPProxy'),'rd','NBS business-performed R&D2592.22bnCNY / same-vintage preliminary GDP126058.2bnCNY ×100 =2.0563676%GDP. GERD/GDP2.65% is already a percentage and is not multiplied by100 again. Performer is not funder.')
        use('publicEducationGDP',val('fiscalEducationGDP'),'moe','Broad fiscal education spending, multiple budget types and SOE-school appropriations; mapped to a reallocation within G, not matched COFOG P3 services.')
        use('initialIncomeGini',val('incomeGini'),'gini','NBS per-capita disposable-income Gini reproduced by UNICEF. Different equivalence/weighting definition from OECD/EU-SILC. Synthetic equal-sized households are a proxy.')
        # No urban-only unemployment rate is used in the national identity.
        assume(p,'employmentRate',95,'National same-coverage unemployment was unavailable;5% unemployment/LF is an explicit scenario assumption, not the urban surveyed5.2% statistic.')
        use('initialParticipationRate',val('employmentPopulationRatioAge15plusProxy')/.95,'nbs','Derived from nationwide age15+ E/pop62.7977% and explicitly assumed national unemployment5%. This older-age definition is applied to the changing15–64model cohort as a disclosed proxy. It is not observed15–64participation.')
        p['coverageGaps']=[x['key'] for x in cn['missing']]
    if code=='CHN':
        gap=read(R/'research/china_profile_candidates/gap_fill.json');gobs={x['key']:x for x in gap['observations']}
        def gmap(key,obskey,note,status='proxy',transform=lambda x:x):
            obs=gobs[obskey];source=gap['sources'].get(obs['source'],{})
            mapped(p,key,transform(obs['value']),'China primary gap-fill: '+obs['source'],source.get('url','https://yss.mof.gov.cn/'),note,status,sourceValue=obs['value'],sourceDefinition=obs.get('definition'))
        gmap('initialPublicDebt','generalGovernmentGrossDebtIMFApril2024','IMF general-government debt/GDP, April2024 vintage; broader than statutory MOF debt, simplified as generic public claims. The denominator vintage differs from revised UN2023 accounts.')
        gmap('initialMortgageGDP','mortgageStockCommercialInstitutions','Commercial financial-institution mortgage stock38170bn / revisedUN2023GDP. Excludes unmatched housing provident fund claims; explicit cross-release mapping.',transform=lambda x:100*x/GDP)
        gmap('publicPensionGDP','publicPensionBenefitsGDP_UNRevised','Sum of enterprise, public-institution and resident basic/personal-account pension BENEFITS, excluding funeral/admin/interfund flows. Flow6522.23bnCNY / revisedUN2023GDP.')
        gmap('mortgageSpread','mortgageRateNewLoansDecember','December2023 new mortgage quote minus end2023 reverse-repo policy rate; current quotes follow policy with configured pass-through.',transform=lambda x:x-p['params']['initialPolicyRate'])
        gmap('loanSpread','businessRateNewLoansDecember','December2023 new business quote minus policy rate. This is a new-loan proxy, not a measured outstanding-stock effective interest rate.',transform=lambda x:x-p['params']['initialPolicyRate'])
        gmap('consumptionTax','netVATNetHHConsumptionWedgeProxy','Final MOF domestic+import VAT minus export refunds / UN household consumption net of these receipts. Uniform model wedge proxy: real VAT has multiple rates and taxes other final uses.')
        gmap('depositInterestTaxableShare','householdSavingsDepositInterestTax','Household savings deposit interest is exempt from individual income tax since2008. Other financial income has different exemptions/holding-period rules;20% aggregate rate remains an assumed effective proxy.',status='observed')
        assume(p,'mortgageOpeningRate',gobs['mortgageRateNewLoansDecember']['value'],'Outstanding-stock weighted mortgage rate is unavailable. December2023 NEW-loan3.97% is used as an explicit stock-rate proxy; not an observed outstanding-loan rate.')
        assume(p,'incomeSupport',7,'Public old-age benefits use verified5.0393%GDP; total7% cash support adds an explicit1.9607%GDP fallback for other benefits. Health in-kind flows are not relabelled cash.')
        p['observations']['broaderFiscalSDDS']={key:gobs[key] for key in ['generalGovernmentRevenueSDDS','generalGovernmentExpenditureSDDS','generalGovernmentBalanceSDDS','publicPensionBenefitsShareSDDSExpenditure']}
        p['observations']['preliminaryHealthEducation']={key:cnobs[key] for key in ['governmentHealth','fiscalEducation']}
        assume(p,'publicHealthPurchaseShare',15,'Matched COFOG P3 health-service composition is unavailable.15% of public purchases is an explicit classification fallback; broader NHCgovernmenthealth spending is a separate reference, not an additional purchase.')
        assume(p,'publicEducationPurchaseShare',20,'Matched COFOG P3 education-services composition is unavailable.20% of public purchases is an explicit reporting fallback, distinct from the broader fiscal education resource budget.')
    else:
        assume(p,'publicHealthPurchaseShare',25,'No matched direct-public-health P3 composition.25% of purchases is an explicit service classification fallback. OECD10.1%GDP all-functional health spending includes transfers and capital and is kept separate.')
        assume(p,'publicEducationPurchaseShare',30,'No matched P3 education service composition.30% of public purchases is an explicit reporting fallback; broader public-school resource budget is separate.')
    # Convert gross-trade observations to the same explicit5%final-goods coverage.
    consumption=100-p['params']['initialGovernmentShare']-p['params']['investmentShare']
    for key,value in {'exportDemand':.05*100*X/GDP,'importShare':min(35,100*.05*(100*M/GDP)*(1+p['params']['consumptionTax']/100)/consumption)}.items():
        mapped(p,key,value,'National accounts2023, final-goods coverage proxy',p['provenance']['governmentShare']['url'],'Five percent of observed gross trade covers the simplified final-goods channel. Gross imports/exports include intermediates and are not silently presented as model final-goods sales.')
    opening_goods=100-consumption+consumption/(1+p['params']['consumptionTax']/100)
    mapped(p,'initialMoneyVelocity',opening_goods/(p['params']['householdWealth']+p['params']['firmLiquidity']),'Opening model normalization',p['provenance']['householdWealth']['url'],'Opening producer-price goods scale / mapped private deposits. Derived normalization, not observed M2 velocity. Subsequent spending velocity is behavioral.','derived')
    # Optional primary-source gapfills use their own recorded scopes/vintages.
    gapfile=R/f'research/{"usa" if code=="USA" else "china"}_profile_candidates/gap_fill.json'
    if gapfile.exists():
        gap=read(gapfile)
        for key,item in gap.get('candidate_parameters',{}).items():
            if key not in defaults:continue
            obs=[gap['observations'][o] for o in item.get('observations',[]) if isinstance(gap.get('observations'),dict) and o in gap['observations']]
            mapped(p,key,item['value'],item.get('dataset','National2023 gap-fill'),item.get('url',obs[0].get('source_url','') if obs else ''),item.get('note','')+' '+item.get('formula',''),item.get('status','proxy'),item.get('year',2023),observations=obs)
        p['gapFillNotes']=gap.get('unavailable',[])
    p['policyAuthority']={'name':'Federal Reserve' if code=='USA' else 'People’s Bank of China','instrument':'Federal-funds target midpoint' if code=='USA' else 'Seven-day reverse repo'}
    # Opening interest conventions, not claims of estimated repricing behavior.
    for key in ['neutralPolicyRate']:
        assume(p,key,2.5 if code=='USA' else 2,'Long-run nominal policy scenario assumption; central-bank rate remains nonnegative and responds to lagged inflation.')
    profiles.append(p)
contexts=read(D/'foreign_pools.json')['contexts']
for p in profiles:
    context_id,ctx=next((int(i),c) for i,c in contexts.items() if c['home']==p['code'])
    p['params']['foreignPoolId']=context_id
    p['provenance']['foreignPoolId']={'status':'design','dataset':'Home-excluding PWT/OECD source pools','note':'Membership excludes every home member and keeps named foreign pools disjoint. US/China substitute EU27 for the home donor.'}
    for code,pool in ctx['providers'].items():
        level={'USA':'usTechnology','CHN':'chinaTechnology','ROW':'rowTechnology','EUR':'europeTechnology'}[code]
        growth={'USA':'usGrowth','CHN':'chinaGrowth','ROW':'rowGrowth','EUR':'europeGrowth'}[code]
        mapped(p,level,pool['relativeTFP']/ctx['homeTFP'],'PWT2023, home-excluding donor pool','https://www.rug.nl/ggdc/productivity/pwt/','PPP-output-weighted ctfp / home ctfp. Aggregate productivity is a firm-technology proxy; donor leader premium and contact dispersion remain assumed.',members=pool['members'])
        mapped(p,growth,pool['historicalGrowth'],'PWT2013–2023','https://www.rug.nl/ggdc/productivity/pwt/','Output-weighted national rtfpna CAGR. A fixed future extrapolation is a scenario assumption; used only with published projection paths off.')
    pool=ctx['providers']['ROW']
    mapped(p,'foreignForecast',p['params'].get('foreignForecast',1),'OECD EO117 conditional long-run scenarios',read(D/'foreign_projections.json')['sources']['method'],f"Annual EFFLABS ratios^0.67 linked to PWT opening levels. Home-excluding ROW projections cover{len(pool['projectionMembers'])}countries and{100*pool['projectionOutputCoverage']:.2f}% of pool2023output. Covered-sample evolution proxies missing members. Published conditional projections are not observed future TFP.",year='2025/2026 projection vintage')
    assume(p,'startupScaleBasis',1,'Use opening productive capital per initial model firm as the real startup size benchmark. Holding the benchmark fixed avoids the shrinking-firm-count feedback; not a forecast estimate.')
    assume(p,'startupSizeHeterogeneity',1,'Mean entrant employment/active-firm employment maps to mean startup capital. A mean-preserving lognormal shape uses the incumbent grouped-size dispersion as an explicit proxy because matched entrant-size distributions are absent. This is not a universal minimum size.')
    p['dataSummary']=dict(Counter(x['status'] for x in p['provenance'].values()))
    p['coverageSummary']={'observedOrMapped':sum(x.get('status') in ['observed','derived','proxy'] for x in p['provenance'].values()),'assumedOrDesign':sum(x.get('status') in ['assumed','design'] for x in p['provenance'].values()),'missingParameterSources':[x['key'] for x in registry if x['key'] not in p['provenance']]}
(D/'profiles.json').write_text(json.dumps(profiles,ensure_ascii=False,indent=2)+'\n')
coverage={'modelVersion':'1.20.0','asOf':'2026-11-13','openingYear':2023,'policy':'Use matched observations first; label derived proxies, missing-data fallbacks and unestimated behavioral rules. No forecast accuracy claim. Genuine empirical zeros remain zero on the relevant tax base.','countries':[{k:p[k] for k in ['code','name','sourceLabel','labourAge','dataSummary','coverageSummary']} for p in profiles],'europeanAuditBefore':audit['summary'],'unemploymentBenefitCorrections':audit['candidateCorrections'],'limitations':audit['limitations'],'newCountryCoverage':{'USA':us['coverage_gaps'],'CHN':[x['key'] for x in cn['missing']]}}
(D/'global_input_coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
(D/'global_input_sources.json').write_text(json.dumps({'USA':us,'CHN':cn,'gapFills':{code:read(f) for code in ['USA','CHN'] if (f:=R/f'research/{"usa" if code=="USA" else "china"}_profile_candidates/gap_fill.json').exists()}},ensure_ascii=False,indent=2)+'\n')
fiscal={}
ugap=read(R/'research/usa_profile_candidates/gap_fill.json')
fiscal['USA']={'name':'United States','scope':'Partial functional references; no matched full COFOG P3 service/cash breakdown. Health and social-protection totals are2023 general-government functional expenditure from OECDGovernment at a Glance2025. Social Security retirement cash excludes government employee pensions and is a subset, not the full public-pension bill. Definitions differ from model current expenses.','rows':[['Healthcare, all expenditure',us['unmapped_observed_statistics']['publicHealthTotalGDP']],['Social protection, all expenditure',us['unmapped_observed_statistics']['socialProtectionTotalGDP']],['Social Security retirement cash, subset',ugap['observations']['ssaRetirementCashGDP']['value']]],'url':'https://www.oecd.org/en/publications/2025/06/government-at-a-glance-2025_70e14c6c/full-report/government-expenditure-by-function-cofog_d2b167d4.html'}
cgap=read(R/'research/china_profile_candidates/gap_fill.json');cg={x['key']:x for x in cgap['observations']};gdp=cnobs['gdp']['value']
fiscal['CHN']={'name':'China','scope':'MOF2023 SDDS general-government operations consolidate four budgets and remove interbudget transfers; land-use-rights sales excluded. This is broader than the general public budget and different from ESA COFOG P3. Ratios use revised UN2023 GDP. Old-age benefit flows are part of expenditure, not extra government consumption.','rows':[['SDDS general-government revenue',100*cg['generalGovernmentRevenueSDDS']['value']/gdp],['SDDS general-government expenditure',100*cg['generalGovernmentExpenditureSDDS']['value']/gdp],['Public pension benefit payments',cg['publicPensionBenefitsGDP_UNRevised']['value']]],'url':cgap['sources']['mof_sdds']['url']}
(R/'dist/global-fiscal-reference-data.mjs').write_text('// Generated from frozen national sources.\nexport const GLOBAL_FISCAL_REFERENCES='+json.dumps(fiscal,ensure_ascii=False,separators=(',',':'))+';\n')
(D/'global_fiscal_references.json').write_text(json.dumps(fiscal,ensure_ascii=False,indent=2)+'\n')
print('Integrated30profiles; refreshed20benefitdenominators; all source gaps remain labelled.')

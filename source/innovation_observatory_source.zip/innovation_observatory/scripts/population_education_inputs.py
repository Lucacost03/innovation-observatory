"""Extract frozen official 2023 population and education inputs; no profile mutation.

Run normally to replay frozen inputs. --refresh downloads new snapshots first.
The resulting proxies do not estimate education quality or a causal productivity effect.
"""
from pathlib import Path
import argparse, concurrent.futures, datetime, hashlib, json, urllib.request
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'research/source_snapshots'
BASE = 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/'
VINTAGE_FILE = ROOT / 'research/population_education_source_vintages.json'
VINTAGES = json.loads(VINTAGE_FILE.read_text()) if VINTAGE_FILE.exists() else {}
SOURCES = {
    'balance': ('demo_gind', 'lang=en&freq=A&time=2023'),
    'ages': ('demo_pjanind', 'lang=en&freq=A&time=2023'),
    'deaths_age': ('demo_magec', 'lang=en&freq=A&sex=T&unit=NR&time=2023'),
    'public_education': ('gov_10a_exp', 'lang=en&freq=A&unit=PC_GDP&sector=S13&cofog99=GF09&na_item=TE&time=2023'),
    'household_education_2018': ('nama_10_cp18', 'lang=en&freq=A&unit=PC_GDP&coicop18=CP10&time=2023'),
    'attainment': ('edat_lfse_03', 'lang=en&freq=A&sex=T&age=Y25-64&isced11=ED5-8&unit=PC&time=2023'),
}


def frozen_source(item, refresh=False):
    key, (dataset, query) = item
    path = RAW / f'population_education_{key}_2023.json'
    url = BASE + dataset + '?' + query
    if refresh or not path.exists():
        with urllib.request.urlopen(url, timeout=90) as response:
            blob = response.read()
        data = json.loads(blob)
        assert 'value' in data and 'dimension' in data, (dataset, data)
        path.write_bytes(blob)
        retrieved = datetime.datetime.now(datetime.timezone.utc).isoformat()
    else:
        blob = path.read_bytes()
        data = json.loads(blob)
        # The first extraction in this task used these freshly downloaded files;
        # retain its capture time thereafter instead of changing vintage on replay.
        retrieved = VINTAGES.get(key,datetime.datetime.fromtimestamp(path.stat().st_mtime,datetime.timezone.utc).isoformat())
    return key, data, {'name':'population_education_'+key,'dataset':dataset,'url':url,
        'path':str(path.relative_to(ROOT)),'sourceUpdatedAt':data.get('updated'),'retrievedAt':retrieved,
        'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'status':'ok'}


def observation(data, geo, **selection):
    sel = {'freq':'A','geo':geo,'time':'2023',**selection}
    offset = 0
    for key, size in zip(data['id'], data['size']):
        index = data['dimension'][key]['category']['index']
        value = sel.get(key)
        if value not in index:
            return {'selection':sel,'value':None,'flag':'missing selection'}
        offset = offset * size + index[value]
    values, flags = data['value'], data.get('status',{})
    value = values.get(str(offset)) if isinstance(values,dict) else values[offset]
    flag = flags.get(str(offset),'') if isinstance(flags,dict) else flags[offset]
    return {'selection':sel,'value':value,'flag':flag or ''}


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--refresh',action='store_true')
    args=parser.parse_args()
    profiles=json.loads((ROOT/'dist/data/profiles.json').read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        inputs=list(pool.map(lambda item:frozen_source(item,args.refresh),SOURCES.items()))
    sources={key:data for key,data,_ in inputs}
    manifest=[meta for _,_,meta in inputs]
    VINTAGE_FILE.write_text(json.dumps({key:meta['retrievedAt'] for key,_,meta in inputs},indent=2)+'\n')
    pwt_path=RAW/'pwt110.xlsx'; workbook=load_workbook(pwt_path,read_only=True,data_only=True)
    iterator=workbook['Data'].iter_rows(values_only=True); header=next(iterator)
    wanted={p['code'] for p in profiles if p['code']!='EU27'}
    hc={}
    for row in iterator:
        get=lambda key:row[header.index(key)]
        if get('year')==2023 and get('countrycode') in wanted:
            hc[get('countrycode')]={'value':get('hc'),'populationMillions':get('pop'),'employmentMillions':get('emp')}
    workbook.close()
    existing_manifest=json.loads((ROOT/'dist/data/official_data_manifest.json').read_text())
    pwt_meta=next(m for m in existing_manifest if m.get('path')==str(pwt_path.relative_to(ROOT)))
    manifest.append({'name':'population_education_human_capital','dataset':'PWT 11.0, Data sheet, hc and emp, 2023',
        'url':'https://www.rug.nl/ggdc/productivity/pwt/','methodologyUrl':'https://www.rug.nl/ggdc/docs/human_capital_in_pwt_90.pdf',
        'path':str(pwt_path.relative_to(ROOT)),'bytes':pwt_path.stat().st_size,'sha256':hashlib.sha256(pwt_path.read_bytes()).hexdigest(),
        'retrievedAt':pwt_meta['retrievedAt'],'status':'ok','license':pwt_meta.get('license')})
    valid_hc=[v for v in hc.values() if v['value'] is not None and v['employmentMillions'] is not None]
    eu_hc=sum(v['value']*v['employmentMillions'] for v in valid_hc)/sum(v['employmentMillions'] for v in valid_hc)
    out={}; missing=[]
    for profile in profiles:
        code,geo=profile['code'],profile['geo']; observations={}
        def obs(key,source,**selection):
            item=observation(sources[source],geo,**selection)
            item.update({'source':'population_education_'+source,'dataset':SOURCES[source][0],
                'url':next(m['url'] for m in manifest if m['name']=='population_education_'+source)})
            observations[key]=item
            if item['value'] is None:missing.append({'country':code,'key':key})
            return item['value']
        population=obs('population','balance',indic_de='JAN')
        births=obs('births','balance',indic_de='LBIRTH'); deaths=obs('deaths','balance',indic_de='DEATH')
        migration=obs('netMigrationPlusAdjustment','balance',indic_de='CNMIGRAT')
        change=obs('populationChange','balance',indic_de='GROW')
        avg=obs('averagePopulation','balance',indic_de='AVG')
        for name,item in [('crudeBirthRate','GBIRTHRT'),('crudeDeathRate','GDEATHRT'),('crudeNetMigrationRate','CNMIGRATRT')]:
            obs(name,'balance',indic_de=item)
        child=obs('childShare','ages',indic_de='PC_Y0_14'); old=obs('oldShare','ages',indic_de='PC_Y65_MAX')
        public=obs('publicEducation','public_education',unit='PC_GDP',sector='S13',cofog99='GF09',na_item='TE')
        private=obs('householdEducation','household_education_2018',unit='PC_GDP',coicop18='CP10')
        tertiary=obs('tertiaryAttainment','attainment',unit='PC',sex='T',age='Y25-64',isced11='ED5-8')
        age_obs=[]
        for age in ['Y_LT1']+['Y'+str(i) for i in range(1,100)]+['Y_OPEN','UNK','TOTAL']:
            item=observation(sources['deaths_age'],geo,unit='NR',sex='T',age=age)
            age_obs.append(item)
        by_age={item['selection']['age']:item['value'] for item in age_obs}
        young_keys=['Y_LT1']+['Y'+str(i) for i in range(1,15)]
        work_keys=['Y'+str(i) for i in range(15,65)]
        valid_cohorts=all(by_age[k] is not None for k in young_keys+work_keys) and by_age['TOTAL'] is not None
        if valid_cohorts:
            young_deaths=sum(by_age[k] for k in young_keys); work_deaths=sum(by_age[k] for k in work_keys)
            unknown=by_age['UNK'] or 0
            old_deaths=by_age['TOTAL']-young_deaths-work_deaths-unknown
            known=young_deaths+work_deaths+old_deaths
            mortality={'child':young_deaths/known,'working':work_deaths/known,'old':old_deaths/known,
                'childCount':young_deaths,'workingCount':work_deaths,'oldCount':old_deaths,'unknownAgeDeaths':unknown,
                'totalDeaths':by_age['TOTAL'],'status':'derived','note':'Deaths aged 0-14 and 15-64 sum single ages. Old deaths are total less the two younger groups and unknown age. Unknown-age deaths are allocated in proportion to known-age deaths when mapping total mortality. Open age interval is included in the old residual.'}
        else:
            mortality={'status':'missing','note':'Incomplete single-age deaths: no national cohort allocation was invented.'}
        observations['deathsByAge']={'source':'population_education_deaths_age','dataset':'demo_magec','url':next(m['url'] for m in manifest if m['name']=='population_education_deaths_age'),'observations':age_obs}
        opening_hc=eu_hc if code=='EU27' else hc.get(code,{}).get('value')
        hc_fallback=opening_hc is None
        if hc_fallback:opening_hc=eu_hc
        params={'initialPopulationMillions':population/1e6,'initialChildShare':child,'initialOldShare':old,
            'birthRate':100*births/population,'deathRate':100*deaths/population,'netMigrationRate':100*migration/population,
            'publicEducationGDP':public,'privateEducationGDP':private,'initialHumanCapital':opening_hc}
        if mortality['status']=='derived':
            params.update({'childDeathShare':mortality['child'],'workingDeathShare':mortality['working'],'oldDeathShare':mortality['old']})
        # Exact flows and stocks are used instead of rounded per-1000 crude rates.
        assert births-deaths+migration==change,(code,'demographic identity')
        assert abs((params['birthRate']-params['deathRate']+params['netMigrationRate'])/100*population-change)<1e-7
        assert 0<=child+old<=100
        out[code]={'year':2023,'geo':geo,'params':params,'workingAgeShare':100-child-old,'averagePopulation':avg,
            'tertiaryAttainment25to64':tertiary,'mortalityAllocation':mortality,'observations':observations,
            'humanCapital':{'value':opening_hc,'status':'proxy','source':'PWT 11.0 hc, 2023',
                'selection':{'countrycode':code,'year':2023,'variable':'hc'},
                'mapping':'Employment-weighted mean of available 27 member values; representative EU27 proxy.' if code=='EU27' else 'EU27 employment-weighted fallback because national hc is missing.' if hc_fallback else 'National index based on years of schooling and assumed returns; does not measure school quality.',
                'components':hc if code=='EU27' or hc_fallback else {code:hc[code]}},
            'notes':['Population stock is 1 January 2023; 2023 demographic events divided by that stock produce annual percent parameters. Published crude rates instead divide by average population and are per 1000.',
                'Repeating a single historical rate in future simulations is an extrapolation, not a demographic forecast. Net migration includes statistical adjustment.',
                'Age shares are rounded Eurostat percentages. The 15-64 share is their complement, not a legal retirement-age or labour-force participation assumption.',
                'COFOG GF09 TE is total government expenditure, including capital formation and transfers. Allocating it within an existing model purchase budget is a proxy and must not duplicate already funded education or university R&D.',
                'COICOP2018 CP10 household education spending is a domestic-concept funding measure, including non-residents locally and excluding residents abroad. It is not expenditure exclusively at privately owned schools. Education provision and funding ownership are different.',
                'PWT hc reflects schooling quantity with assumed returns. Neither spending shares nor attainment identify quality, a causal spending elasticity, or a public/private quality ranking.']}
    result={'year':2023,'countries':out,'missingObservations':missing,'sourceManifest':manifest,
        'definitions':{'rateUnit':'Percent of opening population per year. Exact events/population are used to avoid confusing per-thousand crude rates with percentages.',
            'quality':'No observed education-quality parameter is inferred from spending. Quality scenarios and their productivity response require explicitly assumed coefficients.',
            'educationFunding':'Public COFOG and household COICOP spending are different statistical concepts, not a complete mutually exclusive public/private institution partition.'}}
    (ROOT/'dist/data/population_education_benchmarks.json').write_text(json.dumps(result,indent=2)+'\n')
    (ROOT/'research/population_education_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'countries':len(out),'missing':missing,'Italy':out['ITA']['params'],'EU27':out['EU27']['params'],
        'mortalityCoverage':sum(v['mortalityAllocation']['status']=='derived' for v in out.values())},indent=2))


if __name__=='__main__':main()

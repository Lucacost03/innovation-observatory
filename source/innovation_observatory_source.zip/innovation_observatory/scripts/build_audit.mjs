import fs from 'node:fs';
import {buildParameterAudit} from '../dist/audit.mjs';
import {PARAMETERS,MODEL_VERSION} from '../dist/parameters.mjs';
const profiles=JSON.parse(fs.readFileSync(new URL('../dist/data/profiles.json',import.meta.url)));
const controls=PARAMETERS.filter(parameter=>!parameter.readOnly).length;
const report={modelVersion:MODEL_VERSION,generatedAt:new Date().toISOString(),controls,
 causalCoefficientsEstimated:false,countries:profiles.map(p=>({country:p.code,parameters:buildParameterAudit(p)}))};
fs.writeFileSync(new URL('../dist/data/parameter_audit.json',import.meta.url),JSON.stringify(report,null,2));
console.log(`Audited ${controls} controls across ${profiles.length} presets.`);

"""Integrate frozen official data; keep behavioral responses separate from observations."""
from pathlib import Path
import json,copy
R=Path(__file__).resolve().parents[1];D=R/'dist/data'
load=lambda path:json.loads(path.read_text())
profiles=load(D/'profiles.json');pop=load(D/'population_education_benchmarks.json');housing=load(D/'population_education_housing_services.json');hp=load(D/'housing_pension_benchmarks.json')
gdp_raw=load(R/'research/source_snapshots/housing_pension_gdp_2021.json')
def gdp2021(geo):
 selection={'freq':'A','unit':'CP_MEUR','na_item':'B1GQ','geo':geo,'time':'2021'};index=0
 for key,size in zip(gdp_raw['id'],gdp_raw['size']):index=index*size+gdp_raw['dimension'][key]['category']['index'][selection[key]]
 return gdp_raw['value'][str(index)]
covered=[p for p in profiles if p['code']!='EU27' and not hp['countries'][p['code']]['privatePensionGDP'].get('fallback')]
den=sum(hp['countries'][p['code']]['privatePensionGDP']['value']*gdp2021(p['geo']) for p in covered)
pooled_benefits=sum(hp['countries'][p['code']]['privatePensionBenefitsGDP']['value']*gdp2021(p['geo']) for p in covered)/den
pooled_contributions=sum(hp['countries'][p['code']]['privatePensionContributionsGDP']['value']*gdp2021(p['geo']) for p in covered)/den
benchmarks={}
for profile in profiles:
 code=profile['code'];a=pop['countries'][code];b=housing['countries'][code];c=hp['countries'][code];params=profile['params'];prov=profile['provenance'];mapped={**a['params'],**b['params']}
 for key,val in mapped.items():
  obs=list(a['observations'].values())+list(b['observations'].values())
  sources=[x for x in obs if x.get('url')]
  prov[key]={'status':'proxy','dataset':'Eurostat population/education and PWT schooling; exact selections in population_education_benchmarks.json','year':2023,'note':({'birthRate':'Births divided by opening population, percent. Future rates are scenario assumptions.','deathRate':'Observed deaths divided by opening population calibrate age-specific hazards using observed mortality shares.','netMigrationRate':'Net migration plus statistical adjustment, divided by opening population. Future age allocation and migration are assumptions.','initialHumanCapital':'PWT schooling-based hc index, not observed school quality. EU27 uses an employment-weighted member proxy. Production uses hc relative to its own opening level.','publicEducationGDP':'COFOG total education spending/GDP. Mapped to a reallocation inside delivered government purchases; the source also covers capital and transfers.','privateEducationGDP':'Household education services/GDP, not a direct measure of private school ownership. Mapped to a budget share within consumption.','actualRentGDP':'Observed actual rents/GDP. Anchors rental services; house prices are separate asset valuations.','imputedRentGDP':'Observed noncash owner-occupied housing services/GDP. These are household production and consumption, without new cash.','ownerOccupancy':'Observed share of people living in owner-occupied households mapped to a synthetic owner count.'}.get(key,'Observed demographic opening input; the model uses three aggregate cohorts and preserves exact source definitions in the input benchmark.')),'url':sources[0]['url'] if sources else '', 'benchmark':'population_education_benchmarks.json','flags':sorted({x.get('flag') for x in obs if x.get('flag')})}
 dependencies={'initialPopulationMillions':['population'],'initialChildShare':['childShare'],'initialOldShare':['oldShare'],'birthRate':['births','population'],'deathRate':['deaths','population'],'netMigrationRate':['netMigrationPlusAdjustment','population'],'publicEducationGDP':['publicEducation'],'privateEducationGDP':['householdEducation'],'actualRentGDP':['actualRent'],'imputedRentGDP':['imputedRent'],'ownerOccupancy':['ownerOccupancy'],'childDeathShare':['deathsByAge'],'workingDeathShare':['deathsByAge'],'oldDeathShare':['deathsByAge']}
 for key,names in dependencies.items():
  chosen=[a['observations'].get(name,b['observations'].get(name)) for name in names]
  prov[key].update(dataset=' + '.join(dict.fromkeys(x['dataset'] for x in chosen)),url=chosen[0]['url'],flags=sorted({x.get('flag') for x in chosen if x.get('flag')}),benchmark='population_education_housing_services.json' if key in b['params'] else 'population_education_benchmarks.json',benchmarkSelection='countries.'+code+'.observations.'+names[0])
  prov[key]['components']=[{k:v for k,v in x.items() if k!='observations'} for x in chosen]
 prov['initialHumanCapital'].update(dataset=a['humanCapital']['source'],url='https://www.rug.nl/ggdc/productivity/pwt/',selection=a['humanCapital'].get('selection'),components=a['humanCapital'].get('components'),flags=[])
 mapping={'publicPensionGDP':'publicOldAgeCashGDP','initialHousingGDP':'housingStructuresGDP','initialMortgageGDP':'mortgageDebtGDP','mortgagedOwnerShare':'mortgagedOwnerPopulationShare','initialPrivatePensionGDP':'privatePensionGDP','mortgageOpeningRate':'mortgageStockRate'}
 for key,field in mapping.items():
  source=c[field];mapped[key]=source['value'];prov[key]={**copy.deepcopy(source),'dataset':'Eurostat/ECB housing and pension benchmark','url':next((hp['sources'][v['source']]['url'] for v in source.get('components',[]) if v.get('source') in hp['sources']),''),'note':source['note'],'benchmark':'housing_pension_benchmarks.json'}
 mapped['mortgageSpread']=c['mortgageNewRate']['openingPolicySpread'];prov['mortgageSpread']={**copy.deepcopy(c['mortgageNewRate']),'dataset':'ECB MIR mortgage quote less opening central bank rate','note':c['mortgageNewRate']['note']+' The fixed opening spread and current central bank rate determine subsequent new-loan quotes.','benchmark':'housing_pension_benchmarks.json'}
 mapped['residentialInvestmentShare']=100*c['housingInvestmentShareOfGFCF']['value'];prov['residentialInvestmentShare']={**copy.deepcopy(c['housingInvestmentShareOfGFCF']),'dataset':'Eurostat dwelling/total fixed investment','note':'Dwelling GFCF / total GFCF sets a share of the existing investment envelope. Both business capital and construction must be counted once.','benchmark':'housing_pension_benchmarks.json'}
 mapped['privatePensionContributionRate']=100*c['privatePensionContributionsGDP']['value']/params['laborShare'];prov['privatePensionContributionRate']={**copy.deepcopy(c['privatePensionContributionsGDP']),'dataset':'Eurostat pension actual contributions/model wage bill','note':c['privatePensionContributionsGDP']['note']+' Combined employer and household actual contributions / model gross wages; paid from the wage envelope, not an extra employer cost.','benchmark':'housing_pension_benchmarks.json'}
 mapped['privatePensionWithdrawalRate']=100*c['privatePensionBenefitsGDP']['value']/c['privatePensionGDP']['value'];prov['privatePensionWithdrawalRate']={**copy.deepcopy(c['privatePensionBenefitsGDP']),'dataset':'Eurostat private benefits/entitlements proxy','note':c['privatePensionBenefitsGDP']['note']+' This rate redeems funded claims, depends on liquidity and scales with the older population; DB promises are not guaranteed in this funded-account proxy.','benchmark':'housing_pension_benchmarks.json'}
 if c['privatePensionBenefitsGDP'].get('fallback') or c['privatePensionGDP'].get('fallback'):
  mapped['privatePensionWithdrawalRate']=100*pooled_benefits
  mapped['privatePensionContributionRate']=100*c['privatePensionGDP']['value']*pooled_contributions/params['laborShare']
  for key in ['privatePensionContributionRate','privatePensionWithdrawalRate']:
   prov[key]['fallback']=True;prov[key]['note']='Comparable national private pension cash-flow and entitlement data are incomplete. Covered2021member total cash flows / total entitlements gives a common rate, applied to this preset’s mapped assets. This avoids dividing an EU GDP-flow fallback by a small national fund stock. It is a funding-universe proxy, not observed national cash flows.'
 mapped['publicPensionContributionShare']=min(100,100*c['publicOldAgeCashGDP']['value']/(params['laborShare']*params['incomeTax']/100))
 prov['publicPensionContributionShare']={'status':'proxy','year':2023,'dataset':'Public old-age benefits / existing worker withholding','note':'Budget earmarking proxy, capped at100% of existing worker withholding. Does not estimate a statutory contribution rate or add another tax; the rest of the pension budget uses other taxes/borrowing.'}
 mapped.update(populationDynamics=1,educationEnabled=1,pensionEnabled=1,housingEnabled=1)
 params.update(mapped)
 for key in ['employmentSeparation','jobFindingRate']:
  if key in prov:prov[key]['note']=prov[key]['note'].replace('The model holds the labor force fixed and represents movement between these two statuses.','Transitions apply within the current labor force. Population changes and workforce entry/retirement are tracked separately.')
 for key in ['wealthTax','financialIncomeTax']:
  if key in prov and 'Funded pension claims' not in prov[key]['note']:prov[key]['note']+=' Funded pension claims are excluded from the recurring financial-wealth levy; cash rental receipts use the financial-income tax proxy. Pension contributions and withdrawals are modeled as after-tax asset transactions.'
 benchmarks[code]={'year':2023,'params':mapped,'publicSupportCarveOut':min(params['incomeSupport'],mapped['publicPensionGDP']),'productiveCapitalGDP':100*params['capitalOutputRatio']-mapped['initialHousingGDP'],'privatePensionSourceYear':c['privatePensionGDP']['year'],'sourceNotes':a['notes']+b['notes'],'housingPension':{key:{k:v for k,v in val.items() if k in ['year','status','fallback','note']} for key,val in c.items() if isinstance(val,dict)}}
 assert benchmarks[code]['productiveCapitalGDP']>0
(D/'profiles.json').write_text(json.dumps(profiles,indent=2)+'\n');(D/'society_benchmarks.json').write_text(json.dumps({'countries':benchmarks,'scope':'Three demographic cohorts; observed stocks/funding proxies; schooling, pension, housing-market and migration responses remain unestimated.'},indent=2)+'\n')
manifest=load(D/'official_data_manifest.json')
new=load(R/'research/population_education_manifest.json')+load(R/'research/population_education_housing_services_manifest.json')+list(hp['sources'].values())
for row in new: row.setdefault('dataset',row['name']);row.setdefault('status','ok')
byname={x['name']:x for x in manifest}
for row in new:byname[row['name']]=row
manifest=list(byname.values());(D/'official_data_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
evidence=load(D/'evidence.json');evidence['officialSourcesAdded']=manifest
for key in benchmarks['ITA']['params']:evidence['mapping'][key]=next(p for p in profiles if p['code']=='ITA')['provenance'].get(key,{}).get('note','Scenario mechanism; no estimated causal effect.')
(D/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps({'presets':len(profiles),'sources':len(new),'Italy':benchmarks['ITA']['params'],'EU27':benchmarks['EU27']['params']},indent=2))

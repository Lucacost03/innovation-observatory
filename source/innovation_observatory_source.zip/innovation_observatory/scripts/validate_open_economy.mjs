import assert from 'node:assert/strict';
import {readFileSync, writeFileSync} from 'node:fs';
import {simulate, quantile} from '../dist/engine.mjs';
import {MODEL_VERSION} from '../dist/parameters.mjs';

assert.equal(MODEL_VERSION, '1.6.0', 'Run this archived comparison from the engine 1.6.0 source.');

const root = new URL('../', import.meta.url);
const read = path => JSON.parse(readFileSync(new URL(path, root)));
const sources = name => read('research/source_snapshots/' + name + '.json');
const profiles = read('dist/data/profiles.json');
const hicp = sources('hicp_annual');
const gdp = sources('gdp_growth_2024_25');
const unemployment = sources('unemployment_2024_25');
const seeds = Array.from({length:20}, (_, i) => 2026 + 7919 * i);
const variants = {
  fixed: {foreignTechDispersion:0},
  prices: {priceDynamics:1,foreignTechDispersion:0},
  dispersion: {foreignTechDispersion:.3},
  monetary: {priceDynamics:1,policyDynamics:1,currencyDynamics:1,foreignTechDispersion:0},
  integrated: {priceDynamics:1,policyDynamics:1,currencyDynamics:1,foreignTechDispersion:.3},
};
function observation(table, geo, year, selection) {
  const key = table.id.reduce((position, name, i) => position * table.size[i]
    + table.dimension[name].category.index[{geo,time:String(year),...selection}[name]],0);
  assert(Number.isFinite(table.value[key]),`Missing benchmark for ${geo} in ${year}`);
  return table.value[key];
}
function errors(rows, key) {
  const differences = rows.map(row => row[key] - row.observed[key]);
  const mean = values => values.reduce((sum,value)=>sum+value,0)/values.length;
  return {mae:mean(differences.map(Math.abs)),rmse:Math.sqrt(mean(differences.map(error=>error**2)))};
}
const scores = {};
for (const [label, switches] of Object.entries(variants)) {
  const predictions = [];
  let maxAccountingResidual = 0;
  for (const {code,geo,params} of profiles) {
    const paths = seeds.map(seed => simulate({...params,...switches,periods:8},seed).rows);
    for (const rows of paths) for (const row of rows) {
      maxAccountingResidual = Math.max(maxAccountingResidual,row.relativeResidual,
        Math.abs(row.nominalGDPResidual)/Math.max(1,row.nominalOutput));
    }
    const gdpGrowth = year => observation(gdp,geo,year,{freq:'A',unit:'CLV_PCH_PRE',na_item:'B1GQ'});
    for (const horizon of [1,2]) {
      const year = 2023 + horizon;
      const med = value => quantile(paths.map(path=>value(path[horizon])),.5);
      const actualGDP = horizon === 1 ? gdpGrowth(2024)
        : 100*(Math.sqrt((1+gdpGrowth(2024)/100)*(1+gdpGrowth(2025)/100))-1);
      predictions.push({code,horizon,
        inflation:med(row=>row.inflation),gdp:med(row=>100*((row.output/100)**(1/horizon)-1)),
        unemployment:med(row=>row.unemployment),
        observed:{inflation:observation(hicp,geo,year,{freq:'A',unit:'RCH_A_AVG',coicop:'CP00'}),gdp:actualGDP,
          unemployment:observation(unemployment,geo,year,{freq:'A',unit:'PC_ACT',sex:'T',age:'Y15-74'})}});
    }
  }
  const byScope = aggregate => Object.fromEntries([1,2].map(horizon=>{
    const rows = predictions.filter(row=>row.horizon===horizon && (row.code==='EU27')===aggregate);
    return [horizon,Object.fromEntries(['inflation','gdp','unemployment'].map(key=>[key,errors(rows,key)]))];
  }));
  scores[label] = {switches,paths:profiles.length*seeds.length,maxAccountingResidual,
    memberCountries:byScope(false),eu27:byScope(true),predictions};
  console.log(label,JSON.stringify(scores[label].memberCountries[2]));
}
const report = {modelVersion:MODEL_VERSION,
  protocol:'Retrospective check from the 2023 opening presets, scored on the already examined 2024 and 2025 targets. Medians of 20 matched seeds per preset. Each member country has equal weight. The representative EU27 economy is reported separately. There is no imposed currency shock in this comparison.',
  measurement:'Inflation is the annual rate in the target year, compared with Eurostat all-items HICP. GDP growth is annualized from the opening year, compared with Eurostat chain-linked volume growth. Unemployment is the year-end model rate compared with Eurostat annual unemployment. Error units are percentage points.',
  decision:'Firm-level technology variation is available in new configurations and is preserved as a structural assumption. The monetary and currency channels are optional because their inflation and GDP error changes differ across metrics and years.',
  seeds,scores};
writeFileSync(new URL('dist/data/open_economy_validation.json',root),JSON.stringify(report,null,2)+'\n');

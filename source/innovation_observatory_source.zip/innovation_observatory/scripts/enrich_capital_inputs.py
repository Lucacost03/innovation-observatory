"""Reproduce 2023 portfolio and household capital-tax input proxies.

These are mappings to a small annual model, not statutory tax schedules or
estimated portfolio responses. No coefficient is selected on simulation results.
"""
from pathlib import Path
import csv
import datetime
import hashlib
import json
import openpyxl

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'dist/data'
RAW = ROOT / 'research/source_snapshots'
TAX_URL = 'https://taxation-customs.ec.europa.eu/taxation/economic-analysis/data-taxation-trends_en'
ECB_URL = 'https://www.ecb.europa.eu/stats/pdf/Looking_through_note.en.pdf'
ITALY_URL = 'https://temi.camera.it/leg19/temi/la-fiscalit-internazionale'
WEALTH_URL = 'https://www.europarl.europa.eu/RegData/etudes/ATAG/2025/779237/EPRS_ATA%282025%29779237_EN.pdf'
SOURCES = {
    'capital_italian_wealth_scope': ('Italian Parliament financial-product levy / IVAFE scope, applicable 2023 ordinary rate', ITALY_URL, 'italy_financial_wealth_tax_scope.html'),
    'capital_eu_wealth_scope': ('European Parliament 2025: wealth-tax bases and 2023 receipts', WEALTH_URL, 'eu_wealth_tax_scope_2025.pdf'),
    'capital_portfolio_methodology': ('ECB household portfolio look-through methodology', ECB_URL, 'ecb_portfolio_methodology.pdf'),
    'capital_tax_profiles': ('EC DG TAXUD 2026 country tables, 2023 column',
        'https://taxation-customs.ec.europa.eu/document/download/ff0728c1-9176-4759-b981-8872e0374416_en?filename=Part2_country_profiles.xlsx', 'tax_country_profiles_2026.xlsx'),
    'capital_tax_lists': ('EC DG TAXUD 2026 national tax lists, 2023 column',
        'https://taxation-customs.ec.europa.eu/document/download/600d56d1-ea6e-416e-9981-1c8b9c603b6b_en?filename=NTL+edition+2026+web.xlsx', 'tax_national_lists_2026.xlsx'),
    'foreign_portfolio_lookthrough': ('ECB QSA 2023Q4 VIFA, household debt securities and listed shares',
        'https://data-api.ecb.europa.eu/service/data/QSA/Q.N..W0+W1.S1M.S1.N.A.LE.F3+F511.T+_Z._Z.XDC._T.S.V.N.VIFA?startPeriod=2023-Q4&endPeriod=2023-Q4&format=csvdata', 'qsa_foreign_portfolio_2023.csv'),
    'foreign_portfolio_direct': ('ECB QSA 2023Q4 direct household securities',
        'https://data-api.ecb.europa.eu/service/data/QSA/Q.N..W0+W1.S1M.S1.N.A.LE.F3+F511+F522.T+_Z._Z.XDC._T.S.V.N._T?startPeriod=2023-Q4&endPeriod=2023-Q4&format=csvdata', 'qsa_direct_foreign_2023.csv'),
    'household_property_income': ('Eurostat nasa_10_nf_tr S14_S15 D4 received, 2023',
        'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_nf_tr?lang=en&freq=A&unit=CP_MEUR&sector=S14_S15&direct=RECV&na_item=D4&time=2023', 'household_property_income_2023.json'),
    'household_financial_assets': ('Eurostat nasa_10_f_bs S14_S15 assets, 2023',
        'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_f_bs?lang=en&freq=A&unit=MIO_EUR&co_nco=NCO&sector=S14_S15&finpos=ASS&time=2023', 'household_financial_assets_2023.json'),
}

def read(path):
    return json.loads(path.read_text())

def value(table, selection):
    offset = 0
    for key, size in zip(table['id'], table['size']):
        index = table['dimension'][key]['category']['index'].get(selection[key])
        if index is None:
            return None
        offset = offset * size + index
    return table.get('value', {}).get(str(offset))

def portfolio(rows, geo):
    selected = {(r['COUNTERPART_AREA'], r['INSTR_ASSET']): float(r['OBS_VALUE'])
                for r in rows if r['REF_AREA'] == geo}
    # Keep the same instrument basket in numerator and denominator. Direct
    # fund domiciles are not a substitute for their underlying issuers.
    total = sum(selected[('W0', instrument)] for instrument in ['F3', 'F511'])
    foreign = sum(selected[('W1', instrument)] for instrument in ['F3', 'F511'])
    assert 0 < foreign < total
    return foreign, total

def source(dataset, url, note, **extra):
    return {'status': 'proxy', 'dataset': dataset, 'year': 2023, 'url': url,
            'note': note, **extra}

def main():
    profiles = read(DATA / 'profiles.json')
    prior = read(ROOT / 'research/capital_inputs_prior.json')
    accounts = read(RAW / 'national_accounts.json')
    income = read(RAW / 'household_property_income_2023.json')
    assets = read(RAW / 'household_financial_assets_2023.json')
    lookthrough = list(csv.DictReader((RAW / 'qsa_foreign_portfolio_2023.csv').open()))
    direct = list(csv.DictReader((RAW / 'qsa_direct_foreign_2023.csv').open()))
    covered = {row['REF_AREA'] for row in lookthrough}
    taxbook = openpyxl.load_workbook(RAW / 'tax_country_profiles_2026.xlsx', data_only=True, read_only=True)
    taxlist = openpyxl.load_workbook(RAW / 'tax_national_lists_2026.xlsx', data_only=True, read_only=True)
    benchmark = {}
    for profile in profiles:
        geo = profile['geo']
        gdp = value(accounts, {'freq': 'A', 'unit': 'CP_MEUR', 'na_item': 'B1GQ', 'geo': geo, 'time': '2023'})
        property_income = value(income, {'freq': 'A', 'unit': 'CP_MEUR', 'direct': 'RECV', 'na_item': 'D4', 'sector': 'S14_S15', 'geo': geo, 'time': '2023'})
        financial_assets = value(assets, {'freq': 'A', 'unit': 'MIO_EUR', 'co_nco': 'NCO', 'sector': 'S14_S15', 'finpos': 'ASS', 'na_item': 'F', 'geo': geo, 'time': '2023'})
        sheet = taxbook[geo]
        column = list(next(sheet.iter_rows(min_row=3, max_row=3, values_only=True))).index('2023')
        receipts = next(row[column] for row in sheet.iter_rows(values_only=True) if row[0] == 'Income of households')
        benchmark[profile['code']] = {'gdpEURmillion': gdp, 'householdPropertyIncomeEURmillion': property_income,
            'householdFinancialAssetsEURmillion': financial_assets, 'capitalIncomeTaxGDP': receipts,
            'priorDefaults': {key: prior[profile['code']].get(key, 0) for key in ['foreignPortfolioWeight', 'financialIncomeTax', 'wealthTax', 'incomeTax']}}
    eu = benchmark['EU27']
    eu_income_rate = eu['capitalIncomeTaxGDP'] * eu['gdpEURmillion'] / eu['householdPropertyIncomeEURmillion']
    for profile in profiles:
        code, geo, params = profile['code'], profile['geo'], profile['params']
        b = benchmark[code]
        area = 'I9' if code == 'EU27' else 'GR' if geo == 'EL' else geo
        indirect = area in covered
        foreign, total = portfolio(lookthrough if indirect else direct, area)
        share = foreign / total
        domestic_weight = sum(params.get(key, default) for key, default in [
            ('ventureWeight', 50), ('businessEquityWeight', 15), ('corporateBondWeight', 15), ('governmentBondWeight', 20)])
        params['foreignPortfolioWeight'] = domestic_weight * share / (1 - share)
        assert 0 < params['foreignPortfolioWeight'] < 10000
        b.update(foreignPortfolioShare=share, observedForeignSecurities=foreign, observedTotalSecurities=total,
                 portfolioArea=area, portfolioLookthrough=indirect, portfolioWeight=params['foreignPortfolioWeight'])
        scope = ('Euro-area extra-area proxy for EU27; it is not a consolidated extra-EU observation. ' if code == 'EU27' else '')
        scope += ('Includes indirect holdings through non-MMF funds. ' if indirect else
                  'Direct debt and listed-share holdings only; comparable look-through data are missing. Fund exposures are omitted, so this proxy can understate foreign exposure. ')
        profile['provenance']['foreignPortfolioWeight'] = source('ECB QSA 2023Q4 household securities', ECB_URL,
            scope + f'Foreign debt securities and listed shares / the same total securities basket = {100*share:.2f}%. '
            'A stock composition anchors the share of new model orders, not an estimated annual behavioral response. '
            'Relative weight = domestic weight sum × foreign share / (1 − foreign share). Model venture equity is not separately observed in this basket.',
            selection={'referenceArea': area, 'counterpartAreas': ['W1','W0'], 'instruments': ['F3','F511'], 'breakdown': 'VIFA' if indirect else '_T'})
        fallback = b['householdPropertyIncomeEURmillion'] is None or b['householdPropertyIncomeEURmillion'] <= 0 or b['capitalIncomeTaxGDP'] <= 0
        rate = eu_income_rate if fallback else b['capitalIncomeTaxGDP'] * b['gdpEURmillion'] / b['householdPropertyIncomeEURmillion']
        assert 0 < rate < 70
        params['financialIncomeTax'] = rate
        b.update(financialIncomeTax=rate, financialIncomeTaxFallback=fallback)
        profile['provenance']['financialIncomeTax'] = source('EC DG TAXUD capital taxes on household income / Eurostat household property income', TAX_URL,
            ('EU27 proxy: local property income is missing or the net capital-tax receipt is negative. ' if fallback else '') +
            '2023 household capital-income tax receipts divided by gross household property income received. '
            'This effective aggregate proxy includes tax-base differences such as rents, insurance income, relief and capital gains. '
            'The model applies one rate to cash interest and dividends, including foreign income; it is not a statutory or taxpayer-specific rate.',
            selection={'numerator': 'DG TAXUD capital: income of households (% GDP)', 'denominator': 'S14_S15 D4 RECV, converted to % GDP', 'fallback': fallback})
        # The previous wage deduction already included these personal capital
        # receipts. Separate their base instead of counting them a second time.
        removed = max(0, b['capitalIncomeTaxGDP'])
        params['incomeTax'] = b['priorDefaults']['incomeTax'] - 100 * removed / params['laborShare']
        old_note = profile['provenance']['incomeTax']['note'].split(' Capital-income receipts are removed')[0]
        profile['provenance']['incomeTax'] = {**profile['provenance']['incomeTax'],
            'note': old_note + ' Capital-income receipts are removed using the 2023 DG TAXUD household capital-income category before division by model wages, avoiding duplicate allocation to wage and financial-income taxes.',
            'capitalIncomeReceiptsRemovedGDP': removed}
        wealth_receipts = None
        if code in ['BEL','ESP']:
            sheet = taxlist[geo]
            year_column = list(next(sheet.iter_rows(min_row=8, max_row=8, values_only=True))).index(2023)
            codes = {'C06'} if code == 'BEL' else {'C01', 'C03'}
            wealth_receipts = sum(row[year_column] for row in sheet.iter_rows(values_only=True)
                if row[0] == 'D59A' and row[1] in codes)
        if code == 'ITA':
            params['wealthTax'] = .2
            note = 'Italy’s annual 0.20% financial-product levy / IVAFE anchors this financial-wealth proxy. The model applies it to all recorded financial wealth. Real exemptions, fixed charges on current accounts, asset-specific bases and foreign-tax credits are not replicated. This is not a tax on all Italian net wealth.'
            url, dataset = ITALY_URL, 'Italian Parliament: financial-product levy and IVAFE'
        elif code in ['BEL','ESP']:
            params['wealthTax'] = 100 * wealth_receipts / b['householdFinancialAssetsEURmillion']
            note = ('Belgian securities-account tax receipts (D59A C06).' if code == 'BEL' else
                    'Spanish wealth and large-fortune tax receipts (D59A C01+C03). The real tax also covers non-financial wealth.')
            note += ' 2023 receipts / aggregate household financial assets provides a uniform budget-equivalent proxy. Thresholds, exemptions, regional schedules and the distribution of actual payments are not replicated.'
            url, dataset = TAX_URL, 'EC national tax lists / Eurostat household financial assets'
        else:
            params['wealthTax'] = 0
            note = 'No comparable broad annual household financial-wealth levy is mapped for this preset. The recurring net-wealth tax is concentrated in Spain; property-only taxes, inheritance, transactions and corporate wealth taxes are excluded from this financial-wealth channel. Zero describes this modeled base, not the absence of all wealth-related taxes.'
            url, dataset = WEALTH_URL, 'European Parliament wealth-tax scope / EC national tax lists'
        b.update(wealthTax=params['wealthTax'], wealthTaxReceiptsEURmillion=wealth_receipts)
        if wealth_receipts and profile['provenance']['incomeTax'].get('selection', {}).get('fallback_dataset') == 'household_deductions':
            # D5, unlike the narrower D51 alternative, also contains D59A.
            removal = 100 * wealth_receipts / b['gdpEURmillion']
            params['incomeTax'] -= 100 * removal / params['laborShare']
            profile['provenance']['incomeTax']['wealthReceiptsRemovedGDP'] = removal
            profile['provenance']['incomeTax']['note'] += ' The separately modeled recurring wealth receipts are also removed from the broader D5 fallback.'
        profile['provenance']['wealthTax'] = source(dataset, url, note)
        profile['capitalInputPriorDefaults'] = b['priorDefaults']
        assert 0 <= params['incomeTax'] <= 80
    # A representative EU uses a GDP-weighted member proxy, not an EU tax law.
    aggregate = next(profile for profile in profiles if profile['code'] == 'EU27')
    weights = {row['country']: row['gdpWeight'] for row in aggregate['aggregation']['weights']}
    aggregate['params']['wealthTax'] = sum(benchmark[code]['wealthTax'] * weight for code, weight in weights.items())
    benchmark['EU27']['wealthTax'] = aggregate['params']['wealthTax']
    aggregate['provenance']['wealthTax'] = source('GDP-weighted EU member financial-wealth levy proxies', TAX_URL,
        'GDP-weighted average of the member financial-wealth levy proxies. Positive member rates come from Italy, Belgium and Spain. Other modeled bases are zero. This represents an aggregate assumption; there is no common EU wealth-tax law.')
    (DATA / 'profiles.json').write_text(json.dumps(profiles, indent=2) + '\n')
    (DATA / 'capital_input_benchmarks.json').write_text(json.dumps(benchmark, indent=2) + '\n')
    manifest = [row for row in read(DATA / 'official_data_manifest.json') if row['name'] not in SOURCES]
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for name, (dataset, url, file) in SOURCES.items():
        path = RAW / file
        manifest.append({'name': name, 'dataset': dataset, 'url': url, 'retrievedAt': now, 'status': 'ok',
            'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    (DATA / 'official_data_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    evidence = read(DATA / 'evidence.json')
    evidence['officialSourcesAdded'] = manifest
    evidence['mapping'].update({
        'foreignPortfolioWeight': '2023Q4 household foreign debt securities and listed shares / the same total basket, mapped to relative order weights. VIFA look-through where available; direct holdings otherwise. EU27 uses extra-euro-area proxy.',
        'financialIncomeTax': '2023 DG TAXUD household capital-income tax receipts / Eurostat gross household property income received. An aggregate effective proxy, not a statutory rate. EU27 fallback for Bulgaria and the Netherlands.',
        'wealthTax': 'Financial-wealth levy proxy: Italian annual financial-product levy, Belgian and Spanish observed receipts / household financial assets, zero on modeled bases without comparable levies. EU27 uses GDP-weighted member proxies.',
        'incomeTax': 'Earlier personal-income and social-receipt wage proxy less separately allocated household capital-income receipts; also removes recurring wealth receipts from broad D5 where relevant, avoiding duplicate allocation.'})
    (DATA / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps({'presets': len(profiles), 'Italy': benchmark['ITA'], 'EU27': benchmark['EU27'],
        'incomeTaxFallbacks': [code for code, b in benchmark.items() if b['financialIncomeTaxFallback']],
        'positiveWealthLevyPresets': [code for code, b in benchmark.items() if b['wealthTax'] > 0]}, indent=2))

if __name__ == '__main__':
    main()

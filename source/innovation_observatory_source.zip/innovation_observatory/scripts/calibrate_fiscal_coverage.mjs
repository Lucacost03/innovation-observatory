// Reconcile only frozen2023 fiscal moments; never fit future GDP or CA.
import fs from 'node:fs';
import {FISCAL_ENGINE}from '../dist/fiscal-data.mjs';
import {Economy}from '../dist/engine.mjs';
const root=new URL('../',import.meta.url),read=p=>JSON.parse(fs.readFileSync(new URL(p,root)));
const profiles=read('dist/data/profiles.json'),b=read('dist/data/fiscal_benchmarks.json'),seeds=[2026,9945,17864];
for(const c of Object.values(FISCAL_ENGINE))c.calibration=null;
const results={modelVersion:'1.26.0',seeds,protocol:'One annual step at frozen opening nominal scale with price, population, FX, foreign demand/price growth and policy movements off. Restricted source benefits remain active. Only2023 fiscal moments are reconciled; no later GDP/CA observations used.',countries:{}};
for(const profile of profiles){const source=b.countries[profile.code],rows=seeds.map(seed=>new Economy({...profile.params,populationDynamics:0,priceDynamics:0,policyDynamics:0,currencyDynamics:0,foreignPriceGrowth:0,foreignDemandGrowth:0,supplyNoise:0},seed).step(1,1));
 const mean=fn=>rows.reduce((s,r)=>s+fn(r),0)/rows.length;
 const k={capitalIncomeTaxesGDP:mean(r=>r.financialIncomeTaxPaid+r.wealthTaxPaid),consumptionTaxesGDP:mean(r=>r.nominalConsumptionTax+r.importTariffRevenue),publicPropertyIncomeGDP:mean(r=>r.governmentFirmDividends+r.centralBankRemittance),currentExpenseCoverageGDP:source.opening.currentExpenditureCashEquivalent-mean(r=>r.publicCurrentExpenditure)};
 source.calibration=k;FISCAL_ENGINE[profile.params.foreignPoolId].calibration=k;results.countries[profile.code]=k;
}
b.modelVersion='1.26.0';fs.writeFileSync(new URL('dist/data/fiscal_benchmarks.json',root),JSON.stringify(b,null,2)+'\n');fs.writeFileSync(new URL('dist/fiscal-data.mjs',root),'export const FISCAL_ENGINE='+JSON.stringify(FISCAL_ENGINE)+';\n');fs.writeFileSync(new URL('research/fiscal_reconciliation/coverage_calibration.json',root),JSON.stringify(results,null,2)+'\n');console.log('Frozen-source fiscal coverage calibrated for',profiles.length,'presets.');

"""Map frozen official household moments and gross external positions to presets."""
from pathlib import Path
import json, hashlib, datetime
import openpyxl

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'research/source_snapshots'

def jsvalue(data, selection):
    index=0
    for key,size in zip(data['id'],data['size']):
        index=index*size+data['dimension'][key]['category']['index'][selection[key]]
    return data.get('value',{}).get(str(index))

def gini(values):
    a=sorted(values);total=sum(a);n=len(a)
    return 2*sum((i+1)*v for i,v in enumerate(a))/(n*total)-(n+1)/n

def main():
    profiles=json.loads((ROOT/'dist/data/profiles.json').read_text())
    income=json.loads((SOURCE/'income_gini_reference2023.json').read_text())
    iip=json.loads((SOURCE/'gross_iip_2023.json').read_text())
    book=openpyxl.load_workbook(SOURCE/'HFCS_Statistical_Tables_Wave_2023_October_2026.xlsx',data_only=True)
    financial=book['C3 Total financial assets, amon']
    participation=book['C1 Financial assets - participa']
    net=book['J4 Net wealth inequality indica']
    countries={cell.value:cell.column for cell in financial[5] if cell.value}
    pcountries={cell.value:cell.column for cell in participation[5] if cell.value}
    ncountries={cell.value:cell.column for cell in net[5] if cell.value}
    benchmarks={}
    for p in profiles:
        geo=p['geo'];country='GR' if geo=='EL' else geo
        source_country=country if country in countries else 'euro area'
        col=countries[source_country]
        mean=float(financial.cell(6,col).value)
        deciles=[]
        for row in range(8,25,2):
            value=str(financial.cell(row,col).value)
            deciles.append(.05 if value=='< 0.1' else float(value))
        # Linear quantile interpolation through published deciles. A Pareto top
        # decile matches the published conditional mean without truncating tails.
        points=[0]+deciles
        lower_integral=sum((points[i]+points[i+1])*.05 for i in range(9))
        top_mean=(mean-lower_integral)/.1
        alpha=top_mean/(top_mean-deciles[-1])
        assert alpha>1
        has_assets=float(participation.cell(6,pcountries[source_country]).value)/100
        def integrated_quantile(q):
            if q<=0:return 0
            if q>=.9:
                return lower_integral+.1*deciles[-1]*alpha/(alpha-1)*(1-((1-q)/.1)**(1-1/alpha))
            j=min(8,int(q*10));left=j/10;delta=q-left
            integral=sum((points[k]+points[k+1])*.05 for k in range(j))
            return integral+points[j]*delta+(points[j+1]-points[j])*5*delta*delta
        def full_integral(q):
            return has_assets*integrated_quantile(max(0,(q-1+has_assets)/has_assets))
        values=[20000*(full_integral((i+1)/20000)-full_integral(i/20000)) for i in range(20000)]
        financial_gini=gini(values)
        income_gini=jsvalue(income,{'freq':'A','age':'TOTAL','statinfo':'GINI_HND','geo':geo,'time':'2024'})/100
        base={'freq':'A','unit':'PC_GDP','s_adj':'NSA','bop_item':'FA','geo':geo,'time':'2023',
              'partner':'EXT_EU27_2020' if geo=='EU27_2020' else 'WRL_REST'}
        assets=jsvalue(iip,{**base,'stk_flow':'A_LE'})
        liabilities=jsvalue(iip,{**base,'stk_flow':'L_LE'})
        gross_fallback=assets is None or liabilities is None
        if gross_fallback:
            # Eurostat does not publish this aggregate IIP selection. Use a
            # labeled GDP-weighted member proxy for the matched model stock.
            assert p['code']=='EU27'
            weights={row['country']:row['gdpWeight'] for row in p['aggregation']['weights']}
            assets=sum(benchmarks[c]['observedForeignAssetsGDP']*weight for c,weight in weights.items())
            liabilities=sum(benchmarks[c]['observedForeignLiabilitiesGDP']*weight for c,weight in weights.items())
        assert assets>0 and liabilities>0
        matched=.05*min(assets,liabilities)
        p['params'].update(initialIncomeGini=income_gini,initialWealthGini=financial_gini,
                           initialGrossForeignPosition=matched,importTariff=0)
        p['provenance']['initialIncomeGini']={'status':'proxy','dataset':'Eurostat ilc_di12','year':'2024 survey, generally 2023 income',
            'url':'https://ec.europa.eu/eurostat/databrowser/view/ilc_di12/default/table?lang=en',
            'note':'Observed equivalised disposable-income Gini / 100. Mapped to equal-sized model households. Persistent earnings heterogeneity is a modeling assumption.'}
        p['provenance']['initialWealthGini']={'status':'proxy',
            'dataset':'ECB HFCS 2023 C1/C3','year':'2023 wave',
            'url':'https://www.ecb.europa.eu/home/pdf/research/hfcn/HFCS_Statistical_Tables_Wave_2023_October_2026.zip',
            'note':f'Financial-asset Gini reconstructed from {source_country} participation, deciles and mean, with a fitted Pareto upper tail. This is not a published net-wealth Gini. Missing country distributions use the euro-area proxy. Survey financial assets cover more instruments than this model.'}
        p['provenance']['initialGrossForeignPosition']={'status':'proxy','dataset':'Eurostat bop_gdp6_q FA A_LE/L_LE','year':2023,
            'url':'https://ec.europa.eu/eurostat/databrowser/view/bop_gdp6_q/default/table?lang=en',
            'note':('EU27 uses a GDP-weighted member proxy including intra-EU positions because a consolidated selection is missing. ' if gross_fallback else '')+'Five percent of the smaller observed gross foreign stock initializes matched external assets and funding. This preserves the domestic opening balance sheet. It is a coverage proxy, not the complete national IIP. The matched positions roll over, and net subsequent transactions follow the current account.'}
        benchmarks[p['code']]={'incomeGini':income_gini,'financialWealthGini':financial_gini,
            'netWealthGini':float(net.cell(16,ncountries[source_country]).value),
            'wealthSourceCountry':source_country,'wealthFallback':source_country!=country,
            'incomeSurveyYear':2024,'incomeReferenceYear':2023,'wealthWave':2023,
            'financialParticipation':has_assets,'conditionalFinancialMean':mean,'conditionalFinancialDeciles':deciles,
            'paretoAlpha':alpha,'observedForeignAssetsGDP':assets,'observedForeignLiabilitiesGDP':liabilities,
            'matchedForeignStockGDP':matched,'grossIIPFallback':gross_fallback}
    (ROOT/'dist/data/profiles.json').write_text(json.dumps(profiles,indent=2)+'\n')
    (ROOT/'dist/data/household_benchmarks.json').write_text(json.dumps(benchmarks,indent=2)+'\n')
    manifest=json.loads((SOURCE/'HOUSEHOLD_TRADE_MANIFEST.json').read_text())
    raw=(SOURCE/'HFCS_Statistical_Tables_Wave_2023_October_2026.xlsx').read_bytes()
    manifest=[m for m in manifest if not m['path'].endswith(('hfcs_2023_tables.zip','HFCS_Statistical_Tables_Wave_2023_October_2026.xlsx'))]
    manifest.append({'path':'research/source_snapshots/HFCS_Statistical_Tables_Wave_2023_October_2026.xlsx',
        'zipMember':'HFCS_Statistical_Tables_Wave_2023_October_2026.xlsx',
        'url':'https://www.ecb.europa.eu/home/pdf/research/hfcn/HFCS_Statistical_Tables_Wave_2023_October_2026.zip',
        'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    (SOURCE/'HOUSEHOLD_TRADE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'presets':len(profiles),'wealthFallbacks':[key for key,b in benchmarks.items() if b['wealthFallback']],
        'Italy':benchmarks['ITA']},indent=2))

if __name__=='__main__':main()

"""Lossless shared compression for historical fixtures and large retained source responses."""
from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parents[1]
files=sorted(p for folder in(R/'research').glob('frozen*')if folder.is_dir()for p in folder.rglob('*')if p.is_file()and p.suffix not in['.pyc']and'__pycache__'not in p.parts)
p=R/'research/venture_candidates/input_profiles.json'
if p.exists():files.append(p)
files.extend((R/'research/fiscal_reconciliation/eu').glob('*.json'))
files.append(R/'research/sovereign_foreign_1_26/eurostat_ggd_2023.json')
files.extend((R/'research/source_snapshots').glob('*.json'))
files.extend((R/'research/data_quality_candidates').glob('european_input_audit*.json'))
files.extend((R/'research/forecast_source_candidates').glob('*.json'))
files.extend((R/'research/credit_audit_1_28').glob('*.json'))
files.extend((R/'research/participation_1_29').glob('*.json'))
files.extend((R/'research/import_cost_1_29').glob('*.json'))
# Retain all new primary snapshots and evidence without duplicating large HTML/JSON.
files.extend(p for folder in ['tariffs_1_30','fiscal_latest_1_30'] for p in (R/'research'/folder).rglob('*') if p.is_file() and p.suffix in ['.json','.html'])
# Shared lossless compression of older/current studies; runtime files remain unchanged.
files.extend((R/'dist/data').glob('revision*_validation.json'))
# Large repetitive per-country audit text is restored byte-for-byte before local use.
files.append(R/'dist/data/parameter_audit.json')
files=sorted(set(files))
with tarfile.open(R/'research/archived_fixtures.tar.xz','w:xz',preset=9)as out:
 for p in files:out.add(p,arcname=str(p.relative_to(R)),recursive=False)
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in files};(R/'research/archived_fixtures_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Bundled',len(files),'historical fixtures; bytes',(R/'research/archived_fixtures.tar.xz').stat().st_size)

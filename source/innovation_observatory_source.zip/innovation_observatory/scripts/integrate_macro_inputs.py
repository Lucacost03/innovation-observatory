from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];D=R/'dist/data';read=lambda p:json.loads(p.read_text())
profiles=read(D/'profiles.json');bench=read(R/'research/macro_employment_candidates/benchmark.json');bycode={x['code']:x for x in bench}
for p in profiles:
 b=bycode[p['code']];p.setdefault('employmentDefinitionPrior',{'employmentRate':p['params']['employmentRate'],'age':'15–74'})
 p['params']['initialParticipationRate']=b['participationPct']
 p['params']['employmentRate']=100*b['employmentPopulationPct']/b['participationPct']
 for key in ['initialParticipationRate','employmentRate']:
  p['provenance'][key]={'status':'observed' if key=='initialParticipationRate' else 'derived','year':2023,'age':'15–64','dataset':'Eurostat lfsi_emp_a, sex=T, age=Y15-64, unit=PC_POP, indic_em=ACT and EMP_LFS','url':'https://ec.europa.eu/eurostat/databrowser/view/lfsi_emp_a/default/table?lang=en','benchmark':'employment_population_benchmarks.json','flags':b['flags'],'note':('Labour-force participation = employed plus unemployed / population ages 15–64. The model holds this participation share fixed within its changing working-age cohort.' if key=='initialParticipationRate' else 'Employed / labour force = 100 × published employment/population divided by participation, both ages 15–64. This reproduces the published employment/population rate exactly; independently rounded counts can give slightly different ratios. Inactive adults are included in employment/population, not in unemployment/LF.')}
 for key in ['employmentSeparation','jobFindingRate']:
  p['provenance'][key]['note']=p['provenance'][key]['note'].split(' The transition series has no age selector')[0]+' The transition series has no age selector and covers the broader 15–74 population: applying it to the 15–64 cohort is an explicit proxy.'
 p['params']['assetPurchasesEnabled']=1
 p['provenance']['assetPurchasesEnabled']={'status':'assumed','dataset':'Scenario mechanism; primary central-bank accounting','year':2023,'note':'Emergency purchases are available after two annual readings of inflation at most 0.5% and with a policy rate at most 0.25%. Annual 3% of prior nominal GDP and 50% bond-stock cap are scenario assumptions, not estimated rules. Secondary purchases create reserves and, for nonbank sellers, deposits.','url':'https://www.bankofengland.co.uk/speech/2023/april/quantitative-easing-quantitative-tightening-speech-silvana-tenreyro'}
(D/'profiles.json').write_text(json.dumps(profiles,indent=2)+'\n')
(D/'employment_population_benchmarks.json').write_text(json.dumps({'sourceYear':2023,'retrievedAt':'2026-11-12','age':'15–64','source':'Eurostat lfsi_emp_a','countries':bench,'mapping':'Use published PC_POP employment and participation rates; derive E/LF by division. Counts retained for independent rounding check. Participation fixed within changing age cohort. Transition rates remain a broader-age15–74proxy.'},indent=2)+'\n')
e=read(D/'evidence.json')
e['mapping']['employmentRate']=profiles[0]['provenance']['employmentRate']['note'];e['mapping']['initialParticipationRate']=profiles[0]['provenance']['initialParticipationRate']['note'];e['mapping']['assetPurchasesEnabled']=profiles[0]['provenance']['assetPurchasesEnabled']['note']
(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
print('Mapped28age-consistent2023employment/participationpresets; emergencyassetpurchasesavailable.')

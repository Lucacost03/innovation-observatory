import fs from 'node:fs';
import {simulate,quantile} from '../dist/engine.mjs';
import {simulate as before} from '../research/frozen_engine_v1_18_1/engine.mjs';
const profiles=JSON.parse(fs.readFileSync(new URL('../research/frozen_engine_v1_18_1/profiles.json',import.meta.url)));
const observations=JSON.parse(fs.readFileSync(new URL('../dist/data/finance_validation.json',import.meta.url))).recent.legacy.predictions;
const predictions=[];for(const p of profiles){const row={code:p.code,observed:observations.find(x=>x.code===p.code).observed};for(const [name,fn]of [['before',before],['corrected',simulate]]){
 const runs=[2026,9945,17864].map(seed=>fn({...p.params,periods:8},seed).rows);
 row[name]={gdp:quantile(runs.map(r=>100*((r[2].output/100)**.5-1)),.5),inflation:quantile(runs.map(r=>r[2].inflation),.5),unemployment:quantile(runs.map(r=>r[2].unemployment),.5)};
}predictions.push(row);}
const errors=name=>Object.fromEntries(['gdp','inflation','unemployment'].map(key=>{const a=predictions.filter(x=>x.code!=='EU27').map(x=>x[name][key]-x.observed[key]);return[key,{rmse:Math.sqrt(a.reduce((s,v)=>s+v*v,0)/a.length),mae:a.reduce((s,v)=>s+Math.abs(v),0)/a.length}]}));
const long=[];for(const p of profiles)for(const seed of [2026,9945,17864]){const rows=simulate({...p.params,periods:40},seed).rows;long.push({code:p.code,seed,finalGDP:rows.at(-1).output,averageInflation:100*((rows.at(-1).consumerPriceIndex/100)**(1/40)-1),deflationYears:rows.slice(1).filter(x=>x.inflation<0).length,rows:p.code==='ITA'&&seed===2026?rows.filter(r=>[0,1,5,10,20,40].includes(r.t)).map(r=>({t:r.t,output:r.output,inflation:r.inflation,goodsCPI:r.goodsConsumerPriceIndex,cpi:r.consumerPriceIndex,rent:r.rentPriceIndex,policyRate:r.policyRate})):undefined});}
const stats={before:errors('before'),corrected:errors('corrected'),long:{paths:long.length,medianFinalGDP:quantile(long.map(x=>x.finalGDP),.5),medianAnnualInflation:quantile(long.map(x=>x.averageInflation),.5),yearsDeflation:long.reduce((s,r)=>s+r.deflationYears,0)}};
fs.writeFileSync(new URL('../research/macro_policy/cpi_candidate.json',import.meta.url),JSON.stringify({protocol:'Fixed non-rent CPI chaining and zero policy floor, no education coefficient or GDP damping changes. 3 common seeds,28presets,27country equally weighted2025errors; previously used observations, not held-out. Foreign paths incorporate later information.',stats,predictions,long},null,2));console.log(JSON.stringify(stats));console.log(JSON.stringify(long.find(x=>x.code==='ITA'&&x.seed===2026).rows));

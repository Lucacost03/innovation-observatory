"""Frozen 2023 housing service flows and owner-occupancy; no existing-file mutation."""
from pathlib import Path
import datetime,hashlib,json,urllib.request

ROOT=Path(__file__).resolve().parents[1]; RAW=ROOT/'research/source_snapshots'
BASE='https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/'
URL=BASE+'nama_10_cp18?lang=en&freq=A&unit=PC_GDP&coicop18=CP041&coicop18=CP042&time=2023'
OWNER_URL=BASE+'ilc_lvho02?lang=en&freq=A&unit=PC&rskpovth=TOTAL&hhcomp=TOTAL&time=2023'
path=RAW/'population_education_housing_services_2023.json'
manifest_path=ROOT/'research/population_education_housing_services_manifest.json'
prior=json.loads(manifest_path.read_text()) if manifest_path.exists() else []
if not path.exists():
    with urllib.request.urlopen(URL,timeout=90) as response:path.write_bytes(response.read())
d=json.loads(path.read_text())
owner_path=RAW/'housing_pension_ownership_all_2023.json'
if not owner_path.exists():
    owner_path=RAW/'population_education_ownership_2023.json'
    if not owner_path.exists():
        with urllib.request.urlopen(OWNER_URL,timeout=90) as response:owner_path.write_bytes(response.read())
owner=json.loads(owner_path.read_text())

def obs(data,geo,**selections):
    sel={'freq':'A','geo':geo,'time':'2023',**selections};offset=0
    for key,size in zip(data['id'],data['size']):offset=offset*size+data['dimension'][key]['category']['index'][sel[key]]
    return {'selection':sel,'value':data['value'].get(str(offset)),'flag':data.get('status',{}).get(str(offset),'')}

out={}
for p in json.loads((ROOT/'dist/data/profiles.json').read_text()):
    geo=p['geo'];a=obs(d,geo,unit='PC_GDP',coicop18='CP041');i=obs(d,geo,unit='PC_GDP',coicop18='CP042')
    o=obs(owner,geo,unit='PC',rskpovth='TOTAL',hhcomp='TOTAL',tenure='OWN')
    assert a['value'] is not None and i['value'] is not None and o['value'] is not None,(p['code'],a,i,o)
    assert 0<=a['value']+i['value']<100 and 0<o['value']<100
    out[p['code']]={'year':2023,'geo':geo,'params':{'actualRentGDP':a['value'],'imputedRentGDP':i['value'],'ownerOccupancy':o['value']},
        'observations':{'actualRent':{'dataset':'nama_10_cp18','url':URL,**a},'imputedRent':{'dataset':'nama_10_cp18','url':URL,**i},'ownerOccupancy':{'dataset':'ilc_lvho02','url':OWNER_URL,**o}},
        'notes':['Actual/imputed rentals are household final consumption of housing services in current prices, percent of GDP, domestic concept. They exclude the rest of COICOP housing (utilities, repairs, fuels).',
            'Imputed rental services are own-account household production and consumption; they are not cash receipts, a deposit, mortgage credit or a house-price capital gain.',
            'New dwelling construction is fixed investment; purchases of existing houses are asset transfers. The latter must not be added as GDP.',
            'EU-SILC owner occupancy is the percentage of people in owner-occupied households, not the percentage of individual model households owning a building. Mapping between the two is a proxy.']}
manifest=[]
for name,source,file,url in [('population_education_housing_services','nama_10_cp18 CP041/CP042',path,URL),('population_education_owner_occupancy','ilc_lvho02 OWN',owner_path,OWNER_URL)]:
    meta=next((m for m in prior if m['name']==name),{})
    manifest.append({'name':name,'dataset':source,'url':url,'path':str(file.relative_to(ROOT)),
        'retrievedAt':meta.get('retrievedAt',datetime.datetime.fromtimestamp(file.stat().st_mtime,datetime.timezone.utc).isoformat()),
        'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'status':'ok'})
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
(ROOT/'dist/data/population_education_housing_services.json').write_text(json.dumps({'year':2023,'countries':out,'sourceManifest':manifest,
    'definitions':[{'title':'Eurostat COICOP2018 metadata','url':'https://ec.europa.eu/eurostat/cache/metadata/en/nama_10_cp18_esms.htm'},
        {'title':'ECB owner-occupied housing and inflation measurement','url':'https://www.ecb.europa.eu/press/economic-bulletin/articles/2022/html/ecb.ebart202201_01~f643aad55c.ga.html'}]},indent=2)+'\n')
print(json.dumps({'status':'PASS','presets':len(out),'Italy':out['ITA']['params'],'EU27':out['EU27']['params'],'sourceHashes':len(manifest)},indent=2))

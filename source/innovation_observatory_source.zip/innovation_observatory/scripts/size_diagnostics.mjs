// Starting-state moment check, not a forecast or a parameter-selection loop.
import fs from 'node:fs';
import {Economy,quantile} from '../dist/engine.mjs';
import {DEFAULTS,MODEL_VERSION} from '../dist/parameters.mjs';
import {exitHazards} from '../dist/demography.mjs';
const profiles=JSON.parse(fs.readFileSync(new URL('../dist/data/profiles.json',import.meta.url)));
const sum=xs=>xs.reduce((a,b)=>a+b,0),cases=[],countries=[];
for(const profile of profiles){
 const observed=profile.demographyDiagnostics.deathEmploymentShare;
 const stats={earlier:[],mapped:[]};
 for(let k=0;k<10;k++)for(const mode of ['earlier','mapped']){
  const params={...DEFAULTS,...profile.params,...(mode==='earlier'?{firmSizeDispersion:.18,exitSizeSensitivity:0}:{})};
  const economy=new Economy(params,5001+k*7919),hazards=exitHazards(economy.firms,params);
  const expectedEmploymentShare=100*sum(economy.firms.map((f,i)=>f.employment*hazards[i]))/sum(economy.firms.map(f=>f.employment));
  const expectedEnterpriseShare=100*sum(hazards)/hazards.length;
  stats[mode].push(expectedEmploymentShare);
  cases.push({country:profile.code,seed:economy.seed,mode,observedDeathEmploymentShare:observed,expectedEmploymentShare,expectedEnterpriseShare});
 }
 countries.push({country:profile.code,observedDeathEmploymentShare:observed,
  earlierMedian:quantile(stats.earlier,.5),mappedMedian:quantile(stats.mapped,.5),mappedP10:quantile(stats.mapped,.1),mappedP90:quantile(stats.mapped,.9)});
}
const mae=mode=>sum(cases.filter(x=>x.mode===mode).map(x=>Math.abs(x.expectedEmploymentShare-x.observedDeathEmploymentShare)))/(profiles.length*10);
const report={modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),initialStates:cases.length,
 protocol:'28 presets × ten fixed seeds × two size mappings. Expected opening-state employment exit exposure versus 2023 Eurostat employment share of enterprise deaths. No simulated paths or parameter search.',
 meanAbsoluteMomentDiscrepancyPP:{earlier:mae('earlier'),mapped:mae('mapped')},countries,cases,
 note:'The observed employment moment was inspected during development. This measures an in-sample proxy discrepancy, not holdout RMSE, forecast accuracy or causal validation. Size classes omit within-class variation; capital proxies employment size. Financial defaults and later endogenous adjustment can change realized exits.'};
fs.writeFileSync(new URL('../dist/data/size_mapping_diagnostics.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify({initialStates:report.initialStates,meanAbsoluteMomentDiscrepancyPP:report.meanAbsoluteMomentDiscrepancyPP},null,2));

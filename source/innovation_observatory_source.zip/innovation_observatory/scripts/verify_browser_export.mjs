import assert from 'node:assert/strict';
import fs from 'node:fs';
import {runEnsemble} from '../dist/engine.mjs';
import {MODEL_VERSION} from '../dist/parameters.mjs';
const [jsonPath,eventPath]=process.argv.slice(2);
if(!jsonPath||!eventPath)throw Error('Pass the downloaded experiment JSON and event CSV paths.');
const file=JSON.parse(fs.readFileSync(jsonPath,'utf8')),r=file.result;
assert.equal(file.modelVersion,MODEL_VERSION);assert.equal(r.modelVersion,MODEL_VERSION);assert.equal(r.stepYears,1);
assert.deepEqual(Object.keys(r.first.scenario.foreignHistory[0]),['USA','CHN','ROW']);
const replay=runEnsemble({params:r.params,reference:r.reference,paths:r.paths,shocks:r.shocks});
let checked=0,maxRelativeDifference=0;
for(const side of ['baseline','scenario'])for(let i=0;i<r.raw[side].length;i++){
 const expected=r.raw[side][i],actual=replay.raw[side][i];assert.equal(actual.seed,expected.seed);
 assert.equal(actual.rows.length,expected.rows.length);
 for(let t=0;t<expected.rows.length;t++)for(const [key,value]of Object.entries(expected.rows[t])){
  const difference=Math.abs(actual.rows[t][key]-value)/Math.max(1,Math.abs(value));
  maxRelativeDifference=Math.max(maxRelativeDifference,difference);checked++;
  assert(difference<1e-8,`${side} seed ${expected.seed} period ${t} ${key}`);
 }
}
const csv=fs.readFileSync(eventPath,'utf8').trim().split(/\r?\n/);
const eventCount=r.first.baseline.events.length+r.first.scenario.events.length;
assert.equal(csv.length-1,eventCount);
for(const key of ['equityFunding','loanWriteoff','capital','type','id'])assert(csv[0].includes(`"${key}"`));
assert(r.first.scenario.events.some(x=>x.type==='entry'));
assert(r.first.scenario.events.some(x=>x.type==='exit'));
assert(r.raw.scenario.some(run=>run.rows.some(x=>x.foreignAdopters>0)));
for(const side of ['baseline','scenario']){
 assert.equal(r.first[side].agents.length,r.params.periods+1);
 for(let t=0;t<=r.params.periods;t++)assert.equal(r.first[side].agents[t].length,r.first[side].rows[t].firmCount);
}
const report={status:'PASS',modelVersion:MODEL_VERSION,executedAt:new Date().toISOString(),
 exportedBrowserRuns:r.simulations,comparedNumericValues:checked,maxRelativeReplayDifference:maxRelativeDifference,
 replayTolerance:1e-8,displayedSeedEventRows:eventCount,
 checks:['Browser worker completed a paired foreign-adoption experiment using the USA, China and rest-of-world donors.',
  'Employment and unemployment chart levels open at 92.30% and 7.70% for Italy. Index mode is disabled for the two labor shares.',
  'The Guide explains annual steps and model assumptions. Evidence shows the before-and-after labor audit and rest-of-world weights.',
  'Timeline updates active firms, source-adoption counts and the funded turnover event log.',
  'Active-firm chart selector and population-chart shortcut work.',
  'Full JSON contains versioned settings, both economies, raw row paths, firm/network snapshots and displayed-seed events.',
  'Downloaded event CSV retains the union of entry/exit fields and has exactly the exported event count.',
  'Every exported numeric row value reproduces with the current Node engine within the stated tolerance.'],
 note:'Browser checks are software/UI verification, not empirical validation. Browser paths are excluded from the published final numerical-suite run count.'};
fs.writeFileSync(new URL('../research/browser_qa.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));

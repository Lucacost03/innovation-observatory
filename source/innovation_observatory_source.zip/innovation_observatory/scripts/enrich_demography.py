"""Rebuild 2023 demography/foreign-frontier proxy inputs from frozen sources.

Run after enrich_profiles.py. No network is used. Past TFP growth initializes
an explicit future scenario; it is not a real-time or independently validated
forecast. Firm frontiers, hazard selection and adoption coefficients are assumed.
"""
from pathlib import Path
import csv
import datetime
import hashlib
import json
import math
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'dist/data'
SNAP = ROOT / 'research/source_snapshots'


def decode(dataset):
    cats = [[k for k, _ in sorted(dataset['dimension'][d]['category']['index'].items(), key=lambda x: x[1])]
            for d in dataset['id']]
    rows = []
    for key, value in dataset['value'].items():
        n, indices = int(key), []
        for size in reversed(dataset['size']):
            indices.append(n % size)
            n //= size
        indices.reverse()
        rows.append({**{d: cats[i][indices[i]] for i, d in enumerate(dataset['id'])},
                     'value': value, 'flag': dataset.get('status', {}).get(key, '')})
    return rows


def rest_of_world(pwt):
    current = pwt[pwt.year.eq(2023)].set_index('countrycode').drop(index=['USA', 'CHN'])
    past = pwt[pwt.year.eq(2013)].set_index('countrycode')['rtfpna'].rename('rtfpna_2013')
    candidates = current.join(past)[['country', 'ctfp', 'cgdpo', 'rtfpna', 'rtfpna_2013']]
    required = candidates[['ctfp', 'cgdpo', 'rtfpna', 'rtfpna_2013']]
    pool = candidates[required.notna().all(axis=1) & required.gt(0).all(axis=1)].copy().sort_index()
    pool['weight'] = pool.cgdpo / pool.cgdpo.sum()
    pool['growth_pct'] = 100 * ((pool.rtfpna / pool.rtfpna_2013) ** .1 - 1)
    coverage = {
        'coveredEconomies': len(pool),
        'candidateEconomies': len(candidates),
        'coveredOutputShare': float(pool.cgdpo.sum() / candidates.cgdpo.sum()),
        'excludedDonors': ['USA', 'CHN'],
        'unmatchedEconomies': sorted(set(candidates.index) - set(pool.index)),
        'weighting': 'Fixed 2023 output-side PPP GDP (cgdpo) weights for both averages. The home economy is included when covered.',
    }
    pool.to_csv(DATA / 'pwt_rest_of_world_weights.csv')
    return pool, coverage


def add_labor_inputs(profiles):
    rows = decode(json.loads((SNAP / 'labour_market_transitions.json').read_text()))
    lookup = {(r['geo'], r['unit'], r['wstatus']): r for r in rows if r['value'] is not None}
    definitions = [
        ('employmentSeparation', 'PC_EMP', 'EMP_UNE', 'EMP_EMP'),
        ('jobFindingRate', 'PC_UNE', 'UNE_EMP', 'UNE_UNE'),
    ]
    matched = {key: 0 for key, *_ in definitions}
    for profile in profiles:
        for key, unit, transition, stay in definitions:
            geo = profile['geo']
            pair = [lookup.get((geo, unit, status)) for status in [transition, stay]]
            is_matched = all(pair)
            if not is_matched:
                pair = [lookup[('EU27_2020', unit, status)] for status in [transition, stay]]
            value = 100 * pair[0]['value'] / sum(r['value'] for r in pair)
            low, high = (.1, 50) if key == 'employmentSeparation' else (0, 99)
            assert low <= value <= high, (profile['code'], key, value)
            profile['params'][key] = value
            note = 'Annual transition conditioned on an employed or unemployed endpoint. The model holds the labor force fixed and represents movement between these two statuses.'
            if is_matched:
                matched[key] += 1
            else:
                note += ' The national pair is incomplete. This preset uses the observed EU27 aggregate as a fallback assumption.'
            profile['provenance'][key] = {
                'status': 'proxy' if is_matched else 'assumed', 'dataset': 'Eurostat lfsi_long_a',
                'year': 2023, 'components': pair, 'note': note,
                'flags': sorted({r['flag'] for r in pair if r['flag']}),
            }
    with (DATA / 'labour_market_transitions.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return matched


def enrich():
    profiles = json.loads((DATA / 'profiles.json').read_text())
    source = json.loads((SNAP / 'business_demography.json').read_text())
    rows = decode(source)
    pwt = pd.read_excel(SNAP / 'pwt110.xlsx', sheet_name='Data')
    countries = [p['code'] for p in profiles if p['code'] != 'EU27'] + ['USA', 'CHN']
    cols = ['countrycode', 'country', 'year', 'ctfp', 'rtfpna', 'cgdpo']
    subset = pwt[pwt.countrycode.isin(countries) & pwt.year.isin([2013, 2023])][cols].copy()
    assert len(subset) == 58 and subset[cols].notna().all().all()
    obs = subset[subset.year.eq(2023)].set_index('countrycode')
    before = subset[subset.year.eq(2013)].set_index('countrycode')
    providers = [('USA', 'us'), ('CHN', 'china')]
    growth = {code: 100 * ((float(obs.loc[code, 'rtfpna']) / float(before.loc[code, 'rtfpna'])) ** .1 - 1)
              for code, _ in providers}
    national = {code: float(obs.loc[code, 'ctfp']) for code in countries}
    pool, pool_coverage = rest_of_world(pwt)
    national['ROW'] = float((pool.weight * pool.ctfp).sum())
    growth['ROW'] = float((pool.weight * pool.growth_pct).sum())
    # PWT has no observed EU27 TFP aggregate. This is an expressly labeled
    # output-weighted mean, not the TFP of an aggregate production function.
    members = obs.loc[[p['code'] for p in profiles if p['code'] != 'EU27']]
    national['EU27'] = float((members.ctfp * members.cgdpo).sum() / members.cgdpo.sum())
    sizes = decode(json.loads((SNAP / 'business_demography_sizes.json').read_text()))
    coverage = {'birthRate': 0, 'deathRate': 0, 'foreignLevels': 0,
                'firmSizeDispersion': 0, 'exitSizeSensitivity': 0, 'startupSize': 0}
    for profile in profiles:
        profile['modelVersion'] = '1.4.0'
        params, provenance = profile['params'], profile.setdefault('provenance', {})
        for retired in ['koreaTechnology', 'koreaGrowth']:
            params.pop(retired, None)
            provenance.pop(retired, None)
        for key, indicator, count in [('entryRate', 'ENT_BRTHR_PC', 'birthRate'),
                                      ('exitRate', 'ENT_DTHR_PC', 'deathRate')]:
            values = [r for r in rows if r['geo'] == profile['geo'] and r['time'] == '2023'
                      and r['indic_sbs'] == indicator]
            assert len(values) <= 1
            if values:
                row = values[0]
                params[key] = row['value']
                provenance[key] = {'status': 'proxy', 'dataset': 'Eurostat bd_size', 'year': 2023,
                                   'flags': [row['flag']] if row['flag'] else [], 'components': [row],
                                   'note': 'Business economy B–S excluding O and S94, all enterprise sizes and ages. '
                                   + ('Births' if key == 'entryRate' else 'Deaths')
                                   + ' / active enterprises (%). Mapping a broad enterprise rate to synthetic '
                                   'representative firms is a proxy. Selection, finance and numerical bounds '
                                   'can make realized model rates differ. No conditional exit coefficient is identified.'}
                coverage[count] += 1
            else:
                params[key] = 10.5 if key == 'entryRate' else 8.5
                provenance[key] = {'status': 'assumed', 'year': None,
                                   'note': 'No matching 2023 business-economy observation; illustrative default, not a filled national statistic.'}
        home = national[profile['code']]
        for code, prefix in providers:
            relative = national[code] / home
            assert .1 <= relative <= 5 and -2 <= growth[code] <= 4
            params[prefix + 'Technology'] = relative
            params[prefix + 'Growth'] = growth[code]
            provenance[prefix + 'Technology'] = {
                'status': 'proxy', 'dataset': 'PWT 11.0 ctfp', 'year': 2023,
                'components': {'sourceCountry': code, 'foreignCTFP': national[code], 'homeCTFP': home},
                'note': '2023 cross-country PPP TFP level (USA=1), foreign / home. '
                + ('EU home scale is a cgdpo-weighted national mean, not observed aggregate EU TFP. ' if profile['code'] == 'EU27' else '')
                + 'Using macro TFP as latent firm technology is a proxy. The separately assumed leader '
                'premium is not estimated. A source below firm technology never reduces knowledge.'}
            provenance[prefix + 'Growth'] = {
                'status': 'proxy', 'dataset': 'PWT 11.0 rtfpna', 'year': '2013–2023',
                'components': {'sourceCountry': code, 'rtfpna2013': float(before.loc[code, 'rtfpna']),
                               'rtfpna2023': float(obs.loc[code, 'rtfpna'])},
                'note': '100 × [(rtfpna2023 / rtfpna2013)^(1/10) − 1]. Historical national TFP CAGR. '
                'Its use as constant future frontier-firm growth is an unvalidated extrapolation, not a forecast.'}
        params['rowTechnology'] = national['ROW'] / home
        params['rowGrowth'] = growth['ROW']
        assert .1 <= params['rowTechnology'] <= 5 and -2 <= params['rowGrowth'] <= 4
        provenance['rowTechnology'] = {
            'status': 'proxy', 'dataset': 'PWT 11.0 ctfp and cgdpo', 'year': 2023,
            'components': {'weightedCTFP': national['ROW'], 'homeCTFP': home, **pool_coverage},
            'note': '2023 PPP-output-weighted mean of comparable country TFP levels excluding USA and China, divided by the home TFP anchor. The model applies its separate assumed leader premium.',
        }
        provenance['rowGrowth'] = {
            'status': 'proxy', 'dataset': 'PWT 11.0 rtfpna and cgdpo', 'year': '2013–2023',
            'components': {'weightedGrowthPct': growth['ROW'], **pool_coverage},
            'note': 'Weighted arithmetic mean of national 2013–2023 TFP CAGRs, using the same fixed weights and covered economies as the level. Future donor growth extrapolates this average.',
        }
        coverage['foreignLevels'] += 1
        def size_obs(indicator, size='TOTAL'):
            values = [r for r in sizes if r['geo'] == profile['geo']
                      and r['indic_sbs'] == indicator and r['sizeclas'] == size]
            assert len(values) <= 1
            return values[0] if values else None
        groups = []
        for size in ['0', '1-4', '5-9', 'GE10']:
            count, employment, deaths = [size_obs(k, size) for k in ['ENT_NR', 'EMP_NR', 'ENT_DTHR_PC']]
            if count and employment and count['value'] > 0 and employment['value'] > 0:
                groups.append({'size': size, 'count': count['value'], 'employment': employment['value'],
                               'mean': employment['value'] / count['value'],
                               'deathRate': deaths['value'] if deaths else None,
                               'components': [x for x in [count, employment, deaths] if x]})
        if len(groups) == 4:
            total = sum(g['count'] for g in groups)
            mean_log = sum(g['count'] * math.log(g['mean']) for g in groups) / total
            variance = sum(g['count'] * (math.log(g['mean']) - mean_log) ** 2 for g in groups) / total
            dispersion = math.sqrt(variance)
            assert 0 <= dispersion <= 3
            params['firmSizeDispersion'] = dispersion
            provenance['firmSizeDispersion'] = {
                'status': 'proxy', 'dataset': 'Eurostat bd_size ENT_NR, EMP_NR', 'year': 2023,
                'components': groups,
                'note': 'Count-weighted standard deviation of log class mean persons employed, across '
                '0, 1–4, 5–9, 10+ employee classes. This between-class dispersion omits within-class variation. '
                'A lognormal capital distribution with this sigma is a proxy, not observed microdata or an estimated capital distribution.'}
            coverage['firmSizeDispersion'] += 1
            usable = [g for g in groups if g['deathRate'] is not None and 0 < g['deathRate'] < 100]
            if len(usable) >= 2:
                total = sum(g['count'] for g in usable)
                xbar = sum(g['count'] * math.log(g['mean']) for g in usable) / total
                ybar = sum(g['count'] * math.log(-math.log1p(-g['deathRate']/100)) for g in usable) / total
                slope = -sum(g['count'] * (math.log(g['mean'])-xbar) *
                             (math.log(-math.log1p(-g['deathRate']/100))-ybar) for g in usable) / \
                    sum(g['count'] * (math.log(g['mean'])-xbar) ** 2 for g in usable)
                assert -2 <= slope <= 5
                params['exitSizeSensitivity'] = slope
                provenance['exitSizeSensitivity'] = {
                    'status': 'proxy', 'dataset': 'Eurostat bd_size ENT_DTHR_PC by size', 'year': 2023,
                    'components': usable,
                    'note': 'Negative weighted regression slope of log(-log(1-deathRate/100)) on log '
                    'class mean employment, weighted by enterprise counts. Classes with zero/missing death rates '
                    'are omitted from this descriptive log fit. Capital proxies employment size in the simulator. '
                    'This grouped correlation is not causal identification or firm-level hazard estimation.'}
                coverage['exitSizeSensitivity'] += 1
        birth_emp, death_emp = size_obs('EMP_BRTHR_PC'), size_obs('EMP_DTHR_PC')
        if birth_emp and params['entryRate'] > 0:
            ratio = birth_emp['value'] / params['entryRate']
            assert .05 <= ratio <= .6
            params['entrantSize'] = ratio
            provenance['entrantSize'] = {'status': 'proxy', 'dataset': 'Eurostat bd_size EMP_BRTHR_PC / ENT_BRTHR_PC',
                'year': 2023, 'components': [birth_emp],
                'note': 'Employment share of births / enterprise birth rate = mean employment in a '
                'newborn enterprise / mean active-enterprise employment. Mapped to startup capital size '
                'under an assumed common capital/labor scale. It is not an observed startup capital ratio.'}
            coverage['startupSize'] += 1
        profile['demographyDiagnostics'] = {'year': 2023,
            'birthEmploymentShare': birth_emp['value'] if birth_emp else None,
            'deathEmploymentShare': death_emp['value'] if death_emp else None,
            'birthEmploymentFlags': birth_emp['flag'] if birth_emp else None,
            'deathEmploymentFlags': death_emp['flag'] if death_emp else None,
            'sizeClasses': groups,
            'note': 'Employment shares of births/deaths are additional empirical benchmarks, not imposed simulation outcomes.'}
    labor_coverage = add_labor_inputs(profiles)
    (DATA / 'profiles.json').write_text(json.dumps(profiles, indent=2, allow_nan=False))
    with (DATA / 'business_demography_observations.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    subset.to_csv(DATA / 'pwt_foreign_observations.csv', index=False)
    with (DATA / 'enterprise_size_observations.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(sizes[0]))
        writer.writeheader(); writer.writerows(sizes)
    frontiers = {'modelVersion': '1.4.0', 'sourceYear': 2023, 'nationalCTFP': national,
                 'historicalGrowthPct': growth, 'coverage': coverage,
                 'restOfWorld': pool_coverage,
                 'interpretation': 'National TFP means are observed; mapping to firm knowledge, leader premium, '
                 'source-contact probabilities and future extrapolation are assumptions. Sources are not '
                 'uniformly superior to all domestic firms. No trade, FDI or foreign financial sector is modeled.'}
    (DATA / 'foreign_frontiers.json').write_text(json.dumps(frontiers, indent=2))
    demo = json.loads((SNAP / 'DEMOGRAPHY_MANIFEST.json').read_text())
    workbook = SNAP / 'pwt110.xlsx'
    pwtmeta = {'name': 'pwt_foreign_productivity', 'dataset': 'PWT 11.0',
               'url': 'https://dataverse.nl/api/access/datafile/554105',
               'documentation': 'https://www.rug.nl/ggdc/productivity/pwt/',
               'retrievedAt': '2026-11-03', 'sourceYears': [2013, 2023], 'status': 'ok',
               'path': 'research/source_snapshots/pwt110.xlsx', 'bytes': workbook.stat().st_size,
               'sha256': hashlib.sha256(workbook.read_bytes()).hexdigest(),
               'license': 'CC BY 4.0; Feenstra, Inklaar and Timmer (2015)'}
    sizemeta = json.loads((SNAP / 'SIZE_MANIFEST.json').read_text())
    additions = [demo, pwtmeta, sizemeta]
    (SNAP / 'TURNOVER_MANIFEST.json').write_text(json.dumps(additions, indent=2))
    old = json.loads((SNAP / 'MANIFEST.json').read_text())
    official = old + additions + [json.loads((SNAP / 'LABOUR_MANIFEST.json').read_text())]
    (DATA / 'official_data_manifest.json').write_text(json.dumps(official, indent=2))
    evidence = json.loads((DATA / 'evidence.json').read_text())
    evidence['modelVersion'] = '1.4.0'
    evidence['turnoverInputCoverage'] = coverage
    evidence['laborTransitionCoverage'] = labor_coverage
    evidence['officialSourcesAdded'] = official
    labor_source = {'title': 'Eurostat annual labor market transitions', 'url': official[-1]['documentation']}
    if labor_source not in evidence['officialSources']:
        evidence['officialSources'].append(labor_source)
    evidence['limitations'] = [s for s in evidence['limitations'] if 'no explicit firm entry' not in s]
    evidence['limitations'] += [s for s in [
        'Enterprise rates are aggregate proxy targets, not estimates of firm-level productivity selection.',
        'Foreign technology leaders are synthetic. National PPP TFP levels do not identify within-country firm frontiers.',
        'Foreign knowledge can diffuse, but goods trade, FX, FDI and international financial accounts are absent.',
        'Liquidation prices, startup size and financing rules are unestimated. Unsold assets stay dormant; population bounds are explicit.'
    ] if s not in evidence['limitations']]
    evidence['officialSources'] = [s for s in evidence['officialSources'] if s.get('title') != 'Eurostat: enterprise births and deaths']
    evidence['officialSources'].append({'title': 'Eurostat: enterprise births and deaths',
                                       'url': 'https://ec.europa.eu/eurostat/databrowser/view/bd_size/default/table'})
    (DATA / 'evidence.json').write_text(json.dumps(evidence, indent=2))
    print(json.dumps({'coverage': coverage, 'laborCoverage': labor_coverage,
                      'restOfWorld': pool_coverage,
                      'nationalTFP': {c: national[c] for c in ['ITA','USA','CHN','ROW','EU27']},
                      'historicalGrowth': growth, 'demographyObservations': len(rows)}, indent=2))


if __name__ == '__main__':
    enrich()

// A separate monetary-authority ledger, consolidated into the financial sector
// for national saving. All purchase limits and trigger values are assumptions.
const sum=a=>a.reduce((s,x)=>s+x,0);
export const CENTRAL_BANK_FLOWS={assetPurchases:0,assetPurchasesFromHouseholds:0,assetPurchasesFromBanks:0,assetPurchaseRequest:0,unfilledAssetPurchases:0,assetPurchaseTrigger:0,governmentInterestToCentralBank:0,centralBankReserveInterest:0,centralBankRemittance:0,centralBankSaving:0,publicBondRedemptionsToCentralBank:0};
export function initializeCentralBank(){return {bonds:0,equity:0,lowInflationYears:0};}
export function purchaseAssets(e,p,inflationSignal,nominalGDP,flows){
 const cb=e.centralBank;
 cb.lowInflationYears=inflationSignal<=p.assetPurchaseInflationThreshold?cb.lowInflationYears+1:0;
 const active=Boolean(p.assetPurchasesEnabled&&p.priceDynamics&&p.policyDynamics&&e.monetary.policyRate<=.25&&cb.lowInflationYears>=p.assetPurchaseDelay);
 flows.assetPurchaseTrigger=Number(active);
 if(!active)return;
 const householdBonds=sum(e.households.map(h=>h.bonds)),bankBonds=Math.max(0,e.bank.bonds),eligible=householdBonds+bankBonds;
 const cap=Math.max(0,p.assetPurchaseMaxShare/100*(eligible+cb.bonds)-cb.bonds);
 const requested=Math.max(0,nominalGDP)*p.assetPurchaseRate/100,available=Math.min(requested,eligible,cap),amount=available>1e-10?available:0;
 const fromBanks=eligible>0?amount*bankBonds/eligible:0,fromHouseholds=amount-fromBanks;
 e.bank.bonds-=fromBanks;
 if(householdBonds>0)for(const h of e.households){const paid=fromHouseholds*h.bonds/householdBonds;h.bonds-=paid;h.cash+=paid;}
 cb.bonds+=amount;e.bank.reserves+=amount;
 Object.assign(flows,{assetPurchaseRequest:requested,assetPurchases:amount,assetPurchasesFromBanks:fromBanks,assetPurchasesFromHouseholds:fromHouseholds,unfilledAssetPurchases:requested-amount});
}
export function settleCentralBankIncome(e,p,flows,openingBonds,openingReserveLiability){
 const cb=e.centralBank;
 // Only incremental reserves associated with this extension are remunerated.
 // The legacy opening reserve endowment has no new interest-flow assumption.
 const reserveInterest=Math.max(0,openingReserveLiability)*e.monetary.policyRate/100;
 const coupon=openingBonds*e.monetary.publicDebtRate/100;
 e.ensureGov(coupon,p);e.gov.cash-=coupon;e.bank.reserves-=coupon;cb.equity+=coupon;
 e.bank.reserves+=reserveInterest;e.bank.equity+=reserveInterest;cb.equity-=reserveInterest;
 // Retained losses absorb later profits before any new Treasury remittance.
 const remittance=Math.max(0,cb.equity);cb.equity-=remittance;e.gov.cash+=remittance;e.bank.reserves+=remittance;
 Object.assign(flows,{governmentInterestToCentralBank:coupon,centralBankReserveInterest:reserveInterest,centralBankRemittance:remittance,centralBankSaving:coupon-reserveInterest-remittance});
 return reserveInterest;
}
export function centralBankMetrics(e){return {centralBankBonds:e.centralBank.bonds,centralBankOpeningBacking:e.endowment,centralBankEquity:e.centralBank.equity,centralBankLossCarryforward:Math.max(0,-e.centralBank.equity),centralBankReserveLiability:e.bank.reserves,assetPurchaseReserveLiability:Math.max(0,e.bank.reserves-e.endowment),lowInflationYears:e.centralBank.lowInflationYears};}

export function publicPurchases(params, lastOutput, trendOutput, debt, shock) {
  const weight = params.publicBudgetStability;
  const base = lastOutput + weight * (trendOutput - lastOutput);
  const unadjusted = params.governmentShare / 100 * base * shock;
  const debtExcess = Math.max(0, debt - params.debtTarget / 100 * base);
  const planned = Math.max(params.fiscalFloor / 100 * unadjusted, unadjusted - params.fiscalAdjustment * debtExcess);
  return {publicBudgetBase:base, plannedPublicDemand:planned};
}

export function bankPublicExposure(monetary, expectedLossRate) {
  const expectedBusinessReturn = monetary.effectiveLoanRate-expectedLossRate;
  const returnGap = monetary.newPublicRate-expectedBusinessReturn;
  const publicCreditWeight = Math.max(.2,Math.min(.4,.3+.05*returnGap));
  return {expectedBusinessReturn,publicCreditWeight};
}

export function lendingRoom(equity, loans, publicBonds, capitalRequirement, publicCreditWeight) {
  if (!capitalRequirement) return Infinity;
  return Math.max(0, equity / (capitalRequirement / 100) - loans - publicCreditWeight * publicBonds);
}

// Redemption exchanges claims for cash; principal is neither GDP nor income.
// Keep the observed liquidity ratio as a target and retire excess cash against
// outstanding bonds pro rata. No borrowing is created to refill this target.
export function redeemPublicBonds(government,bank,households,cashTarget,centralBank=null) {
  const bankDebt=Math.max(0,bank.bonds),householdDebt=households.reduce((s,h)=>s+Math.max(0,h.bonds),0),centralBankDebt=Math.max(0,centralBank?.bonds??0),debt=bankDebt+householdDebt+centralBankDebt;
  const target=Math.min(debt,Math.max(0,government.cash-cashTarget));
  const bankRedemption=debt>0?Math.min(bankDebt,target*bankDebt/debt):0,centralBankRedemption=debt>0?Math.min(centralBankDebt,target*centralBankDebt/debt):0,householdTarget=target-bankRedemption-centralBankRedemption;
  bank.bonds=Math.max(0,bank.bonds-bankRedemption);
  let householdRedemption=0;
  if(householdDebt>0)for(const h of households){const balance=Math.max(0,h.bonds),paid=Math.min(balance,householdTarget*balance/householdDebt);h.bonds=Math.max(0,balance-paid);h.cash+=paid;householdRedemption+=paid;}
  if(centralBank){centralBank.bonds-=centralBankRedemption;bank.reserves-=centralBankRedemption;}
  const amount=bankRedemption+householdRedemption+centralBankRedemption;
  government.cash=Math.max(0,government.cash-amount);
  return {publicBondRedemptions:amount,publicBondRedemptionsToBank:bankRedemption,publicBondRedemptionsToHouseholds:householdRedemption,publicBondRedemptionsToCentralBank:centralBankRedemption,treasuryCashTarget:cashTarget};
}

export function savingBalances({flows, householdIncome, nominalConsumption, nominalGovernment,
  productionValue, vat, wages, businessInterest, publicGrants, publicNonBusiness, grossInvestment, publicSavingCheck, currentAccount}) {
  const transfers = flows.cashSupport + flows.unemploymentBenefits + publicNonBusiness;
  const bondInterest = flows.governmentInterestToBank + flows.governmentInterestToHouseholds + (flows.governmentInterestToCentralBank??0);
  const householdSaving = householdIncome + (flows.pensionAccruedIncome??0) - nominalConsumption;
  const firmSaving = productionValue + publicGrants + flows.firmDepositInterest - wages - businessInterest - flows.corporateBondInterest - flows.profitTaxPaid - flows.firmDividends - (flows.governmentFirmDividends??0) - (flows.pensionDividends??0);
  const bankSaving = businessInterest + flows.governmentInterestToBank - flows.bankDividends
    - flows.householdDepositInterest - flows.firmDepositInterest - (flows.bankFundingInterest??0) + (flows.mortgageInterest??0) + (flows.bankRentalIncome??0) - (flows.pensionDepositInterest??0) + (flows.centralBankReserveInterest??0);
  const publicSaving = vat + flows.wageWithholding + flows.profitTaxPaid + flows.financialIncomeTaxPaid + flows.wealthTaxPaid + (flows.importTariffRevenue??0)
    + (flows.governmentFirmDividends??0) + (flows.centralBankRemittance??0) - nominalGovernment - transfers - publicGrants - bondInterest;
  const privateSaving = householdSaving + firmSaving + bankSaving + (flows.centralBankSaving??0);
  const nationalSaving = privateSaving + publicSaving;
  const savingIdentityResidual = nationalSaving - grossInvestment - currentAccount;
  const publicSavingResidual = publicSaving - publicSavingCheck;
  const scale = Math.max(1,productionValue,Math.abs(nominalGovernment),Math.abs(publicSavingCheck),Math.abs(grossInvestment));
  if (Math.max(Math.abs(savingIdentityResidual),Math.abs(publicSavingResidual)) > 1e-8 * scale)
    throw Error('Saving and investment accounts did not reconcile.');
  return {householdSaving, firmSaving, bankSaving, publicSaving, privateSaving, nationalSaving,
    grossInvestment, privateNetLending:privateSaving-grossInvestment, currentAccount,
    savingIdentityResidual, publicSavingResidual};
}

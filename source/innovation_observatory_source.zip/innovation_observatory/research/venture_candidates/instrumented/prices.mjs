const MIN_PRICE_CHANGE = 100 * Math.log(.9);
const MAX_PRICE_CHANGE = 100 * Math.log(1.2);

export function spendingTurnover(params, opening, householdShare, policyRate, demandShock) {
  const rateMove = policyRate - opening.initialPolicyRate;
  const spendingMultiplier = (1 + params.velocityShift / 100)
    * Math.exp(-params.velocityRateSensitivity * rateMove) * demandShock;
  const openingPlan = opening.consumptionIncome * opening.initialIncome
    + opening.consumptionWealth * opening.householdWealth;
  const planned = params.consumptionIncome * opening.initialIncome
    + params.consumptionWealth * opening.householdWealth;
  const householdTurnover = spendingMultiplier * (openingPlan > 0 ? planned / openingPlan : 1);
  const velocity = opening.initialMoneyVelocity * Math.max(.05, 1 - householdShare + householdShare * householdTurnover);
  return {velocity, spendingMultiplier};
}

export function advancePrices(previous, openingConsumerPrice, params, {money, velocity, goods, currencyPressure = 0}) {
  // Use a behavioral velocity and the latest completed output. Defining
  // velocity as this year's nominal sales divided by money would be circular.
  const quantityPriceGap = 100 * Math.log(
    Math.max(1e-9, money) * velocity / (Math.max(1e-9, goods) * previous.producerPrice),
  );
  const monetaryPriceContribution = params.priceDynamics ? params.quantityPriceAdjustment * quantityPriceGap : 0;
  const plannedChange = monetaryPriceContribution + currencyPressure;
  const change = Math.max(MIN_PRICE_CHANGE, Math.min(MAX_PRICE_CHANGE, plannedChange));
  const producerPrice = previous.producerPrice * Math.exp(change / 100);
  const consumerPrice = producerPrice * (1 + params.consumptionTax / 100);
  return {
    producerPrice,
    consumerPrice,
    consumerPriceIndex: 100 * (consumerPrice / openingConsumerPrice),
    inflation: 100 * (consumerPrice / previous.consumerPrice - 1),
    producerInflation: 100 * Math.expm1(change / 100),
    priceDynamicsActive: params.priceDynamics,
    quantityPriceGap,
    monetaryPriceContribution,
    priceMoney: money,
    moneyVelocity: velocity,
    priceGoods: goods,
    priceBoundHit: Number(change !== plannedChange),
  };
}

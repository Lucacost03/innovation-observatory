export const LABOR_FORCE = 100;

// The annual transition proxies describe changes in labor-force status.
// Incumbents who remain employed may move to another firm's vacancy.
export function matchEmployment(openingJobs, desiredJobs, separationRate, jobFindingRate,laborForce=LABOR_FORCE) {
  const openingEmployment = openingJobs.reduce((total, jobs) => total + jobs, 0);
  const continuingEmployment = openingEmployment * (1 - separationRate / 100);
  const retained = openingJobs.map((jobs, i) => Math.min(jobs * (1 - separationRate / 100), desiredJobs[i]));
  const vacancies = desiredJobs.map((jobs, i) => jobs - retained[i]);
  const vacanciesTotal = vacancies.reduce((total, jobs) => total + jobs, 0);
  const retainedTotal = retained.reduce((total, jobs) => total + jobs, 0);
  const transfers = Math.min(vacanciesTotal, Math.max(0, continuingEmployment - retainedTotal));
  const searchCapacity = Math.max(0, laborForce - openingEmployment) * jobFindingRate / 100;
  const hires = Math.min(vacanciesTotal - transfers, searchCapacity);

  const allocations = vacancies.map((vacancy, i) => {
    const share = vacanciesTotal > 0 ? vacancy / vacanciesTotal : 0;
    return {retained: retained[i], transferred: transfers * share, hired: hires * share};
  });
  return {openingEmployment, searchCapacity, allocations};
}

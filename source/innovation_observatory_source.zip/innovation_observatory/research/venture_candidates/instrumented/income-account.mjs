// Income-side GDP at current prices. Gross operating surplus includes
// depreciation and production subsidies, before interest and profit taxes.
export function incomeAccount(productionValue,wages,productTaxes,productionSubsidies,nominalGDP) {
  const labourIncome=wages,grossCapitalIncome=productionValue-wages+productionSubsidies;
  const netProductionTaxes=productTaxes-productionSubsidies;
  const incomeGDPResidual=nominalGDP-labourIncome-grossCapitalIncome-netProductionTaxes;
  if(Math.abs(incomeGDPResidual)>1e-8*Math.max(1,Math.abs(nominalGDP)))throw Error('Income GDP did not reconcile.');
  return {labourIncome,grossCapitalIncome,netProductionTaxes,incomeGDPResidual,
    labourIncomeShare:nominalGDP>0?100*labourIncome/nominalGDP:0,
    capitalIncomeShare:nominalGDP>0?100*grossCapitalIncome/nominalGDP:0,
    netProductionTaxShare:nominalGDP>0?100*netProductionTaxes/nominalGDP:0};
}

export const SHOCK_TYPES = {
  demand:{label:'Household demand',unit:'%',min:-95,max:100},
  supply:{label:'Productive capacity',unit:'%',min:-95,max:100},
  credit:{label:'Bank credit supply',unit:'%',min:-95,max:100},
  government:{label:'Public purchases',unit:'%',min:-95,max:100},
  foreignDemand:{label:'Foreign demand',unit:'%',min:-95,max:100},
  policyRate:{label:'Central bank rate',unit:'percentage points',min:-15,max:15,additive:true},
  exchangeRate:{label:'Currency strength',unit:'log % of target',min:-40,max:40,additive:true},
  foreignTFPUSA:{label:'US TFP growth',unit:'percentage points per year',min:-5,max:5,additive:true},
  foreignTFPCHN:{label:'China TFP growth',unit:'percentage points per year',min:-5,max:5,additive:true},
  foreignTFPROW:{label:'Rest-of-world TFP growth',unit:'percentage points per year',min:-5,max:5,additive:true},
};

// Explicit zero is valid. Empty strings, null and booleans are missing or
// malformed inputs, not numerical zero (which Number(...) would otherwise use).
export const isNumericInput=value=>typeof value==='number'||typeof value==='string'&&value.trim()!=='';

export function validateShocks(shocks = []) {
  if (!Array.isArray(shocks) || shocks.length>20) throw Error('Use up to 20 shocks.');
  const groups=new Map();
  return shocks.map(({type,start,duration,magnitude,recovery=0,eventId,eventName})=>{
    const definition=Object.hasOwn(SHOCK_TYPES,type)?SHOCK_TYPES[type]:null;
    if(![start,duration,magnitude,recovery].every(isNumericInput))throw Error('Complete every shock value; use an explicit zero for no effect.');
    start=Number(start);duration=Number(duration);magnitude=Number(magnitude);recovery=Number(recovery);
    if (!definition || !Number.isInteger(start) || start<1 || start>120 || !Number.isInteger(duration) ||
        duration<1 || duration>120 || !Number.isFinite(magnitude) || magnitude<definition.min ||
        magnitude>definition.max || !Number.isFinite(recovery) || recovery<0 || recovery>1)
      throw Error('Invalid shock schedule.');
    const result={type,start,duration,magnitude,recovery};
    if(eventId!=null) {
      if(typeof eventId!=='string'||!/^[A-Za-z0-9_-]{1,80}$/.test(eventId))throw Error('Invalid event ID.');
      result.eventId=eventId;
    }
    if(eventName!=null) {
      if(typeof eventName!=='string'||!eventName.trim()||eventName.trim().length>80)throw Error('Invalid event name.');
      result.eventName=eventName.trim();
    }
    if(eventId!=null) {
      const schedule=JSON.stringify([start,duration,recovery,result.eventName??null]);
      if(groups.has(eventId)&&groups.get(eventId)!==schedule)throw Error('Effects in one event must share its name and timing.');
      groups.set(eventId,schedule);
    }
    return result;
  });
}

export function shockValues(year,shocks) {
  const values=Object.fromEntries(Object.entries(SHOCK_TYPES).map(([key,definition])=>[key,definition.additive?0:1]));
  for (const {type,start,duration,magnitude,recovery} of shocks) {
    if (year<start) continue;
    const elapsed=Math.max(0,year-(start+duration-1));
    const change=magnitude*recovery**elapsed;
    if (SHOCK_TYPES[type].additive) values[type]+=change;
    else values[type]*=1+change/100;
  }
  return values;
}

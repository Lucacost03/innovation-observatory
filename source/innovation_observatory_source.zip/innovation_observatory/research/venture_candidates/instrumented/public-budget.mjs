// Reporting allocations only: no payments, behaviour or agent stocks change.
const nonnegative=x=>Math.max(0,x??0);
const split=(total,a,b)=>{
 const scale=Math.max(100,nonnegative(a)+nonnegative(b));
 const first=total*nonnegative(a)/scale,second=total*nonnegative(b)/scale;
 return [first,second,Math.max(0,total-first-second)];
};
export const PUBLIC_EXPENSE_ITEMS=[
 ['Healthcare services','publicHealthcarePurchases'],
 ['Public education services','publicEducationServicePurchases'],
 ['Other public goods and services','otherPublicPurchases'],
 ['Public old-age cash benefits','publicOldAgeCashAllocated'],
 ['Survivor cash benefits','publicSurvivorCashAllocated'],
 ['Sickness and disability cash benefits','publicSicknessCashAllocated'],
 ['Other cash social support','otherSocialCashAllocated'],
 ['Unemployment cash benefits','unemploymentBenefits'],
 ['Public research grants and transfers','publicResearch'],
 ['Interest on public debt','governmentInterest'],
];
export function publicBudgetMetrics(row,p){
 const fields={publicHealthcarePurchases:0,publicEducationServicePurchases:0,otherPublicPurchases:0,publicOldAgeCashAllocated:0,publicSurvivorCashAllocated:0,publicSicknessCashAllocated:0,otherSocialCashAllocated:0,publicCurrentRevenue:0,publicCurrentExpenditure:0,publicSocialSpending:0,publicHealthcareGDP:0,publicEducationServicesGDP:0,publicOldAgeCashGDP:0,publicSocialSpendingGDP:0,publicCurrentRevenueGDP:0,publicCurrentExpenditureGDP:0,publicSocialShareOfSpending:0,publicBudgetAllocationResidual:0,publicBudgetSavingResidual:0,publicBudgetRatioDefined:0};
 if(row.initialObservation)return fields;
 const [health,education,otherPurchases]=split(nonnegative(row.nominalGovernment),p.publicHealthPurchaseShare,p.publicEducationPurchaseShare);
 const oldAge=p.pensionEnabled?nonnegative(row.publicPensionBenefits):nonnegative(row.cashSupport)*Math.min(100,nonnegative(p.oldAgeFlatSupportShare))/100;
 const pool=Math.max(0,row.cashSupport-oldAge);
 const [survivors,sickness,otherCash]=split(pool,p.survivorOtherSupportShare,p.sicknessOtherSupportShare);
 const revenue=row.nominalConsumptionTax+row.importTariffRevenue+row.wageWithholding+row.profitTaxPaid+row.financialIncomeTaxPaid+row.wealthTaxPaid+row.governmentFirmDividends+row.centralBankRemittance;
 const expenditure=row.nominalGovernment+row.cashSupport+row.unemploymentBenefits+row.publicResearch+row.governmentInterest;
 const social=health+education+row.cashSupport+row.unemploymentBenefits;
 const ratio=value=>row.nominalOutput>1e-9?100*value/row.nominalOutput:0;
 Object.assign(fields,{publicHealthcarePurchases:health,publicEducationServicePurchases:education,otherPublicPurchases:otherPurchases,publicOldAgeCashAllocated:oldAge,publicSurvivorCashAllocated:survivors,publicSicknessCashAllocated:sickness,otherSocialCashAllocated:otherCash,publicCurrentRevenue:revenue,publicCurrentExpenditure:expenditure,publicSocialSpending:social,publicHealthcareGDP:ratio(health),publicEducationServicesGDP:ratio(education),publicOldAgeCashGDP:ratio(oldAge),publicSocialSpendingGDP:ratio(social),publicCurrentRevenueGDP:ratio(revenue),publicCurrentExpenditureGDP:ratio(expenditure),publicSocialShareOfSpending:expenditure>1e-9?100*social/expenditure:0,publicBudgetSavingResidual:revenue-expenditure-row.publicSaving,publicBudgetRatioDefined:Number(row.nominalOutput>1e-9)});
 fields.publicBudgetAllocationResidual=expenditure-PUBLIC_EXPENSE_ITEMS.reduce((s,[,key])=>s+(fields[key]??row[key]),0);
 return fields;
}

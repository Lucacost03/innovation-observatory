const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const businessRate = (p, policyRate) =>
  clamp(p.initialPolicyRate + p.loanSpread + p.loanRatePassThrough*(policyRate-p.initialPolicyRate),0,30);

function depositRates(policyRate,p) {
  const positiveRate=Math.max(0,policyRate);
  return {householdDepositRate:p.householdDepositPassThrough*positiveRate,
    firmDepositRate:p.firmDepositPassThrough*positiveRate};
}

export function initializeMonetary(p) {
  const openingBusinessRate = businessRate(p,p.initialPolicyRate);
  return {
    policyRate: Math.max(0,p.initialPolicyRate),
    ruleRate: Math.max(0,p.initialPolicyRate),
    currencyRuleStrength: 100,
    ...depositRates(p.initialPolicyRate,p),
    realPolicyRate: p.initialPolicyRate - p.initialPolicyInflation,
    foreignRealRate: p.foreignRateShift,
    policyInflationSignal: p.initialPolicyInflation,
    policyInflationTargetUsed: p.policyInflationTarget,
    policyDynamicsActive: 0,
    effectiveLoanRate: openingBusinessRate,
    openingBusinessRate,
    newPublicRate: p.bondRate,
    publicDebtRate: p.bondRate,
    bondPolicyPremium: 0,
    investmentRateMultiplier: 1,
    currencyStrength: 100,
    currencyAppreciation: 0,
    currencyDynamicsActive: 0,
    currencyPriceContribution: 0,
    baseForeignContact: p.foreignContact,
    effectiveForeignContact: p.foreignContact,
  };
}

export function advanceMonetary(previous, p, inflationSignal, shocks = {}) {
  // A rate chosen before this year's prices uses only the last known inflation.
  const targetRate = p.neutralPolicyRate + p.inflationResponse * (inflationSignal - p.policyInflationTarget);
  const ruleRate = p.policyDynamics
    ? clamp(previous.ruleRate + p.policyAdjustment * (targetRate - previous.ruleRate), 0, 20)
    : previous.ruleRate;
  const policyRate = clamp(ruleRate+(shocks.policyRate??0),0,20);
  const policyMove = policyRate - p.initialPolicyRate;
  const realPolicyRate = policyRate - inflationSignal;
  const effectiveLoanRate = businessRate(p,policyRate);
  const newPublicRate = clamp(p.bondRate + p.bondRatePassThrough * policyMove, 0, 30);
  const bondPolicyPremium = previous.bondPolicyPremium
    + p.bondRepricing * (newPublicRate - p.bondRate - previous.bondPolicyPremium);
  const publicDebtRate = clamp(p.bondRate + bondPolicyPremium, 0, 30);
  const investmentRateMultiplier = Math.exp(-p.investmentRateSensitivity * (effectiveLoanRate - previous.openingBusinessRate));

  // Compare the policy rate after this year's decision with the latest known
  // inflation. Lower purchasing-power returns put pressure on the currency.
  const previousLog = Math.log(previous.currencyRuleStrength / 100);
  const targetLog = (p.currencyPressure + p.currencyRateResponse * (realPolicyRate - p.foreignRateShift)) / 100;
  const trendLog = p.currencyDynamics ? previousLog+p.currencyAdjustment*(targetLog-previousLog) : previousLog;
  const ruleLog = clamp(trendLog,-Math.log(2),Math.log(2));
  const currencyRuleStrength = 100*Math.exp(ruleLog);
  const currencyStrength = 100*Math.exp(clamp(ruleLog+(shocks.exchangeRate??0)/100,-Math.log(2),Math.log(2)));
  const currencyAppreciation = 100 * (currencyStrength / previous.currencyStrength - 1);
  const effectiveForeignContact = clamp(p.foreignContact * (currencyStrength / 100) ** p.currencyAdoptionSensitivity, 0, 1);

  return {
    policyRate, ruleRate, currencyRuleStrength, ...depositRates(policyRate,p), realPolicyRate, foreignRealRate: p.foreignRateShift,
    policyInflationSignal: inflationSignal, policyInflationTargetUsed: p.policyInflationTarget,
    policyDynamicsActive: p.policyDynamics,
    effectiveLoanRate, openingBusinessRate:previous.openingBusinessRate, newPublicRate, publicDebtRate, bondPolicyPremium,
    investmentRateMultiplier, currencyStrength, currencyAppreciation,
    currencyDynamicsActive: p.currencyDynamics,
    currencyPriceContribution: -p.currencyPricePassThrough * currencyAppreciation,
    baseForeignContact: p.foreignContact, effectiveForeignContact,
  };
}

// Equal-weight synthetic households. Negative disposable income is retained.
// With a positive mean, the usual Gini can exceed one when some incomes
// are negative. A nonpositive mean with unequal values has no useful Gini.
const sum = values => values.reduce((total,value)=>total+value,0);

// Match a Gini moment by changing the concentration of persistent household
// ranks. Only initial endowments and earnings weights are fitted, not outcomes.
export function giniWeights(scores,target) {
  const maximum=1-1/scores.length;
  const desired=Math.max(0,Math.min(maximum-1e-9,target));
  const peak=Math.max(...scores);
  const weights=power=>{
    const values=scores.map(score=>Math.exp(Math.max(-700,(score-peak)*power)));
    const total=sum(values);return values.map(value=>value/total);
  };
  let low=0,high=1;
  while(distributionStats(weights(high)).gini<desired&&high<1024)high*=2;
  for(let i=0;i<60;i++) {
    const mid=(low+high)/2;
    if(distributionStats(weights(mid)).gini<desired)low=mid;else high=mid;
  }
  return weights((low+high)/2);
}

export function distributionStats(values) {
  if (!values.length || !values.every(Number.isFinite)) throw Error('Invalid household distribution.');
  const sorted=values.slice().sort((a,b)=>a-b),count=sorted.length,total=sum(sorted);
  const percentile=q=>{
    const rank=(count-1)*q,low=Math.floor(rank);
    return sorted[low]+(sorted[Math.ceil(rank)]-sorted[low])*(rank-low);
  };
  const allEqual=sorted[0]===sorted.at(-1);
  const giniDefined=total>0 || (allEqual&&sorted[0]>=0);
  const gini=!giniDefined ? null : allEqual ? 0 : Math.max(0,
    2*sum(sorted.map((value,i)=>(i+1)*value))/(count*total)-(count+1)/count);
  const quintiles=Array.from({length:5},(_,group)=>{
    const start=count*group/5,end=count*(group+1)/5;
    let value=0;
    for(let i=Math.floor(start);i<Math.ceil(end);i++)
      value+=sorted[i]*Math.max(0,Math.min(i+1,end)-Math.max(i,start));
    return {mean:value/(end-start),share:total>0?100*value/total:null};
  });
  return {count,total,mean:total/count,median:percentile(.5),min:sorted[0],max:sorted.at(-1),
    p10:percentile(.1),p90:percentile(.9),gini,giniDefined,quintiles,
    zeroCount:values.filter(v=>v===0).length,negativeCount:values.filter(v=>v<0).length};
}

export function histogram(values,binCount=12) {
  const stats=distributionStats(values);
  // Include zero to make charts comparable to their units. Do not trim tails.
  let low=Math.min(0,stats.min),high=Math.max(0,stats.max);
  if(low===high)high=low+1;
  const width=(high-low)/binCount;
  const bins=Array.from({length:binCount},(_,i)=>({low:low+i*width,high:low+(i+1)*width,count:0,share:0}));
  for(const value of values)bins[Math.max(0,Math.min(binCount-1,Math.floor((value-low)/width)))].count++;
  for(const bin of bins)bin.share=100*bin.count/values.length;
  return {bins,low,high,count:values.length};
}

export function householdMetrics(income,wealth) {
  const i=distributionStats(income),w=distributionStats(wealth);
  return {incomeGini:i.gini??0,incomeGiniDefined:Number(i.giniDefined),wealthGini:w.gini??0,
    wealthGiniDefined:Number(w.giniDefined),householdIncomeTotal:i.total,householdWealthTotal:w.total};
}

export function debtMetrics(publicDebt,bankLoans,corporateBonds,nominalGDP,mortgages=0) {
  const debtRatioDefined=Number(nominalGDP>0),privateDebt=bankLoans+corporateBonds+mortgages;
  return {privateDebt,debtRatioDefined,
    publicDebtGDP:debtRatioDefined?100*publicDebt/nominalGDP:0,
    privateDebtGDP:debtRatioDefined?100*privateDebt/nominalGDP:0};
}

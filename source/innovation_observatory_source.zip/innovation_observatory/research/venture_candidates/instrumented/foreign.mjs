import {FOREIGN_PROJECTIONS} from './foreign-projection-data.mjs';
export {FOREIGN_PROJECTIONS};
// National PWT levels anchor the mean of synthetic technology opportunities.
// Their dispersion and the premium over national averages are assumptions.
export const FOREIGN_PROVIDERS = [
  {code: 'USA', name: 'United States', relative: 'usTechnology', growth: 'usGrowth'},
  {code: 'CHN', name: 'China', relative: 'chinaTechnology', growth: 'chinaGrowth'},
  {code: 'ROW', name: 'Rest of world (excl. USA and China)', relative: 'rowTechnology', growth: 'rowGrowth'}
];
export function initializeForeign(p) {
  return Object.fromEntries(FOREIGN_PROVIDERS.map(s => [s.code,
    p.initialTechnology * p[s.relative] * p.foreignLeaderPremium]));
}

// Annual rates come from within-country OECD efficiency ratios, transformed
// with OECD's labour share. They are a projection proxy, not future observations.
export function foreignGrowthRates(p, elapsed, shock = {}) {
  const calendarYear = FOREIGN_PROJECTIONS.baseYear + elapsed;
  const scenario = FOREIGN_PROJECTIONS.scenarios[p.foreignProjectionScenario ?? 0].code;
  const index = Math.min(FOREIGN_PROJECTIONS.lastYear - FOREIGN_PROJECTIONS.baseYear, Math.max(1, elapsed));
  const rates = {calendarYear,scenarioIndex:p.foreignProjectionScenario ?? 0,
    active:Number(!!p.foreignForecast),extrapolated:Number(!!p.foreignForecast && calendarYear > FOREIGN_PROJECTIONS.lastYear)};
  for (const source of FOREIGN_PROVIDERS) {
    const path = FOREIGN_PROJECTIONS.multipliers[scenario][source.code];
    const baseline = p.foreignForecast ? 100 * (path[index] / path[index - 1] - 1) : p[source.growth];
    const offset = shock['foreignTFP' + source.code] ?? 0;
    const applied = baseline + offset;
    if (!Number.isFinite(applied) || applied <= -100) throw Error('Foreign TFP growth must stay above −100%.');
    rates[source.code] = {baseline,applied,offset};
  }
  return rates;
}

export function foreignRowMetrics(p, levels, origin, elapsed = 0, rates = null) {
  const result = {foreignForecastActive:Number(!!p.foreignForecast),
    foreignProjectionScenario:p.foreignProjectionScenario ?? 0,
    foreignProjectionCalendarYear:FOREIGN_PROJECTIONS.baseYear + elapsed,
    foreignProjectionExtrapolated:rates?.extrapolated ?? 0};
  for (const source of FOREIGN_PROVIDERS) {
    result['foreignTFPIndex' + source.code] = 100 * levels[source.code] / origin[source.code];
    result['foreignTFPGrowth' + source.code] = rates?.[source.code].applied ?? 0;
    result['foreignBaselineGrowth' + source.code] = rates?.[source.code].baseline ?? 0;
  }
  return result;
}
export function learnForeign(a, lagged, p, seed, time, id, draw, contactProbability = p.foreignContact) {
  if (!contactProbability || !p.foreignAdoption || draw(seed, time, id, 500) >= contactProbability)
    return {a, gain: 0, source: null, contact: null, target: 0, benchmark: 0, tail: false};
  const provider = FOREIGN_PROVIDERS[Math.floor(draw(seed, time, id, 501) * FOREIGN_PROVIDERS.length)];
  const benchmark = lagged[provider.code];
  const dispersion = p.foreignTechDispersion;
  let target = benchmark;
  if (dispersion > 0) {
    const z = Math.sqrt(-2 * Math.log(draw(seed, time, id, 502))) * Math.cos(2 * Math.PI * draw(seed, time, id, 503));
    target *= Math.exp(dispersion * z - dispersion ** 2 / 2);
  }
  const rate = Math.max(0, Math.min(1, p.foreignAdoption * p.absorptiveCapacity * p.humanCapital));
  const gain = rate * Math.max(0, target - a);
  return {a: a + gain, gain, source: gain > 0 ? provider.code : null, contact: provider.code,
    target, benchmark, tail: gain > 0 && benchmark <= a};
}

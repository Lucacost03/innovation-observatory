// Primary issues transfer existing deposits. Bank loans have their own
// balance sheet. Domestic claims settle at face or paid-in cost.
const sum = values => values.reduce((total,value)=>total+value,0);
const allocationWeights = {
  ventureEquity: 'ventureWeight',
  businessEquity: 'businessEquityWeight',
  corporateBonds: 'corporateBondWeight',
  governmentBonds: 'governmentBondWeight',
  foreignAssets: 'foreignPortfolioWeight',
};

export class HouseholdMarket {
  constructor(households, spendingPlans, p) {
    this.households = households;
    const weights = Object.entries(allocationWeights);
    const totalWeight = sum(weights.map(([,key])=>p[key]));
    const budgets = households.map((h,i)=>Math.max(0,h.cash-spendingPlans[i])*p.marketDepositShare/100);
    this.orders = Object.fromEntries(weights.map(([kind,key])=>[
      kind, budgets.map(budget=>totalWeight ? budget*p[key]/totalWeight : 0),
    ]));
    this.budget = totalWeight ? sum(budgets) : 0;
  }

  purchase(kind, requested, requireFull = false) {
    return this.matchOrders(this.orders[kind],requested,requireFull);
  }

  matchOrders(orders,requested,requireFull) {
    const available = orders.map((order,i)=>Math.min(order,Math.max(0,this.households[i].cash)));
    const total = sum(available);
    if (requested<=0 || total<=0 || (requireFull && total<requested)) return null;
    const amount = Math.min(total,requested);
    const buyers = available.map((order,i)=>{
      const payment = order*(amount/total);
      this.households[i].cash -= payment;
      orders[i] -= payment;
      return payment;
    });
    return {amount,buyers};
  }

  // This runs after domestic orders have closed for the year.
  closeForeignOrders(currentAccount, exchangePrice) {
    const explicit = this.purchase('foreignAssets',Infinity);
    const unused = this.households.map((_,i)=>sum(Object.values(this.orders).map(orders=>orders[i])));
    const surplus = this.matchOrders(unused,Math.max(0,currentAccount-(explicit?.amount??0)),false);
    for (const issue of [explicit,surplus]) if (issue) {
      issue.buyers.forEach((paid,i)=>{
        const h=this.households[i];
        h.foreignAssetCost ??= h.foreignAssets*exchangePrice;
        h.foreignAssetCost+=paid;
        h.foreignAssets+=paid/exchangePrice;
      });
    }
    return {foreignAssetPurchases:(explicit?.amount??0)+(surplus?.amount??0),foreignAssetSurplusPurchases:surplus?.amount??0};
  }
}

export const corporateDebt = issuer => issuer.corporateBonds?.balance ?? 0;
export const totalBusinessDebt = firm => firm.loan + corporateDebt(firm);
const equityValue = (firm,price) => price*(firm.capital+firm.inventory)+firm.cash-totalBusinessDebt(firm);

export function issueClaim(firm,kind,issue,share = 1) {
  const position = firm[kind] ??= {balance:0,holders:new Float64Array(issue.buyers.length)};
  position.balance += issue.amount*share;
  for (let i=0;i<position.holders.length;i++) position.holders[i] += issue.buyers[i]*share;
}

export function fundExistingFirms(market,firms,cashNeeds,p,price,flows) {
  for (const kind of ['businessEquity','corporateBonds']) {
    const orders = firms.map((firm,i)=>{
      const capacity = kind==='businessEquity'
        ? (equityValue(firm,price)>0 ? cashNeeds[i] : 0)
        : Math.max(0,p.maxLeverage*firm.capital*price-totalBusinessDebt(firm));
      return Math.min(cashNeeds[i],capacity);
    });
    const total = sum(orders);
    const issue = market.purchase(kind,total);
    if (!issue) continue;
    for (const [i,firm] of firms.entries()) {
      if (!orders[i]) continue;
      if (kind==='businessEquity') firm.founderEquity ??= equityValue(firm,price);
      const share = orders[i]/total;
      const cash = issue.amount*share;
      issueClaim(firm,kind,issue,share);
      firm.cash += cash;
      cashNeeds[i] = Math.max(0,cashNeeds[i]-cash);
    }
    flows[kind==='businessEquity'?'businessEquityIssued':'corporateBondsIssued'] += issue.amount;
  }
}

const creditCash = (household,amount) => {household.cash+=amount;};

export function payHolders(households,position,amount,credit = creditCash) {
  if (!amount || !position?.balance) return;
  const fraction = amount/position.balance;
  for (const [i,h] of households.entries()) credit(h,position.holders[i]*fraction);
}

export function redeemCorporateDebt(households,issuer,amount) {
  if (!amount) return;
  const position = issuer.corporateBonds;
  payHolders(households,position,amount);
  const balance = Math.max(0,position.balance-amount);
  const remaining = balance/position.balance;
  for (let i=0;i<position.holders.length;i++) position.holders[i] *= remaining;
  position.balance = balance;
}

export function repayBusinessDebt(households,firm,amount) {
  const debt = totalBusinessDebt(firm);
  const paid = Math.min(debt,amount);
  const corporate = debt>0 ? paid*(corporateDebt(firm)/debt) : 0;
  const bank = paid-corporate;
  firm.cash -= paid;
  firm.loan = Math.max(0,firm.loan-bank);
  redeemCorporateDebt(households,firm,corporate);
  return {bank,corporate};
}

export function payFirmOwners(households,firm,amount,credit = creditCash,creditPublic = null,creditPension = null) {
  const venture = firm.ventureEquity?.balance ?? 0;
  const equity = firm.businessEquity?.balance ?? 0;
  let legacy = amount;
  if (venture+equity>0) {
    const total = firm.founderEquity+venture+equity;
    const vcPayment = amount*venture/total, equityPayment = amount*equity/total;
    payHolders(households,firm.ventureEquity,vcPayment,credit);
    payHolders(households,firm.businessEquity,equityPayment,credit);
    legacy -= vcPayment+equityPayment;
  }
  const publicPayment=legacy*(firm.publicOwnership??0);
  if(publicPayment){
    if(!creditPublic)throw Error('Public ownership needs a matching payment account.');
    creditPublic(publicPayment);
  }
  const pensionPayment=legacy*(firm.pensionOwnership??0);
  if(pensionPayment){if(!creditPension)throw Error('Pension ownership needs a matching payment account.');creditPension(pensionPayment);}
  for (const h of households) credit(h,(legacy-publicPayment-pensionPayment)*h.ownership);
  return publicPayment;
}

// Public ownership is a share of the original owners' residual claim. New
// household share issues dilute it; public equity is not a debt obligation.
export function publicEquityValue(firms,price=1,ownershipKey='publicOwnership') {
  return sum(firms.map(firm=>{
    const issued=(firm.ventureEquity?.balance??0)+(firm.businessEquity?.balance??0);
    const legacyFraction=issued>0?(firm.founderEquity??0)/Math.max(1e-12,(firm.founderEquity??0)+issued):1;
    const netAssets=price*(firm.capital+firm.inventory)+(firm.cash??0)-(firm.loan??firm.claim??0)-corporateDebt(firm);
    return Math.max(0,netAssets)*(firm[ownershipKey]??0)*legacyFraction;
  }));
}

export function marketHoldings(firms) {
  return {
    householdCorporateBonds:sum(firms.map(corporateDebt)),
    householdVentureEquity:sum(firms.map(firm=>firm.ventureEquity?.balance??0)),
    householdBusinessEquity:sum(firms.map(firm=>firm.businessEquity?.balance??0)),
  };
}


export function foreignCashYield(params) {
  const real = 1+params.foreignRateShift/100;
  const prices = 1+params.foreignPriceGrowth/100;
  return Math.max(0,100*(real*prices-1));
}

export function payForeignIncome(households,yieldRate,exchangePrice,credit) {
  let total=0;
  for (const h of households) {
    const income=h.foreignAssets*yieldRate/100*exchangePrice;
    credit(h,income);
    total+=income;
  }
  return total;
}


export function financialWealth(households,firms,exchangePrice) {
  const assets=households.map(h=>h.cash+h.bonds+h.foreignAssets*exchangePrice+(h.pensionValue??0)+(h.bankTermClaims??0));
  for (const f of firms) for (const key of ['corporateBonds','ventureEquity','businessEquity']) {
    if (!f[key]) continue;
    f[key].holders.forEach((stake,i)=>{assets[i]+=stake;});
  }
  return assets;
}

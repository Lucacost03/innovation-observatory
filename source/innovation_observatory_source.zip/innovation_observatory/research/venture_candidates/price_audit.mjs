import fs from 'node:fs';import {simulate as before} from './instrumented/engine.mjs';import {simulate as after} from './price_aware/engine.mjs';
const ps=JSON.parse(fs.readFileSync(new URL('./input_profiles.json',import.meta.url))).filter(p=>['ITA','DEU','EU27'].includes(p.code)),runs=[];
for(const p of ps)for(const seed of[2026,9945,17864]){
 const b=before({...p.params,periods:40},seed).rows,a=after({...p.params,periods:40},seed).rows;const sums=r=>({entries:r.reduce((s,x)=>s+x.entries,0),funding:r.reduce((s,x)=>s+x.ventureFunding,0),finalFirms:r.at(-1).firmCount,finalGDP:r.at(-1).output,maxResidual:Math.max(...r.map(x=>x.relativeResidual))});
 runs.push({code:p.code,seed,before:sums(b),priceAware:sums(a),estateCapitalAtEntryYears:b.filter(x=>x.vcEstateCapitalAtEntry>1e-8).length,totalEstateCapitalAtEntry:b.reduce((s,x)=>s+(x.vcEstateCapitalAtEntry??0),0),affordableRejected:b.reduce((s,x)=>s+(x.vcPriceAwareAffordableRejected??0),0),meanCostSaving:b.slice(1).reduce((s,x)=>s+x.vcStartupFunds-x.vcPriceAwareInitialAsk,0)/40});
}
fs.writeFileSync(new URL('./price_audit.json',import.meta.url),JSON.stringify({scope:'Candidate exact asset-purchase cost versus original full producer-price funding gate, same seed/profile; accounting mechanism test not forecast validation',runs},null,2));console.log(JSON.stringify(runs,null,2));

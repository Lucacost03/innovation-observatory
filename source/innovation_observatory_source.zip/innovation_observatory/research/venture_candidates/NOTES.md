# Venture funding and entry audit

Completed 2026-11-13 on a frozen 1.19.1 engine closure. Nine 40-year runs: ITA, DEU and EU27, seeds 2026, 9945 and 17864. These are paired mechanism tests, not historical backtests or evidence of forecast accuracy. Only research files were written. The current app was not edited.

## Baseline diagnosis

All nine paths reach only 2–6 firms. All have zero new firms and zero venture funding in the final ten years. Every rejected entry opportunity in these runs fails full financing, rather than physical capital availability. Instrumentation was checked against the original engine at audit time: all existing numeric output fields agree to relative tolerance 1e-9.

The binding feedback is a fixed-size, fully financed startup requirement. Required startup capital equals current total productive capital divided by the current opening firm count, multiplied by the observed birth employment-size ratio. Firm count falls while capital remains in surviving firms or estates, so the minimum funding ask rises sharply. Expected entry opportunities also fall with the number of active firms. The latter is consistent with expressing births as a rate of active enterprises; the hard minimum capital requirement is an additional assumption.

Late venture budgets do not uniformly fall. For example, the DEU seed-2026 annual mean budget rises from 0.99 to 1.66 between years 1–10 and 31–40, while the single startup funding ask rises from 1.14 to 39.53. EU seed-2026 budget rises from 2.24 to 3.80, while the ask rises from 2.56 to 53.61. ITA seed-2026 budget falls from 1.53 to 1.05, but the ask still rises from 4.01 to 27.57. No capital-availability rejection occurs.

Household market budgets are set from opening deposits after reserving planned consumption, before current wages, transfers and dividends arrive. Startup funding occurs late in the period. Actual cash may therefore differ from the reserved orders, and unused orders are not automatically reassigned among domestic security types. This timing is an assumption, not a discovered missing cash transfer. Existing venture claims receive dividends and liquidation proceeds; there is no general maturity or secondary resale channel.

The observed foreign-security stock share is mapped into a relative order weight, so high foreign weights leave less of each household market budget for venture orders (about 20% in ITA, 16% in DEU, 30% in EU with these defaults). A stock-share-to-annual-order mapping is an explicitly unestimated portfolio rule. Removing foreign investment improves some entry counts but is not an accuracy fix and is not recommended.

## Tested candidates

**Price-aware acquisition funding:** replace the all-full-producer-price capital funding ask with the exact cost of available discounted estate capital plus full-price incumbent capital and the configured cash buffer. This removes a price/accounting inconsistency without giving firms free assets. In all nine baseline paths it changes no numerical outcome: no rejected opportunity becomes affordable. It is a defensible isolated correction, not a solution to the main decline. Estates are often available only after the financing barrier is already too large.

**Opening real capital anchor plus exact acquisition funding:** hold the real capital requirement at opening productive capital / opening firm count × the observed birth-size ratio, while acquisition prices remain current. This avoids assuming that every startup must scale up just because other firms die. It is still an unestimated dynamic assumption, and does not solve ITA entry decline or validate forecast accuracy.

| Area | Seed | Final firms: baseline → anchor | Late entries: baseline → anchor | Late annual birth rate: anchor | Final real GDP: baseline → anchor | Final unemployment: baseline → anchor |
|---|---:|---:|---:|---:|---:|---:|
| DEU | 2026 | 2 → 2 | 0 → 1 | 2.33% | 194.95 → 191.05 | 2.24% → 2.55% |
| DEU | 9945 | 3 → 3 | 0 → 1 | 2.27% | 182.82 → 182.75 | 2.26% → 2.26% |
| DEU | 17864 | 2 → 11 | 0 → 5 | 5.49% | 189.32 → 187.97 | 2.22% → 2.24% |
| ITA | 2026 | 5 → 5 | 0 → 0 | 0.00% | 150.97 → 150.78 | 4.94% → 4.94% |
| ITA | 9945 | 6 → 7 | 0 → 0 | 0.00% | 149.05 → 150.65 | 4.09% → 3.81% |
| ITA | 17864 | 4 → 4 | 0 → 0 | 0.00% | 145.37 → 145.39 | 4.90% → 4.92% |
| EU27 | 2026 | 2 → 7 | 0 → 3 | 3.23% | 180.66 → 173.56 | 4.02% → 8.14% |
| EU27 | 9945 | 3 → 7 | 0 → 4 | 4.49% | 169.73 → 170.43 | 4.21% → 4.51% |
| EU27 | 17864 | 2 → 12 | 0 → 7 | 5.69% | 187.78 → 177.76 | 4.16% → 4.59% |

Late means years 31–40. The annual birth rate above is total births / summed annual opening firm counts, ×100. Source birth-rate inputs are DEU 8.43%, ITA 7.78%, EU27 10.5%. These are source-year enterprise-birth proxies, not mandatory model outcomes. Candidate runs have no nonfinite rows and maximum relative accounting residual below 6.6e-15. GDP and unemployment change in both directions; these diagnostics cannot establish which long-run path is closer to reality.

## Empirical distinction and next improvement

The source startup-size ratio is Eurostat EMP_BRTHR_PC / ENT_BRTHR_PC, the mean newborn employment relative to mean active-enterprise employment. Mapping it into capital uses an assumed common capital/labour ratio, as documented in scripts/enrich_demography.py. Treating the mean as one hard minimum suppresses all below-average startups. Further, the source birth rate includes ordinary enterprise births, while all model births must obtain venture-equity funding. Founder-financed and debt-financed birth channels are absent. These scope and distribution assumptions deserve explicit labels; no observed financing mix is supplied by the present dataset.

An empirical birth size-class distribution could support heterogeneous startup employment requirements if matched observations cover the relevant country and enterprise scope. It would not by itself identify capital requirements or founder/debt/venture financing shares. Do not force an upward VC trend, mechanically replace all exits, switch off foreign investment, or change venture weights merely to hit a desired firm count.

## Regression checks for an app correction

- Separate opportunity, firm-cap, capital-shortage and financing-shortage counters; report budgets and minimum asks with failed entries.
- Price the exact estate/full-price mix separately for each sequential startup, since earlier entrants can consume cheap estates.
- Verify household cash paid equals new firm equity funding and household claims; acquired capital leaves sellers or estates exactly once.
- With exact-cost funding, the startup cash remaining after acquisitions must equal the configured working-cash buffer (within tolerance).
- Verify liquidated-estate creditors, equity holders and capital balances reconcile after partial and complete sales.
- Preserve finite output, nonnegative asset/debt bounds, income/expenditure GDP reconciliation, sector financial balances, and ΔNFA = CA = S − I.
- Re-run source-year empirical moment checks and a held-out historical comparison before describing a dynamic assumption as an accuracy improvement.

## Reproducibility files

- `input_profiles.json`: selected country profiles used by the diagnostic closures.
- `instrumented/`: frozen engine dependency closure with passive entry diagnostics.
- `audit.mjs`, `audit.json`: baseline paths and one-at-a-time sensitivities. The original instrumentation comparison in this script references the app dist/engine.mjs as it existed at audit time.
- `price_aware/`, `price_audit.mjs`, `price_audit.json`: exact-cost candidate.
- `opening_anchor/`, `anchor_audit.mjs`, `anchor_audit.json`: opening real capital scale plus exact-cost candidate.
- `summary.json`: compact combined results.

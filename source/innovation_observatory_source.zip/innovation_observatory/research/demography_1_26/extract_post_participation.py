"""Project retained Eurostat age-band rates into transparent eligibility proxies.

Rates are percentages, not fractions. No survey observation directly identifies
participation above each country's legal pension cutoff. The age65+ / age15–64
ratio is an explicit modelling proxy; it is not an estimated reform elasticity.
"""
from pathlib import Path
import hashlib
import json
import math
import csv
import io
import re

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'lfsa_argan_2023.json'
raw_bytes = RAW.read_bytes()
manifest = json.loads((ROOT / 'manifest.json').read_text())
source = next(x for x in manifest if x['file'] == RAW.name)
assert hashlib.sha256(raw_bytes).hexdigest() == source['sha256']
raw = json.loads(raw_bytes)
cohorts = json.loads((ROOT / 'age_cohorts_2023.json').read_text())['countries']
geo_by_code = dict(AUT='AT', BEL='BE', BGR='BG', HRV='HR', CYP='CY',
    CZE='CZ', DNK='DK', EST='EE', FIN='FI', FRA='FR', DEU='DE', GRC='EL',
    HUN='HU', IRL='IE', ITA='IT', LVA='LV', LTU='LT', LUX='LU', MLT='MT',
    NLD='NL', POL='PL', PRT='PT', ROU='RO', SVK='SK', SVN='SI', ESP='ES',
    SWE='SE', EU27='EU27_2020')
age_labels = {'Y15-64': '15–64', 'Y_GE65': '65+', 'Y65-74': '65–74',
              'Y65-69': '65–69', 'Y70-74': '70–74'}
url = 'https://ec.europa.eu/eurostat/databrowser/view/lfsa_argan/default/table?lang=en'


def observation(geo, age):
    selection = dict(freq='A', unit='PC', sex='T', age=age,
                     citizen='TOTAL', geo=geo, time='2023')
    index = 0
    for dimension, size in zip(raw['id'], raw['size']):
        index = index * size + raw['dimension'][dimension]['category']['index'][selection[dimension]]
    value = raw['value'].get(str(index))
    flag = raw.get('status', {}).get(str(index))
    if value is not None:
        assert math.isfinite(value) and 0 <= value <= 100
    return {'rate': value, 'sourceFlag': flag, 'rawIndex': index,
            'sourceAgeBand': age, 'ageLabel': age_labels[age]}


countries = {}
for code, cohort in cohorts.items():
    if code not in geo_by_code:
        entry=next(x for x in json.loads((ROOT/'ilo_participation_manifest.json').read_text()) if x['file']==f'ilo_{code}_participation_2023.csv')
        data=(ROOT/entry['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==entry['sha256']
        rows=list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))
        selected={key:next(x for x in rows if x['ref_area']==code and x['sex']=='SEX_T' and x['time']=='2023' and x['classif1']==key)for key in ['AGE_YTHADULT_Y15-64','AGE_AGGREGATE_YGE65']}
        pre=selected['AGE_YTHADULT_Y15-64'];older=selected['AGE_AGGREGATE_YGE65'];pr=float(pre['obs_value']);old=float(older['obs_value'])
        assert pre['source']==older['source'] and 0<pr<=100 and 0<=old<=100
        countries[code]={'name':cohort['name'],'sourceYear':2023,'rateOlder':old,'ratePre':pr,'relativePercent':100*old/pr,'sourceAgeBand':'AGE_AGGREGATE_YGE65','preAgeBand':'AGE_YTHADULT_Y15-64','sourceURL':entry['url'],'sourceProvider':'ILOSTAT published age-band estimates','sourceCode':pre['source'],'status':'published provider estimates; derived age-profile proxy','caveat':'ILOSTAT age-band estimates, not an observed reform elasticity. Source codes and status flags are retained; source-vintage/modelled-versus-national detail is not inferred from numerical precision. The US older estimate is cross-checked against BLS CPS annual2023 rate19.2% with a different civilian noninstitutional population scope.','fallbackRelativePercent':None,'fallbackStatus':None,'olderBands':{'Y_GE65':{'rate':old,'sourceFlag':older['obs_status']or None}},'preBand':{'rate':pr,'sourceFlag':pre['obs_status']or None},'rawCoordinates':selected,'sha256':entry['sha256']}
        continue
    geo = geo_by_code[code]
    pre = observation(geo, 'Y15-64')
    bands = {age: observation(geo, age) for age in ['Y_GE65', 'Y65-74', 'Y65-69', 'Y70-74']}
    older = bands['Y_GE65']
    assert pre['rate'] is not None and pre['rate'] > 0 and older['rate'] is not None
    relative = 100 * older['rate'] / pre['rate']
    countries[code] = {
        'name': cohort['name'], 'sourceYear': 2023, 'geo': geo,
        'rateOlder': older['rate'], 'ratePre': pre['rate'],
        'relativePercent': relative, 'sourceAgeBand': 'Y_GE65',
        'sourceAgeLabel': '65+', 'preAgeBand': 'Y15-64',
        'sourceURL': url, 'status': 'observed age-band rates; derived policy-eligibility proxy',
        'caveat': 'Age65+ includes people on both sides of some legal pension cutoffs. The ratio to age15–64 is a proxy for continued participation after model eligibility, not an observed pensioner employment rate, an actual retirement age, or an estimated response to changing the legal age. Employment and labour-force participation differ. Changing the cutoff while holding this ratio constant is an additional scenario assumption.',
        'fallbackRelativePercent': None, 'fallbackStatus': None,
        'olderBands': bands, 'preBand': pre,
        'relativePercent65to74': 100 * bands['Y65-74']['rate'] / pre['rate'],
        'sourceUpdated': raw['updated'],
    }

# Independent national-provider cross-check of the published US older-age rate.
bls=next(x for x in json.loads((ROOT/'ilo_participation_manifest.json').read_text()) if x['file']=='bls_cpsaat03_2023.html')
b=(ROOT/bls['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==bls['sha256']
rows=[re.sub(r'<[^>]+>',' ',r)for r in re.findall(r'<tr[^>]*>(.*?)</tr>',b.decode(),re.S)]
older=next(' '.join(r.split())for r in rows if ' '.join(r.split()).startswith('65 years and over '))
nums=re.findall(r'[0-9,]+(?:\.[0-9]+)?',older[len('65 years and over '):]);population=float(nums[0].replace(',',''));labor=float(nums[1].replace(',',''));rate=float(nums[2])
assert population==58260 and labor==11196 and rate==19.2
assert abs(countries['USA']['rateOlder']-rate)<.1
countries['USA']['nationalCrossCheck']={'sourceURL':bls['url'],'populationThousands':population,'laborForceThousands':labor,'publishedParticipationRate':rate,'scope':'BLS civilian noninstitutional population65+; not identical to all-population ILO coverage','rawSHA256':bls['sha256']}

result = {
    'openingYear': 2023, 'countries': countries,
    'definition': 'Labour-force participation rate = employed plus unemployed people in the labour force, divided by population of the same age band, times100. Rates are annual2023 and total sex; European data are all citizenship, unitPC. USA/China use the same age bands from retained ILOSTAT published estimates.',
    'units': {'rateOlder': 'percent of age65+ population',
              'ratePre': 'percent of age15–64 population',
              'relativePercent': '100 * rateOlder / ratePre; divide by100 to obtain the model multiplier'},
    'preferredProxy': 'Age65+ is used because the engine applies its post-eligibility proxy to the whole older population. The narrower age65–74,65–69,70–74 bands are also retained for sensitivity analysis, not silently averaged.',
    'source': {'dataset': raw['label'], 'code': 'lfsa_argan', 'sourceURL': url,
               'downloadURL': source['url'], 'updated': raw['updated'],
               'rawFile': RAW.name, 'sha256': source['sha256'],
               'coordinates': {'freq': 'A', 'unit': 'PC', 'sex': 'T', 'citizen': 'TOTAL', 'time': '2023'},
               'sourceFlagDefinitions': raw['extension']['status']['label']},
    'limitations': [
        'Country-specific empirical age-band rates replace a universal assumed coefficient only where verified data are available. Source rates are survey estimates and rounded to one decimal; derived ratios have no added empirical precision.',
        'The age-band ratio is not a country-specific statutory-pension-age rate. Do not treat eligibility as a compulsory work exit or calibrate this ratio as an estimated reform response.',
        'Eurostat source flags, including breaks, definition differences and low reliability, remain attached to each observation. A missing narrower-band estimate remains null.',
        'USA and China use separately retained ILOSTAT published age-band estimates. Their underlying source codes and source flags are preserved; these are not treated as directly observed pension-reform responses.',
        'Opening aggregate participation must be calibrated separately if this proxy is mapped across differently sized working-age and older cohorts.',
    ],
}
(ROOT / 'post_eligibility_participation_2023.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
assert len(countries) == 30
assert sum(c['relativePercent'] is not None for c in countries.values()) == 30
assert all(abs(c['relativePercent'] - 100*c['rateOlder']/c['ratePre']) < 1e-12
           for c in countries.values() if c['relativePercent'] is not None)
validation = {'status': 'PASS', 'profiles': 30, 'observedAgeBandPairs': 28,
              'explicitFallbacks': [], 'additionalILOPublishedPairs': ['USA','CHN'],
              'preferredOlderBand': 'Y_GE65',
              'sourceFlaggedPreferredPairs': {c: {'older': x['olderBands']['Y_GE65']['sourceFlag'], 'pre': x['preBand']['sourceFlag']}
                  for c,x in countries.items() if x['preBand'] is not None and (x['preBand']['sourceFlag'] or x['olderBands']['Y_GE65']['sourceFlag'])},
              'missingNarrowerBands': {c: [k for k,v in x['olderBands'].items() if v['rate'] is None]
                  for c,x in countries.items() if any(v['rate'] is None for v in x['olderBands'].values())},
              'EU27RelativePercent': countries['EU27']['relativePercent'],
              'minObservedRelativePercent': min(x['relativePercent'] for x in countries.values() if x['relativePercent'] is not None),
              'maxObservedRelativePercent': max(x['relativePercent'] for x in countries.values() if x['relativePercent'] is not None)}
(ROOT / 'post_participation_validation.json').write_text(json.dumps(validation, indent=2) + '\n')
print(json.dumps(validation))

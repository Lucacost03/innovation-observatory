from pathlib import Path
import json,hashlib,urllib.request,urllib.parse,datetime
R=Path(__file__).resolve().parent
ps=json.loads((R.parents[1]/'dist/data/profiles.json').read_text())
manifest=[]
def fetch(name,url):
 p=R/name
 if not p.exists():
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=90)as f:p.write_bytes(f.read())
 manifest.append(dict(file=name,url=url,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),retrievedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 return p
params=[('lang','en'),('freq','A'),('unit','NR'),('sex','T'),('sinceTimePeriod','2023'),('untilTimePeriod','2023')]+[('geo',p['geo'])for p in ps if p['code']not in['USA','CHN']]
fetch('eurostat_demo_pjan_2023.json','https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_pjan?'+urllib.parse.urlencode(params))
fetch('eurostat_pensions_missoc.pdf','https://ec.europa.eu/eurostat/statistics-explained/SEPDF/cache/133610.pdf')
fetch('ssa_1957.html','https://www.ssa.gov/benefits/retirement/planner/1957.html')
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print([(m['file'],m['bytes'])for m in manifest])

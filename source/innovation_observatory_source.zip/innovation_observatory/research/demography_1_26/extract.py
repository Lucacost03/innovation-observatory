"""Reconstruct source age profiles and transparent retirement reference proxies."""
from pathlib import Path
import json,hashlib,re,math
R=Path(__file__).resolve().parent;ROOT=R.parents[1];read=lambda p:json.loads(p.read_text());ps=read(ROOT/'dist/data/profiles.json');raw=read(R/'eurostat_demo_pjan_sexes_2023.json');totalraw=read(R/'eurostat_demo_pjan_2023.json')
for m in read(R/'manifest.json'):
 if m.get('sha256'):
  file=R/m['file']
  if not file.exists()and file.suffix.lower()in['.pdf','.xlsx']:continue # Optional raw bytes remain inGit; exact cell/manual projections retained.
  assert hashlib.sha256(file.read_bytes()).hexdigest()==m['sha256'],m['file']
def coord(d,**s):
 i=0
 for k,n in zip(d['id'],d['size']):i=i*n+d['dimension'][k]['category']['index'][s[k]]
 return d['value'].get(str(i)),d.get('status',{}).get(str(i)),i
cohorts={}
for p in ps:
 if p['code']in['USA','CHN']:continue
 per={};flags={}
 for sex,name in [('T','counts'),('M','maleCounts'),('F','femaleCounts')]:
  vals=[]
  for age in range(101):
   agecode='Y_LT1'if age==0 else'Y_OPEN'if age==100 else'Y'+str(age);v,flag,i=coord(raw,freq='A',unit='NR',age=agecode,sex=sex,geo=p['geo'],time='2023');assert v is not None,(p['code'],sex,age)
   vals.append(v)
   if flag:flags[sex+':'+str(age)]=flag
  total,fl,ix=coord(raw,freq='A',unit='NR',age='TOTAL',sex=sex,geo=p['geo'],time='2023');assert sum(vals)==total,(p['code'],sex,total,sum(vals));per[name]=vals
 assert all(per['counts'][i]==per['maleCounts'][i]+per['femaleCounts'][i]for i in range(101))
 total=sum(per['counts']);cohorts[p['code']]=dict(name=p['name'],sourceYear=2023,referenceDate='2023-01-01',source='Eurostat demo_pjan',url='https://ec.europa.eu/eurostat/databrowser/view/demo_pjan/default/table?lang=en',updated=raw['updated'],total=total,totalMillions=total/1e6,terminalAge=100,terminalLabel='100+',ageResolution='Observed single ages0–99 and open100+',status='observed/official estimates; source flags preserved',flags=flags,**per)
# Census vintage2023 workbook; store a compact exact cell projection to allow
# the normal source bundle to omit optional XLSX bytes.
projection=R/'census_single_age_projection_2023.json'
if not projection.exists():
 import openpyxl
 rows=list(openpyxl.load_workbook(R/'census_syasexn_2023.xlsx',read_only=True,data_only=True).active.values);per={};sex=None
 for rowno,row in enumerate(rows,1):
  label=row[0]
  if label in['Total Population','Male','Female']:sex={'Total Population':'counts','Male':'maleCounts','Female':'femaleCounts'}[label];per[sex]=[]
  elif sex and isinstance(label,str)and re.fullmatch(r'\.(?:\d+|100\+)',label):per[sex].append(dict(age=100 if label=='.100+'else int(label[1:]),value=row[5],cell=f'F{rowno}'))
 projection.write_text(json.dumps(per,indent=2)+'\n')
projected=read(projection);per={k:[x['value']for x in v]for k,v in projected.items()};assert all(len(v)==101 for v in per.values());assert all(per['counts'][i]==per['maleCounts'][i]+per['femaleCounts'][i]for i in range(101))
cohorts['USA']=dict(name='United States',sourceYear=2023,referenceDate='2023-07-01',source='US Census NC-EST2023-SYASEXN, vintage2023 released27June2024',url='https://www2.census.gov/programs-surveys/popest/tables/2020-2023/national/asrh/nc-est2023-syasexn.xlsx',total=sum(per['counts']),totalMillions=sum(per['counts'])/1e6,terminalAge=100,terminalLabel='100+',ageResolution='Observed single-age official population estimates0–99 and100+',status='official estimate; older vintage explicitly retained, later Census revisions not silently mixed',flags={},**per)
# WB/HNP counts are UN-based estimates, not a Chinese census. Retain the
# source80+ open band instead of manufacturing a Chinese centenarian profile.
wb=read(R/'wb_5year_population_counts_2023.json');obs={(x['countryiso3code'],x['indicator']['id']):x for x in wb[1]};per={'maleCounts':[0.0]*101,'femaleCounts':[0.0]*101};bands=[]
for lo in range(0,85,5):
 band=f'{lo:02d}{lo+4:02d}'if lo<80 else'80UP';entry=dict(lowerAge=lo,upperAge=lo+4 if lo<80 else None)
 for sex,key in [('MA','maleCounts'),('FE','femaleCounts')]:
  o=obs['CHN','SP.POP.'+band+'.'+sex];assert o['value']is not None;entry['male'if sex=='MA'else'female']=o['value']
  if lo<80:
   for a in range(lo,lo+5):per[key][a]=o['value']/5
  else:per[key][80]=o['value']
 bands.append(entry)
per['counts']=[a+b for a,b in zip(per['maleCounts'],per['femaleCounts'])];total=sum(per['counts']);assert abs(total-1410710000)<.001
cohorts['CHN']=dict(name='China',sourceYear=2023,referenceDate='2023-07-01, UN-based midyear estimates',source='WorldBank Health Nutrition and Population Statistics source16; UN age/sex distributions',url='https://api.worldbank.org/v2/country/CHN/indicator/SP.POP.0004.MA?source=16&date=2023&format=json',updated=wb[0]['lastupdated'],total=total,totalMillions=total/1e6,terminalAge=80,terminalLabel='80+',ageResolution='Observed/estimated5-yearbands0–79 and open80+; uniform within5-yearbands is an explicit model interpolation',status='proxy: UN-based estimated age profile with within-band interpolation',flags={},sourceBands=bands,notes=['Indices81–100 are execution padding, not observed zero population at those ages. Bucket80contains all80+; retain it as an open terminal bucket when aging.','UN/WB midyear total differs from NBS year-end population and scope. If the model retains an NBS total, rescaling this age distribution is a mapping proxy.'],**per)
for c,x in cohorts.items():
 x['weights']=[v/x['total']for v in x['counts']];x['percentages']=[100*v/x['total']for v in x['counts']];x['maleWeights']=[v/x['total']for v in x['maleCounts']];x['femaleWeights']=[v/x['total']for v in x['femaleCounts']];x['childShare']=sum(x['percentages'][:15]);x['workingAge15to64Share']=sum(x['percentages'][15:65]);x['older65plusShare']=sum(x['percentages'][65:]);assert abs(sum(x['weights'])-1)<1e-12
(R/'age_cohorts_2023.json').write_text(json.dumps(dict(openingYear=2023,countries=cohorts,limitations=['Country reference dates/vintages differ and are explicit. Counts are official estimates, not exact error-free censuses.','Chinese single ages within5-yearbands are interpolated uniformly;80+ remains open.','Future births, deaths, migration, participation and retirement responses are scenario assumptions unless separately sourced.']),indent=2)+'\n')
# Table1, printedpage12, manually transcribed from retained primary PDF.
y=lambda yr,mo=0:yr+mo/12
rawages={'AUT':(65,60),'BEL':(65,65),'BGR':(y(64,6),62),'HRV':(65,63),'CYP':(65,65),'CZE':(64,64),'DNK':(67,67),'EST':(y(64,6),y(64,6)),'FIN':(y(64,3),y(64,3)),'FRA':(62,62),'DEU':(y(65,11),y(65,11)),'GRC':(67,67),'HUN':(65,65),'IRL':(66,66),'ITA':(67,67),'LVA':(y(64,6),y(64,6)),'LTU':(y(64,6),64),'LUX':(65,65),'MLT':(64,64),'NLD':(y(66,10),y(66,10)),'POL':(65,60),'PRT':(y(66,4),y(66,4)),'ROU':(65,62),'SVK':(64,y(63,6)),'SVN':(65,65),'ESP':(y(66,4),y(66,4)),'SWE':(62,62)}
ret={};pdfurl='https://ec.europa.eu/eurostat/statistics-explained/SEPDF/cache/133610.pdf'
for p in ps:
 c=p['code']
 if c not in rawages:continue
 m,f=rawages[c];sexM=sum(cohorts[c]['maleCounts'])/cohorts[c]['total'];rep=sexM*m+(1-sexM)*f
 ret[c]=dict(name=p['name'],sourceYear=2023,maleAge=m,femaleAge=f,representativeAge=rep,referenceAge=m,status='derived policy proxy'if m!=f else'observed statutory reference mapped as a common model cutoff',representativeMethod='Population-sex-share-weighted male/female statutory references; not an observed mean retirement age.'if m!=f else'Common male/female source reference, simplified into one policy cutoff.',source='Eurostat/MISSOC Table1, statutory pension ages2012/2023',url=pdfurl,coordinate='Table1 printedpage12;2023male/female columns',sourceTableMaleAge=m,sourceTableFemaleAge=f,notes=['Actual labour-market exit, earliest pension claiming, full-rate entitlement and pension eligibility are different measures. Career-length and special occupational conditions are not modelled.'])
ret['FRA']['notes'].append('The source table reports62 as the2023opening reference. The September2023reform increased the minimum age by birth cohort; it must not be silently called today’s rule.')
ret['SWE'].update(maleAge=66,femaleAge=66,representativeAge=66,referenceAge=66,status='proxy: guarantee-pension eligibility age, not mandatory retirement',source='Swedish Pensions Agency official2023 report; supersedes stale flexible-from62 table entry',url='https://www.pensionsmyndigheten.se/statistik/publikationer/pensionsaldrar-arbetslivets-langd-2023/',coordinate='Effekter av höjda åldersgränser i pensionssystemet;2023ages63/66/69',earliestEarningsPensionAge=63,guaranteePensionAge=66,meanPensionClaimAge=66.0,meanLabourForceExitAge=64.4,representativeMethod='Guarantee-pension eligibility66 is the explicit scalar reference; earnings-related earliest age63 and actual mean exit64.4 are separately retained.');ret['SWE']['notes'].append('The retained Eurostat/MISSOCtable labels flexible pension from62, but official Swedish sources confirm63for earnings-related and66for guarantee pension from2023. These are not one universal compulsory retirement age.')
ret['USA']=dict(name='United States',sourceYear=2023,maleAge=66.5,femaleAge=66.5,representativeAge=66.5,referenceAge=66.5,status='proxy: cohort-specific SocialSecurity full benefit age',representativeMethod='1957birth-cohort full retirement age66.5, reaching eligibility in2023; not a mandatory labour exit.',source='SocialSecurity Administration retirement planner',url='https://www.ssa.gov/benefits/retirement/planner/1957.html',coordinate='Pageheading and full-benefit row66years6months',earliestClaimAge=62,fullAgeForBorn1960plus=67,notes=['Full retirement age depends on birth year;67for1960andlater cohorts is not silently substituted for the2023retiring cohort.','Pension claiming and employment can overlap.'])
ret['CHN']=dict(name='China',sourceYear=2023,maleAge=60,femaleAge=None,femaleAgeAlternatives=[50,55],representativeAge=60,referenceAge=60,status='proxy: urban male and rural-resident reference; no observed population-wide scalar',representativeMethod='60is a documented legal reference for male employees and rural/nonsalaried resident pensions; female employee50/55rules remain distinct. No unsupported occupation-weighted mean is invented.',source='China2024NPC reform decision/StateCouncil Information Office; SSA official international pension summary',url='https://www.ssa.gov/policy/docs/progdesc/intl_update/2024-10/',primaryURL='https://english.scio.gov.cn/pressroom/2024-09/14/content_117428449.html',coordinate='China reform: normalage60→63men,55→58white-collarwomen,50→55blue-collarwomen; resident pensionage60',femaleWhiteCollarAge=55,femaleBlueCollarAge=50,ruralResidentAge=60,laterReform=dict(effectiveYear=2025,transitionYears=15,targetMale=63,targetFemaleWhiteCollar=58,targetFemaleBlueCollar=55),notes=['Chinese2023normal retirement is not uniformly60for all workers. Female occupational composition was not verified; femaleAge staysnull, with known alternatives retained.','The2025reform changes future statutory ages. A frozen2023policy baseline is an explicit scenario, not a claim that legislation stays unchanged.','RawChineseSCIOpage503/timeout is disclosed; officialSSA summary successfully retrieved.'])
EU=[p for p in ps if p['code']not in['USA','CHN','EU27']];den=sum(cohorts[p['code']]['total']for p in EU);weighted=sum(ret[p['code']]['representativeAge']*cohorts[p['code']]['total']for p in EU)/den
ret['EU27']=dict(name='EuropeanUnion(EU27)',sourceYear=2023,maleAge=None,femaleAge=None,representativeAge=weighted,referenceAge=weighted,status='derived policy proxy, not a common EU statutory age',representativeMethod='2023population-weighted mean of27country representative reference cutoffs, with Sweden66override and national sex weighting.',source='Member-country official references and Eurostatdemo_pjan populations',url=pdfurl,notes=['There is no single EUretirement law. This scalar represents an aggregate-economy scenario, not a27-country micro-simulation.'])
assert len(ret)==len(cohorts)==30
(R/'retirement_ages_2023.json').write_text(json.dumps(dict(openingYear=2023,countries=ret,sourceTiming='2023opening policy references, with later reforms separately retained',limitations=['No scalar represents everysex,career,occupation,earlyclaimrule or actualexitage.','Model eligibility and the statistical15–64population must remain distinct. Do not force all pensioners out of work.','Future policy paths and participation elasticities require separately labelled assumptions.']),indent=2)+'\n')
print(json.dumps({'status':'PASS','countries':30,'singleAgeProfiles':29,'fiveYearOpen80Profile':'CHN','EURepresentativeAge':weighted,'ChinaPopulation':cohorts['CHN']['total'],'USA':cohorts['USA']['total'],'EU':cohorts['EU27']['total']}))

from pathlib import Path
import json,urllib.request,urllib.parse,hashlib,datetime
R=Path(__file__).resolve().parent;manifest=json.loads((R/'manifest.json').read_text())
def fetch(name,url):
 p=R/name
 if not p.exists():
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=90)as f:p.write_bytes(f.read())
 manifest[:]=[x for x in manifest if x['file']!=name];manifest.append(dict(file=name,url=url,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),retrievedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()));(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(name,p.stat().st_size,flush=True)
 return p
bands=[str(a).zfill(2)+str(a+4).zfill(2)for a in range(0,80,5)]+['80UP']
inds=['SP.POP.'+b+'.'+s for b in bands for s in ['MA','FE']]
u='https://api.worldbank.org/v2/country/CHN;USA/indicator/'+';'.join(inds)+'?source=16&date=2023&format=json&per_page=10000'
fetch('wb_5year_population_counts_2023.json',u)
fetch('wb_metadata_8589.json','https://api.worldbank.org/v2/indicator/SP.POP.8589.MA?format=json')
ps=json.loads((R.parents[1]/'dist/data/profiles.json').read_text());params=[('lang','en'),('freq','A'),('unit','NR'),('sinceTimePeriod','2023'),('untilTimePeriod','2023')]+[('geo',p['geo'])for p in ps if p['code']not in['USA','CHN']]
fetch('eurostat_demo_pjan_sexes_2023.json','https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_pjan?'+urllib.parse.urlencode(params))
fetch('china_retirement_2024.html','https://english.scio.gov.cn/pressroom/2024-09/14/content_117428449.html')
if(R/'census_syasexn_2023.xlsx').exists():fetch('census_syasexn_2023.xlsx','https://www2.census.gov/programs-surveys/popest/tables/2020-2023/national/asrh/nc-est2023-syasexn.xlsx')

# Defense: observed spending, unidentified technology effect

The2023 MOF national general-public-budget defense function is1,580.508bnCNY, equivalent to1.2211562688% of revisedGDP. This is an observed final-account amount within that budget scope. It is not a claim that every defense-related activity is covered. The2025 final-account reference is retained separately in the full observation JSON; do not mix its amount into the2023 opening balance.

These fiscal tables do not separately disclose current purchases P3, personnel, equipment investment or militaryR&D. All such2023 splits are null in the engine-ready file. Do not substitute zero and do not call all defense expenditure research.

The2019 official defense white paper describes personnel, training/sustainment, and equipment. Its last tabulated composition refers to2017, not2023:30.8%,28.1% and41.1%. The equipment category includes research/development/testing as well as procurement, repair and transport; it is not anR&D share. That old composition must not be used as a measured current allocation.

Primary context: https://english.scio.gov.cn/2019-07/24/content_75026800_6.htm ; official Ministry of Defense text https://www.mod.gov.cn/gfbw/xwfyr/rdjj/4846890_7.html . The2023 nationalR&D communiqué reports performer totals and national R&D, not a matched causal defense-to-civilianTFP elasticity: https://www.stats.gov.cn/sj/zxfb/202410/t20241002_1956810.html .

Possible demand, financing, resource-allocation and dual-use knowledge effects can be explored in the simulation. A sign or size for net civilian productivity gains is not empirically identified by these budget observations. No positive automaticTFP multiplier is justified by this extraction. A scenario that reallocates a fixed budget must debit the displaced uses and avoid counting government R&D twice.

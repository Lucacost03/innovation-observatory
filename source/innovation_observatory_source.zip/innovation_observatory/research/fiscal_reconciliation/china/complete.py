from rebuild import *
if __name__=='__main__':
 src=[('nbs_gdp_revision_2023.html','https://www.stats.gov.cn/sj/zxfb/202412/t20241227_1957915.html'),('moe_education_2023.html','https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html')]
 codes={'general_revenue':3997529,'general_expenditure':3997526,'fund_revenue':3997522,'fund_expenditure':3997520,'statecapital_revenue':3997517,'statecapital_expenditure':3997514,'social_revenue':3997512,'social_expenditure':3997510}
 src +=[(k+'_2025.html',f'https://yss.mof.gov.cn/2025zyjs/202609/t20260916_{v}.htm')for k,v in codes.items()]
 def fetch(z):
  try:return get(z[1],z[0])
  except Exception as e:return dict(file=z[0],url=z[1],status="unavailable_raw",error=str(e))
 with concurrent.futures.ThreadPoolExecutor(max_workers=5)as ex:extra=list(ex.map(fetch,src))
 mf=json.loads((P/'manifest.json').read_text());(P/'manifest.json').write_text(json.dumps(mf+extra,ensure_ascii=False,indent=2)+'\n')
 print('Downloaded',len(extra),'additional official files')

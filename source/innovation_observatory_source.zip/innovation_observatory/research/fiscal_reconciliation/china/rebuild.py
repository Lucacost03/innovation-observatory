"""Re-extract China fiscal tables from official retained HTML (stdlib only)."""
from pathlib import Path
import urllib.request,urllib.parse,re,json,hashlib,datetime,concurrent.futures,html
from html.parser import HTMLParser
P=Path(__file__).resolve().parent
class Tables(HTMLParser):
 def __init__(self):super().__init__();self.rows=[];self.row=None;self.cell=None
 def handle_starttag(self,t,a):
  if t=='tr':self.row=[]
  if t in ['td','th'] and self.row is not None:self.cell=[]
 def handle_data(self,d):
  if self.cell is not None:self.cell.append(d)
 def handle_endtag(self,t):
  if t in ['td','th']and self.cell is not None:
   self.row.append(re.sub(r'\s+',' ',''.join(self.cell)).strip());self.cell=None
  if t=='tr'and self.row is not None:
   if any(self.row):self.rows.append(self.row)
   self.row=None

def get(url,name):
 f=P/name
 if not f.exists():
  with urllib.request.urlopen(url,timeout=60)as r:f.write_bytes(r.read())
 return dict(file=name,url=url,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),bytes=f.stat().st_size,retrievedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='downloaded')
def rows(name):
 p=Tables();p.feed((P/name).read_text());return p.rows
if __name__=='__main__':
 src=[('general_government_2024.html','https://yss.mof.gov.cn/2024zyjs/202510/t20251024_3974874.htm')]
 codes={'general_revenue':3942864,'general_expenditure':3942884,'fund_revenue':3942833,'fund_expenditure':3942831,'statecapital_revenue':3942828,'statecapital_expenditure':3942822,'social_revenue':3942820,'social_expenditure':3942817}
 src +=[(k+'_2023.html',f'https://yss.mof.gov.cn/2023zyjs/202408/t20240830_{v}.htm')for k,v in codes.items()]
 def fetch(z):return get(z[1],z[0])
 with concurrent.futures.ThreadPoolExecutor(max_workers=5)as ex:manifest=list(ex.map(fetch,src))
 (P/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 for f in ['general_revenue_2023.html','general_expenditure_2023.html','social_revenue_2023.html','social_expenditure_2023.html']:
  z=rows(f);(P/(f+'.rows.json')).write_text(json.dumps(z,ensure_ascii=False,indent=2)+'\n');print(f,len(z),z[:4])

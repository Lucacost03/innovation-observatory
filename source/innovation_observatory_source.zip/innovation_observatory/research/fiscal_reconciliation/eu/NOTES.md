# European general-government fiscal ledger, recovered15November2026

All27EU members and the EU27 aggregate have matched2023 general-government S13 total revenue, expenditure, net lending/borrowing and government consumption. The same-country same-year GDP denominator is used throughout each matrix.2024 and2025 observations are separate references and never relabeled2023 opening data.

The frozen JSON-stat files are direct Eurostat API responses. `download_manifest.json` records URLs, retrieval timestamps, source-update timestamps, byte sizes and SHA256 hashes. `engine_extract.py` rebuilds `engine_inputs.json`, `coverage.json` and `fiscal_lines.csv` entirely offline and verifies raw hashes. A hash verifies byte identity, not statistical truth. Statistics remain subject to revision.

## Source vintages and missing values

- `gov_10a_main`:21October2026; amounts in millionEUR and published roundedPC_GDP ratios retained.
- `gov_10a_taxag`:5November2026;14 missing household/corporate tax cells across7countries are filled with the matching2023 S13 source series. The original main-file missing values remain in `valuesMillionEUR`; filled values are explicitly recorded in `resolvedValuesMillionEUR` and `sourceResolution`.
- `nama_10_gdp`:11November2026; annual B1GQ CP_MEUR denominator. This latest national-account denominator may differ slightly from the earlier published fiscal PC_GDP denominator. Both versions are retained; the difference is not hidden.
- `gov_10a_exp`:21October2026; complete broad2023 functional coverage, with some detailed missing cells. Most2025 functions are unavailable. A missing cell remains `null`, never an observation of zero.
- Denmark2025 revenue is unavailable after the dividend correction. Do not construct it from expenditure plus EDP balance. The21October2026 official release also shows the missing revenue. Bulgaria2025 EDP figures carry a Eurostat reservation; source flags are retained.

## Additive accounts and overlap

Revenue categories: P11_P12_P131 + D2REC + D39REC + D4REC + D5REC + D61REC + D7REC + D9REC.

Expenditure categories: P2 + D1PAY + D29PAY + D3PAY + D4PAY + D5PAY + D62PAY + D632PAY + D7PAY + D8 + D9PAY + P5 + NP.

Missing components are listed explicitly. The residual from the published total less available components is recorded as an unresolved residual; a small residual does not prove that each missing component is zero. Rounding can leave sub-millionEUR discrepancies. Current expenditure is TE−P5−NP−D9PAY; current revenue is TR−D9REC. These are derived bridges, distinct from total net lending/borrowing.

Government consumption P3 is not total expenditure and is not disjoint from employee compensation/intermediate purchases. It includes noncash depreciation and deducts sales. Do not add P3 to its own inputs or add consumption of fixed capital again to total expenditure. Public investment is already part of national gross investment and is not an additional GDP component on top of total I.

COFOG functions are an alternative classification. Healthcare, education, defense and social protection TE cannot be added on top of economic expenditure categories. Cash pension subsets cannot be added again on top of total cash social benefits.

## Defense evidence now available

GF02 provides total defense expenditure and P3 defense consumption for all28 European presets in2023. Its subdivisions include GF0201 military defense, GF0202 civil defense, GF0203 foreign military aid, GF0204 R&Ddefense and GF0205 defense n.e.c. All original reported items remain in `functionsMillionEUR`; the optional D62PAY key is an explicit alias of raw D62 for interoperability, not another payment.

GF0204 TE is observed spending classified as defense R&D. Bulgaria2023 does not report a value; it is not zero. Croatia,Cyprus,Greece,Ireland,Latvia,Malta report genuine zero values at the source's monetary precision. These observations do not identify a defense-to-civilian TFP elasticity or a guaranteed civilian innovation return. Nor are COFOG defense definitions identical to NATO military expenditure or SIPRI estimates. No causal coefficient or growth multiplier is invented in this ledger.

Example2023 observations, with the common GDP denominator:

- Italy: revenue46.52811836%GDP, expenditure53.62349521%, net borrowing7.09537685%; public consumption17.83733272%GDP. Defense TE25513millionEUR, P322559millionEUR, R&Ddefense TE75millionEUR.
- EU27: revenue45.44282172%GDP, expenditure48.81247048%, net borrowing3.36964875%; defense TE232115.4millionEUR, P3194036.6millionEUR, R&Ddefense TE4242.1millionEUR.

Official release: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-ap

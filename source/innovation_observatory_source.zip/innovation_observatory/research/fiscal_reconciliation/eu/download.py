"""Optional raw-file recovery from exact manifest URLs; extraction itself is offline."""
from pathlib import Path
import json,urllib.request,hashlib
O=Path(__file__).resolve().parent
for s in json.loads((O/'download_manifest.json').read_text()):
 p=O/s['file']
 if not p.exists():p.write_bytes(urllib.request.urlopen(s['url'],timeout=55).read())
 digest=hashlib.sha256(p.read_bytes()).hexdigest()
 if digest!=s['sha256']:raise RuntimeError(f"{p.name}: source bytes changed; retain this new vintage separately, do not overwrite expected hashes.")
 print(p.name,'verified',len(p.read_bytes()))

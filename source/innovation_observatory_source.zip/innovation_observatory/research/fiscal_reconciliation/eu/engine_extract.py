"""Rebuild all28 European fiscal matrices using frozen official JSON-stat files.
No missing observation is converted into an observed zero. Percentages are
recomputed with one annual nominal GDP denominator (not rounded PC_GDP).
"""
from pathlib import Path
import json,hashlib,csv
O=Path(__file__).resolve().parent;R=O.parents[2]
load=lambda n:json.loads((O/(n+'.json')).read_text())
main,gdp,func,tax=[load(n)for n in ['main','gdp','functions','taxes']]
def cell(d,**q):
 i=0;s={}
 for k,n in zip(d['id'],d['size']):
  index=d['dimension'][k]['category']['index'];v=q.get(k,next(iter(index)));s[k]=v
  if v not in index:return None,'absent category',s
  i=i*n+index[v]
 return d.get('value',{}).get(str(i)),d.get('status',{}).get(str(i),''),s
M={
'revenue':'TR','expenditure':'TE','balance':'B9','governmentConsumption':'P3','publicGFCF':'P51G','grossCapitalFormation':'P5','inventoryValuablesInvestment':'P52_P53','netNonProducedAssets':'NP','capitalFormationAndNonProducedAssets':'OP5ANP','consumptionFixedCapital':'P51C','publicWagesCompensation':'D1PAY','publicWagesSalaries':'D11PAY','employerContributionsPaid':'D12PAY','intermediateConsumption':'P2','otherProductionTaxesPaid':'D29PAY','subsidiesPaid':'D3PAY','propertyIncomePaid':'D4PAY','interestPaid':'D41PAY','interestPaidBeforeFISIM':'D41GPAY','otherPropertyIncomePaid':'D42_TO_D45PAY','currentTaxesPaid':'D5PAY','cashSocialBenefits':'D62PAY','inKindPurchasedBenefits':'D632PAY','cashAndPurchasedBenefits':'D62_D632PAY','currentTransfersPaid':'D7PAY','pensionEntitlementAdjustment':'D8','capitalTransfersPaid':'D9PAY','investmentGrantsPaid':'D92PAY','otherCapitalTransfersPaid':'D99PAY','salesIncludingOwnAccount':'P11_P12_P131','marketAndOwnAccountOutput':'P11_P12','marketSales':'P11','ownAccountOutput':'P12','nonmarketSalesFees':'P131','taxesProductionImports':'D2REC','VAT':'D211REC','productTaxes':'D21REC','otherProductionTaxesReceived':'D29REC','subsidiesReceived':'D39REC','propertyIncomeReceived':'D4REC','interestReceived':'D41REC','dividendsReceived':'D42REC','otherPropertyIncomeReceived':'D42_TO_D45REC','currentIncomeWealthTaxes':'D5REC','incomeTaxes':'D51REC','householdIncomeTaxes':'D51A_C1REC','corporateIncomeTaxes':'D51B_C2REC','otherCurrentTaxes':'D59REC','netSocialContributions':'D61REC','employerActualContributions':'D611REC','householdActualContributions':'D613REC','currentTransfersReceived':'D7REC','capitalTransfersReceived':'D9REC','capitalTaxes':'D91REC','otherCapitalTransfersReceived':'D99REC','netOperatingSurplus':'B2N','oldAgeCashMain':'D62PAY_GF1002','survivorCashMain':'D62PAY_GF1003','unemploymentCashMain':'D62PAY_GF1005','currentInternationalTransfersPaid':'D74PAY','EUOwnResourcesPaid':'D76PAY','EUCurrentTransfersReceived':'D7REC_S212','foreignCapitalTransfersPaid':'D9PAY_S2','foreignCapitalTransfersReceived':'D9REC_S2'}
RK=['salesIncludingOwnAccount','taxesProductionImports','subsidiesReceived','propertyIncomeReceived','currentIncomeWealthTaxes','netSocialContributions','currentTransfersReceived','capitalTransfersReceived']
EK=['intermediateConsumption','publicWagesCompensation','otherProductionTaxesPaid','subsidiesPaid','propertyIncomePaid','currentTaxesPaid','cashSocialBenefits','inKindPurchasedBenefits','currentTransfersPaid','pensionEntitlementAdjustment','capitalTransfersPaid','grossCapitalFormation','netNonProducedAssets']
countries={};csvrows=[];fills=[];coverage=[]
profiles=json.loads((R/'dist/data/profiles.json').read_text())
for p in profiles:
 if p['code']in ['USA','CHN']:continue
 cc,geo=p['code'],p['geo'];country={'code':cc,'geo':geo,'name':p['name'],'years':{}}
 for year in [2023,2024,2025]:
  yr=str(year);GDP,gflag,gcoord=cell(gdp,geo=geo,time=yr)
  vals,flags,coords,pcts={}, {}, {}, {}
  for k,item in M.items():
   value,flag,coord=cell(main,geo=geo,time=yr,unit='MIO_EUR',na_item=item);vals[k]=value;flags[k]=flag;coords[k]=coord;pcts[k]=cell(main,geo=geo,time=yr,unit='PC_GDP',na_item=item)[0]
  resolved=dict(vals);resolution={}
  if year==2023:
   for k,item in [('householdIncomeTaxes','D51A_C1'),('corporateIncomeTaxes','D51B_C2')]:
    if resolved[k]is None:
     value,flag,coord=cell(tax,geo=geo,time=yr,na_item=item)
     if value is not None:
      resolved[k]=value;resolution[k]={'source':'gov_10a_taxag','file':'taxes.json','valueMillionEUR':value,'flag':flag,'selection':coord};fills.append({'country':cc,'field':k,**resolution[k]})
  ratio=lambda v:None if v is None or GDP is None else 100*v/GDP
  def derived(v):
   out={}
   if v['revenue']is not None:out['unresolvedRevenueComponentResidual']=v['revenue']-sum(v[k]for k in RK if v[k]is not None)
   if v['expenditure']is not None:out['unresolvedExpenditureComponentResidual']=v['expenditure']-sum(v[k]for k in EK if v[k]is not None)
   if all(v[k]is not None for k in ['revenue','capitalTransfersReceived']):out['currentRevenue']=v['revenue']-v['capitalTransfersReceived']
   if all(v[k]is not None for k in ['expenditure','grossCapitalFormation','netNonProducedAssets','capitalTransfersPaid']):out['currentExpenditure']=v['expenditure']-v['grossCapitalFormation']-v['netNonProducedAssets']-v['capitalTransfersPaid']
   if all(v[k]is not None for k in ['netSocialContributions','employerActualContributions','householdActualContributions']):out['mixedSocialContributionResidual']=v['netSocialContributions']-v['employerActualContributions']-v['householdActualContributions']
   return out
  der=derived(resolved);fs,ffs={},{}
  for fun in func['dimension']['cofog99']['category']['index']:
   fvalues,fflags={},{}
   for item in func['dimension']['na_item']['category']['index']:
    value,flag,coord=cell(func,geo=geo,time=yr,cofog99=fun,na_item=item)
    if value is not None:fvalues[item]=value
    if flag:fflags[item]=flag
   if fvalues:
    if 'D62'in fvalues:fvalues['D62PAY']=fvalues['D62'] # explicit alias, not additive
    fs[fun]=fvalues
   if fflags:ffs[fun]=fflags
  residual=None if any(vals[k]is None for k in ['revenue','expenditure','balance'])else vals['revenue']-vals['expenditure']-vals['balance']
  z=dict(GDPmillionEUR=GDP,GDPFlag=gflag,GDPSelection=gcoord,valuesMillionEUR=vals,valuesPctGDP={k:ratio(v)for k,v in vals.items()},resolvedValuesMillionEUR=resolved,resolvedValuesPctGDP={k:ratio(v)for k,v in resolved.items()},publishedPctGDP=pcts,sourceFlags=flags,sourceCoordinates=coords,sourceResolution=resolution,derivedMillionEUR=der,derivedPctGDP={k:ratio(v)for k,v in der.items()},missingRevenueComponents=[k for k in RK if resolved[k]is None],missingExpenditureComponents=[k for k in EK if resolved[k]is None],sourceBalanceResidualMillionEUR=residual,functionsMillionEUR=fs,functionalFlags=ffs)
  country['years'][yr]=z
  for k in M:csvrows.append({'code':cc,'name':p['name'],'year':year,'field':k,'na_item':M[k],'millionEUR':resolved[k],'GDPmillionEUR':GDP,'percentGDP':ratio(resolved[k]),'flag':flags[k],'resolutionSource':resolution.get(k,{}).get('source','gov_10a_main')})
  coverage.append({'country':cc,'year':year,'GDP':GDP,'revenue':vals['revenue'],'expenditure':vals['expenditure'],'balance':vals['balance'],'balanceResidualMillionEUR':residual,'missingRevenueComponents':z['missingRevenueComponents'],'missingExpenditureComponents':z['missingExpenditureComponents'],'functions':len(fs),'defenseTE':fs.get('GF02',{}).get('TE'),'defenseP3':fs.get('GF02',{}).get('P3'),'defenseRAndDTE':fs.get('GF0204',{}).get('TE')})
 countries[cc]=country
out=dict(sourceYear=2023,source='Eurostat consolidated general-government S13 fiscal, tax and COFOG accounts; annual nominal GDP from nama_10_gdp',sources=json.loads((O/'download_manifest.json').read_text()),countryCount=len(countries),fieldMapping=M,nonOverlappingRevenueKeys=RK,nonOverlappingExpenditureKeys=EK,countries=countries,sourceResolutionFills=fills,limitations=['GDP denominators use the11November2026 national-accounts release while main fiscal data use21October2026. PublishedPC_GDP ratios are retained separately and can differ due to rounding and revision.','Missing source observations staynull; unresolved residuals do not prove a particular missing component is zero.','Denmark2025revenue remains unavailable; do not infer it by adding expenditure and EDPbalance.','P3 government consumption overlaps employee compensation/intermediate purchases, includes noncash CFC and deducts sales. Do not add P3 to those components.','Functional COFOG TE is an alternative classification to economic TE components. GF0204 is R&Ddefence functional expenditure, not a measured causal civilian spillover or guaranteed productivity return.','Some D62PAY aliases infunctions are copies of rawCOFOGD62 for interoperability; do not add aliases.'])
(O/'engine_inputs.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
(O/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
with (O/'fiscal_lines.csv').open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=list(csvrows[0]));w.writeheader();w.writerows(csvrows)
assert len(countries)==28
for c in countries.values():
 z=c['years']['2023'];assert all(z['resolvedValuesMillionEUR'][k]is not None for k in ['revenue','expenditure','balance','governmentConsumption','cashSocialBenefits','grossCapitalFormation','capitalTransfersPaid','capitalTransfersReceived','netNonProducedAssets','corporateIncomeTaxes','currentIncomeWealthTaxes','netSocialContributions'])
 assert abs(z['sourceBalanceResidualMillionEUR'])<=1.01
for s in out['sources']:assert hashlib.sha256((O/s['file']).read_bytes()).hexdigest()==s['sha256']
print(json.dumps({'countries':len(countries),'taxSplitsFilled':len(fills),'coverage2023':[x for x in coverage if x['year']==2023],'Denmark2025':countries['DNK']['years']['2025']['valuesPctGDP']['revenue']},indent=2))

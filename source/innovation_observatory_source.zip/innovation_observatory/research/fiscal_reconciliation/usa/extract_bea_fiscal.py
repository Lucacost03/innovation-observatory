"""Reproduce US fiscal observations from retained annual BEA XLSX source cells.
Run with Python3 + openpyxl. Source units are millions USD; output amounts billions.
Raw spreadsheets can be re-downloaded at the exact URLs in manifest.json.
"""
from pathlib import Path
import json,csv,hashlib
import openpyxl
R=Path(__file__).resolve().parent
manifest=json.loads((R/'manifest.json').read_text())
for m in manifest:
 assert hashlib.sha256((R/m['file']).read_bytes()).hexdigest()==m['sha256'],m['file']
books={n:openpyxl.load_workbook(R/f'Section{n}All.xlsx',read_only=True,data_only=True)for n in [1,2,3,7]}
tables={};observations=[]
for n,names in {1:['T10105-A'],2:['T20100-A'],3:['T30100-A','T30905-A','T31005-A','T31105-A','T31200-A','T31505-A','T31600-A','T31700-A'],7:['T70900-A','T71100-A','T72300-A','T72400-A']}.items():
 for name in names:
  rs=list(books[n][name].values);header=next(x for x in rs if x[0]=='Line');cols={y:header.index(str(y))for y in [2023,2024,2025]};pub=rs[4][0];tables[name]={}
  for i,row in enumerate(rs,1):
   if row[0]and str(row[0]).isdigit():
    line=int(row[0]);
    if name=='T20100-A'and line>34:continue
    tables[name][line]={}
    for year,col in cols.items():
     raw=row[col];value=raw/1000 if isinstance(raw,(int,float))else None
     entry=dict(table=name,line=line,label=row[1].strip(),seriesCode=row[2],year=year,rawValue=raw,rawUnit='million USD',billionUSD=value,sourceFile=f'Section{n}All.xlsx',cell=openpyxl.utils.get_column_letter(col+1)+str(i),published=pub,status='observed'if value is not None else 'unavailable')
     tables[name][line][year]=entry;observations.append(entry)
def get(table,line,year):return tables[table][line][year]['billionUSD']
def item(table,line,year,label=None):
 e=tables[table][line][year];return dict(label=label or e['label'],billionUSD=e['billionUSD'],percentGDP=100*e['billionUSD']/get('T10105-A',1,year)if e['billionUSD']is not None else None,table=table,line=line,seriesCode=e['seriesCode'],cell=e['cell'],published=e['published'],status=e['status'])
anchors={}
for y in [2023,2024,2025]:
 g=get('T10105-A',1,y);v=lambda t,l:get(t,l,y);a=lambda n: v('T30100-A',n)
 summary={'socialSecurityRetirementAndDependentsSubset':{2023:1072.644,2024:1154.994,2025:1265.933}[y],'GDP':g,'currentRevenue':a(1),'currentExpenditure':a(20),'currentBalance':a(1)-a(20),'totalRevenue':a(34),'totalExpenditure':a(37),'netLendingBorrowing':a(43),'governmentConsumption':a(21),'governmentGrossInvestment':a(39),'governmentSalesOtherSectors':v('T31005-A',11),'governmentGeneralOwnAccountInvestment':v('T31005-A',10),'governmentConsumptionFixedCapital':v('T31005-A',5),'governmentConsumptionCashNetSalesProxy':a(21)-v('T31005-A',5),'grossedRevenueIncludingGeneralGovernmentSalesProxy':a(34)+v('T31005-A',11),'grossedExpenditureIncludingGeneralGovernmentSalesProxy':a(37)+v('T31005-A',11),'MedicareBenefits':v('T31200-A',6),'MedicaidBenefits':v('T31200-A',33),'unemploymentInsuranceBenefits':v('T31200-A',7),'socialBenefitsToPersons':a(24),'socialBenefitsToPersonsMinusMedicareMedicaidProxy':a(24)-v('T31200-A',6)-v('T31200-A',33),'socialSecurityOASDIBenefits':v('T31200-A',5),'healthConsumption':v('T31700-A',7),'educationConsumption':v('T31700-A',9),'healthCurrentTotal':v('T31600-A',28),'educationCurrentTotal':v('T31600-A',30),'publicEmployeeDBPensionImputedInterestOnGovEmployerClaims':v('T71100-A',50),'governmentCashInterestProxyExcludingDBImputedClaims':a(27)-v('T71100-A',50),'totalGovernmentInterest':a(27),'federalPublicEmployeeDBBenefitWithdrawals':v('T72300-A',26),'stateLocalPublicEmployeeDBBenefitWithdrawals':v('T72400-A',20),'disposablePersonalIncome':v('T20100-A',27),'netOwnerRentalIncome':v('T70900-A',9)+v('T70900-A',12),'partialCashIncomeProxyExcludingMedicareMedicaidAndNetOwnerRent':v('T20100-A',27)-v('T31200-A',6)-v('T31200-A',33)-v('T70900-A',9)-v('T70900-A',12),'defenseConsumption':v('T30905-A',18),'defenseGrossInvestment':v('T30905-A',19),'defenseConsumptionAndInvestment':v('T30905-A',17),'defenseResearchInvestment':v('T30905-A',24),'defenseCurrentFunctionalExpense':v('T31600-A',7),'defenseCompensation':v('T31105-A',5),'defenseIntermediatePurchases':v('T31105-A',9),'defenseConsumptionFixedCapital':v('T31105-A',8),'defenseOwnAccountInvestment':v('T31105-A',27),'defenseSalesToOtherSectors':v('T31105-A',28),'allGovernmentResearchInvestment':v('T30905-A',8)}
 revLabels={3:'Personal current taxes',4:'Production/import taxes',5:'Corporate income taxes',6:'Taxes from foreign residents',8:'Social insurance contributions from persons',9:'Social contributions from abroad',12:'Interest receipts',13:'Rent and royalty receipts',14:'Dividend receipts',16:'Other current transfers from business',17:'Other current transfers from persons',18:'Other current transfers from abroad',19:'Government enterprise current surplus, signed'}
 expLabels={21:'Government consumption expenditure, includes noncash CFC',24:'Social benefits to persons',25:'Social benefits to the rest of world',26:'Other current transfers to the rest of world',28:'Interest to persons and businesses',29:'Interest to the rest of world',30:'Subsidies'}
 capLabels={39:'Gross public investment (not an extra addition to total national investment)',40:'Capital transfers paid',41:'Net purchases of nonproduced assets',42:'Noncash consumption of fixed capital, subtract in total-expenditure bridge',36:'Capital transfers received'}
 rev=[item('T30100-A',l,y,label)for l,label in revLabels.items()];exp=[item('T30100-A',l,y,label)for l,label in expLabels.items()];cap=[item('T30100-A',l,y,label)for l,label in capLabels.items()]
 checks=dict(revenueRoundingBillionUSD=a(1)-sum(x['billionUSD']for x in rev),expenseRoundingBillionUSD=a(20)-sum(x['billionUSD']for x in exp),totalRevenueBridgeResidual=a(34)-a(1)-a(36),totalExpenseBridgeResidual=a(37)-a(20)-a(39)-a(40)-a(41)+a(42))
 assert all(abs(x)<.003 for x in checks.values()),checks
 anchors[str(y)]=dict(retirementSubsetSource={'url':'https://www.ssa.gov/OACT/STATS/table4a5.html','year':y,'coordinate':'Retired workers + wives/husbands + dependent children, millionUSD; excludes survivors/disability','scope':'SSA OASI retirement and dependents subset, not all public pensions'},summary={k:dict(billionUSD=v,percentGDP=100*v/g)for k,v in summary.items()},revenueItems=rev,expenseItems=exp,capitalBridgeItems=cap,checks=checks,defenseItems=[item('T31105-A',l,y)for l in [1,2,5,6,7,8,9,27,28,29,30,31,38,39,40]])
result=dict(country='USA',sourceYear=2023,latestCompleteReferenceYear=2025,source='BEA NIPA annual tables; October29,2026 download vintage (table-specific publication dates retained)',sourceUnits='MillionsUSD; all billionUSD fields divide the workbook cell by1000 exactly',countryScope='Federal,state,andlocal government consolidated in NIPA3.1; do not add3.2and3.3without eliminating intergovernment transfers',anchors=anchors,methodologySources=['https://www.bea.gov/data/government/receipts-and-expenditures','https://www.bea.gov/resources/methodologies/nipa-handbook/pdf/chapter-9.pdf'],limitations=['2023opening statistics are revised observations, not a real-time2023information vintage. Latest2024/25references are separate.','NIPA government consumption is net of government sales and includes noncash capital consumption. Sales-grossed totals are comparison proxies, not exact published IMF/GFSM totals.','Medicare/Medicaid are not unrestricted cash benefits. The remaining benefit aggregate also includes noncash SNAP, education and other items; it is not a fully verified cash aggregate.','Subtract NET owner rental income, not gross imputed rent, from DPI when making a partial cash-income proxy. Other pension, insurance and FISIM imputations remain.','Public-employee DB imputed interest creates a noncash pension claim, not a freely spendable bank deposit. Funded DB withdrawals are financial-asset transactions, not another current government social benefit.','National-defense R&D is BEA-produced R&D investment, not a causal civilian TFP elasticity or an extra addition to GDP. Current defense function and consumption-plus-investment have different scope; do not add them.'])
(R/'USA_fiscal_anchors.json').write_text(json.dumps(result,indent=2)+'\n');(R/'BEA_fiscal_observations.json').write_text(json.dumps(observations,indent=2)+'\n')
with(R/'BEA_fiscal_observations.csv').open('w')as f:
 writer=csv.DictWriter(f,fieldnames=list(observations[0]));writer.writeheader();writer.writerows(observations)
print(json.dumps({'years':list(anchors),'observations':len(observations),'checks':{y:a['checks']for y,a in anchors.items()},'2023GDP':anchors['2023']['summary']['GDP']},indent=2))

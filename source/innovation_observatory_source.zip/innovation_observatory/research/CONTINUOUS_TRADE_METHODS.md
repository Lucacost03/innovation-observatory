# Continuous export bids — engine 1.24.0

This release addresses a numerical market-clearing artifact found while continuing the current-account and productivity audit. It does not introduce a new empirical TFP target or force a country's trade balance to keep its historical sign.

## The artifact and correction

The prior market represented 90% of foreign orders in four equal blocks bidding 0.90, 0.97, 1.03 and 1.10 times the base foreign bid. Ten percent were repeat customers paying at least 1.01 times the domestic bid. Domestic orders were a separate block. Sorting these point masses gave large discontinuous reallocations when a small price change moved a foreign block past the domestic price.

In a controlled 100-unit order book with 100 available goods and domestic demand of 100, moving the base foreign bid from 1/1.03−1e−8 to 1/1.03+1e−8 raised exports from 32.5 to 55 units, despite the negligible price change. The continuous version moves exports from 44.9999965 to 45.0000035. This is a numerical continuity check, not an empirical elasticity estimate.

The revised 90% component is uniform over 0.865–1.135 times the base bid. This interval extends about half a typical old grid spacing beyond the outer bracket centers. Its mean multiplier is 1.0, exactly the old four-block mean; the total quantity of foreign orders and the 10% repeat-customer component are preserved. The interval and distribution shape are a declared smoothing choice, not fitted data. No range, elasticity, demand-growth rate or R&D parameter was searched against later observations.

The algorithm cuts the continuous distribution at the domestic and repeat-customer bid prices. It then clears in descending bid order. If supply runs out inside a segment, only its highest bids are filled, and receipts integrate those prices rather than averaging the entire unfilled segment. Firm allocations account for inventory exhaustion during each tranche. No output, deposits or foreign demand are manufactured. The earlier rule remains available through the advanced `continuousForeignBids=0` comparison setting; source presets use 1.

## Independent checks and comparative evidence

A separately frozen old market module checks legacy replay. Independent dense lists of 20,000 foreign buyers check the continuous solution across ample supply, scarce supply, different price offers and different domestic demand. Other checks cover goods conservation, nonnegative inventories, unfilled low bids, full-order quantity and average-receipt preservation, saved scenarios, parameter timing and no effect from future changes.

The main study runs all 30 presets × 5 common seeds × 2 rules × 40 annual steps: 300 paths and 12,000 years, with two additional 12-year timing paths. All outcomes are retained. It verifies independently calculated S−I=CA and transaction ΔNFA=CA, positive gross foreign channels and finite financial/goods accounting results. The maximum relative accounting gap is below 3e−14.

The 29 individual countries are pooled without duplicating the EU aggregate. Available 2024/2025 current accounts supply 57 country-year observations, each compared across five seeds (285 model-observation pairs). Current-account MAE falls from 2.003834 to 1.987469 percentage points of GDP, RMSE from 2.707563 to 2.692350. China MAE falls from 3.095040 to 2.972590; the USA and EU aggregate barely change. Bulgaria, Croatia, Luxembourg and Poland have small error increases. The improvement is modest and is not universal.

Real GDP growth is annualized from the 2023origin and compared with 58 country-year observations, each across five seeds. RMSE changes from 4.369757 to 4.368890 percentage points: effectively unchanged and still poor. The EU aggregate is reported separately. Source targets use frozen Eurostat chain-volume growth, BEA's September 2026 annual revisions for USA 2024/2025 (3.0%,2.3%), NBS final2024 growth and preliminary 2025 growth for China (both 5.0%). Official web-table coordinates and dates are retained; raw HTML is not archived for those four supplemental observations. Two World Bank API attempts timed out, so no WDI observation was invented. Source vintages are disclosed and not presented as information available in 2023.

The acceptance criterion was removal of the numerical jump, lower all-country retrospective CA MAE, and no GDP RMSE increase greater than 0.25pp. It was recorded after a preliminary USA/China/EU screen and before inspection of the all-country result; this is not an ex-ante preregistration. The tested outcomes and revised source vintages have already been examined, so no untouched holdout or statistical confidence interval is claimed. Five seeds are simulation variation, not five independent historical data sets.

## Retained weaknesses

Long-run behavior remains mixed. Across the 150 paths per rule, low-employment years (employment below 50% of the labor force) increase from 261 to 290; years at the nominal currency bounds increase from 411 to 417. Other foreign-income cash shortfalls decrease in aggregate. These screening cutoffs are assumptions and not empirical forecast targets. Long-run paths do not become validated because the market-clearing calculation is smoother. The new numerical rule is enabled for source presets because it removes an artificial point-mass sensitivity and modestly improves the available current-account comparison; the earlier rule remains reviewable rather than being deleted.

Source 2023 current accounts, PWT historical TFP benchmarks and country-specific OECD conditional frontier paths from 1.23 are retained. None of these fixes establishes a permanent USA-versus-EU future TFP ranking. Causal policy multipliers and broader long-run GDP dynamics remain unvalidated.

## Reproduction

Run `node tests/continuous-bids.mjs` or the full `npm test`. The test writes `dist/data/trade_bid_validation.json`, including every country/seed comparison and long-run summary. `research/trade_bid_candidates/protocol.json` records the decision rule and preliminary-screen disclosure. `manifest.json` hashes the frozen Eurostat snapshot and the extracted USA/China observation file; the latter hash verifies the extracted file, not raw official HTML. The frozen 1.23 market module supports replay. The opening export-order calibrator now calls exactly one `Economy.step(1,1)` instead of generating eight steps to read the first one; fitted export-sales moments remain within the same tolerance.

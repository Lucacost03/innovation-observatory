# Country-specific allocations in the other sectors

Research only, 12 November 2026. No application, behavioural equation, profile or Git edits were made.

## Ready for the website audit

`existing_applied_ratios.json` contains every country and EU27 with four existing allocation records, their observed or proxy target, current preset proportion, scope, source URL and assumed/proxy/derived status. `extract_existing.py` reproduces the file from current profiles and frozen input benchmarks.

- **Households:** all 28 foreign securities-order proportions reproduce their existing country-specific ECB QSA portfolio stock proxy exactly. The target is foreign F3+F511 / the same total F3+F511 basket. Twenty-two presets include fund look-through; Czechia, Denmark, Hungary, Poland, Romania and Sweden use direct holdings. EU27 uses the extra-euro-area I9 proxy, not observed consolidated extra-EU holdings. This is an observed stock composition mapped to order weights, not an estimated annual propensity. Realised foreign purchases may differ because orders need financing and unfilled domestic orders can move abroad when the current account permits.
- **Firms:** 24 business R&D labour-cost / total GERD shares are matched. France, Ireland, Netherlands and EU27 retain explicit 60% assumptions. Those four records have `targetPct: null`, `appliedPct: 60`, `basis: assumed`; do not show them as empirical matches. The share allocates the existing research budget to payroll. The source's non-labour part is still a benchmark, not a separately financed model cost.
- **Households/firms:** all 28 residential-investment proportions use country-specific dwelling GFCF / total GFCF proxies. This already allocates the existing fixed-investment envelope. National GFCF includes broader sectors than the model's investor accounts, so the mapping is a proxy.
- **Firms/government:** 26 public research business-grant proportions have matched funding data; Bulgaria and EU27 retain the current explicit fallback. The JSON uses null empirical targets for assumed cases. These ratios apply to the public research envelope, not total government expenditure.

`appliedPct` in this file refers to the current **preset**. A live sector view should recalculate configured proportions from that simulation's effective parameters at the selected year, including user edits and paths. Label them "configured allocation" rather than claiming every realized expenditure has that ratio: credit constraints and unfilled orders can alter realised outcomes.

## Where forcing a percentage would change its meaning

The 0.9 propensity to consume from lagged income and the separate deposit draw are unestimated marginal/behavioural rules. Observed average consumption/disposable-income is not a valid one-for-one replacement: deposit spending, housing services, saving and time lags already enter elsewhere.

The 20% bank share of public debt is an assumed opening-holder allocation. The model omits much of the observed issuer-holder matrix and foreign government-bond ownership. Raising this to a national financial-sector stock share without supplying matching liabilities and checking reserves can invalidate the opening balance sheet. Likewise, financial-sector interest receipts, lending capacity and risk weights cannot be replaced by a single revenue percentage without changing the model's banking contracts and market structure.

Existing domestic market weights are venture 50, other business equity 15, corporate bonds 15, government bonds 20. The existing QSA F3/F511 data can identify broad domestic debt/listed-share composition, but F3 mixes government, financial and nonfinancial issuers and F511 excludes venture and unlisted equity. `rejected_broad_domestic_composition.json` records this tempting but non-comparable mapping; it is deliberately not selected.

## Additional issuer data investigated, not selected

A broad QSA issuer-sector query returned HTTP404. The corresponding official ECB SHSS query succeeded and its raw response/manifest are retained as `shss_domestic_household_issuers_2023.csv` and `shss_manifest.json`: 66 records, three instruments/issuer combinations for 21 national reference areas plus U2. The query is household/NPISH direct domestic holdings at market value, 2023Q4: S11 F3, S11 F511, S13 F3. These are a narrower scope than the existing QSA fund-look-through basket and leave six non-euro-area preset countries without direct matches. EU27 would again need an explicitly labelled euro-area proxy. No stock-derived annual-flow rule was estimated or simulated here and no candidate is recommended without the root owner's controlled evaluation.

Primary methodology:

- ECB sector accounts: https://www.ecb.europa.eu/stats/macroeconomic_and_sectoral/sector_accounts/html/index.en.html
- ECB household investment fund look-through: https://www.ecb.europa.eu/stats/pdf/Looking_through_note.en.pdf
- ECB SHSS data information: https://data.ecb.europa.eu/data/datasets/SHSS/data-information
- ECB SHSS methodology: https://data.ecb.europa.eu/methodology/securities-holdings-statistics

The official SHSS documentation describes selected euro-area holder sectors, security-by-security coverage, and restrictions for detailed issuer-country government securities. Securities held through funds are not automatically the same as direct household holdings.

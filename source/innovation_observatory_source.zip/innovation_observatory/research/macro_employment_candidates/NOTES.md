# Opening employment: 2023, ages 15–64

The Eurostat API snapshot was accessed on 12 November 2026 and reports an
underlying update of 6 November 2026. It is a revised 2023 observation, not a
live 2026 starting value. The Observatory's other opening accounts use 2023,
so retaining that year avoids combining incompatible starting years.

## Definitions and results

`lfsi_emp_a`, annual, total sex, ages `Y15-64`, contains both employed persons
(`EMP_LFS`) and the labour force (`ACT`) in both thousand persons and percent
of the population. All four observations are present for each of the 27
member countries and the EU27 aggregate. `benchmark.json` retains every used
source observation and flag; `manifest.json` retains the exact URLs, dataset
vintages and SHA256 hashes. `python3 extract.py` reproduces the benchmark
offline. Use `--refresh` only to intentionally revise the vintage.

| Economy | Employment / population 15–64 | Labour force / population 15–64 |
| --- | ---: | ---: |
| Italy | 61.5% | 66.7% |
| EU27 | 70.4% | 75.0% |
| Germany | 77.3% | 79.8% |
| Netherlands | 82.4% | 85.5% |

The existing model's roughly 92% Italian starting employment is employment
divided by the active labour force. That denominator excludes people outside
the labour force. It is therefore not evidence that 92% of working-age
residents work. The previous input additionally used unemployment ages15–74
while the population module uses a15–64 working-age cohort. A correction can
align the age group and expose the missing inactive share.

Recommended primary display: **Employed residents, ages15–64 (% of that age
group)**. Retain the internal firm's employed/active-labour-force matching
concept, clearly labelled. Show participation and inactivity separately;
do not move all inactive people into unemployment, and do not replace the
internal employed/LF ratio with the61.5% employment/population observation.

The benchmark provides the count-derived employed/LF ratio
`100 * EMP_LFS(THS_PER) / ACT(THS_PER)`. The population rates and person counts
are independently rounded by the publisher. Multiplying that ratio by the
published participation rate can differ from the published employment/pop
rate by up to0.09094percentage points. For an opening display that reproduces
both published population rates exactly, derive employed/LF from the two
published `PC_POP` observations instead; label this as a rounded-rate
derivation and use the counts as a rounding check. Either is defensible if
the chosen numerical mapping is documented rather than presented as extra
measurement precision.

## Transitions

The downloaded `lfsi_long_a` dimensions are `freq,unit,wstatus,sex,geo,time`.
There is no selectable age dimension in this official annual table. Its
broader15–74 transitions should therefore stay explicitly labelled as a
proxy if used with the corrected15–64 opening rates. Existing two-state
conditioning also excludes the third inactive endpoint; it does not estimate
an endogenous participation response. Eurostat's longitudinal metadata
describes the15–74 population, survey matching, sampling limitations and
experimental breakdowns. Do not claim these transition parameters are an
exact age15–64 estimate or that the model now forecasts inactivity behaviour.

## Official references

- [Dataset](https://ec.europa.eu/eurostat/databrowser/view/lfsi_emp_a/default/table?lang=en)
- [Main-indicator definitions](https://ec.europa.eu/eurostat/cache/metadata/en/lfsi_esms.htm)
- [Participation definition](https://ec.europa.eu/eurostat/cache/metadata/en/tipslm60_esms.htm)
- [Transition metadata](https://ec.europa.eu/eurostat/cache/metadata/en/lfsi_long_esms.htm)

The main-indicator metadata distinguishes employment/population, unemployment/
labour force and activity/population. These are three different ratios. The
15–64 choice is consistent with the current model's working-age cohort; it
does not make the Eurostat headline20–64 employment series interchangeable.

"""Freeze/verify the age-consistent 2023 labour opening benchmark.

Run without arguments to reproduce from the bundled snapshots. Run --refresh
to download a newer data vintage; that is an explicit benchmark revision.
This script writes only its own research directory, never application files.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import csv
import hashlib
import json
import urllib.request

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCES = {
    'employment_2023': 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lfsi_emp_a?lang=en&freq=A&age=Y15-64&sex=T&time=2023',
    'transition_2023': 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lfsi_long_a?lang=en&freq=A&sex=T&time=2023',
}


def decode(dataset):
    categories = []
    for dimension in dataset['id']:
        index = dataset['dimension'][dimension]['category']['index']
        categories.append([code for code, _ in sorted(index.items(), key=lambda item: item[1])])
    rows = []
    for flat, value in dataset.get('value', {}).items():
        if value is None:
            continue
        position, indices = int(flat), []
        for size in reversed(dataset['size']):
            indices.append(position % size)
            position //= size
        row = {dimension: categories[i][index] for i, (dimension, index) in
               enumerate(zip(dataset['id'], reversed(indices)))}
        row.update(value=value, flag=dataset.get('status', {}).get(flat, ''))
        rows.append(row)
    return rows


def main():
    refresh = argparse.ArgumentParser()
    refresh.add_argument('--refresh', action='store_true')
    args = refresh.parse_args()
    manifest = []
    for name, url in SOURCES.items():
        destination = HERE / (name + '.json')
        if args.refresh or not destination.exists():
            with urllib.request.urlopen(url, timeout=90) as response:
                destination.write_bytes(response.read())
        source = json.loads(destination.read_text())
        manifest.append({'file': destination.name, 'url': url,
                         'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
                         'updated': source['updated'], 'dimensions': source['id'],
                         'observationYear': 2023})
    employment = json.loads((HERE / 'employment_2023.json').read_text())
    rows = decode(employment)
    lookup = {(row['geo'], row['indic_em'], row['unit']): row for row in rows}
    profiles = json.loads((ROOT / 'dist/data/profiles.json').read_text())
    benchmark = []
    for profile in profiles:
        geo = profile['geo']
        selected = {name: lookup[(geo, indicator, unit)] for name, indicator, unit in [
            ('employedThousands', 'EMP_LFS', 'THS_PER'),
            ('labourForceThousands', 'ACT', 'THS_PER'),
            ('employmentPopulationPct', 'EMP_LFS', 'PC_POP'),
            ('participationPct', 'ACT', 'PC_POP'),
        ]}
        employed = selected['employedThousands']['value']
        labour = selected['labourForceThousands']['value']
        assert 0 < employed < labour
        employed_lf = 100 * employed / labour
        participation = selected['participationPct']['value']
        reported_population = selected['employmentPopulationPct']['value']
        population_product = employed_lf * participation / 100
        # Each published percentage is rounded independently to 0.1pp, and
        # counts to thousands. Permit a small, disclosed rounding residual.
        assert abs(population_product - reported_population) < .11
        benchmark.append({
            'code': profile['code'], 'geo': geo, 'name': profile['name'],
            'year': 2023, 'age': 'Y15-64', 'sex': 'T',
            **{name: row['value'] for name, row in selected.items()},
            'employmentLabourForcePct': employed_lf,
            'unemploymentLabourForcePct': 100 - employed_lf,
            'unemploymentPopulationPct': participation - population_product,
            'inactivePopulationPct': 100 - participation,
            'impliedEmploymentPopulationPct': population_product,
            'publishedRoundingResidualPp': population_product - reported_population,
            'previousEmploymentLabourForcePctAge15_74': profile['params']['employmentRate'],
            'components': list(selected.values()),
            'flags': sorted({row['flag'] for row in selected.values() if row['flag']}),
        })
    assert len(benchmark) == 28
    (HERE / 'benchmark.json').write_text(json.dumps(benchmark, indent=2) + '\n')
    fields = [key for key in benchmark[0] if key not in ('components', 'flags')]
    with (HERE / 'benchmark.csv').open('w') as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        writer.writerows({key: row[key] for key in fields} for row in benchmark)
    (HERE / 'manifest.json').write_text(json.dumps({
        'accessDateUTC': '2026-11-12',
        'snapshots': manifest,
        'checks': {'economies': 28, 'requiredSourceObservations': 112,
                   'missingSourceObservations': 0,
                   'maximumPublishedRoundingResidualPp': max(abs(row['publishedRoundingResidualPp']) for row in benchmark)},
        'definitions': {
            'employmentPopulationPct': 'Employed / population ages15–64, published PC_POP.',
            'participationPct': 'Labour force / population ages15–64, published PC_POP.',
            'employmentLabourForcePct': '100 × EMP_LFS THS_PER / ACT THS_PER, both ages15–64.',
            'unemploymentLabourForcePct': '100 minus employmentLabourForcePct; derived from matching counts.',
            'inactivePopulationPct': '100 minus participationPct.',
            'transitionAgeCoverage': 'lfsi_long_a has no age dimension; age15–74 transition probabilities remain a broader-age proxy if retained with a15–64 opening benchmark.',
        },
        'metadataUrls': [
            'https://ec.europa.eu/eurostat/cache/metadata/en/lfsi_esms.htm',
            'https://ec.europa.eu/eurostat/cache/metadata/en/lfsi_long_esms.htm',
            'https://ec.europa.eu/eurostat/cache/metadata/en/tipslm60_esms.htm',
        ],
    }, indent=2) + '\n')
    print(json.dumps({'economies': len(benchmark), 'observations': 112,
                      'maxRoundingResidualPp': max(abs(row['publishedRoundingResidualPp']) for row in benchmark)}))


if __name__ == '__main__':
    main()

# Population and education input mapping

Prepared for the population, pension, education and housing extension. This file concerns empirical inputs only. It does not estimate demographic forecasts, school quality, spending elasticities or policy effects.

## Reproduce

Run `python3 scripts/population_education_inputs.py`. Frozen snapshots are reused by default. `--refresh` explicitly retrieves a new data vintage. The extractor does not edit profiles, parameter definitions, the global manifest, the engine or the interface. Outputs are `dist/data/population_education_benchmarks.json`, `research/population_education_manifest.json` and a retained capture-time sidecar. The project already supplied the frozen PWT 11 workbook.

There are 28 country/EU presets, seven source hashes and no missing selected inputs. A separate executed check is retained in `research/population_education_checks.json`; all population identities, positive education spending, cohort mortality partitions and frozen hashes passed. The maximum reconstruction error from floating-point rate conversion was 4.66e-10 persons.

| Input | Official selection | Unit and mapping |
|---|---|---|
| Opening population | `demo_gind`, `JAN`, 2023 | Persons on 1 January; divide by 1e6 for displayed millions |
| Births, deaths, migration | `demo_gind`, `LBIRTH`, `DEATH`, `CNMIGRAT`, 2023 | Counts. Divide each by the opening population and multiply by100 for annual percent parameters |
| Young and old shares | `demo_pjanind`, `PC_Y0_14`, `PC_Y65_MAX`, 2023 | Published percentages; working-age share is100 minus both |
| Deaths by cohort | `demo_magec`, sexT, unitNR, single ages, 2023 | Sum0–14 and15–64. Old deaths are total less these and unknown ages; the open age interval remains in the old residual |
| Public education funding | `gov_10a_exp`, sectorS13, functionGF09, transactionTE, unitPC_GDP, 2023 | Total government education expenditure/GDP |
| Household education funding | `nama_10_cp18`, COICOP2018CP10, unitPC_GDP, 2023 | Household education-services expenditure/GDP, domestic concept |
| Adult tertiary attainment | `edat_lfse_03`, sexT, ageY25-64, ISCED ED5-8, unitPC, 2023 | Optional descriptive benchmark; not mapped to quality |
| Human-capital stock proxy | PWT11.0 `hc`, 2023 | Schooling/assumed-returns index. EU27 is an employment-weighted mean across all27 members |

Each selected Eurostat observation retains its exact dimension selections, value and flags. Each snapshot retains a URL, source update time, captured vintage and SHA256. PWT `hc` selections and the EU employment weights are also retained. These are revised historical observations retrieved in2026, rather than the information set available in2023.

## Demographic definitions and limitations

Eurostat's published crude birth, death and net-migration rates use average population and are expressed per1000. They are retained for reference but are not silently treated as percentages. The model parameters instead use exact event counts divided by the opening stock. Thus births−deaths+net migration reproduces the observed annual population change without relying on rounded crude rates.

`CNMIGRAT` includes statistical adjustment. It is the demographic balance residual, rather than a pure observed migration-policy response. Repeating2023 rates is an extrapolation and does not reproduce Eurostat population projections.

All28 presets have complete younger single-age mortality observations; none has unknown-age deaths in the selected data. The old-age residual avoids treating an open final-age category as missing deaths. The observed shares can calibrate annual cohort hazards as `(aggregate death fraction × cohort death share) / opening cohort population share`. Holding those hazards fixed allows total mortality to respond to aging. A fixed future allocation of migration by age, fractional cohort aging, a labour-force participation ratio and a legal retirement-age interpretation are separate modeling assumptions. Age65+ is not equivalent to all pension recipients, and ages15–64 are not equivalent to the labour force.

## Education definitions and limitations

The legacy `nama_10_co3_p3` table lacked2023 household education data for18 selected presets. The extractor uses the current COICOP2018 table instead, obtaining observations for all28 presets. The unused legacy snapshot is retained as a trace of the rejected data path; it is not a fallback and is not used to calibrate the new inputs.

Government COFOG total education expenditure is broader than final consumption: it includes capital spending and transfers. A model allocation within the existing public-purchase budget is therefore a proxy. It must not add a second copy of already financed education, university research or grants. Household payments can go to public as well as private providers; funding source and provider ownership are distinct. COICOP2018 uses the domestic concept, including locally purchased education by non-residents and excluding resident purchases abroad.

Neither expenditure/GDP nor adult tertiary attainment identifies school quality. PWT `hc` uses schooling quantity and assumed returns; its own methodology does not capture schooling quality. A model may expose independent public/private teaching-quality scenarios and a delayed human-capital response, but those coefficients should remain labeled assumptions. OECD PISA reports associations between spending and performance with strong variation and diminishing relationships; it does not establish a universal causal spending-to-productivity coefficient or superiority of one funding model.

## Primary definitions

- Eurostat demographic balance metadata: https://ec.europa.eu/eurostat/cache/metadata/en/demo_gind_esms.htm
- Eurostat COFOG metadata: https://ec.europa.eu/eurostat/cache/metadata/en/gov_10a_exp_esms.htm
- Eurostat COICOP2018 metadata: https://ec.europa.eu/eurostat/cache/metadata/en/nama_10_cp18_esms.htm
- Eurostat educational attainment: https://ec.europa.eu/eurostat/databrowser/view/edat_lfse_03/default/table
- PWT human-capital methodology: https://www.rug.nl/ggdc/docs/human_capital_in_pwt_90.pdf
- PWT original methodological paper: https://www.rug.nl/ggdc/docs/the_next_generation_of_the_penn_world_table.pdf
- OECD PISA2022 learning resources: https://www.oecd.org/en/publications/pisa-2022-results-volume-ii_a97db61c-en/full-report/component-12.html

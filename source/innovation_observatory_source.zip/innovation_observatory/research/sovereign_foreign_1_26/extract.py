"""Frozen2023 foreign sovereign positions; source observations kept distinct from model mappings."""
from pathlib import Path
import json,hashlib,datetime,csv
from html.parser import HTMLParser
class HTMLRows(HTMLParser):
 def __init__(self):super().__init__();self.rows=[];self.row=None;self.cell=None
 def handle_starttag(self,tag,attrs):
  if tag=='tr':self.row=[]
  if tag in['td','th']and self.row is not None:self.cell=[]
 def handle_data(self,data):
  if self.cell is not None:self.cell.append(data)
 def handle_endtag(self,tag):
  if tag in['td','th']and self.cell is not None:self.row.append(' '.join(' '.join(self.cell).split()));self.cell=None
  if tag=='tr'and self.row is not None:self.rows.append(self.row);self.row=None

R=Path(__file__).resolve().parent;ROOT=R.parents[1]
read=lambda p:json.loads(p.read_text())
x=read(R/'eurostat_ggd_2023.json');profiles=read(ROOT/'dist/data/profiles.json');fiscal=read(ROOT/'dist/data/fiscal_benchmarks.json')
def observation(**sel):
 s=dict(freq='A',na_item='GD',sector2='S2',sector='S13',maturity='TOTAL',unit='MIO_EUR',time='2023');s.update(sel);i=0
 for d,n in zip(x['id'],x['size']):
  j=x['dimension'][d]['category']['index'].get(s[d]);
  if j is None:return None,None,None
  i=i*n+j
 values=x.get('value',{});flags=x.get('status',{});v=values.get(str(i))if isinstance(values,dict)else values[i];f=flags.get(str(i))if isinstance(flags,dict)else flags[i]
 return v,f,s
out={}
for p in profiles:
 c=p['code'];base=dict(name=p['name'],openingYear=2023,totalForeignGovDebtGDP=None,foreignGovSecuritiesGDP=None,foreignGovOtherDebtGDP=None,governmentDebtSecuritiesKnownSubsetGDP=None,foreignGovSecuritiesProxyGDP=None,totalGovDebtSecuritiesGDP=None,foreignShareOfGovDebtSecurities=None,foreignShareOfGovDebtSecuritiesProxy=None,observedForeignDebtSharePct=None,sourceFlags={},notes=[])
 if c not in['USA','CHN','EU27']:
  g=fiscal['countries'][c]['years']['2023']['GDP'];vals={};coords={};flags={}
  for k,selection in [('total',{'sector2':'S1_S2'}),('foreign',{}),('foreignSecurities',{'na_item':'GD_F3'}),('foreignLoans',{'na_item':'GD_F4'}),('totalSecurities',{'na_item':'GD_F3','sector2':'S1_S2'}),('residentFinancial',{'sector2':'S12'}),('centralBank',{'sector2':'S121'}),('publishedGDP',{'unit':'PC_GDP'})]:
   v,f,s=observation(geo=p['geo'],**selection);vals[k]=v;flags[k]=f;coords[k]=s
  pct=lambda v:100*v/g if v is not None else None
  assert vals['foreign']is not None and vals['total']is not None,c
  base.update(totalForeignGovDebtGDP=pct(vals['foreign']),foreignGovSecuritiesGDP=pct(vals['foreignSecurities']),foreignGovOtherDebtGDP=pct(vals['foreign']-vals['foreignSecurities'])if vals['foreignSecurities']is not None else None,totalGovDebtSecuritiesGDP=pct(vals['totalSecurities']),foreignShareOfGovDebtSecurities=100*vals['foreignSecurities']/vals['totalSecurities']if vals['foreignSecurities']is not None and vals['totalSecurities']else None,observedForeignDebtSharePct=100*vals['foreign']/vals['total'],sourceFlags=flags,sourceCoordinates=coords,mappingStatus='observed total external government debt; instrument split observed'if vals['foreignSecurities']is not None else'observed total external government debt; foreign securities split unavailable',source='Eurostat gov_10dd_ggd',url='https://ec.europa.eu/eurostat/databrowser/view/gov_10dd_ggd/default/table?lang=en',sourceVintage=x['updated'],sourceAmountUnit='million EUR',GDP=g,sourceTotalDebt=vals['total'],sourceForeignDebt=vals['foreign'],sourceForeignSecurities=vals['foreignSecurities'],sourceForeignLoans=vals['foreignLoans'],sourceTotalDebtSecurities=vals['totalSecurities'],sourceResidentFinancialDebt=vals['residentFinancial'],sourceResidentCentralBankDebt=vals['centralBank'],publishedForeignGovDebtGDP=vals['publishedGDP'],notes=['IssuerS13 general government, holderS2 restofworld, total maturity, face-value Maastricht debt. Total foreign debt includes loans/deposits as well as securities.','All GDP shares use the common2023 fiscal-ledger denominator. Original publishedPC_GDP and source flags remain separate.','National S2 contains otherEU members and cannot be summed as EU27 extra-EU government debt.'])
 elif c=='USA':
  g=fiscal['countries']['USA']['years']['2023']['GDP'];treasuries=7940.008;mspd=26352.8845117092;foreignDebt=8401.9
  if(R/'fed_x1.html').exists():
   parser=HTMLRows();parser.feed((R/'fed_x1.html').read_text());headers=next(r for r in parser.rows if r[:3]==['Line','Series','Description']);row=next(r for r in parser.rows if any('FL374190025'in cell for cell in r));foreignDebt=float(row[headers.index('2023')]);assert foreignDebt==8401.9
  if(R/'tic_table3.txt').exists():
   lines=(R/'tic_table3.txt').read_text().splitlines();header=next(i for i,l in enumerate(lines)if l.startswith('country\tcountry_code\tdate'))
   rows=list(csv.DictReader(lines[header:],delimiter='\t'));matches=[r for r in rows if r.get('date')=='2023-12'and r.get('country')in['Grand Total','Grand total','Total']]
   if not matches:matches=[r for r in rows if r.get('date')=='2023-12'and r.get('country_code')=='99996']
   if matches:treasuries=float(matches[0]['for_treas_pos'])/1000
  if(R/'mspd_2023.json').exists():
   data=read(R/'mspd_2023.json')['data'];classes={'Bills','Notes','Bonds','Treasury Inflation-Protected Securities','Floating Rate Notes','Federal Financing Bank'}
   marketable=[r for r in data if r.get('security_class_desc')in classes];assert len(marketable)==6
   mspd=sum(float(r['debt_held_public_mil_amt'])for r in marketable)/1000;assert abs(mspd-26352.8845117092)<1e-8
  assert abs(treasuries-7940.008)<1e-8,treasuries
  base.update(totalForeignGovDebtGDP=100*foreignDebt/g,governmentDebtSecuritiesKnownSubsetGDP=100*treasuries/g,foreignGovSecuritiesProxyGDP=100*(treasuries+116.7)/g,foreignShareOfGovDebtSecuritiesProxy=100*treasuries/mspd,observedForeignDebtSharePct=100*foreignDebt/38158.5,mappingStatus='observed broad external government debt; exact whole-government securities split unavailable',source='Federal ReserveZ.1X.1/X.4 and TreasuryTIC Table3',url='https://www.federalreserve.gov/apps/fof/DisplayTable.aspx?t=X.1',sourceVintage='Fed2026-09-11; TIC history retrieved2026-11-15',sourceAmountUnit='billion USD',GDP=g,sourceForeignDebt=foreignDebt,sourceTotalDebt=38158.5,sourceForeignTreasuries=treasuries,sourceForeignMunicipalSecuritiesMarketValue=116.7,treasuryMarketableHeldByPublicBillionUSD=mspd,foreignTreasurySharePct=100*treasuries/mspd,treasuryDenominatorURL='https://fiscaldata.treasury.gov/datasets/monthly-statement-public-debt/summary-of-treasury-securities-outstanding/',sourceCoordinates={'broadForeign':'FedX.1line10 FL374190025,2023=8401.9bn; X.4line21','broadTotal':'FedX.4line11 FL374190005,2023=38158.5bn','TreasuryForeign':'TICTable3 GrandTotal2023-12,for_treas_pos=7940008millionUSD','TreasuryTotal':'MSPDTable1record_date2023-12-31; sum six marketable classes(Bills,Notes,Bonds,TIPS,FRN,FederalFinancingBank), debt_held_public_mil_amt /1000; agrees marketable subtotal'},notes=['Fed gross general-government debt includes pension/guarantee liabilities and payables: its scope is broader than the model public-debt book. Foreign liabilities include SDR allocations and payables as well as bonds.','TIC7940.008bn is a federal Treasury subset with custodial/market valuation, not exact general-government bonds.','Municipal116.7bn contains some nonprofit/corporate issuers; adding it creates a labelled issuer/valuation proxy, not an exact whole-government securities observation.','TICforeign / MSPDmarketableheldpublic=30.12956% is a federal-only mixed-valuation ownership proxy, not an observed general-government annual issuance share.','Fed raw X.1 HTML and X.4 PDF retained with hashes; foreign creditors re-extracted from the2023column. Full source definitions remain broader than the model book.'])
 elif c=='CHN':
  g=129427.17
  base.update(totalForeignGovDebtGDP=100*3077.5/g,foreignGovSecuritiesGDP=100*2695.4/g,foreignGovOtherDebtGDP=100*382.1/g,mappingStatus='observed external general-government debt with securities/loans split',source='SAFE2023 external debt by issuer sector',url='https://www.safe.gov.cn/safe/2024/0329/24175.html',sourceVintage='2024-03-29',sourceAmountUnit='billion CNY',GDP=g,sourceForeignDebt=3077.5,sourceForeignSecurities=2695.4,sourceForeignLoans=382.1,sourceCoordinates={'total':'Generalgovernment30775hundredmillionCNY','securities':'Short2870+long24084hundredmillionCNY','loans':'Long3821hundredmillionCNY'},notes=['Both domestic and foreign-currency external debt; issuer general government. Mainland scope excludesHongKong/Macao/Taiwan.','Original SAFE GDP ratio used older preliminary GDP; ratios here use revised2023GDP129427.17bnCNY.','A matched total domestic government bond-pool denominator was not verified; do not claim an exact foreign-bond ownership percentage.'])
 else:
  base.update(mappingStatus='unavailable extra-EU general-government external debt stock',source='No verified extra-EU aggregate located',url='https://ec.europa.eu/eurostat/cache/metadata/en/bop_6_esms.htm',notes=['NationalS2 includes intra-EU holdings and cannot be added to infer EU27 foreign government debt. Euro-area data use a different perimeter.','No extra-EU stock or securities split is fabricated. Any opening model amount or future foreign-demand share must be an explicit assumption.'])
 base['modelPublicDebtGDP']=p['params']['initialPublicDebt'];base['mappedForeignPublicDebtSharePct']=100*base['totalForeignGovDebtGDP']/base['modelPublicDebtGDP']if base['totalForeignGovDebtGDP']is not None else None;base['mappedForeignSecuritiesSharePct']=100*base['foreignGovSecuritiesGDP']/base['modelPublicDebtGDP']if base['foreignGovSecuritiesGDP']is not None else None
 out[c]=base
result={'openingYear':2023,'sourceObservationsOnly':True,'countries':out,'coverage':{'presets':len(out),'totalForeignDebtObserved':sum(v['totalForeignGovDebtGDP']is not None for v in out.values()),'exactForeignSecuritiesObserved':sum(v['foreignGovSecuritiesGDP']is not None for v in out.values()),'exactForeignBondOwnershipShareObserved':sum(v['foreignShareOfGovDebtSecurities']is not None for v in out.values())},'interpretation':['A current-account surplus can coexist with foreign sovereign bond holdings and gross two-way capital flows.','Foreign sovereign issuance is a financial transaction, not current-account income. Interest abroad is a primary-income debit.','Within the model zero-capital-account/no-valuation convention, changes in transaction-cost NFA equal CA. Real measured NIIP also has valuation and other-volume changes.','Existing otherForeignIncomeGDP already contains unallocated sovereign external interest. Rebase it when coupons become explicit, to avoid double counting.']}
(R/'opening_foreign_sovereign_2023.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
manifest=read(R/'download_manifest.json')if(R/'download_manifest.json').exists()else[]
eu={'file':'eurostat_ggd_2023.json','url':'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10dd_ggd?lang=en&freq=A&time=2023','sha256':hashlib.sha256((R/'eurostat_ggd_2023.json').read_bytes()).hexdigest(),'bytes':(R/'eurostat_ggd_2023.json').stat().st_size,'updated':x['updated'],'status':'downloaded'}
manifest=[m for m in manifest if m['file']!='eurostat_ggd_2023.json']+[eu];(R/'download_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(result['coverage']))

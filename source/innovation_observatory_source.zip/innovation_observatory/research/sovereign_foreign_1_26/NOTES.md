# Foreign government debt: observed2023 positions and scope

`opening_foreign_sovereign_2023.json` covers all30modelpresets. It is a source ledger; it does not silently turn unverified splits into zero. Rebuild offline with `python3 research/sovereign_foreign_1_26/extract.py` from retained primary raw snapshots. Retained raw bytes have hashes in `download_manifest.json`; web-only coordinates are distinguished from downloaded snapshots.

Eurostat `gov_10dd_ggd`: annual2023, general governmentS13, holderS2(restofworld), total maturity, instrumentsGD,GD_F3,GD_F4. Exact broad foreign debt is available for all27members. Exact foreign-held debt securities are available for19; the other8remainnull. GDP ratios are re-expressed with the same2023GDP denominator used in fiscal ledgers. Broad Maastricht debt is face-value consolidated deposits,securities and loans. **Do not label all foreign debt as foreign government bonds.** Greece is a clear warning: foreign bond ownership is4.8761%of the securities book, whereas a large broad foreign-debt share mainly reflects official loans. Foreign residents for a national member include otherEU members: summing these into an EU27 extra-EU total would double count intra-EU positions. EU27 external sovereign totals remain unavailable.

USA: Federal Reserve currentZ.1X.1/X.4,11September2026vintage, observes2023total foreign creditors8401.9billionUSD and broad consolidated general-government debt38158.5billionUSD. The denominator includes pension/guarantee liabilities and other payables, so its scope differs from a narrow marketable bond book or IMF headline debt ratio. TICTable3, GrandTotal,2023-12, gives foreign Treasury holdings7940008millionUSD, a federal-issuer known subset. Treasury+municipal securities is a labelled broader issuer/valuation proxy because municipal issuers include some nongovernment entities. Exact whole-general-government securities/otherdebt split staysnull. The federal Treasury foreign-ownership proxy uses foreignTIC holdings divided by marketableTreasuries heldbypublic at2023-12-31 from MSPDTable1; custody/market versus principal valuations differ. This stock ratio is not an empirically estimated annual foreign issuance demand share.

China: SAFE29March2024release, end2023general-government foreign debt30775hundredmillionCNY. Debt securities=2870short+24084long; loans=3821. These are3077.5,2695.4and382.1billionCNY. GDP ratios use the revised2023GDP129427.17billionCNY instead of the preliminary denominator in the original release. Mainland residency excludesHongKong,Macao,Taiwan. A matched entire domestic government-securities denominator was not verified and is not invented.

## Accounting implications

Foreign bond issuance is a financial-account transaction. It is not export income or a current-account receipt. New issuance can produce both a new external liability and a bank settlement asset; the transaction alone need not change national net foreign assets. Redemption reverses both financing legs without creating current income or GDP.

Interest to foreign holders belongs to primary income paid abroad. It lowers the current account and domestic national saving relative to an otherwise identical resident-held claim. However, the model's existing `otherForeignIncomeGDP` residual was already calibrated to observedCA and therefore includes unallocated sovereign external interest. Rebase the residual when making that interest explicit to avoid counting it twice.

A positive current account does not require foreigners to sell all government bonds. Gross two-way financial transactions and portfolio diversification can coexist with a national surplus. Conversely, a current-account deficit does not identify which domestic sector must borrow or guarantee investors' willingness to fund it. Any investor-demand law using rates,currency,debt or laggedCA is an explicit behavioral assumption, not the accounting identity.

ECB'sBOP/IIPmethodology states that current+capital account net lending equals financial-account net asset acquisitions minus liability incurrence. NIIP stock changes also contain exchange-rate/price revaluations and other-volume changes. Therefore model `Δtransaction-costNFA=CA` requires its stated zero-capital-account/no-other-volume convention; it is not a universal equality for measured market-valueNIIP.

Primary methodology:
- https://www.ecb.europa.eu/press/pubbydate/2025/html/ecb.bopiipbook202507.en.html (generalprinciples,lines121–142; portfolioinvestment/primaryincome sections).
- https://ec.europa.eu/eurostat/cache/metadata/en/gov_10dd_esms.htm (Maastricht debt instruments/valuation and scope).
- https://ec.europa.eu/eurostat/cache/metadata/en/bop_6_esms.htm (BPM6 accounting categories).

This is a partial represented external balance sheet. Adding previously omitted sovereign liabilities does not make it an empirically complete nationalIIP. Opening bank gross external assets/liabilities and household foreign assets must be checked for scope overlap before adding positions.

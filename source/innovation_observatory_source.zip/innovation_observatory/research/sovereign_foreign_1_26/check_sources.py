"""Integrity, source-coordinate, missingness and scope checks; not forecast validation."""
from pathlib import Path
import json,hashlib,subprocess,sys
R=Path(__file__).resolve().parent
m=json.loads((R/'download_manifest.json').read_text());verified=0
for item in m:
 if item.get('status')!='downloaded':continue
 p=R/item['file']
 if not p.exists() and item.get('optionalInSourceBundle'):continue
 assert p.exists(),p
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],p
 verified+=1
subprocess.run([sys.executable,str(R/'extract.py')],check=True,capture_output=True)
x=json.loads((R/'opening_foreign_sovereign_2023.json').read_text());c=x['countries'];assert len(c)==30
assert x['coverage']['totalForeignDebtObserved']==29
assert x['coverage']['exactForeignSecuritiesObserved']==20
assert x['coverage']['exactForeignBondOwnershipShareObserved']==19
for code,z in c.items():
 total=z['totalForeignGovDebtGDP'];securities=z['foreignGovSecuritiesGDP']
 if securities is not None:
  assert total is not None and 0<=securities<=total+1e-8
  assert abs(securities+z['foreignGovOtherDebtGDP']-total)<1e-8
 if z['foreignShareOfGovDebtSecurities']is not None:assert 0<=z['foreignShareOfGovDebtSecurities']<=100
assert c['EU27']['totalForeignGovDebtGDP']is None
assert c['USA']['foreignGovSecuritiesGDP']is None
assert abs(c['USA']['sourceForeignTreasuries']-7940.008)<1e-8
assert abs(c['USA']['foreignTreasurySharePct']-30.12955942819872)<1e-8
assert c['GRC']['foreignShareOfGovDebtSecurities']<5 and c['GRC']['observedForeignDebtSharePct']>70
print(json.dumps({'status':'PASS','rawFilesHashed':verified,'coverage':x['coverage'],'checks':['Foreign broad debt, securities and unallocated splits stay separate','MissingEU27extraEUstock not nationalS2sum','USA Treasury subset is not exactwholeGovsecurities','Greece officialloan/bondscope distinction retained','SourceGDP ratios, instrumentownershipshares and derivedresiduals reconcile']}))

# Foreign productivity projections and event examples — engine 1.18

The population, education, pension and housing additions were completed and
published as engine 1.17 before this change. Those mechanisms remain active.

## Source and interpretation

The frozen source is OECD Economic Outlook 117 long-term scenarios, the 2025
update, reported last updated on 6 January 2026 and retrieved on 8 November
2026. Its public annual data run through 2100. Six conditional paths vary the
energy transition, climate damage and mitigation costs. BAU1 is the default
scenario choice; that choice is an assumption, not an empirical finding.

The published variable EFFLABS is trend labour efficiency. OECD uses

\[Y_t=(EFFLABS_t L_t)^{0.67}K_t^{0.33}.\]

Thus the implied Hicks-neutral productivity multiplier within each country is

\[A_t/A_{2023}=(EFFLABS_t/EFFLABS_{2023})^{0.67}.\]

This transformation must not be confused with GDP growth, GDP per worker or a
directly published PWT-comparable TFP forecast. EFFLABS is a headcount-based
residual; PWT separately adjusts labour for human capital. Linking the derived
growth to the existing PWT opening level is an explicit cross-source proxy.
OECD's model includes empirically estimated convergence alongside assumed
global technical progress, decaying momentum and climate/mitigation channels.
The future is not observed, and conditional scenarios are not predictions
with established accuracy for this simulator.

## Rest-of-world average

The opening PWT pool contains 118 countries other than the USA and China.
Published comparable OECD national paths overlap 47 of them, representing
74.98577409185644% of the pool's fixed 2023 PPP output. The internal OECD model's
139-country coverage is not its public per-country data coverage.

For the covered set C, the linked index is

\[R_t=\frac{\sum_{i\in C} GDP^{PPP}_{i,2023}\,ctfp_{i,2023}
 (EFFLABS_{i,t}/EFFLABS_{i,2023})^{0.67}}
 {\sum_{i\in C} GDP^{PPP}_{i,2023}\,ctfp_{i,2023}}.\]

R_2023 = 1. The full opening rest-of-world level is retained and grown by R.
Covered-sample evolution therefore proxies uncovered countries; missing
national forecasts are not fabricated. No overlapping OECD/world aggregate
enters the sum. The home country remains in the rest-of-world pool when
covered, matching its established definition of excluding only USA and China.
Raw national-currency efficiency levels are never averaged across countries.

## Time, updates and shocks

Each step is one year. The foreign calendar starts in 2023 and advances with
every step, including optional settling. Normal year 1 therefore uses the
2024-to-2023 annual ratio. A donor closes year t at

\[D_t=D_{t-1}(1+(g^{source}_t+s_t)/100),\]

where s is the additive foreign-growth event offset in percentage points.
Source growth varies by calendar year. A scenario change uses the new
scenario's subsequent annual rates and retains the level already accumulated.
Events may raise or reduce each source separately, overlap and fade. A
completed growth shock does not reverse its accumulated level effect. Rates
at or below -100% are rejected rather than silently producing invalid levels.

The donor endpoint is appended only after current learning. Adoption still
uses completed history with the configured additional delay. A foreign growth
event can affect competition through the subsequent foreign technology basket
and later domestic adoption; it never grants immediate domestic knowledge.

The published paths end in 2100. Afterward the final published annual rate is
repeated, flagged and described as extrapolation. There is no random forecast
revision law or feedback from the representative domestic economy into OECD
paths. Scenario controls and named events supply explicit changes. The dataset
is a frozen reproducible vintage; it does not silently update over the network.

Published paths are enabled in country presets. Disabling them restores the
three existing fixed historical-growth controls. Generic defaults keep that
legacy mode for reproducibility. Saved custom fixed-growth values or paths
migrate in fixed-rate mode so their inputs are not ignored; resetting an
economy enables the new country default. Other settings and events persist.

## Event examples

Every event example supplies a name, start, duration, remaining fraction and
nonzero effects. A planner with neither parameter paths nor saved shocks opens a filled economic-downturn example
as an unsaved draft. Parameter-based examples display their actual paths instead. Selecting another example replaces that untouched draft. Apply commits it, Cancel leaves the experiment unchanged.
Saved events reopen without adding an example. The foreign innovation example
adds 0.5 percentage points to US/rest-of-world growth and 0.8 to China's growth
for five years, then halves the remaining effect each later year. These sizes
are illustrative assumptions, not estimated probabilities or effect sizes.

## Validation boundary

`tests/foreign-projections.mjs` verifies raw-source hashes, the transformation,
the excluded-country weighted average, all six scenarios, annual compounding,
prospective changes, positive/negative/overlapping/fading events, adoption
delay, the tail, settling, saved-setting migration and source-off equivalence
to frozen 1.17. It also checks all four social channels and the GDP/financial
identities across every opening economy.

This 2025/2026 projection vintage was unavailable in 2023. Existing retrospective
2025 error comparisons keep this new option off and remain separate, previously
examined diagnostics. Adding these projections does not demonstrate improved
past-only forecasting accuracy. No response coefficient was optimized against
those scores.

`scripts/build_foreign_projections.py` compiles only frozen official inputs.
Exact URLs and hashes are in `research/forecast_source_candidates/candidate_manifest.json`
and `dist/data/foreign_projections.json`. The generated browser module contains
the same paths, avoiding network requests during a simulation.

Primary sources:

- [OECD 2025 long-run model and production function](https://www.oecd.org/en/publications/oecd-global-long-run-economic-scenarios_00353678-en/full-report/component-4.html)
- [OECD estimation and coverage annex](https://www.oecd.org/en/publications/oecd-global-long-run-economic-scenarios_00353678-en/full-report/component-8.html)

"""Freeze and extract official2023social/fiscal benchmarks. Run from any directory."""
from pathlib import Path
import json,hashlib,urllib.request,datetime,csv
R=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
QUERIES={
 'gov_exp_2023':'gov_10a_exp?lang=en&freq=A&unit=PC_GDP&sector=S13&time=2023',
 'gov_main_2023':'gov_10a_main?lang=en&freq=A&unit=PC_GDP&sector=S13&time=2023',
 'pensions_all_schemes_2023':'spr_exp_pens?lang=en&freq=A&unit=PC_GDP&time=2023'}
BASE='https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/'
now=datetime.datetime.now(datetime.timezone.utc).isoformat();sources={};tables={}
for name,query in QUERIES.items():
 file=OUT/(name+'.json');url=BASE+query
 if not file.exists():file.write_bytes(urllib.request.urlopen(url,timeout=120).read())
 raw=file.read_bytes();tables[name]=json.loads(raw)
 sources[name]={'file':file.name,'url':url,'retrievedAt':now,'updated':tables[name].get('updated'),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'id':tables[name]['id'],'size':tables[name]['size']}
def get(table,**q):
 i=0;selection={}
 for dim,n in zip(table['id'],table['size']):
  c=table['dimension'][dim]['category']['index'];key=q.get(dim,next(iter(c)))
  if key not in c:return {'value':None,'selection':{**q,dim:key},'flag':'absent category'}
  i=i*n+c[key];selection[dim]=key
 return {'value':table.get('value',{}).get(str(i)),'selection':selection,'flag':table.get('status',{}).get(str(i),'')}
profiles=json.loads((R/'dist/data/profiles.json').read_text());prior=json.loads((R/'dist/data/housing_pension_benchmarks.json').read_text())['countries']
exp,main,pensions=[tables[n] for n in QUERIES];countries={};missing=[]
for profile in profiles:
 code,geo=profile['code'],profile['geo'];a={'code':code,'geo':geo,'name':profile['name'],'year':2023,'unit':'% GDP','observations':{}}
 def obs(name,table,source,**q):
  row=get(table,geo=geo,**q);row['source']=source;a['observations'][name]=row
  if row['value'] is None:missing.append({'country':code,'field':name,'flag':row['flag']})
  return row['value']
 for name,item in {'governmentRevenue':'TR','governmentExpenditure':'TE','governmentConsumptionMain':'P3','publicGFCFMain':'P51G','cashSocialBenefitsMain':'D62PAY','oldAgeCashMain':'D62PAY_GF1002','survivorCashMain':'D62PAY_GF1003','unemploymentCashMain':'D62PAY_GF1005','interestMain':'D41PAY','capitalTransfersMain':'D9PAY','subsidiesMain':'D3PAY'}.items():obs(name,main,'gov_main_2023',na_item=item)
 for name,item in {'governmentExpenditureCOFOG':'TE','governmentConsumptionCOFOG':'P3','cashSocialBenefitsCOFOG':'D62','publicGFCFCOFOG':'P51G'}.items():obs(name,exp,'gov_exp_2023',cofog99='TOTAL',na_item=item)
 for key,func in {'health':'GF07','education':'GF09','socialProtection':'GF10','oldAge':'GF1002','survivors':'GF1003','sicknessDisability':'GF1001'}.items():
  for suffix,item in {'Total':'TE','Consumption':'P3','CashBenefits':'D62','GFCF':'P51G'}.items():obs(key+suffix,exp,'gov_exp_2023',cofog99=func,na_item=item)
 for func in ['GF01','GF02','GF03','GF04','GF05','GF06','GF07','GF08','GF09','GF10']:obs('function'+func,exp,'gov_exp_2023',cofog99=func,na_item='TE')
 for name,item in {'allSchemePensions':'TOTAL','allSchemeOldAge':'OLD','allSchemeAnticipatedOldAge':'AOLD','allSchemePartialPensions':'PART','allSchemeSurvivors':'SRV','allSchemeDisability':'DIS','allSchemeEarlyReducedCapacity':'ERRC','allSchemeEarlyLabourMarket':'ERLM'}.items():obs(name,pensions,'pensions_all_schemes_2023',spdepb=item,spdepm='TOTAL')
 o={k:v['value'] for k,v in a['observations'].items()};a['values']=o
 a['derived']={
 'healthShareOfPublicConsumption':o['healthConsumption']/o['governmentConsumptionCOFOG'],
 'educationShareOfPublicConsumption':o['educationConsumption']/o['governmentConsumptionCOFOG'],
 'socialProtectionShareOfTotalExpenditure':o['socialProtectionTotal']/o['governmentExpenditureCOFOG'],
 'socialFunctionsTotalGDP':o['healthTotal']+o['educationTotal']+o['socialProtectionTotal'],
 'COFOGTotalDifferenceVsMain':o['governmentExpenditureCOFOG']-o['governmentExpenditure'],
 'COFOGConsumptionDifferenceVsMain':o['governmentConsumptionCOFOG']-o['governmentConsumptionMain'],
 'COFOGFunctionsSumRoundingResidual':sum(o['function'+f] for f in ['GF01','GF02','GF03','GF04','GF05','GF06','GF07','GF08','GF09','GF10'])-o['governmentExpenditureCOFOG'],
 'oldAgeSurvivorsCashGDP':o['oldAgeCashBenefits']+o['survivorsCashBenefits']}
 a['existingModel']={k:profile['params'].get(k) for k in ['governmentShare','initialGovernmentShare','publicEducationGDP','publicPensionGDP','incomeSupport']}
 a['existingOldAgeBenchmark']=prior[code]['publicOldAgeCashGDP']['value']
 countries[code]=a
report={'retrievedAt':now,'sourceYear':2023,'countries':countries,'sources':sources,'missingObservations':missing,'definitions':{
 'publicExpenditure':'S13 total expenditure (TE) is not the GDP government-final-consumption (P3) component; it also includes cash benefits, interest, investment and other transfers.',
 'healthEducationTotal':'COFOG GF07/GF09 TE include all expenditure transaction types. Their P3 component is compatible with an allocation inside government final consumption. Do not add the full TE onto the existing government purchase total.',
 'socialProtection':'COFOG GF10 excludes health services classified in GF07 and includes old-age/survivors plus disability, families, unemployment, housing and other welfare. It is a functional aggregate, not a separate additive line on top of pensions.',
 'pensions':'The existing publicPensionGDP is public old-age cash benefits GF1002 D62, not all pension types. Survivors GF1003 D62 can be displayed as a separate funded subset of cash benefits. GF1001 D62 includes sickness as well as disability benefits and cannot be called disability pensions.',
 'ESSPROS':'spr_exp_pens covers cash pension benefits across social-protection schemes, including public and relevant private schemes. It has no public/private split in this extract. It must not automatically replace public spending or be added to public pensions/private funded withdrawals.',
 'allocation':'Use function P3 / COFOG TOTAL P3 to allocate the existing model government purchase budget, preserving its envelope. Source main P3 differs slightly from COFOG TOTAL P3 in some countries; preserve each definition and do not force sums across sources.',
 'vintage':'Both fiscal API snapshots were updated21October2026 at differenttimes. Small table differences are consistent with compilation/rounding/revision alignment; do not assume their causes are uniquely identified. Earlier narrative articles cite an older data extraction and may differ.'}}
core=['governmentRevenue','governmentExpenditure','governmentConsumptionCOFOG','cashSocialBenefitsCOFOG','healthTotal','healthConsumption','educationTotal','educationConsumption','socialProtectionTotal','socialProtectionCashBenefits','oldAgeCashBenefits','survivorsCashBenefits','sicknessDisabilityCashBenefits','allSchemePensions']
report['coreCoverage']={'fields':core,'observations':len(core)*len(countries),'missing':[(code,key) for code,c in countries.items() for key in core if c['values'][key] is None]}
assert not report['coreCoverage']['missing']
(OUT/'benchmark.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'manifest.json').write_text(json.dumps({'retrievedAt':now,'sources':sources},indent=2)+'\n')
fields=['code','name','governmentRevenue','governmentExpenditure','governmentConsumptionMain','governmentConsumptionCOFOG','healthTotal','healthConsumption','educationTotal','educationConsumption','socialProtectionTotal','socialProtectionCashBenefits','oldAgeCashBenefits','survivorsCashBenefits','sicknessDisabilityCashBenefits','allSchemePensions']
with (OUT/'benchmark.csv').open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for a in countries.values():w.writerow({k:a.get(k,a['values'].get(k))for k in fields})
print(json.dumps({'countries':len(countries),'observations':sum(len(x['observations']) for x in countries.values()),'missing':missing,'ITA':countries['ITA']['values'],'EU27':countries['EU27']['values']},indent=2))

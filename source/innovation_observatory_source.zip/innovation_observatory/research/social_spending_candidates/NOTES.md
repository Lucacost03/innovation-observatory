# Verified social spending: definitions before adjusting totals

Checked 12 November 2026. Research only; no app/model files modified.

## Official 2023 opening data

All figures below are % of GDP from the raw Eurostat API snapshots, not 2026 current spending.

| Measure | Italy | EU27 |
|---|---:|---:|
| General-government revenue (gov_10a_main TR) | 46.5 | 45.4 |
| General-government total expenditure (gov_10a_main TE) | 53.6 | 48.8 |
| Government final consumption (gov_10a_main P3) | 17.8 | 21.0 |
| COFOG total government final consumption (gov_10a_exp TOTAL P3) | 17.9 | 21.1 |
| Health total expenditure (GF07 TE) | 6.5 | 7.2 |
| Health final consumption (GF07 P3) | 6.1 | 6.5 |
| Public education total expenditure (GF09 TE) | 3.9 | 4.7 |
| Public education final consumption (GF09 P3) | 3.4 | 3.8 |
| Social protection total expenditure (GF10 TE) | 21.0 | 19.1 |
| Cash social benefits, all functions (TOTAL D62) | 19.8 | 15.9 |
| Cash social benefits, social protection function (GF10 D62) | 19.8 | 15.6 |
| Public old-age cash benefits (GF1002 D62) | 13.2 | 9.6 |
| Public survivors' cash benefits (GF1003 D62) | 2.3 | 1.4 |
| Public sickness/disability cash benefits (GF1001 D62) | 1.6 | 1.8 |
| All-scheme total pensions (ESSPROS spr_exp_pens) | 15.49 | 12.28 |

Coverage: all 27 EU countries plus EU27 have all 392 core observations (14 selected measures × 28 economies). Optional pension subtypes and selected gov_main cash-benefit splits have missing values; those remain null, not zero. France, Germany and Slovakia have provisional flags for several COFOG entries; Latvia and EU27 all-scheme pension totals have estimated flags. Every observation retains its flag and exact selection. The benchmark also retains all ten top-level COFOG functions, main fiscal aggregates and secondary transaction components. Small independently rounded function totals need not sum exactly to the rounded aggregate.

Snapshots: gov_10a_exp updated21October2026 23:00+0200; gov_10a_main updated21October2026 11:00+0200. Their P3 totals differ slightly (including Italy/EU by0.1pp). Both values are preserved. Compilation/rounding/revision alignment may contribute; the cause is not uniquely established here. Earlier Statistics Explained pages cite earlier extraction dates and give EU health7.3/social19.2 instead of the current API7.2/19.1. Use the actual frozen API values consistently.

## Findings for the model

1. **Existing public old-age inputs match the data exactly for all28economies.** `publicPensionGDP` is13.2%for Italy and9.6%for EU27, matching GF1002 D62. It is not total pension expenditure. A low-looking old-age line must not be corrected merely to match a broader total.
2. **Survivors and sickness/disability already belong to cash social benefits.** They can be separately displayed as subsets of the model's non-old-age cash support; do not add them on top of the same total. GF1001 includes sickness cash benefits, not just disability pensions. Calling all of it disability pensions would be a new definition error.
3. **All-scheme ESSPROS pension totals have a wider perimeter.** `spr_exp_pens` includes old-age, anticipated/partial old-age, disability, survivors and early retirement, across public and relevant private social-protection schemes. This extract has no institutional public/private split. It cannot simply replace public old-age cash spending or be added to public pensions plus private funded-pension withdrawals.
4. **Italy's support input already excludes separately modeled unemployment where observed.** Existing incomeSupport18.918%plus the observed unemployment cash share~0.892%equals total cash social benefits~19.81%. Italy has unemploymentReplacement20.8975%to model that second part. EU27 has a missing separate unemployment cash split in gov_main; its incomeSupport15.915%retains the whole cash-benefit envelope and the extra unemployment replacement is0. That fallback does not omit the unknown unemployment share. Similar source fallbacks occur for other countries.
5. **Healthcare is hidden inside government purchases.** The model can allocate actual delivered government final consumption to healthcare and education using their P3 shares within COFOG TOTAL P3: Italy health6.1/17.9≈34.08%,education3.4/17.9≈18.99%; EU health6.5/21.1≈30.81%,education3.8/21.1≈18.01%. These allocations sum below100%in every economy and preserve the existing government-purchase envelope.
6. **Education's existing3.9%/4.7%input is a TE-based proxy, not solely delivered education services.** Total function spending includes capital, transfers and administration. The P3 comparison (3.4%/3.8%) is the like-for-like quantity inside final government consumption. For empirical clarity, retain total function TE as a reference benchmark and separately identify the service/consumption portion. Do not add the education/health TE total to existing G: that double counts much of their spending.
7. **TE is not G in the expenditure GDP identity.** Cash transfers, interest, public capital spending and many other transfers are public expenses but are outside government final consumption. Public investment belongs to I; pensions redistribute income instead of directly adding GDP. Italy2023had main publicGFCF3.2%,capitaltransfers5.9%,interest3.6%,subsidies1.8%: the large total government envelope therefore cannot be compared with only the model's G purchase line. This is a source-scope explanation, not advice to add all those amounts mechanically.
8. **Display source benchmarks and simulated flows distinctly.** The model's normalized opening G18.1596%for Italy and21.8736%for EU27 use domestic-use shares, not literal national GDP ratios; the provenance already acknowledges this. A source TE benchmark cannot be advertised as exactly matched model total expenditure. Later model shares can fall because public purchases follow their own budget trend and simulated GDP grows. That is a model dynamic assumption, not automatically wrong initial data.

## Primary source URLs

- COFOG data and definitions:
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10a_exp?lang=en&freq=A&unit=PC_GDP&sector=S13&time=2023
  https://ec.europa.eu/eurostat/cache/metadata/en/gov_10a_exp_esms.htm
- General government accounts:
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10a_main?lang=en&freq=A&unit=PC_GDP&sector=S13&time=2023
- All-scheme pensions and ESSPROS scope:
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/spr_exp_pens?lang=en&freq=A&unit=PC_GDP&time=2023
  https://ec.europa.eu/eurostat/cache/metadata/en/spr_esms.htm
- ESA2010government final consumption definition (market purchases plus government-produced individual/collective services):
  https://ec.europa.eu/eurostat/databrowser/product/view/teina030
- Eurostat manual explaining P31/D63 and purchased market services D632:
  https://ec.europa.eu/eurostat/documents/3859598/10142242/KS-GQ-19-010-EN-N.pdf/ed64a194-81db-112b-074b-b7a9eb946c32?t=1569418084000

Useful retrieved refs (parent must open before citing): COFOG metadata turn109view0; ESSPROS metadata turn110view1; ESA consumption definition turn108search1; manual turn108search27. The numeric evidence is in the exact raw API snapshots and benchmark selections, not the older narrative articles.

"""Latest matched fiscal references, kept separate from the2023 opening."""
from html.parser import HTMLParser
from pathlib import Path
import json,re,hashlib
R=Path(__file__).resolve().parents[2];F=Path(__file__).resolve().parent
class TableParser(HTMLParser):
 def __init__(s):super().__init__();s.rows=[];s.r=None;s.c=None
 def handle_starttag(s,t,a):
  if t=='tr':s.r=[]
  if t in ['th','td']:s.c=[]
 def handle_endtag(s,t):
  if t in ['th','td']and s.r is not None and s.c is not None:s.r.append(' '.join(''.join(s.c).split()));s.c=None
  if t=='tr'and s.r is not None:s.rows.append(s.r);s.r=None
 def handle_data(s,d):
  if s.c is not None:s.c.append(d)
b=(F/'eurostat_oct2026.html').read_bytes();m=json.loads((F/'release_manifest.json').read_text());assert hashlib.sha256(b).hexdigest()==m['sha256']
p=TableParser();p.feed(b.decode('utf-8'));profiles=json.loads((R/'research/frozen_engine_v1_29/profiles.json').read_text());names={x['name']:x['code']for x in profiles};names['EU']='EU27';data={};country=None;mode=None
parse=lambda v:float(v.replace(' ','').replace('−','-'))if re.fullmatch(r'[−-]?[\d ]+(?:\.\d+)?',v)else None
for row in p.rows:
 if not row:continue
 title=row[0].strip();title='Denmark'if title.startswith('Denmark')else title
 if title in names:country=names[title];data.setdefault(country,{});mode=None;continue
 if country is None:continue
 if title.startswith('Government deficit'):mode='deficit';continue
 if title.startswith('Government debt'):mode='debt';continue
 if 'of GDP'in title and len(row)==5 and mode:
  key='deficitGDP'if mode=='deficit'else'debtGDP'
  for year,v in zip([2022,2023,2024,2025],row[-4:]):
   value=parse(v);data[country].setdefault(str(year),{})[key]=-value if key=='deficitGDP'and value is not None else value
  mode=None;continue
 if title in ['Government revenue','Government expenditure']:
  key='revenueGDP'if title=='Government revenue'else'expenditureGDP'
  for year,v in zip([2022,2023,2024,2025],row[-4:]):data[country].setdefault(str(year),{})[key]=parse(v)
  mode=None;continue
 if title:mode=None
assert len(data)==28,(len(data),list(data))
for code,v in data.items():assert 'deficitGDP'in v['2025']and'debtGDP'in v['2025'],code
assert data['ITA']['2025']['deficitGDP']==3.1 and data['EU27']['2025']['debtGDP']==81.5
assert data['DNK']['2025']['revenueGDP']is None,'Do not invent the missing revised Denmark revenue.'
bench=json.loads((R/'dist/data/fiscal_benchmarks.json').read_text())['countries'];out={}
for profile in profiles:
 code=profile['code'];source=bench[code]
 if code in data:
  v={'year':2025,**data[code]['2025'],'sourceURL':m['url'],'releaseDate':'2026-10-21','scope':'ESA2010 S13 general government; published rounded ratios','status':'observed, revised; rounded','note':'2026 forecasts are not mixed into2025 actuals.'}
  if code=='DNK':v['note']+=' Revenue is unavailable in this release pending a dividend-recording correction; not inferred from expenditure and surplus.'
 elif code=='USA':
  z={k:x['percentGDP']for k,x in source['years']['2025']['summary'].items()}
  v={'year':2025,'deficitGDP':-z['netLendingBorrowing'],'revenueGDP':z['totalRevenue'],'expenditureGDP':z['totalExpenditure'],'debtGDP':None,'sourceURL':source['url'],'releaseDate':'2026-10-29','scope':'BEA NIPA calendar-year general government; native net-sales presentation','status':'observed, revised','note':'Whole general-government calendar-year net borrowing differs from the federal fiscal-year budget deficit. No federal ratio is substituted. A matched current debt definition is not provided in this reference.'}
 else:
  z=source['years']['latest']['published2024'];GDP=134806.6
  v={'year':2024,'deficitGDP':100*(z['expenditure']-z['revenue'])/GDP,'revenueGDP':100*z['revenue']/GDP,'expenditureGDP':100*z['expenditure']/GDP,'debtGDP':None,'sourceURL':source['url'],'releaseDate':'2025-10-24','scope':'MOF four-budget consolidated SDDS coverage; NBS final2024 GDP','status':'latest matched consolidated reference verified','GDPBillionsCNY':GDP,'GDPSourceURL':'https://www.stats.gov.cn/sj/zxfb/202512/t20251226_1962144.html','note':'2025 partial budget tables are not a verified same-scope consolidated total. This broad coverage is different from the narrower general-public-budget headline. Current/capital split remains unavailable.'}
 out[code]={'name':profile['name'],'openingYear':2023,'openingDeficitGDP':source['opening']['expenditure']-source['opening']['revenue'],'latest':v}
result={'verifiedAsOf':'2026-11-20','openingYear':2023,'countries':out,'note':'Latest actuals are references, not model targets. Year0 remains the matched2023 opening; later rows are simulated. Capital fiscal inputs are separately dated and explicitly conditioned on published policy composition.'}
(F/'latest_fiscal_references.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');(R/'dist/data/latest_fiscal_references.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');(R/'dist/fiscal-latest-data.mjs').write_text('export const FISCAL_LATEST='+json.dumps(out,separators=(',',':'))+';\n')
print('Verified latest matched references for30presets; EU2025, USA2025, China2024. Denmark revenue remains unavailable.')

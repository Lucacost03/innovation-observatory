# Dated fiscal evidence for engine1.30

`extract.py` parses the retained Eurostat21October2026 EDP release and checks its SHA256. It combines those2025 observations with separately retained BEA2025 general-government and MOF2024 consolidated China records. Final NBS2024 GDP is used for China. Newer partial China budgets are not treated as the same consolidated series. Source-year labels and missing Denmark revenue are retained.

`extract_capital.py` extracts2023–25 capital spending/receipts from the archived country fiscal ledgers. The source components and any rounding difference are preserved. This policy information conditions the simulation; it does not target the deficit or fit future GDP. Current/capital separation for China is unavailable. See `research/TARIFF_FISCAL_METHODS_1_30.md` for the cash/accrual and future-policy limitations.

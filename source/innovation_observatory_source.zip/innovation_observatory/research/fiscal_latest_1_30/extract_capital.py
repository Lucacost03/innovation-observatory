"""Dated published capital flows; no deficit target or future GDP fitting."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[2];b=json.loads((R/'dist/data/fiscal_benchmarks.json').read_text())['countries'];ps=json.loads((R/'dist/data/profiles.json').read_text());out={}
for p in ps:
 c=b[p['code']];records={}
 for y in ['2023','2024','2025']:
  a=c['years'].get(y)
  if not a:continue
  if 'values'in a:
   v=a['values'];parts=[v.get('capitalFormationAndNonProducedAssets'),v.get('capitalTransfersPaid')];exp=sum(parts)if all(x is not None for x in parts)else None;rev=v.get('capitalTransfersReceived')
  elif 'summary'in a:
   v={k:z['percentGDP']for k,z in a['summary'].items()};exp=v['totalExpenditure']-v['currentExpenditure'];rev=v['totalRevenue']-v['currentRevenue']
  else:continue
  records[y]={'expenditure':exp,'revenue':rev}
 if '2023'in records:
  assert abs(records['2023']['expenditure']-c['opening']['capitalExpenditure'])<.0006
  records['2023']['componentRoundingResidual']=records['2023']['expenditure']-c['opening']['capitalExpenditure']
  records['2023']['expenditure']=c['opening']['capitalExpenditure']
  assert abs(records['2023']['revenue']-c['opening']['capitalRevenue'])<1e-8
 out[str(p['params']['foreignPoolId'])]={'country':p['code'],'source':c['source'],'url':c['url'],'records':records,'scope':c['opening']['sourceScope']}
root=Path(__file__).resolve().parent
(root/'dated_capital_components.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
(R/'dist/fiscal-capital-data.mjs').write_text('export const CAPITAL_FISCAL_PATHS='+json.dumps(out,separators=(',',':'))+';\n')
print('Capital source paths:',sum(bool(x['records'])for x in out.values()),'of',len(out),'presets; China split stays unavailable.')

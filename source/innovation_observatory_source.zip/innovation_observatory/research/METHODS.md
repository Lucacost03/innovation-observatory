# Empirical tariffs, dated capital fiscal policy and debt reconciliation — engine 1.30

The opening economy is still **2023**, and each period is one year. The latest actual fiscal observations are separate references: Eurostat's 21 October 2026 EDP release for EU members/EU27 in 2025; BEA's 29 October 2026 NIPA vintage, whole general government in calendar 2025; and the latest verified matching MOF four-budget consolidated China reference in 2024, using NBS final 2024 GDP. China's later partial budget releases are not silently treated as a verified consolidated total. Denmark's missing 2025 revenue remains null. A federal US fiscal-year deficit and a narrow Chinese budget deficit are not substituted for broader model coverage. References are verified as of 20 November 2026; source releases can subsequently be revised.

## What was wrong and what changed

The deficit formula already used total expenditure minus total revenue over current nominal GDP, correctly including capital coverage and excluding bond principal repayment. Large 2023 figures were sometimes being compared with later actuals. In addition, 2023 capital fiscal expenses were repeated as a fixed budget-base share forever. For Italy, this perpetuated exceptional payable-tax-credit expenditure. The retained source capital expense is about 9.150% of GDP in 2023, 5.405% in 2024 and 6.022% in 2025. It includes capital formation/non-produced assets plus capital transfers; these financing payments do not add another good to national investment.

Every preset with a verified split now uses its published calendar-year capital fiscal expense and receipt shares through 2025. Those shares are applied to the existing lagged nominal public-budget base, rather than targeting a deficit or GDP outcome. Where a component is missing, only the most recent verified component is carried forward, with its source year recorded. After the last observed year, continuing the latest share is explicitly an assumption. China's missing current/capital split is unchanged. Fiscal current coverage, tax receipts, pensions, demand, financing and income remain simulated. No coefficient was chosen from the diagnostic GDP, current-account or deficit outcomes.

**This is a conditional historical simulation**, incorporating fiscal information published after 2023. Its comparisons to 2024–25 GDP and fiscal outcomes are not a real-time forecast or an untouched holdout. The change improves the date coverage of capital inputs; it does not make every model deficit equal observed data. Italy still has an important limitation: accrual expenditure on payable credits and later use against taxes affect deficit and cash debt differently. A verified opening credit-liability stock and redemption schedule were unavailable; no schedule is invented. The model's cash-equivalent transfer bridge does not reproduce that full EDP adjustment.

## Opening tariff measurement and recipient

All 30 presets now use observed 2023 customs duties divided by matched goods-import value, multiplied by 100. This is an **effective duty yield**, not a statutory MFN schedule. Duty-free/preferential goods dilute the average; unilateral duties received can enter it. Import VAT and excise are excluded. These are opening-year estimates, not 2026 tariff-policy forecasts.

- EU members: Eurostat `gov_10a_taxag`, receiver `S212`, transaction `D2121`, accrued customs duties in million EUR, divided by `ext_lt_intratrd` all-partner goods imports, including duty-free intra-EU trade. EU27 uses extra-EU imports only. The sum of member duties differs by EUR0.2 million from the aggregate due to source rounding. National collection/residence and transit differences make this an aggregate proxy.
- USA: BEA calendar-year customs duties via FRED `B235RC1A027NBEA`, USD81.633 billion, divided by BOP goods imports `B1242C1A027NBEA`, USD3,104.719 billion: **2.629320%**. The denominator is broader than the dutiable customs base.
- China: MOF final 2023 national customs receipts of CNY259.088 billion divided by NBS 2023 goods imports of CNY17,984.2 billion: **1.440642%**. Final accounts supersede the earlier execution estimate.
- EU27: **1.001007%**; Italy: **0.513398%**. National EU averages are lower because their denominator includes intra-EU trade. Each country's actual numerator, denominator, currency, scope and exact source URL are retained in `data/tariffs_2023.json`.

The detailed WITS 2023 schedule-based rates are retained as cross-checks, not mixed with the preferred duty-yield estimator. Their preference/partner coverage and treatment of unilateral duties differ. Raw primary snapshots, SHA256 manifests and extraction scripts remain in `research/tariffs_1_30`.

The model has one composite import good. Mapping a goods duty yield to that good is a coverage proxy, not an assertion that services pay customs duties. Gross duty raises the import consumer price before VAT, contributes to nominal product taxes, and enters real GDP at the opening tax rate. A tariff-rate increase does not itself become extra real production. The import-choice weight is analytically re-expressed for each opening tariff to preserve the previously source-matched opening border import value. This is not a new tariff shock at year 0.

National EU customs duties belong to EU institutions; 25% is retained as collection compensation under the 2021–27 own-resources arrangements. The model settles net75% externally, distinguishes compensation from national customs tax, and removes the corresponding opening collection-fee coverage from the residual receipt bridge so it is not counted twice. Non-EU domestic customs tax coverage is similarly reclassified out of other production taxes. EU institutions are domestic at EU27 level. The EU27 fiscal benchmark still sums member-government S13 accounts, so its category mapping is an aggregate bridge rather than a full EU-institution budget.

The fee and external duty use a net settlement proxy; there is no extra collection-service production or GDP created. A complete national-accounts service/export ledger is not modeled. The opening residual external income/transfer coverage is rebased once for explicit net customs settlement, preserving opening CA rather than counting the existing EU payment twice. Future tariff changes alter actual settlement and are not rebased away. Continuation of the25% collection compensation beyond2027 is an assumption.

## Exact public-debt explanation

The independently checked stock bridge is:

Δ outstanding public debt = total deficit + Δ treasury cash + recapitalisation − public-equity liquidation proceeds − noncash pension interest.

The ratio change is decomposed exactly into deficit/current GDP, other stock-flow adjustments/current GDP, and the change caused by the nominal GDP denominator. Thus a reduced deficit can coexist with rising debt/GDP. Cash buffers, recapitalisation and noncash accruals also distinguish debt changes from the deficit. Floating-point cancellation is measured relative to debt scale; very large nominal long-run quantities can have a nonzero absolute residual despite tiny relative error.

The graph menu uses the English displayed labels in alphabetical order, with metric keys as deterministic ties. Historical chart endpoints remain inspectable with Home/End and arrow keys. Tooltips and fiscal outcomes show the calendar year. With optional settling, displayed year0 is after the settling years; it is not relabelled2023.

## Executed verification and accuracy limits

228 paths and 9096 annual steps passed. All30 presets have three matched 1.29/1.30 seed pairs (one120-year pair and two12-year pairs), plus an8-year legacy replay for every preset. Six economies have no-anticipation zero/raised-tariff cases. 131370 shared values reproduce frozen1.29 with the new switches disabled. The largest relative sector-account residual is 2.942321170221002e-14; the largest relative public-debt bridge residual is 6.298250809777528e-11. Checks include expenditure GDP, S−I=CA, ΔNFA=CA, public debt holders, public/private debt bridges, capital buyer/seller payments, gross international activity, source-year capital paths, missing references, saved-edit migration and alphabetical graph options. Source audits reproduce the empirical ratios from retained raw data; hashes establish integrity, not statistical truth.

Across29 individual countries (EU27 separately), conditional deficit RMSE changes **2.62533780109248 to 2.607327163118978 ppGDP**; MAE changes 2.081057465451267 to 2.0526517923081244. GDP-growth RMSE changes **3.656153306981908 to 3.6551844713889814 pp** and CA RMSE **2.813652766161387 to 2.8138375442993953 ppGDP**. The last comparison worsens slightly. These are date-conditioned retrospective diagnostics on revised observations already examined in earlier work. Repeated seeds are not additional historical observations. No overall forecasting or causal-policy accuracy is established. Every country error and the remaining deviations from observed deficits are retained, not replaced by a target.

Paired scenarios still inherit unestimated trade, fiscal, price, innovation and demographic responses. Century-long runs extrapolate far beyond observed policy and can hit price/currency bounds or other implausible states. They are numerical stress tests, not national forecasts. `data/revision130_validation.json` contains every comparison, long-run diagnostic and limitation.

## Reproduction

Restore shared fixtures with `python3 scripts/unpack_source_fixtures.py`, then run `npm run test:revision130`. Source mappings can be rebuilt with `node scripts/integrate_1_30.mjs` after the frozen1.29 inputs and current fiscal/participation mappings are in place; it always derives the preserved opening moments from frozen1.29. `extract_capital.py` and `extract.py` generate the dated policy and newer reference modules; tariffs `rebuild.py` reconstructs all30 duty yields from retained primary snapshots. The full source ZIP includes the same code, evidence, raw sources and validation scripts with lossless fixture restoration.

## Browser verification

Managed-preview checks completed for Italy, USA, China and Denmark: empirical tariff controls, current evidence, missing-source display, separate observed/simulated dates, alphabetical graph options, Home/End chart inspection and the expandable public debt bridge. A matched Italy8-year/3-seed experiment completed. Current evidence and the existing graph layout were visually inspected; `research/browser_qa_1_30.json` retains the scope. All30-country coverage comes from source and model tests rather than browser sampling.


## Historical1.29 and earlier studies

# Participation, imported costs and fiscal balance — engine 1.29.0

The three requested mechanisms are implemented. **Numerical and accounting checks pass; historical GDP and current-account forecasting accuracy did not improve in this comparison.** Source fidelity and internal consistency do not establish reliable forecasts or causal policy effects.

## Participation and population

The old rule assigned the same participation probability at every age from 15 to 64. Changing the composition within that group could not change its aggregate rate. The new rule uses country-specific 2023 rates for ages 15–24, 25–54 and 55–64. European inputs come from Eurostat EU-LFS `lfsa_argan`, total sex and all citizenship. USA and China use retained ILOSTAT published provider estimates. All 30 presets have complete age bands. Raw coordinates, flags, hashes and extraction scripts are retained in `research/participation_1_29/`.

One common logit intercept reconciles source age rates with the model's cohort weights and opening aggregate. Fitted probabilities remain between 0 and 100%; these adjusted probabilities are modelling proxies. Source rates for ages 65+ are mapped through the existing relative participation control. USA combines an OECD opening aggregate with an ILO age shape; that source difference is explicit.

China's opening participation now uses the ILOSTAT 15–64 estimate of 75.202%, replacing the old 66.1028% national 15+ proxy. It is labelled a published estimate. Opening employment within its labour force remains a separate 95% scenario assumption. Initial GDP and labour force remain normalised to 100; no output, cash or additional opening jobs are created by this reporting correction.

As cohorts age, survive and migrate, their weights change. Within-band future participation is held fixed as a composition-only scenario. All 30 presets consequently show changing aggregate participation. This cross-section does not identify future sex/cohort trends, schooling decisions, cyclical discouragement or policy effects. Fixed population and unchanged policy can correctly give constant participation; no arbitrary noise is added. Age-specific unemployment is not modelled: job allocation retains a common employment share within the active labour force.

Pension eligibility remains distinct from compulsory labour exit and statistical working age, which stays 15–64. The existing pension-reform coefficient shifts the late-career/older participation transition relative to its opening position; this response is an assumption. Human-capital averaging uses the same active-age weights. Existing broad mortality and migration allocation assumptions remain.

## Imported production costs and real trade prices

The real exchange-rate index is nominal currency strength multiplied by domestic producer prices divided by foreign prices. A higher value means real appreciation. The imported-cost index is `100 × foreign price / (currency strength / 100)`. Its annual producer-price contribution is the existing pass-through coefficient times `100 × log(current import cost / previous import cost)`.

This replaces the old arithmetic nominal-FX-only producer term. It includes foreign price changes, treats reciprocal currency moves symmetrically in logs, and does not generate repeated inflation from a constant import-cost level. The resulting domestic producer price enters the same year's real exchange rate and trade conditions. Direct consumer-import prices remain a separate CPI component. Money, velocity, output, central-bank responses and the disclosed annual price guards remain active.

This is an aggregate pricing proxy in a value-added economy, not a complete intermediate input-output ledger. It adds no intermediate purchase, foreign payment or extra GDP. Consumer-import tariffs are not silently extended to firm inputs. OECD `IMGR_INT / PROD` could measure imported intermediates relative to gross output, but the accessed OECD downloads returned 403 and national coefficients could not be verified. Missing values and failed access are retained in `research/import_cost_1_29/evidence.json`. The existing common pass-through, usually 0.10, remains an editable assumption, not a measured national exposure or estimated elasticity. EU27 would require consolidated extra-EU inputs; summing member imports would incorrectly include internal trade.

Primary IMF research supports dampening of competitiveness effects through imported input costs, but does not imply generally neutral current accounts. Trade openness can offset lower elasticities. No zero-current-account or neutrality target is imposed. Demand, trade volumes, technology, foreign income and financing respond jointly. Controlled cases verify partial and complete mathematical price offsets. Large changes that exceed the annual price guard are reported as bounded. Every country also has matched depreciation experiments with and without producer-cost feedback; no effect appears before the shock.

## Government deficit / GDP

Deficit equals total government expenditure minus total revenue, the negative of net lending/borrowing. Dividing by that year's nominal GDP and multiplying by 100 gives the ratio. Positive means deficit; negative means surplus. The existing full fiscal coverage includes current and capital items, with its source scopes, noncash adjustments and assumed private counterparts retained.

Bond issuance, principal repayment and asset purchases are financing transactions. They do not become extra revenue or expenses. Year 0 shows the 2023 annual fiscal reference, which is not paid again into opening stocks. Generic experiments without an opening fiscal reference show unavailable values. The ratio is unavailable when nominal GDP is not positive. The outcomes, chart selector and government budget show the measure.

## Executed validation and limits

450 paths and 11760 annual steps cover every preset. Five paired seeds compare independently frozen 1.28 with 1.29: the first pair runs 120 years and the other four run 12. Each country also has an eight-year legacy replay and four twelve-year import-cost/depreciation comparisons. 57480 shared numeric values replay the frozen engine with the new mechanisms disabled. 3630 network frames preserve valid live, unique, non-self links. Maximum relative accounting residual: 2.353672812205332e-14. GDP, matched capital payments, public/private debt bridges, population, S − I = CA and changes in net foreign assets reconcile.

Using identical revised 2024/25 observations, pooled 29-country GDP RMSE changes 3.7014100060578676 → 3.7455683719927637 percentage points; MAE 2.8674851392728447 → 2.8908795354421257. Current-account RMSE changes 2.752196819477575 → 2.7546238806347842 percentage points of GDP; MAE 2.0708267347591023 → 2.078276478668073. 15 country GDP errors and 21 current-account errors worsen. All misses remain in the report. The overlapping EU27 aggregate is scored separately.

These observations were already examined in earlier work. This is a retrospective diagnostic, not an untouched holdout or independent forecasting validation. Repeated seeds are not additional historical observations. No coefficient or country inclusion was selected against future GDP or current-account values.

The 120-year paths are structural stress tests far beyond the evidence, not forecasts. 4 of 30 end below 1% modelled private debt/GDP; 3 exceed 300% at some point. These are diagnostic cutoffs, not calibrated targets. Weak output, extreme debt, currency bounds and price guards remain visible. Some long-run dynamics remain unrealistic.

Browser exports for USA and China use eight years and ten paired seeds each. Independent Node replays verify aggregate paths, paired effects, 95% intervals and inference. Per-country hashes and numeric comparisons are in `research/participation_1_29/browser_qa_USA.json` and `browser_qa_CHN.json`. Participation endpoints, the China scope correction and opening/final deficit displays were inspected. The current visual proof is `research/browser-participation-costs-1_29.jpg`.

## Primary references

- Eurostat: https://ec.europa.eu/eurostat/databrowser/view/lfsa_argan/default/table?lang=en
- ILOSTAT: exact API URLs and provider coordinates in `participation_age_rates_2023.json`.
- IMF: https://www.imf.org/-/media/files/publications/esr/2019/english/ch2.pdf
- ECB: https://www.ecb.europa.eu/press/economic-bulletin/html/eb201702.en.html
- OECD definitions: https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/trade-in-value-added/tiva-indicators-guide-2023.pdf

Opening source year is 2023; revised data retrieved in 2026 are not a real-time 2023 forecast vintage.


## Historical1.28 and earlier studies

# Policy-rate decisions, real exchange rates and private finance — engine 1.28.0

Current source inputs retain2023 initial policy quotes, fiscal totals, debt stocks, capital and human capital. New source/mechanism conventions are recorded separately in research/credit_audit_1_28/conventions.json. No future GDP or CA sets a financial coefficient or a debt target.

Policy decisions: common25bp steps for ECB/US instruments; China uses a10bp7-day repo convention supported by2023 policy decisions. Other national instruments use an explicit25bp scenario convention anchored to the observed opening quote, preserving off-quarter values such as Denmark3.60. These are not universal empirical restrictions. Several steps can occur within one model year. Unrounded policy-rule memory prevents artificial sticking from repeated rounding. The US target range remains0.25pp wide; the source opening5.375 is the midpoint of5.25–5.50. Midpoints enter transmission; ranges are displayed. Nonnegative bounds remain. The rule responds to lagged inflation; forecasts of actual central-bank meetings, full forward-looking mandates and joint euro-area policymaking are not identified.

Policy-linked loan, mortgage, deposit and public rates retain their existing spreads/pass-through and repricing. Commercial rates need not lie on the policy grid. A24,330-case lattice check covers all30 presets, extreme shocks, nonnegative bounds, opening instruments, commercial pass-through and no rounding-induced sticking. Policy level charts show the first paired seed as held-rate steps, with central95% seed-spread bands; Difference mode retains mean paired confidence intervals. Seed medians can lie between legal individual quotes and must not be presented as actual decisions.

Trade verification: q=(nominal currency strength)×domestic producer price/foreign price. Holding other inputs fixed, a real appreciation lowers foreign orders and raises imported-goods competition. A nominal depreciation exactly offset by domestic inflation leaves q and real trade competitiveness unchanged. Both signs and this counterexample pass all30 presets. Tariffs, productivity, foreign demand and funded domestic purchases remain separate. This is a model producer-price basket, not an observed CPI-based BIS real effective exchange-rate series or bilateral multi-country trade model. No unsupported replacement of the working real-price channel was made.

Business capital is now bought with actual funding and matching producer receipts; an unfunded order cannot become fixed capital. New bank lending creates matching deposits; equity/bonds transfer existing household deposits. Funded quantities leave producers' inventories and enter buyers' productive capital, counted once in GDP. Capital purchases are capitalized assets, not an extra current expense. The transaction/timing and allocation rules remain assumptions, not estimated credit-demand elasticities. Zero cash and constrained banks can reduce orders; no debt/GDP floor or automatic target stock is imposed.

Housing borrowers can preserve liquidity by using a financing-share proxy derived from initial mortgage debt and the synthetic mortgaged-owner structure collateral. This is not observed new-loan LTV. Policy-linked borrowing costs, income, LTV, down payments, available collateral and bank capital constrain credit. The final code caps the preference by the existing LTV and caps loan proceeds at the actual purchase budget, preventing an unintended cash-out refinance in a purchase-only transaction. The earlier450-path exploratory specification is frozen separately in research/frozen_credit_prototype_1_28 and labelled pre-correction; nine representative40-year prototype paths replay exactly.

Private debt is bank business credit + corporate bonds + household mortgages, a partial model measure. Initial business leverage is assumed; unmodelled consumer credit and other national liabilities are excluded. Debt is divided by current annual nominal GDP. Independently measured debt changes equal new borrowing minus principal paid minus principal extinguished in default. Default principal is not counted twice with collateral losses. The exact annual debt/GDP bridge splits net credit flows over current GDP from the change in the nominal-GDP denominator. A lower ratio can occur with a rising nominal debt stock. Principal repayment is not an income/GDP expense. These checks pass every step in the release comparison.

Final release comparison: 600 paths,26640 annual steps,30 presets×10 paired seeds×two independently frozen/current engines. Three pairs per preset run120years; seven run12. The120-year runs are numerical/structural stress tests, not validated forecasts; they extrapolate beyond published data. Network checks cover 3630 frames, with no invalid live/self/duplicate links and the requested degree. Maximum relative accounting residual is 5.5566662382489085e-14. Baseline1.27 rows replay independently when the new mechanisms are disabled.

Identical revised2024/25 observations, already examined in prior work, give pooled29-country GDP RMSE 3.7204824383403516 → 3.6960363824614513pp and MAE 2.872175020773367 → 2.8548572381739454pp. CA RMSE 2.817912360573007 → 2.786655911857522ppGDP; CA MAE worsens slightly (2.094029683142161 → 2.0973110841561). There are58 country/horizon GDP comparisons,57 CA comparisons, with ten repeated seeds each; repeated seeds are not new historical observations. EU27 overlaps its members and is scored separately; its GDP error worsens slightly. 11 country GDP errors worsen. This is a small retrospective fit gain, not an untouched holdout, general forecasting validity or empirical causal policy validation.

Among90120-year candidate stress paths,77old paths end below1% modeled private debt/GDP compared with9current paths. No floor was added. 10current paths exceed300% at some point, an illustrative diagnostic cutoff rather than an empirical bound. Extreme debt and low-output paths remain; changing finance mechanisms does not establish all long-run dynamics are realistic.

Primary references: Federal Reserve December13,2023 statement (https://www.federalreserve.gov/newsevents/pressreleases/monetary20231213a.htm); ECB rate history (https://www.ecb.europa.eu/stats/policy_and_exchange_rates/key_ecb_interest_rates/html/index.en.html); PBOC2023Q3 report (https://www.pbc.gov.cn/zhengcehuobisi/125207/125227/125957/4883187/1f14dbe28ec4408cbf45cee06f86808a/2023112817393565251.pdf); BIS real-exchange-rate methodology (https://data.bis.org/faq); BIS credit coverage (https://data.bis.org/topics/TOTAL_CREDIT); Bank of England money creation (https://www.bankofengland.co.uk/explainers/how-is-money-created); ECB SAFE financing uses (https://www.ecb.europa.eu/stats/ecb_surveys/safe/html/ecb.safe202504~3839a2deca.en.html). These support instrument definitions and mechanism directions, not a calibrated universal coefficient.


## Historical1.27 and earlier studies

# GDP hours, paired inference and independent sites — engine 1.27.0

The published1.26 engine and30 source profiles are frozen under research/frozen_engine_v1_26. No GDP trend target or ceiling was added. Education strength and the opening adult-human-capital source values are retained. An early-years education-off ablation yields essentially identical GDP. The initial stock is normalized, so simply reducing it is not a supported fix for the early surge.

PWT11.0 avh annual hours per person engaged2013–2023 supply the maximum/2023 hours ratio, mapped to the existing firm hours ceiling for all30 presets. EU27 uses employment-weighted member hours. The observations and SHA256 are in hours_envelope.json. Mapping aggregate hours to a representative firm's bound, and treating the historical range as a future limit, remain explicit proxy assumptions. This is not a measured physical bound or an estimated behavioural elasticity; future exceptional hours can be entered as an intervention. No country was selected based on later GDP errors. No future GDP/CA observation sets the ceiling.

Validation executes 600 paths and 12240 annual transitions. All30 presets use10 shared seed pairs; first3 seeds run40years,others12. GDP comparisons cover 58 independent country/horizon definitions with 580 seed-observation pairs. The two-year score is CAGR from the2023 origin, not just year2 growth. The overlapping EU27 aggregate is scored separately. Revised2024/25 observations were already examined in earlier work, not an untouched holdout or a real-time2023 forecasting vintage.

Pooled GDP RMSE: 4.35726470400738 → 3.7204824383403516 percentage points. MAE: 3.7076037522974965 → 2.872175020773367. CA RMSE worsens: 2.55528939998204 → 2.817912360573007 percentage points of GDP.13 individual-country GDP errors worsen, including USA and China. This is a GDP-fit improvement with disclosed trade-offs, not a claim of universal or out-of-sample reliability. Long-run poor paths are retained. All financial identities reconcile, maximum relative residual 1.7430501486614958e-14.

Rejected trials: full source-consumption anchoring and joint consumption/firm-allocation alignment worsen pooled GDP error. Their experimental engine, exact inputs, all results and ablation variants remain in research/growth_audit_1_27; they do not run in production. Randomizing the network gives negligible short-horizon error improvement and has no empirical topology calibration, so its partly rewired-ring topology is retained. 1230 frames passed identity, live-neighbour, degree, duplicate and self-link checks. Directed reachability can be incomplete (minimum 0.47368421052631576); clusters are retained rather than artificially imposing full connectivity. No real-firm adjacency data are claimed. Size remains productive capital, with circle area on a fixed time scale.

Real GDP per capita growth =100×[(realGDP_t/pop_t)/(realGDP_(t−1)/pop_(t−1))−1]. It is annual growth, not a level gap or cumulative growth rate. Year0 without a preceding model observation is displayed/exported unavailable; internal placeholders retain finite engine rows for compatibility. It replaces the visible original-cohort knowledge outcome; internal knowledge diagnostics remain for earlier experiments and decompositions.

Level paths use interpolated empirical P2.5–P97.5 across seeds, a central95% simulation interval, with medians. Difference mode and headline cards use the mean of seed-level paired effects and a95% Student t interval, mean ± t_(.975,n−1)×sampleSD/sqrt(n). Final real-GDP percentage effect per seed is the stated primary comparison. Years are not independent replicates. Two-sided p-values test zero mean paired effect; failure to reject is not equivalence. Other outcomes/years are exploratory pointwise comparisons without multiplicity correction. One seed and zero-variance samples have no invented t-test p-values; small or skewed samples may violate the t approximation. Seed pairs must behave independently. These intervals quantify conditional Monte Carlo uncertainty only, excluding data, parameter and model uncertainty; they do not validate a real-world causal policy effect.

Independent numeric references:199 Student t critical values and49 tail probabilities from scipy.stats.t, plus analytic paired SE/interval, identical-control, constant-effect, single-seed and95% quantile cases. Source: NIST/SEMATECH https://www.itl.nist.gov/div898/handbook/prc/section3/prc312.htm . PWT source: https://www.rug.nl/ggdc/productivity/pwt/ .

Browser QA exported30 EU27 seed pairs over8years; independent Node replay checked264367 numeric values including paired means, confidence limits and p-values, maximum relative difference2.02e−13. Year0/final-year hover, both chart modes and the replacement metric were checked through controls. The report is browser_qa.json. Extra all-country source, global-input, education and financial regressions pass. Older1.26 study replay is pinned to its frozen engine/input profiles.

Only after model/interval/browser checks, the shared launcher and cross-links were removed from both Innovation Observatory and Econometrics Lab. Each keeps its current audience. No curriculum order, progress or econometric model was changed in that site.


## Historical1.26 and earlier studies

# Annual age cohorts, consistent income measurement and foreign public creditors — engine 1.26

Each period is one year. All 30 country/area presets start from documented 2023 source references, not current 2026 populations or policies. Annual age profiles advance as cohorts survive, age, receive migrants and reach the pension threshold. Statistical working age (15–64), pension eligibility and labour-force participation are different measures.

European source age counts are single-year Eurostat observations; US counts are Census 2023 single ages. China uses World Bank/HNP five-year counts (UN-based) with uniform within-band allocation explicitly marked as a proxy. The China 80+ group remains open; ages 81–100 are padding rather than invented observed ages. Editing opening child/older shares rescales the corresponding observed age profile. Death hazards use observed mortality shares in three broad statistical groups; age-specific hazards inside those groups, future migration allocation/skills and future birth rates remain simplified assumptions. Age-cohort stocks balance births minus deaths plus net migration each year.

The editable **Pension eligibility age** has a country-specific, dated statutory reference. Sex/career differences and early/full-benefit distinctions are retained in the source download. A population-weighted or otherwise representative scalar is a proxy, not the actual age every worker retires. Sweden uses the 2023 guarantee-pension age reference of 66, with earliest income pension 63 retained, replacing a stale source entry. The US reference is full-benefit age 66 years 6 months for the cohort reaching that age in 2023; long-run age 67 is separate. China has sex/occupation-specific ages; the male/rural reference of 60 is not claimed to be a national average. EU27 is a derived weighted reference, not an EU-wide pension law. Future reforms are not automatically predicted: use a timeline, including the illustrative +2 years from year 5 example.

Baseline labour participation before age 65 matches each preset's observed initial 15–64 participation. European older participation uses the observed Eurostat 65+/15–64 activity-rate ratio; USA and China use separately retained ILOSTAT published estimates for the same age bands, with source codes/status flags and a US BLS cross-check. The activity boundary starts at age 65, independent of the country's legal pension age. A pension reform shifts that activity profile by an **unestimated default 0.5 year per policy-year change**; 0 and 1 are sensitivity bounds. Eligibility changes pension benefit commitments independently. This avoids pretending that all eligible people stop work, or applying a 65+ average only to people above age 67.

## The US opening labour-share jump

The published 1.25 seed-2026 example rose from 58.1734% to 61.6145% between years 0 and 1. Its opening income account omitted 4.10884 nominal units of other production-tax coverage used from year 1. Applying consistent coverage gives an opening share of 60.7276%: about 2.5542 points of the 3.4411-point jump were a measurement discontinuity. The remaining roughly 0.8869 point reflects the model's wage/hours and value-added response; it is not validated next-year wage data. The isolated measurement correction leaves all wages, GDP and later numerical rows unchanged.

The model's opening labour scale uses PWT labour shares as a proxy. PWT uses basic-price GDP, estimated self-employment income and different methods across countries. It is not literal employee wages divided by market-price GDP or the displayed factor-income denominator. China's PWT method is “Naïve share”, status “Assumed constant or interpolated”; this is now labelled a proxy. BEA's employee compensation share of factor income rose only about 0.0757 percentage point from 2023 to 2024, but its definition differs from the model's adjusted labour proxy. The model must not claim that its remaining jump matches that observation.

## Government bonds sold abroad and external accounting

Opening external public claims use Eurostat `gov_10dd_ggd`, Federal Reserve/TIC/US Treasury and SAFE source snapshots. Total external government debt is observed for 29 presets; the EU27 extra-EU aggregate is unavailable and is displayed as missing, with a zero execution sentinel explicitly disclosed. National foreign-holder positions include intra-EU holdings and cannot be summed to obtain extra-EU debt.

Foreign securities, identified other debt and unallocated external instruments are separate. Greece's high external public debt mainly represents official loans, not a high foreign ownership of the bond book. The US Treasury holdings are a verified subset with a narrower issuer/valuation scope than broad general-government external debt; the residual stays unallocated. China SAFE provides securities and loan instruments. Stock ownership maps to new-issue participation as an unestimated flow proxy; return, currency, debt and lagged current-account risk tilt that participation. A current-account deficit does not mechanically require foreign government borrowing, and a surplus can coexist with it.

At foreign issue, public liabilities and financial-sector external settlement assets increase together; at foreign principal repayment both fall. Neither operation improves the current account. Coupons on opening external public debt reduce primary income. The existing opening residual foreign-income channel is rebased before coupons are shown explicitly, preventing double counting. All domestic/foreign government holders and the public expense bridge reconcile. National saving minus investment equals CA; independent annual net foreign asset transactions equal CA. Currency valuation is reported separately. Bonds are domestic-currency claims; secondary trading, full national IIP coverage, foreign capital transfers and country-specific investor-demand elasticities remain outside this implementation.

## GDP declines: inspect drivers, retain weak paths

The new outcome details decompose each seed's largest peak-to-later-year real-GDP decline into consumption, government consumption, fixed investment, inventory accumulation and net exports. These components add exactly to the GDP change. Technology, paid hours and capacity use show accompanying movements. A short inventory reversal can lower GDP despite rising final demand; longer weak paths can reflect consumption/investment, labour supply and financing feedbacks. These are model co-movements, not a demonstrated normal business cycle or a causal identification.

A separate trial aligned opening firm demand with capital×technology. It worsened the same-country, same-seed retrospective GDP RMSE (about 4.419 to 4.539 points) and was rejected. No coefficient was selected to improve previously examined future outcomes. The current comparison uses the independently frozen published 1.25 engine, all 30 presets, three paired seeds and 40 annual steps. Revised 2024/25 observations are retrospective diagnostics, not untouched holdout validation. The country pool excludes the overlapping EU27 aggregate, which is scored separately. Full scores, long-run weaknesses, income decompositions, foreign claims and policy mechanism checks are in `revision126_validation.json`.

Source raw bytes/hashes, coordinate extracts and definitions are in `research/demography_1_26`, `research/sovereign_foreign_1_26` and `research/dynamics_audit_1_26/income_evidence`. Optional PWT DTA/PDF and pension/Fed PDFs remain in versioned source; the downloadable bundle includes reproducible compact extracts, source URLs, hashes and retrieval instructions within its hosting size limit. Historical engine fixtures are losslessly compressed with a hash manifest. Source calibration uses opening-year fiscal moments only. Legacy engines and calibration are retained for independent replay; current requested structural channels are tested separately from forecast accuracy.


## Earlier fiscal and component studies

# Fiscal coverage and defence — engine1.25

The source origin remains2023, aligned with capital and labour inputs. All30presets have verified opening general-government revenue/expenditure totals and detailed economic classifications. Latest2024/25 observations are separate references, not mixed-year opening stocks or fitted future targets. Official statistics can be revised; hashes establish file integrity, not certainty.

## Fiscal measurement and implementation

European ESA2010 S13 revenue equals sales/own-account output, taxes, social contributions, property income and transfers. Economic expenditure includes compensation, inputs, taxes/subsidies, property income, social benefits, transfers and capital uses. P3 already overlaps payroll and inputs, includes noncash consumption of fixed capital and deducts sales: do not add it again to the economic classification. Functional health, education, social protection and defence are alternative overlapping classifications. Missing optional cells and flags are retained; household/corporate tax gaps use only the matched official tax supplement. Denmark2025 revenue is unavailable, not fabricated from expenditure plus an EDP balance.

BEA federal/state/local NIPA current accounts differ from ESA/GFSM. Total expenditure bridges current expenses by adding gross public investment, capital transfers and nonproduced-asset purchases, then subtracting depreciation already inside government consumption. Native2023 revenue27.3883%GDP and expenditure35.2969%GDP are reported. Government sales2.4475%GDP are grossed equally for the internal execution bridge and netted equally for reporting; that gross comparison is a proxy, not a literal IMF total.

The old USA economy paid no Medicare/Medicaid purchases despite opening household income including those noncash benefits. It generated an initial model current surplus instead of the observed current deficit, then reduced private spending and output. The correction finances restricted third-party health purchases6.8428%of lagged nominalGDP in the same rationed goods market. Services enter household consumption once, are VAT-free, and never become spendable household deposits. The partial cash income proxy removes Medicare/Medicaid and NET owner rental income, not gross imputed rent. Other insurance/pension imputations remain a limitation.

USA public-employee defined-benefit imputed interest is not all a bond coupon. New accruals create equal noncash household claims and government pension liabilities, with no deposits. Their distribution by earnings rank is an assumption; the opening stock is not identified. Bond borrowing/redemption remains separate. The public retirement-benefit source is a verified Social Security retirement subset, not all public pensions.

China uses the MOF published four-budget consolidated aggregate and revised2023GDP129427.17billionCNY. Internal social-fund subsidies and land-related asset operations are removed. General-budget taxes, social-fund contributions and residual receipts are disjoint. Full consolidated current/capital/P3/interest splits are unavailable. The model's combined fiscal-coverage execution convention does not turn unknown source capital spending into observed zero. Property/transaction taxes are not a broad annual wealth tax.2024 is the latest directly published consolidated total located; detailed2025 budgets do not establish a published consolidated2025 total.

The broader fiscal execution is explicitly a CASH-EQUIVALENT COVERAGE BRIDGE. Three frozen2023 seeds, with price/population/policy/FX and foreign trend movements disabled, measure already-funded model flows. Source household-tax/social, corporate-tax, production-tax and other-current receipts reconcile through cash-constrained signed adjustments; unpaid amounts are reported. Missing current expense coverage is a signed transfer to firms. Own-account memos are equal noncash receipts/expenses. Capital receipts/outlays are financing transfers against national investment ALREADY counted: no duplicate GDP or current income. Exact private counterpart allocations and public capital ownership are not identified. Future lagged-GDP-share continuation, rather than source statistics, is an assumption. User tax changes still change their corresponding tax channel; no future GDP or current-account target is imposed.

## Checks and limits

`tests/fiscal-source-audit.py` checks primary raw hashes, coordinate extracts, economic category sums/rounding, missing fields and source scopes. `tests/fiscal-reconciliation.mjs` compares independently archived published1.24source with the candidate, all30presets×5matchedseeds×40annualsteps. It checks source totals, source-only migration, authored settings, future-event timing, income/expenditure GDP, labour+capital shares, noncash claims, sector deposit bridges, independent national saving−investment=current account and annual NFA transaction changes. Seeds are repeated stochastic model draws, not independent historical observations.

Revised2024/25 GDP annualised growth over horizons1/2 and matched annual current accounts form retrospective diagnostics.29countries are pooled, EU27 scored separately. USA GDP RMSE improves2.96→0.94points; pooledGDP4.37→4.35andCA2.69→2.54. Some individual errors worsen and extreme long-run paths remain. The correction improves fiscal coverage/accounting and modest aggregate fit; it does not establish forecast accuracy, realistic long-run dynamics or causal multipliers. No coefficients were chosen to make USA GDP rise or to restore a country growth ranking.

## Defence classification and experimental channel

Eurostat GF02P3/totalP3 classifies existing government consumption for28European presets. GF02TE, personnel, inputs, capital formation and GF0204R&D are retained as separate source concepts with missing cells. BEA defence consumption, gross investment and R&D investment have their actual scopes: R&D investment is part of gross investment. G+I is an output-use measure, not an interchangeable fiscal cash-total statistic. China general-budget defence is observed, but its military P3/personnel/investment/R&D split remains unavailable. No obsolete equipment share substitutes for R&D.

`publicDefensePurchaseShare` only classifies existing G; it does not increase spending, GDP or technology. For China the default execution0means unallocated P3, and charts display unavailable rather than zero defence. Users can supply an explicit allocation assumption. Reported healthcare, education, defence and other services sum to G once, with normalization if edited shares exceed100%.

`defenseResearchChange` is a signed intervention in government-funded R&D, default0meaning NO CHANGE rather than zero military research. The example adds0.10GDPbudgetpoints fromyear4. Funding increases the existing public research budget once. Its government-funded business portion increases requested total business GERD; the general government business-allocation and labour-share proxies apply. Actual research requires paid workers and finance in the existing model. Private funding is not automatically multiplied; no direct TFP increment is assigned. Public nonbusiness research uses the existing explicitly unestimated frontier mechanism. Negative changes cannot create negative funding. Timing tests prevent future events affecting earlier states.

Moretti, Steinwender and Van Reenen, Review of Economics and Statistics107(1),2025,14–27, DOI10.1162/rest_a_01293, find evidence of public-R&D-induced private research and productivity gains in studied OECD industries/French firms. Working-paper/published specifications differ. This is not an elasticity for total military expenses, all countries, or direct TFP; no universal point estimate is imposed. The simulation omits identified military import content, security benefits, military-sector production and country-specific innovation spillovers. These omissions are visible, not replaced with fabricated observations.

`tests/defense.mjs` verifies source allocation, no double counting, all30unchanged baseline GDP paths, positive/negative funding, future timing and accounting. Classification improves measurement; no forecast improvement is claimed from renaming expenses. Exact observations and scenarios: `defense_benchmarks.json`, `defense_validation.json`.

## Reproducibility

Primary research folders retain raw sources, extraction scripts, source coordinates, flags and hashes. The downloadable bundle losslessly compresses repeated archived fixtures, restored with verified hashes by `npm test`. Large optional BEA workbooks stay in Git; full extracted observations, URLs, hashes and extraction scripts remain in the25MiBdownload. Source-scope and missing-category limitations survive both routes. Rebuild order is documented in README.


## Archived studies and earlier releases

# Continuous export bids — engine 1.24.0

This release addresses a numerical market-clearing artifact found while continuing the current-account and productivity audit. It does not introduce a new empirical TFP target or force a country's trade balance to keep its historical sign.

## The artifact and correction

The prior market represented 90% of foreign orders in four equal blocks bidding 0.90, 0.97, 1.03 and 1.10 times the base foreign bid. Ten percent were repeat customers paying at least 1.01 times the domestic bid. Domestic orders were a separate block. Sorting these point masses gave large discontinuous reallocations when a small price change moved a foreign block past the domestic price.

In a controlled 100-unit order book with 100 available goods and domestic demand of 100, moving the base foreign bid from 1/1.03−1e−8 to 1/1.03+1e−8 raised exports from 32.5 to 55 units, despite the negligible price change. The continuous version moves exports from 44.9999965 to 45.0000035. This is a numerical continuity check, not an empirical elasticity estimate.

The revised 90% component is uniform over 0.865–1.135 times the base bid. This interval extends about half a typical old grid spacing beyond the outer bracket centers. Its mean multiplier is 1.0, exactly the old four-block mean; the total quantity of foreign orders and the 10% repeat-customer component are preserved. The interval and distribution shape are a declared smoothing choice, not fitted data. No range, elasticity, demand-growth rate or R&D parameter was searched against later observations.

The algorithm cuts the continuous distribution at the domestic and repeat-customer bid prices. It then clears in descending bid order. If supply runs out inside a segment, only its highest bids are filled, and receipts integrate those prices rather than averaging the entire unfilled segment. Firm allocations account for inventory exhaustion during each tranche. No output, deposits or foreign demand are manufactured. The earlier rule remains available through the advanced `continuousForeignBids=0` comparison setting; source presets use 1.

## Independent checks and comparative evidence

A separately frozen old market module checks legacy replay. Independent dense lists of 20,000 foreign buyers check the continuous solution across ample supply, scarce supply, different price offers and different domestic demand. Other checks cover goods conservation, nonnegative inventories, unfilled low bids, full-order quantity and average-receipt preservation, saved scenarios, parameter timing and no effect from future changes.

The main study runs all 30 presets × 5 common seeds × 2 rules × 40 annual steps: 300 paths and 12,000 years, with two additional 12-year timing paths. All outcomes are retained. It verifies independently calculated S−I=CA and transaction ΔNFA=CA, positive gross foreign channels and finite financial/goods accounting results. The maximum relative accounting gap is below 3e−14.

The 29 individual countries are pooled without duplicating the EU aggregate. Available 2024/2025 current accounts supply 57 country-year observations, each compared across five seeds (285 model-observation pairs). Current-account MAE falls from 2.003834 to 1.987469 percentage points of GDP, RMSE from 2.707563 to 2.692350. China MAE falls from 3.095040 to 2.972590; the USA and EU aggregate barely change. Bulgaria, Croatia, Luxembourg and Poland have small error increases. The improvement is modest and is not universal.

Real GDP growth is annualized from the 2023origin and compared with 58 country-year observations, each across five seeds. RMSE changes from 4.369757 to 4.368890 percentage points: effectively unchanged and still poor. The EU aggregate is reported separately. Source targets use frozen Eurostat chain-volume growth, BEA's September 2026 annual revisions for USA 2024/2025 (3.0%,2.3%), NBS final2024 growth and preliminary 2025 growth for China (both 5.0%). Official web-table coordinates and dates are retained; raw HTML is not archived for those four supplemental observations. Two World Bank API attempts timed out, so no WDI observation was invented. Source vintages are disclosed and not presented as information available in 2023.

The acceptance criterion was removal of the numerical jump, lower all-country retrospective CA MAE, and no GDP RMSE increase greater than 0.25pp. It was recorded after a preliminary USA/China/EU screen and before inspection of the all-country result; this is not an ex-ante preregistration. The tested outcomes and revised source vintages have already been examined, so no untouched holdout or statistical confidence interval is claimed. Five seeds are simulation variation, not five independent historical data sets.

## Retained weaknesses

Long-run behavior remains mixed. Across the 150 paths per rule, low-employment years (employment below 50% of the labor force) increase from 261 to 290; years at the nominal currency bounds increase from 411 to 417. Other foreign-income cash shortfalls decrease in aggregate. These screening cutoffs are assumptions and not empirical forecast targets. Long-run paths do not become validated because the market-clearing calculation is smoother. The new numerical rule is enabled for source presets because it removes an artificial point-mass sensitivity and modestly improves the available current-account comparison; the earlier rule remains reviewable rather than being deleted.

Source 2023 current accounts, PWT historical TFP benchmarks and country-specific OECD conditional frontier paths from 1.23 are retained. None of these fixes establishes a permanent USA-versus-EU future TFP ranking. Causal policy multipliers and broader long-run GDP dynamics remain unvalidated.

## Reproduction

Run `node tests/continuous-bids.mjs` or the full `npm test`. The test writes `dist/data/trade_bid_validation.json`, including every country/seed comparison and long-run summary. `research/trade_bid_candidates/protocol.json` records the decision rule and preliminary-screen disclosure. `manifest.json` hashes the frozen Eurostat snapshot and the extracted USA/China observation file; the latter hash verifies the extracted file, not raw official HTML. The frozen 1.23 market module supports replay. The opening export-order calibrator now calls exactly one `Economy.step(1,1)` instead of generating eight steps to read the first one; fitted export-sales moments remain within the same tolerance.


## Earlier current-account and component audits

# Current accounts, R&D units and comparable productivity — engine 1.23.0

The current release corrects source mappings and missing external-income accounting. It does not establish a validated structural forecast. One step remains one year; the default origin is a normalized 2023 snapshot.

## Primary observations and units

Frozen IMF balance-of-payments data distributed by World Bank WDI provide current accounts (BN.CAB.XOKA.GD.ZS), exports/imports of goods and services in current USD (BX.GSR.GNFS.CD, BM.GSR.GNFS.CD), and GDP in current USD (NY.GDP.MKTP.CD). WDI national-accounts shares supply government final consumption, fixed investment and gross capital formation. The net other-income/transfer balance is CA minus goods/services exports less imports. It is not mislabeled trade. The unused secondary-income snapshot is retained as context; it is not added again.

2023 CA/GDP: USA −3.3489507%, China +1.4068110%, constructed EU27 +2.5823208%. Later observations are displayed separately: 2025 USA −3.8254127%, China +3.7697224%. The available 2024 EU constructed balance is +3.1563697%; at least one 2025 member observation is absent, so the UI displays a gap instead of inventing an EU value. EU CA is the sum of member current-account values divided by member GDP, not an official consolidated extra-EU balance. Intra-EU asymmetries can remain.

China business-performed R&D is 2592.22bn CNY divided by same-vintage preliminary GDP 126058.2bn CNY ×100 =2.0563676% GDP. The old formula multiplied an already percentage-valued ratio by100 again, generated205.9347%, and runtime sanitization clipped it to 10%. The correction uses the NBS source arithmetic directly. A regression now checks every raw source parameter against its runtime bounds; clipping source errors can no longer silently pass release tests.

National PWT11.0 rtfpna observations support within-country historical TFP growth. 2013–2023 annual compound growth is2.2525395% China,.5293373% USA,.1891736% EU constructed mean. EU weights are fixed 2023 PPP output-side cgdpo shares over all 27 members. This is a weighted mean of national growth rates, not a national-accounts aggregate TFP index. Other historical windows can change magnitudes and rankings. It does not imply that every EU country underperforms the USA or that future rankings are fixed. The extracted CSV is checked field-by-field against the frozen official workbook.

## Opening accounting and trade coverage

The old origin always set CA 0 and S=I, despite nonzero net exports. Moreover, scaling both gross trade flows to5% scaled the complete net balance too. The revised origin preserves observed net goods/services exports N, while compressing only common offsetting gross trade B=.05×min(X,M): model exports B+max(N,0), imports B+max(−N,0). Both gross channels remain positive. This is an explicit model-coverage proxy, not a representation of complete national gross exports/imports. Imported intermediates and supply chains remain absent.

Government consumption and fixed investment now use actual GDP shares rather than shares of domestic final uses. Opening inventory investment is gross capital formation less fixed capital formation. Consumption is the residual consistent with GDP 100, housing services, net trade and inventory investment. BOP/national-accounts definition differences enter that residual, rather than being falsely presented as a completely harmonized observed consumption series.

An unobserved potential export order book is calibrated to the opening realized-sales proxy under frozen 2023 conditions. Prices, policy, currency, population and foreign demand are held fixed and supply noise removed; three predeclared seeds2026,9945,17864 are averaged. Bisection fits that opening sales moment, with maximum absolute error below .000057 GDP units. No2024/2025 CA targets enter this calibration. This fixes an unsuccessful intermediate bid-ladder scaling that inflated orders. Order books and behavioral trade elasticities are not directly observed or econometrically estimated.

Year0 combines annual source-flow benchmarks with opening financial stocks. CA, gross investment and the implied saving benchmark are displayed. They are not applied to stocks again: year0 has no represented previous stock observation and its annual NFA-change metric is unavailable. For every completed simulation year, independently computed acquisition-cost ΔNFA=CA and S−I=CA. Currency valuation is recorded separately. Initial net IIP remains a simplified matched-stock proxy, not an empirically calibrated complete national IIP.

## External income and finance

The model now includes net other primary/secondary income and transfers, allocated to household deposits as a condensed sector-allocation proxy. At opening it equals observed CA minus net goods/services trade; modeled opening household portfolios and net bank settlement holdings are zero in the source presets. It is not counted as production or GDP. Continuation as a percentage of lagged nominal GDP is an assumption. Outgoing payments require available household cash; shortfalls remain explicitly reported. This simplification can matter substantially for small financial centers.

Financial-sector net foreign settlement assets earn the foreign basket cash yield and net foreign funding pays it. Household foreign assets retain their own foreign yield. Under equal yields and fixed FX, debt-funded matched portfolios generate offsetting income and funding cost. The net settlement position is denominated in domestic units, whereas household portfolios bear currency valuation risk; they are not identical instruments under changing FX. Equal asset/funding yields and absence of a sovereign or bank external risk premium are assumptions. Financial-sector foreign income enters its independently calculated saving once.

## Domestic knowledge and exchange rates

Previously, domestic knowledge advanced at a common .3% while foreign donors used country-specific conditional projections. The home frontier now uses the same annual OECD EFFLABS ratio^0.67 transformation as the donor paths. USA and China use their national series. EU uses the same covered-member aggregate proxy as the EU foreign donor. Countries without a national path explicitly use the EU projection fallback. OECD BAU1/BAU2/ET1–ET4 remain selectable. Paths use the2025/2026 vintage, which was unavailable at the2023 origin; this is not a real-time historical forecast. The last source growth rate repeats beyond 2100. The historical PWT growth benchmark supplies the editable fallback when conditional paths are disabled.

Home knowledge advances after the year's firm learning; firms cannot adopt a future frontier early. Actual innovation still requires funded research, success draws, absorption and a positive sampled learning gap. The frontier is a knowledge opportunity, not an imposed firm-technology or GDP target. The old output-based TFP residual is numerically retained and clearly relabeled; a separate capital-weighted firm-technology index starts at100. Current-capital weights include composition/entry/exit effects. Neither simulated measure has identical input or sector coverage to national PWT TFP.

The old currency reference remained nominal 100 even as domestic and foreign prices diverged, mechanically driving real depreciation/surpluses under low domestic inflation. A gradual completed-price PPP reference can now enter the existing real-rate premium rule. Default adjustment speed .15 is an unestimated long-run scenario; it is not exact short-run PPP or an estimated Chinese managed-exchange-rate model. FX shocks, the central-bank response, adoption-cost effects and nominal50–200 bounds remain. Bound-hitting paths are retained in the report. The speed was not optimized to future CA observations.

## Executed comparisons and limitations

The new focused audit executes60 paths /2400 annual steps: all 30 current presets for 40 years plus15 current/15 earlier matched USA, China and EU paths across five common seeds. The release also reruns the existing all-country baseline/stress, education, configuration, finance, trade and event suite. Source checks independently verify270 macro coordinates and4176 PWT extract fields, and all source hashes.

Five available country-year CA observations (USA/China 2024–2025, constructed EU 2024) are each compared across five identical seeds:25 model-observation pairs. Mean absolute error falls from 3.54028 to 1.65511 percentage points of GDP, RMSE from 3.59816 to2.12367. All countries, seeds and years are retained. Revised source vintages, OECD projections published after the origin, and these already examined outcomes mean this is a retrospective diagnostic, not an untouched forecast holdout. Per-country MAE: USA 3.95562→.64033, China 3.52214→3.09504, EU 2.74587→.80482. China’s remaining near-term CA error is large. No broad GDP/TFP forecasting gain is claimed.

Long runs still include GDP weakness, low employment in some presets, binding currency bounds and cash-constrained foreign transfers in small financial centers. For example, China can briefly enter a simulated deficit and then return to a surplus; the historical opening surplus is not a permanent restriction. The40-year simulated USA/EU technology ranking can differ from historical 2013–2023 growth because source projections and financial/demand responses differ. These are conditional scenario outcomes, not empirical claims about the current world.

A source cash-budget MPC variant was investigated but not added: in one-seed diagnostics it moved China’s early CA closer to observed values but worsened the already weak US GDP path. This is insufficient evidence for a general improvement. No universal innovation coefficient, fiscal stimulus or forced trade sign was tuned to hide weak outcomes.

Saved scenarios refresh only unchanged old source mappings, including the corrupted Chinese10% fallback. Authored rates, references, event schedules and custom frontier rates remain; custom pre-1.23 frontier choices disable the new home projection unless requested. Source benchmark fields refresh and migration is idempotent. A deliberate old custom China10% R&D value is indistinguishable from the former clipped default, so the backed-up old scenario remains available for review.

## Reproduction

Run `npm test`, `python3 scripts/check_macro_sources.py`, and `python3 scripts/check_global_sources.py`. To rebuild from frozen data run the global integrator, education integrator, macro integrator, then export-order calibrator in that order. `dist/data/macro_external_benchmarks.json` and `macro_external_validation.json` contain exact inputs and all retained comparisons; the source manifest records source URLs, retrieval and hashes. Large earlier trajectory fixtures are losslessly bundled as `research/historical_runs.tar.xz` in the downloadable source; unpack with `python3 scripts/unpack_historical_runs.py` before optional earlier study scripts. They are not needed by the current release suite.


## Archived studies and earlier releases

# Updated learning data and stronger skills transmission — engine 1.22.0

The current release uses World Bank HCI+ 2026 national learning data and adds an adjustable workforce-skills effect on research and domestic/foreign technology adoption. The new **Education & innovation** experiment doubles the elasticity of that skills multiplier from year 1 and raises public/household-funded school quality by 50% from year 4. National data presets retain the prior elasticity of 1 because a larger causal coefficient has not been identified. Its value is an explicit experimental assumption, not an empirically validated improvement to the default forecast.

## Updated primary data

The frozen Catalog panel and official World Bank repository panel contain the 2025 HCI+ estimates, released in 2026. Catalog: https://datacatalog.worldbank.org/search/dataset/0067030/human-capital-index-plus . Repository: https://github.com/worldbank/HCI-Plus . Source URLs, retrieval dates and SHA256 hashes are in `research/education_2026/source_manifest.json` and the downloadable education benchmark file.

All 29 national presets now use this release. EU27 is reconstructed from member scores using 2023 population aged 0–14 as a pupil-cohort proxy. US 509.7613 is above the constructed EU27 504.3997; it is below several EU members. Italy is 500.0652. These are harmonized learning outcomes on a TIMSS-equivalent scale, not university rankings, research leadership, spending efficiency or a causal public/private comparison. Source harmonization across grades and test programs does not remove every comparability problem. The two distributions are copies of the same primary dataset; their match is source-format consistency, not independent measurement confirmation.

The 2025 estimate label is distinct from actual assessment timing. Most selected learning sources are PISA 2022 and/or TIMSS 2023; Luxembourg retains PISA 2018. China retains a 441 national extrapolation from PISA/PIRLS 2015. The 2026 update does **not** provide a new nationwide Chinese test. Leading Chinese provinces cannot silently stand in for the whole country. OECD PISA 2025 reports 597 in science, 612 in mathematics and 527 in reading for Beijing, Shanghai, Jiangsu and Zhejiang, a regional population on a different scale. The evidence page displays these results as context, with their scope, and does not substitute them into the national parameter. Source: https://www.oecd.org/en/publications/pisa-2025-results-volume-i_73451bc5-en/full-report/student-performance-in-pisa-2025_23e075c2.html . No exact contemporary national China-versus-EU ranking is inferred from these mismatched populations.

Each national quality input remains harmonized score /625. Source years and test programs are extracted from the official HCI+ `hlo_data.dta` output; the compact, exact metadata projection is saved as `learning_source_metadata.csv`, with its parent hash and transformation. The original two Stata intermediates remain in Git but are omitted from the downloadable source bundle because they include large, unnecessary country/year grids. Their exact URLs and hashes allow retrieval. The bundle includes both full country-year CSV panels in lossless XZ compression, the codebook, the source metadata projection and all inputs needed by the offline integration script. It does not require those omitted intermediates to run.

The HCI+ definition of learning-adjusted schooling differs from the previous HCI: **LAYS = (primary/secondary expected years + pre-primary expected years) × HLO /625**. We checked this definition against the source codebook and all 29 national rows. Omitting pre-primary would create an error of about 0.7–0.8 learning-adjusted years in many of these countries. The broader education pillar also reproduces 12 × LAYS +64 × min(tertiary completion, 0.5), in index points. These are source-arithmetic checks, not new aggregate production coefficients. Only both-sex measures are used; the codebook's flagged female-LAYS construction is not used.

Using 2025 estimates in the model's 2023 normalized opening economy is a disclosed latest-data proxy and uses later information. It cannot be presented as a real-time 2023 forecast. Public/private causal quality gaps remain unidentified; both funding channels receive the national anchor as an explicit allocation fallback. Current adult PWT human capital remains separate. Updating the learning source does not create an instant GDP jump or replace today's workforce with today's students.

## Stronger education transmission

Let H be the current workforce human-capital index divided by its opening value, and η be **Education effect on innovation and adoption**. The research/learning multiplier is H^η. Previously it was H, equivalent to η=1. At η=2, a 10% increase in workforce skills gives a 21% increase in this multiplier. This does not imply a 21% change in successful innovations, technology, TFP or GDP.

The multiplier enters funded research success probabilities, domestic knowledge-gap adoption and foreign technology adoption. Existing probability bounds, available knowledge gaps, foreign access and adoption delays remain. It does not directly multiply the TFP residual or GDP, alter paid research finance, or bypass production constraints. A lower H can also weaken innovation/adoption more strongly. Direct labour efficiency still uses H once. School funding and quality use the existing per-child resource response and learning lag; neither its 0.2 elasticity nor its ten-year delay is changed.

The direction of the channel has support in research on human capital and diffusion, including Benhabib and Spiegel, *Human Capital and Technology Diffusion*, FRBSF working paper 2003-02: https://www.frbsf.org/research-and-insights/publications/working-papers/2003/12/human-capital-and-technology-diffusion/ . This does not estimate the value 2 in this ABM, establish a universal dominance of education over other controls, or distinguish a causal education multiplier from institutional and selection effects. The stronger experiment and adjustable control expose that uncertainty; no coefficient was selected to force GDP upward.

Legacy 1.21 quality settings, references and timeline targets are rescaled by new opening anchor / saved opening anchor. This preserves the user's relative intervention when national source values change and applies once. Earlier unit multipliers still migrate correctly. Numerical experiment design and prior user edits are retained.

## Executed validation

- The new skills-transmission study passed **125 paths and 4,925 annual steps**, including all 30 presets and two common seeds at strengths 1 and 2 with a year-4 quality reform. Maximum relative accounting residual: 1.42e-14.
- Controlled first-step comparisons across **1,800 firms** held skills, funding and production constant. Stronger transmission did not reduce firm technology or create same-period goods. A scheduled future strength change did not affect previous years. Disabling education neutralized the multiplier. Source-anchor migration preserved relative edits and was idempotent.
- Among the 60 strength-2 versus strength-1 reform pairs, final firm technology was higher in all 60. GDP was higher in 57 and lower in 3; the output-based TFP residual was higher in 59 and lower in 1. Median final gaps were about 0.36% for GDP, 0.33% for the TFP residual and 0.44% for technology. These are conditional sensitivity outcomes with endogenous demand, finance and reallocation; they are not forecast accuracy scores.
- The income/source study passed **129 paths and 5,070 steps**. With strength 1, all 1,028,418 shared economic values still match frozen 1.20 within numerical tolerance, excluding the two deliberately rebased income shares. Source changes do not introduce an artificial GDP jump. Equivalent relative quality reforms first affect human capital in year 14 when starting in year 4 with the ten-year lag.
- **174 values** across six fields and 29 national economies match the World Bank Catalog and official repository panels. There are 29 learning-adjustment and 29 education-pillar arithmetic checks, plus source-assessment metadata matches and EU aggregation checks.
- All-country inputs, startup funding, saved settings, event scheduling, counters, finance, trade and external-finance regression checks passed. The independent existing source audit passed 28 hashes, 205 PWT fields, 1,731 European mappings, 1,607 Eurostat coordinates and 108 separate PWT comparisons. Its count does not include the new education-source checks.

Results are retained in `education_tfp_validation.json`, `education_income_validation.json` and the existing component reports. These establish source fidelity, accounting, timing and controlled mechanism behavior. Causal education-to-TFP strength, long-run realism and out-of-sample forecast gains remain unestablished. Earlier studies below retain their original engine and data definitions.


## Earlier education and component studies

# Income shares and national education anchors — engine 1.21.0

This release corrects reporting definitions and replaces uniform school-quality inputs with documented national learning proxies. Accounting, source arithmetic and preservation of the previous economic response pass the checks below. No new causal coefficient or out-of-sample forecasting improvement is claimed.

## Two income components

Labour income L is gross model wages, including paid research. Gross capital income K is the existing gross operating surplus, before interest, profit tax and depreciation. Its definition is unchanged. The displayed denominator is F = L + K, labelled **GDP income excluding net taxes**. The displayed shares are 100 L / F and 100 K / F. The capital share is computed as the complement of the labour share, including after display rounding, so the pair totals 100%.

GDP at market prices still reconciles to L + K + net production taxes. Taxes less subsidies remain in fiscal accounts, raw exports and the identity audit. Removing their row from the outcome display does not distribute government tax receipts to capital or change production, wages, tax cash flows or market-price GDP. These are income shares, not estimates of labour and capital contributions to GDP growth. Gross capital income includes capital consumption; it is not household disposable capital income.

Negative capital income is retained, so a valid pair may include a labour share above 100% and a negative capital share. When combined income is nonpositive or numerically zero, the shares are undefined and masked in tables/charts. They are not fabricated as a 0%/100% pair.

## Primary education data

Source: World Bank, Human Capital Index 2020, Harmonized Test Scores (HD.HCI.HLOS), Expected Years of School (HD.HCI.EYRS), and Learning-Adjusted Years of School (HD.HCI.LAYS). The World Bank formula is LAYS = expected years × harmonized score / 625. We use the quality factor score / 625 as a learning-outcome proxy, with 625 as the advanced-learning reference. It is neither a literal percentage of curriculum mastered nor an estimate of school effectiveness isolated from family background.

- Catalog: https://datacatalog.worldbank.org/search/dataset/0038030/human-capital-index
- Official workbook: https://datacatalogfiles.worldbank.org/ddh-published-v2/0038030/1/DR0046209/hci_data_september_2020.xlsx
- Official CSV archive: https://databankfiles.worldbank.org/public/ddpext_download/HCI_CSV.zip
- Method and country appendix: https://documents1.worldbank.org/curated/en/456901600111156873/pdf/The-Human-Capital-Index-2020-Update-HumanCapital-in-the-Time-of-covid-19.pdf

Frozen workbook SHA256: `1cf2ddf10b386a5fb8439a3d6294736fe7d8d9ba3b4152a58f2022095ccbbf95`.
Frozen CSV archive SHA256: `f9fe346a4b38d529fc2a3898ddd49371ad623fae8421b8c4a955b214c9b0f3cc`.

Both files and retrieval metadata are in `research/education_quality_candidates/`. The two formats are consistency checks on the same source, not independent estimates. The report download was blocked by the download route; its method and appendix were inspected through web retrieval. That failed raw download is disclosed in the manifest.

`scripts/integrate_education_quality.py` verifies the frozen hashes, matches 87 values (three indicators for 29 national economies) across the workbook and CSV, and checks all 29 LAYS identities. It records each assessment's year and program separately from the 2020 release year. Most underlying assessments are 2018; Cyprus and China use 2015 metadata. These are pre-pandemic anchors for the model's 2023 snapshot, not observations of learning in 2023. Later pandemic losses and subsequent reforms are not inferred.

Rounded examples: Italy 493, United States 512, China 441, Estonia 543, Romania 442. All national presets use their own score. EU27 is a constructed mean using each member's 2023 population aged 0–14 as a pupil-cohort weight. It is not an official EU test score, uses no GDP weights, and cannot reproduce assessment-sample weights. EU learning-adjusted schooling is the weighted mean of national LAYS, not the product of two separately averaged indicators.

China's 441 is the World Bank's **extrapolated national estimate**, with PISA/PIRLS 2015 metadata. The strong results for selected Chinese provinces are not treated as national observations. Additional representativeness uncertainty is explicit. No test-score confidence interval is invented from the unrelated lower/upper bounds of the overall HCI index.

## What the learning data can and cannot change

Public and household-funded education quality controls now open at the national quality factor. A national mean cannot identify causal public/private differences. Assigning that factor to both funding channels is explicitly labelled an **assumed national-anchor allocation fallback**. Household funding is also not identical to private-school ownership. A controlled public/private comparison would require consistent sector coverage and adjustment for pupil background and selection; those estimates are unavailable in this source bundle.

Education resources are the sum of delivered real public and household education spending, each multiplied once by its quality relative to the country's opening anchor. Funding is not counted twice. The resulting change in resources per child enters the existing response rule. Current adult human capital remains the PWT schooling-based measure. This prevents the addition of a new score field from immediately changing GDP or double counting existing skills.

The existing 0.2 resource elasticity and ten-year learning lag remain unestimated assumptions. They were not adjusted to make GDP rise or make this release's paths look better. A score difference alone cannot identify a causal return to education or its GDP effect. Cross-country anchors improve the correspondence of the inputs to measured learning; they do not establish the model's causal accuracy.

Legacy saved quality values and quality-path targets are multiplied by the current country anchor, preserving their previous relative settings (for example, 1.5 becomes a 50% increase over that anchor). Current-version edits and references remain intact. Invalid blank, null and boolean values still fail validation. Reset selects the updated country source preset.

## Executed checks

`npm test` passed the current release suite: education/income, all-country inputs, startup funding, saved settings, event scheduling, counters, financial accounting, trade and external finance.

The education/income report records 129 paths and 5,070 model years, including all 30 presets and paired baseline/reference runs. It compared 1,028,418 old economic row values against a frozen import closure and profiles from published engine 1.20.0, source commit `b7a64f02074e4dcf8842ef053afafff7045bef3e`. The only excluded old fields are the two intentionally rebased income shares. Baselines and equivalent relative education reforms reproduce the old response within 1e-9. The maximum relative accounting residual is 1.12e-14; the maximum two-share gap is zero. With a reform starting in year 4 and the existing ten-year lag, the first human-capital/GDP change is in year 14. Tests also cover signed capital income, undefined shares, funding × quality counted once, source coverage, legacy scenario/reference/path migration and malformed targets.

The separate current all-country suite passed 135 paths and 4,980 years. Existing finance, trade and foreign-position stress tests passed. `scripts/check_global_sources.py` passed its 28 source hashes, 205 PWT field checks, 1,731 European mappings, 1,607 Eurostat source-coordinate checks and 108 independent PWT comparisons. The new learning-source checks are reported separately; they do not inflate that older source count.

Browser checks verify different Italy, US and China learning inputs, source coverage and caveats, a filled relative education experiment, two-row income reporting at opening and later years, and evidence/simulator navigation. Exact observations and proof image paths are retained in `research/browser_qa.json`.

These tests establish definitions, input mapping, deterministic replay, timing and accounting consistency. Reliable long-run macroeconomic forecasts, causal policy effects and separate public/private efficiency remain unestablished. Earlier studies below retain their original scope, input vintage and engine labels.


## Earlier input and component studies

# Global inputs, entry and accounting — engine 1.20.0

This release adds the United States and China to the 27 EU country presets and representative EU27 economy. Each step remains one year; the normalized opening snapshot uses 2023 inputs with explicitly disclosed reference dates and revision vintages. Simulated futures and response coefficients are not observations.

## Data standard for every preset

Matched country observations take priority. A direct statistic, an arithmetic derivation, a proxy mapped to the model and a missing-data/behavioural assumption are distinguished. The complete parameter audit covers numerical choices as well. Source integrity, mapping consistency, structural plausibility and predictive accuracy are different claims.

The European audit independently checks 1,731 mapping calculations,1,607 frozen Eurostat coordinates and 108 PWTworkbook fields. Twenty unemployment-benefit replacement scales used the denominator from the previous employment definition. Recomputing them with matched 15–64 employment/participation preserves their original observed cash-benefit/GDP flow; the error in that component previously ranged from−3.07% to+4.76%. Source and mapped parameter values are now separate fields, and coverage summaries are recomputed. The after-correction audit has no numerical mapping or value-metadata discrepancies. This does not establish that every official statistic is error-free.

Additional integrity checks hash 28 retained primary-source files and check 205 PWTfields across all 29 national economies. The EU aggregate retains its explicit weighted construction. Missing European R&D cost splits, unmatched local-currency loan quotes, funded-pension data, wealth-survey coverage and extra-EUportfolio scopes remain identified in research/data_quality_candidates/NOTES.md. Stock compositions do not estimate annual portfolio responses.

## United States

The Federal Reserve release dated 19 March 2026 provides one coherent 2023 GDP/expenditure/deposit vintage, rather than mixing revisions. GDP is 27,811.5 bnUSD; its published expenditure components differ by 0.1 bnUSD rounding. Government consumption excludes transfers; public gross investment stays in total fixed investment. Household deposits exclude money-market funds. Firm deposits include corporate and noncorporate enterprises, broader than European S11.

Matched OECD annual employment and participation use ages 15–64. Annual-average CPI-Uinflation is 4.1%; the end 2023 policy representation is the 5.375% midpoint of the federal-funds target range, not the annual effective rate. OECD IDDdisposable-income Gini is 0.3944025. FHFAend 2023 outstanding principal-weighted mortgage interest is 4.0%; the Q4 new-loan rate is 7.0%, producing a 1.625 point opening policy spread. These are distinct stock/new-loan conventions.

Debt/GDP uses the explicitly identified IMFcalendar-GDP vintage; a later fiscal-year-denominator alternative is retained without blending. WDIannual population differs from PWT's vintage; PWT still supplies the capital, income-share and schooling anchors. The Social Security retirement cash observation excludes government-employee plans, and cannot be labelled the full public old-age bill. OECDhealth and social-protection totals are broader functional spending, not COFOGP3 services or cash alone. The public-budget view labels these as limited-coverage references.

Effective tax bases, full private-only funded pensions, financial-wealth distribution, national enterprise demography/size distributions, foreign portfolio allocation and several housing/demographic flows lack matched inputs in the retained bundle. Their configured fallback values are explicitly assumed, with US-specific portfolio/home-bias and loan conventions. No federal statutory VAT is invented: the model consumption wedge is an assumed sales/excise proxy.

## China

UNSNAAMA revised 2023 current-CNYaccounts supply expenditure shares. The source GDP129,427.17 bnCNY differs from component spending by−57.982669 bnCNY; the discrepancy is retained in the observations. NBSpreliminaryGDP126,058.2 bnCNY supplies the denominator for deposits/income ratios from the same communiqué. These vintages are not silently mixed into a supposedly single measured balance sheet.

NBSannualCPIinflation is 0.2%. The end 2023 policy anchor is the 1.80% seven-day reverse-repo rate, not LPR. Public pension benefit payments total 6,522.23 bnCNY from MOFfinal insurance accounts; this excludes funeral/admin/interfund spending. The commercial-institution mortgage stock is 38,170 bnCNY, with the source scope caveat retained. The 3.97% Decembernew-loan mortgage quote supplies its spread over policy; using it for the unobserved opening stock rate is explicitly a proxy. The 3.75% new-business quote is also distinguished from the outstanding book.

MOFSDDSoperations consolidate four budgets and remove interbudget transfers, giving revenue 32,499.9 bnCNY and spending 39,846.2 bnCNY. This broader measure replaces any claim that the partial general public budget is complete. It remains distinct from ESACOFOG P3 functional services. Final domestic/import VAT and export refunds supply an effective uniform-wedge proxy; actual multiple rates and other tax bases are not replicated. Household savings-deposit interest is exempt from individual income tax and is excluded from the model financial-income base. The aggregate rate on other financial flows remains an assumption because portfolio/holding-period exemptions are not identified. Property/stamp duties are not reclassified as annual financial-wealth taxes.

NBSnationwide employment and age 15+population imply 62.7977% employment/population. A same-vintage national participation/unemployment pair was not verified. The preset explicitly assumes 5% national unemployment and derives participation; it does not use urban-only 5.2% unemployment. Applying this 15+level to the model's 15–64 cohort evolution is a visible coverage proxy. The income Gini 0.465 uses NBSper-capita disposable income, a different equivalence/weighting definition from OECD/EU-SILC. Wealth concentration and missing portfolio, school, pension and housing quantities remain assumptions.

## Foreign membership and projections

All 30 contexts exclude their home members from every foreign source. European countries use USA,China and ROW,with home excluded fromROW. EU27 excludes all 27 members. The US usesEU27,China and ROW; China usesUSA,EU27 and ROW. Named pools and ROWare disjoint. Their PWTctfplevels use 2023 PPPoutput weights. Contact probabilities and the trade-competitiveness basket remain simplified, unestimated weights.

OECD EO117 EFFLABS ratios are transformed with its 0.67 labour share, then linked to PWTopening levels. Pool paths use fixed opening output×TFPweights over covered members, with coverage percentages retained for each home context. Covered-sample evolution proxies uncovered members; no national forecast is invented for them. Six conditional scenarios vary annual growth through 2100; the final growth rate is extrapolated afterward. This 2025/2026 vintage was unavailable in 2023 and cannot provide a real-time historical forecast test. UIcontrols, donor tables, trade comparisons, events and findings all use the active source set. Self-country foreign growth shocks have no effect.

## Startup rule and controlled comparisons

The previous rule multiplied current productive capital per surviving firm by an observed mean entrant employment ratio. As firm counts shrank, this became a rising minimum capital requirement for every entrant. The nine examined baselines ended with 2–6 firms and no entry or VCfunding in their final decade, even where available VCbudgets rose.

Mean startup capital now uses opening productive capital per initial synthetic firm. Each prospective entrant draws a mean-preserving lognormal size. Its shape uses the incumbent grouped-size dispersion as a disclosed proxy because a matched entrant distribution was unavailable. The employment-to-capital conversion, shape and fixed real benchmark remain assumptions; this is not a fitted firm-entry forecast. Actual financing prices use the liquidation discount only for assets still available in estates; the remainder costs the producer price. Working cash is fully funded. No deposits or capital are granted free.

Every entrant still requires pooled household equity. Broad observed enterprise births include founder/self-financed/debt-only firms that this simplified financing channel does not separately represent. Funding and entry may still decline; no minimum entry count or rising VCtrend is imposed. Attempted capital/cash demand, available venture orders and finance versus asset rejections are separate metrics.

The controlled nine-path comparison holds country inputs/foreign pools fixed. The purchase-cost correction alone reproduces 143,892 common values from the frozen instrumented 1.19.1 engine. Opening-scale varied sizes produce late entry in all nine examined paths. GDP and unemployment effects are mixed and recorded. These are mechanism/accounting comparisons, not evidence of improved empirical forecasting accuracy or a coefficient search.

## Additional accounting repair

Long runs exposed an existing underwater-house sale bug. A seller could repay more mortgage principal than sale proceeds plus available cash, causing a negative deposit. A subsequent negative pension contribution corrupted fund units. Offers now respect the seller's actual cash needed to release the matching mortgage collateral. The debt is not forgiven. Pension contributions cannot be negative, and aggregate pension units must equal household holdings. A direct underfunded/funded sale test and Romanian long-run paths cover this failure. No education elasticity, lag or growth cap was changed.

## Validation and remaining limits

npm test runs the current all-country and controlled startup suites, configuration migration, event scheduling, counters, finance, trade and foreign-asset components. The primary all-country report includes 135 paths and 4,980 annualsteps, including 30 presets×2 seeds×baseline/stress 40 yearpaths; its largest relative reconciliation gap is 1.12 e−14. Both trade flows and gross external positions stayed positive throughout all 4,800 annualsteps in that baseline/stress matrix. Selected severe or deliberately inactive scenarios can still have binding real resource constraints; the model does not invent exports in a complete production collapse.

The current results retain floor/cap hits, falling firm populations, extreme employment/debt outcomes and all controlled comparison results. Macroeconomic realism, complete national-account coverage, endogenous institution-specific response estimates and untouched out-of-sample accuracy remain unestablished. Source/mapping corrections improve input fidelity; accounting identities do not prove that simulated futures are true.


## Archived component and input studies

# Current country budget allocation audit — engine 1.19.1

# Country-specific spending allocations — engine 1.19.1

This update verifies and exposes the composition of budgets already represented in the economy. It changes their functional classification, not aggregate payments, tax rates, the pension law, education responses or financing behaviour. All 28 presets use their own source percentages; no Italian or EU percentage is imposed on other countries.

## Verified official inputs

Frozen Eurostat 2023 general-government accounts (`gov_10a_main`), functional expenditure (`gov_10a_exp`) and all-scheme pension statistics (`spr_exp_pens`) cover all 27 EU members plus EU27. The benchmark contains 392 complete core country/indicator observations, exact selections, source flags and SHA256 hashes. Raw observations and extraction code are in research/social_spending_candidates; the public download is data/social_spending_benchmarks.json. These are revised 2023 opening references, not current 2026 spending.

| Official 2023 measure, % GDP | Italy | EU27 |
|---|---:|---:|
| Government revenue | 46.5 | 45.4 |
| Total government expenditure | 53.6 | 48.8 |
| Health expenditure, all transactions | 6.5 | 7.2 |
| Education expenditure, all transactions | 3.9 | 4.7 |
| Social protection, all transactions | 21.0 | 19.1 |
| Public old-age cash benefits | 13.2 | 9.6 |
| Public survivor cash benefits | 2.3 | 1.4 |
| Public sickness/disability cash benefits | 1.6 | 1.8 |

All 28 existing public old-age inputs match the official source. Replacing Italy's 13.2 with ESSPROS total pensions of 15.49 would mix pension types and public/private schemes. The corresponding EU27 all-scheme total is 12.28, with a different scope from its 9.6 public old-age cash benefits. Sickness/disability cash benefits are not identical to disability pensions. Pensions and other cash benefits are parts of social protection, not additional amounts to add on top of that aggregate.

Healthcare was previously unlabelled within government purchases; it was not necessarily absent from public consumption. Survivor and sickness/disability payments were unlabelled within flat cash social support. The model already removed old-age benefits from that flat support when paying its separately modelled retiree-linked old-age transfers. Earmarked pension contributions are part of existing worker tax/social-contribution receipts, not another tax receipt.

## Percentages applied to comparable budget totals

Health services and education services use their country's COFOG P3 function divided by COFOG total P3. Italy's shares are 6.1/17.9 = 34.08% and 3.4/17.9 = 18.99%. EU27's are 6.5/21.1 = 30.81% and 3.8/21.1 = 18.01%. Each year's actual model public purchases are split into these two categories and the residual other services. The three parts always sum to that existing purchase budget.

Source survivor and sickness/disability D62 amounts are divided by the original non-old-age cash-support pool after excluding any separately modelled unemployment benefit. Each year's existing non-old-age cash support uses those fixed percentages, with the residual labelled other cash support. When the age-linked pension mechanism is disabled, the old-age share remains identifiable inside the flat support pool. Allocations never add a second transfer or change which household receives the actual cash. For a custom malformed allocation whose shares exceed 100%, the reporting helper normalizes those shares rather than showing negative residual spending; all empirical preset shares fit without this guardrail.

Full COFOG health/education TE includes consumption, investment and transfers. Applying TE/TOTAL TE to the model's narrower current-expense total would not preserve the meaning of its actual service and benefit ledgers. The update therefore applies empirical shares to comparable transaction budgets and separately displays each source function's percentage of full national expenditure. It does not claim that all current model expense shares equal full national TE shares. Matching both every component/GDP ratio and every full-budget share would require a complete public investment, capital-transfer and tax ledger. Adding those totals as extra consumption would double count demand and distort GDP.

COFOG total P3 and main-table P3 differ by 0.1 percentage point in Italy and EU27. Shares use numerator and denominator from the same table. The cause of those table differences is not uniquely identified here; labels preserve the definitions and rounded source values.

The existing public school-resource funding proxy uses the broader education expenditure benchmark. Its calculation, effective-resource weights, elasticity and lag remain untouched. The new fiscal education-service classification is a different view of the same overall budget, not a second expense or a reason to reduce human-capital effects.

## Revenues, expenses and presentation

The Government sector view now shows each expense in nominal model units, as a percentage of current nominal GDP, and as a percentage of represented current expenses. Revenue minus current expenses equals public saving. Public bond principal redemption and bank recapitalisation remain separately labelled financing/exceptional operations outside the current-expense composition. Pension contribution earmarks are not added again to revenue.

Observed 2023 full-budget reference percentages appear separately from simulated annual outcomes. At year 0, simulated annual receipts/payments remain unobserved gaps; the official reference has nonzero spending values. General-government TE has wider coverage than the model's delivered purchases, cash transfers, research and interest. Public capital spending, other capital transfers, subsidies and some receipts do not have a complete separate ledger here. Differences in gross spending/revenue coverage must not be presented as forecast errors or filled with invented transfers.

Later spending/GDP can decline because the configured public-budget trend grows more slowly than GDP, or because actual orders are rationed. This is a scenario assumption/result, not a reason to automatically increase a source input or damp real GDP. The public budget rule remains editable and unchanged.

## Other sectors: supported shares and limits

Country allocation targets already applied elsewhere are now visible next to current configured percentages in each sector view:

- Household foreign securities composition: 28 presets, 22 with fund look-through and six direct-holding proxies. The same relative weight mapping continues to allocate the existing investment-market order budget. It is a securities-stock composition used as a flow-allocation proxy, not an estimated propensity to invest or a percentage of total household income.
- Business R&D labour costs / business GERD: 24 matched presets; France, Ireland, Netherlands and EU27 retain a labelled 60% assumption. Only the labour part is explicitly paid as research hours; other R&D costs remain a benchmark.
- National dwelling GFCF / total GFCF: 28 source proxies for the existing residential/business investment envelope, not an observation of who finances each project.
- Government-funded R&D performed by business / total public research: 26 matched presets; Bulgaria and EU27 retain labelled assumptions. The share applies to that research budget, not the total public budget.

Actual funding, capacity, market demand and disabled channels can keep realized spending below configured budgets. Custom scenario paths update the displayed configured percentage while the empirical reference stays fixed.

The household consumption/income ratio cannot simply replace the marginal consumption propensity: this model also has a wealth-draw term. National bank asset shares do not describe the combined bank, monetary authority, pension-fund and direct financial-market system. Household issuer data retrieved for 21 national areas plus euro area have incomplete country coverage, exclude the available fund look-through and omit some model instruments. The broad domestic debt/equity candidate also mixes financial-sector issuers with the model's narrower issuer set. Those candidates are recorded but rejected for this update, without inventing a common ratio or claiming a simulation improvement. Venture/equity/debt weights, deposit retention and the bank share of government bonds remain explicit assumptions.

## Executed tests

Before the changes, 168 complete 40-year baseline/stress paths were captured from published engine 1.19.0, commit 0a8e265d9c202f95c788c7a194911be7b18f42aa. After the changes, every previous numerical row value reproduced its original SHA256 projection exactly across 6,720 annual steps. The new classification sums reconcile with maximum absolute budget-amount residual below 2.3e-13 model units. GDP, inflation, employment, human capital, agent stocks and all original transactions are unchanged.

The new tests also verify all source hashes, 28 old-age benchmarks, all country allocation parameters, zero-budget cases, disabling age-linked pensions, migration of saved experiments, counterparty revenue/expense sums, S-I=CA and current-account/NFA transactions. They independently confirm 28 existing portfolio percentages, 24 research-labour targets, 28 housing-investment targets and 26 public research targets. Source targets stay fixed when users edit scenario allocation weights.

Additional sector-flow, configuration, event-input and monetary-policy suites passed. No new predictive-accuracy gain is claimed: these are source-definition, allocation and presentation corrections that preserve the existing economic dynamics.


## Monetary and employment audit — engine 1.19.0

# Monetary policy, prices and employment — engine 1.19.0

The prior source is frozen at commit 4a4f472759c7aba5623adefe0d2f66573f2239f5 in research/frozen_engine_v1_18_1. Each module was compared byte-for-byte with the published source and hashed. This change corrects an index-construction error and adds requested scenario mechanisms. It does not establish out-of-sample accuracy.

## Prices

The old engine chained the next non-rent price change onto the previous headline CPI, which already contained rent, then mixed rent into the index again. The non-rent basket now has its own stored `goodsConsumerPriceIndex`. The headline level combines that basket and the rent index once using the opening actual-rent expenditure weight. Owner-occupied imputed rent remains outside this consumer basket. A deterministic 40-year test holds non-rent prices constant and raises rent 2% annually: at a 10% rent weight the correct level is 90+10×1.02^t, rather than a repeatedly reweighted headline series.

The existing money×velocity/output producer-price equation, gradual adjustment, exchange pass-through and VAT treatment remain. There is no producer inflation anchor and no positive lower bound on inflation. Weak nominal spending or growing real production can still produce deflation. Housing quantity/price rules and the illustrative foreign basket remain unestimated.

## Rate floor and emergency asset purchases

Nominal opening, neutral, rule and shocked policy rates are bounded at 0%. Real policy rates can be negative. A 0% floor is a requested model convention, not a claim about real-world possibilities; the ECB has operated with negative deposit-facility rates.

The representative monetary authority counts only previously observed annual inflation readings. Purchases require money-based prices and responsive rate policy to be enabled, the current nominal policy rate at most 0.25%, and at least two consecutive observed readings at or below the configured very-low threshold (default 0.5%, editable only up to 0.5%). The annual budget defaults to 3% of last nominal GDP. Holdings are capped at 50% of outstanding public bonds, with eligible existing household and bank bonds a further constraint. These numerical thresholds, caps and proportional seller allocation are scenario assumptions, not estimated policy rules. No current-year inflation or future output is used for the decision.

Purchases take place in the secondary market at model face value, before the current period's prices and financing plans. Bank sellers exchange bond assets for reserves. Household sellers exchange bond claims for deposits, with matching reserves at their commercial bank. Private net wealth, public gross debt and GDP are unchanged by the purchase principal. Deposits and reserves are not the same money aggregate. Subsequent lending, spending and reinvestment affect the outcome; inflation is not forced back to target.

The separate central-bank ledger includes bond assets, reserve liabilities and retained income/losses. It earns the same repriced coupon as the other holders of existing public debt. Incremental reserve liabilities from this extension earn the current policy rate. The legacy opening reserve residual is left under its previous no-remuneration convention; its backing is a labeled unobserved opening-book residual, not an empirical security portfolio. Coupon receipts debit Treasury deposits and reserve balances; reserve interest credits bank equity and reserves. Positive retained income after losses is remitted to government. Losses remain on the central bank's ledger rather than automatically triggering commercial-bank insolvency.

Surplus-funded public-bond redemption covers households, banks and the monetary authority pro rata. Central-bank principal repayment destroys matching reserves; principal is neither public expense nor GDP. The financial-sector view consolidates commercial bank, monetary authority and pension fund; their internal reserves and fund deposits cancel. National saving includes central-bank retained income, keeping S-I=CA and acquisition-cost NFA transactions=CA. The model omits market-value duration gains/losses, a term-premium QE channel and country-specific Eurosystem profit allocation; these are limits on interpretation.

Primary sources: Bank of England, Tenreyro 2023 on asset swaps and reserves versus deposits; ECB 2023 Money and Inflation on money demand and transmission; ECB annual-account FAQs and profit/loss explainer on reserve costs, losses and distributions. Exact URLs and limitations are recorded in research/macro_policy_candidates/EVIDENCE.md. The source descriptions support accounting and qualitative channels, not the selected numerical policy coefficients.

## Employment definitions

All 27 EU countries and EU27 use revised 2023 Eurostat `lfsi_emp_a`, sex T, age Y15-64, unit PC_POP, indic_em EMP_LFS and ACT. The displayed employment/population percentage is the published employment rate. Participation is employed+unemployed divided by working-age population. Internal employed/labour-force = 100 × published employment/population / participation. This reproduces the rounded published population rates exactly. Independently rounded THS_PER counts are retained for comparison and can imply differences up to 0.091 percentage points. Source flags are preserved.

Italy opens at 61.5% employment/population and 66.7% participation; EU27 at 70.4% and 75.0%. Earlier figures around 92% for Italy were shares of the labour force, not of all working-age people. The prior broader-age 15–74unemployment complement has been replaced for opening calibration. The annual `lfsi_long_a` transition series has no age selector and remains an explicitly labeled broader-age 15–74proxy. Participation is fixed within the changing 15–64 cohort; labour-force matching continues to sum employed and unemployed to 100% of that labour force. Do not substitute 61.5 for the internal labour-force employed share: doing so would misclassify inactivity as unemployment.

Raw responses, extraction code, country benchmark, flags, retrieval timestamps and SHA256manifest are in research/macro_employment_candidates; the website publishes data/employment_population_benchmarks.json. These are 2023 opening inputs, not 2026 current rates.

## Education: retained, not damped

Public and household-funded education already use delivered nominal purchases, deflated to real resources and divided by the current child population, multiplied once by the relevant effectiveness assumption. This update exposes public/private funding indices and quality-adjusted resource indices without changing that calculation, the 0.2 learning elasticity,10-year lag, cohort entry or labour-productivity multiplier. Doubling real per-child funding doubles its resource input; it is not multiplied through a second quality formula.

Five common-seed Italy sensitivities compare the current coefficient, education off, and half the response over 40 years. The median final-GDP contribution of the current education channel relative to education off is approximately 1.13%. The half-response case lowers GDP but does not demonstrate improved accuracy. The short 2023–25 benchmark cannot identify a 10-year schooling-to-worker lag. No independent long-horizon causal validation supports choosing the candidate, so it is rejected and the original coefficient retained. Published school-spending research supports potential learning gains but does not provide a universal annual macro GDP elasticity for these economies.

## Executed evidence

`macro_policy_validation.json` records 168 country/seed baseline and stress paths across 6,720 annual steps, all 28 opening employment calibrations, known-CPI tests, purchase asset swaps, eligibility and timing, finite assets and caps, reserve interest, coupon/remittance/loss accounting, public redemptions, education funding/timing and all main identities. Maximum relative accounting residual is below 3e-14. Purchases occur in 72 of 168 baseline/stress paths. Across 84 baseline paths, deflation occurs in 501 of 3,360 simulated years, versus 1,021 before; median compound inflation rises from about 0.81% to 1.39%. These are simulation comparisons, not observed frequencies or a reason to suppress genuine deflation.

The equally weighted 27-country retrospective 2025 diagnostic, with three shared seeds and 2023 presets, has real GDP growth RMSE 3.892 pp versus 3.879 before, and inflation RMSE 2.172 pp versus 2.171 before. GDP is annualized 2023–25. Small increases are reported rather than tuned away: index arithmetic and observed denominator corrections should not be selected by accidental forecast-error cancellation. These observations have been used previously and OECD foreign paths contain later information, so this is not independent or real-time forecast validation.

All 22 existing regression suites plus the new macro suite pass. The first turnover test attempts uncovered an obsolete assertion that treated newly reported closing foreign levels as unchanged in the first growth-shock year and mixed immediate trade competition with delayed learning. The corrected test checks the pre-event prefix, verifies the closing foreign level changes on schedule, and isolates the adoption-delay check from trade. Initial failure logs and the successful retry are retained. Historical exact fingerprints use the archived 1.18.1 engine; current monetary and CPI changes intentionally alter later outcomes. Current paths continue to pass stock-flow, timing and conservation tests.


## Historical and component studies

# Innovation Observatory — engine 1.30.0 validation

Executed reports: general 2026-11-12T18:05:59.717Z; turnover 2026-11-12T18:10:20.346Z; diffusion 2026-11-12T18:07:31.120Z and labor 2026-11-12T18:05:37.042Z.

**Numerical, accounting, timing and reproducibility checks: PASS. Empirical dynamic validity and out-of-sample forecast accuracy: NOT ESTABLISHED.**

## Model time, labor matching and public purchases

Each step represents one model year. Year 0 uses 2023 opening stocks and normalized demand benchmarks when settling is zero. Settling advances the economy before year 0. The labor force opens at 100 units. With population dynamics active it follows the working-age cohort; employment and unemployment are shares of the current labor force. The original-channel audits below use fixed-population inputs with the new additions off; the current society validation is reported separately. The initial Italy preset has 92.3% employment and 7.7% unemployment in the active labor force.

The previous engine could place every worker in a job. The revised engine separates a share of incumbent jobs, reassigns continuing workers to vacancies and matches a share of opening unemployment. Firms adjust hours after matching. Credit and cash restrict funded payroll. The opening employment control is bounded at 99.9%. Positive separations and partial matching keep unemployment positive during the run.

Eurostat `lfsi_long_a` follows corresponding quarters in consecutive years. The two-state model conditions on employed and unemployed endpoints. The separation proxy is EMP_UNE divided by the sum of EMP_EMP and EMP_UNE. The job finding proxy is UNE_EMP divided by the sum of UNE_EMP and UNE_UNE. Both ratios are expressed as percentages. National or EU aggregate pairs match 25/28 separation inputs and 27/28 job finding inputs. The remaining controls are labeled EU27 fallback assumptions. The source flags are included in the download.

Public borrowing finances delivered purchases after household payments and consumption tax receipts. Under an isolated supply shock with public purchases of 2.827 units, borrowing fell from 45.000 to 2.827 units. This test holds taxes, opening debt and other public outflows at zero.

The before and after comparison uses 28 presets, five common seeds and 40 model years. The old engine reached 100% employment in 100/140 paths. The current engine reached it in 0/140 paths, with a peak of 98.46%. 19 current paths reach employment below 50% and 66 reach public debt above 300% of GDP. The full comparison also includes an intermediate run with the prior donor anchors to separate the technology-pool change. `employment_audit.json` contains every outcome.

## Implemented behavior

Firms now enter and leave. At the same size and arrears, worse opening technology raises relative exit probability. The mean nonfinancial hazard is normalized to a 2023 Eurostat enterprise death-rate proxy. A descriptive size/exit slope comes from grouped Eurostat observations; it is not a causal firm-level estimate. Financial failures may add exits. Independent startup opportunities do not impose one-for-one replacement.

Cash first pays creditors. Remaining loans are written off; funded asset sales can subsequently recover written-off claims. Unsold real assets remain in liquidation estates. Dormant capital depreciates. Households fund their pro-rata common ownership contributions from their own deposits, and entrants buy existing capital. Secondhand transfers enter neither GDP nor new investment. New firms have zero contemporaneous GDP and start operating the next period. Capital, inventories, financial flows and bank accounts reconcile.

Permanent firm IDs preserve histories and process-specific seeded draws after an exit. Links are repaired against current IDs. Delayed histories exclude firms that did not yet exist. Current-capital technology compares active firms; original-cohort knowledge freezes its last value on exit and excludes entrants. Comparisons reconcile knowledge changes among common IDs, capital reallocation and unmatched populations. The unmatched contribution is not causal identification of turnover.

Firms sample the USA, China and a rest-of-world technology pool with equal source probabilities after a contact. The rest-of-world anchor uses 118 of 183 PWT economies outside the USA and China. They account for 91.18% of reported 2023 PPP output in that pool. The home economy is included where covered. Fixed 2023 output-side PPP GDP weights produce a mean `ctfp` of 0.684878 and a mean national 2013–2023 `rtfpna` CAGR of -0.0852% per year. `pwt_rest_of_world_weights.csv` records all members and weights. The model divides the level by the home anchor and applies the configured leader premium. This sets the mean of each source's distribution. Firms adopt positive sampled gaps according to the configured absorption and learning rates. Future donor growth extrapolates the historical average.

## Empirical inputs and mappings

The 223 controls separate source statistics, arithmetic transformations, proxies, numerical choices and assumptions. 64 frozen official source files retain exact URLs, retrieval dates, source flags and SHA256 hashes. 2023 is the common opening year. Revised observations retrieved in November 2026 are not a real-time 2023 information vintage.

All 28 presets have matched enterprise birth/death rates, grouped size dispersion, descriptive size/exit slopes, startup-size proxies and foreign productivity ratios. Enterprise demography covers the broad business economy, including non-employers; applying its active-enterprise denominator to a synthetic opening population is a mapping assumption. Financial defaults and bounds can change realized rates.

- Size dispersion is the count-weighted standard deviation of log class mean persons employed, across 0, 1–4, 5–9 and 10+ employee classes. Within-class dispersion is unavailable. Applying that sigma to a lognormal capital distribution assumes a size/capital relationship.
- The size/exit coefficient is the negative weighted regression slope of log(-log(1-deathRate/100)) on log class mean employment, weighted by enterprise counts. Zero/missing death rates are omitted from this descriptive log fit. It does not identify firm-level conditional failure behavior.
- Startup size is employment share of births divided by the enterprise birth rate. Converting this employment ratio to startup capital assumes a common capital/labor scale.
- PWT `ctfp` supports cross-country PPP TFP level comparisons. Country-specific `rtfpna` indexes are used only for temporal growth. The EU home denominator is a cgdpo-weighted national TFP mean, not an observed EU aggregate TFP or a measured firm frontier.

Earlier audited employment, fiscal, financial-stock, R&D and financing-cost mappings are retained. R&D labor is finite and funded within the wage bill; non-labor GERD remains an unfinanced benchmark. This is not a complete SNA intangible-capital or detailed equity-instrument account.

## Executed checks

Earlier fixed-price audit reports cover 2,306 paths: 999 general/source/accounting runs, 440 diffusion/assumption-sensitivity runs, 584 turnover/foreign and 283 labor audit runs. They also cover 160 paths through archived engines for comparison. The 560 opening states are counted separately. The price experiment has its own comparison below.

Largest reported relative accounting residual: 4.909e-14. Largest capital-stock reconciliation residual in the turnover suite: 9.734e-13 model units. Runtime checks reject nonfinite stocks, unfunded accounting transactions and failed reconciliations.

- At equal arrears, worse opening technology raises relative exit risk; mean nonfinancial risk matches the chosen aggregate proxy. Selection can be disabled.
- All three new official source files match their frozen SHA256; all 28 presets have 2023 birth/death observations and reproducible national TFP ratios. Future growth and firm leader premiums are explicitly proxy/assumption mappings.
- Archived 1.3 reproduces all shared 1.2 row fields for nine paired comparisons when both channels and the capacity weighting are disabled.
- Demand shares account for productive capacity, preventing tiny startups from receiving the same target demand as large incumbents at equal technology.
- Exact repeatability, no future intervention leakage, permanent non-reused IDs, changing firm counts, entry/exit event logs and valid repaired network snapshots pass.
- Foreign adoption is nonnegative, gap-bounded, delayed and independently switchable. Inferior foreign donors never lower technology. Future donor growth does not enter an earlier adoption decision.
- No startup gets unfunded equity or free assets; common owners fund their own pro-rata equity contributions; all opportunities reconcile. Unsold assets remain dormant. Population floor/cap interventions are counted explicitly. Capital and inventories reconcile across transfers and depreciation.
- Technology comparisons match permanent IDs and reconcile surviving-firm learning, reallocation and unmatched population contributions even when the two populations differ.
- Executed a predeclared 2×2 mechanism comparison: all 28 presets × five common seeds × four channel combinations, 40 steps. All outcomes are retained; plausibility flags are not forecast scores.

The pure-learning suite also tests 1,000 same-state adoption comparisons and 30 paired multi-period comparisons with innovation, turnover and foreign learning disabled. Raising the same-state adoption fraction never subtracts existing knowledge. This mechanical property does not establish a positive total GDP response.

## Controlled final simulation comparison

Protocol: 28 presets × five common seeds × four channel combinations × 40 annual steps, with no settling or exogenous shocks. The capacity-aware allocation rule and the same matched initial inputs apply to every combination. Coefficients are not selected on the outcomes. Every case is retained in `turnover_experiments.csv` and `research/turnover_experiments.json`.

| Channel combination | Runs | Employment below 50% | Debt above 300% GDP | Population floor | Population cap | Median final employment | Median final debt/GDP |
|---|---:|---:|---:|---:|---:|---:|---:|
| Entry/exit and foreign adoption off | 140 | 0 | 76 | 0 | 0 | 96.19% | 334.43% |
| Entry/exit only | 140 | 41 | 96 | 66 | 0 | 92.07% | 454.08% |
| Foreign adoption only | 140 | 0 | 61 | 0 | 0 | 96.16% | 247.46% |
| Both enabled | 140 | 46 | 86 | 64 | 0 | 92.10% | 343.54% |

A path can trigger several flags. The thresholds are assumed plausibility screens, not empirical event probabilities. Both enabled versus both off gives 34/140 negative final GDP gaps and 7 negative active-technology gaps. These outcomes are retained. Foreign adoption improves some screens, while turnover can worsen others. Correct accounting does not make every added mechanism beneficial or realistic.

The diffusion protocol uses five paired seeds for every preset. Eight predeclared illustrative assumption specifications use two paired seeds each for Italy, EU27 and Germany. Earlier archived diffusion results use different mechanisms and seed counts; their signs are not a matched before/after accuracy comparison.

## Iteration, unsuccessful experiment and justified correction

The first turnover variant treated similarly sized firms as targets for aggregate enterprise-count rates and used a size-blind demand target. A tiny startup could attract target demand similar to a large producer, stranding productive capacity. In the initial both-on factorial subset, 107/140 paths reached employment below 50%, and 139 exceeded debt/GDP 300%. This variant was unsuccessful and is frozen with its inputs, engine and outcomes in `research/failed_turnover_v1_3_initial/`.

A controlled intermediate correction changed only the capacity basis of demand targets, with the same earlier inputs and 140 country/seed cases. Employment-below-50 flags fell to 36/140; debt-above-300 flags were 101/140. This is a numerical plausibility correction, not forecast improvement. Its code is frozen in `research/capacity_share_variant/`, and all intermediate cases are in `research/capacity_share_experiment.json`.

The final implementation makes that allocation assumption explicit as `capacityCompetition`, enabled in all four final combinations. Its zero setting replays the earlier size-blind rule. Final inputs also replace the narrow common size dispersion and startup-size guess with documented size-class proxies, and anchor the size/exit relationship to grouped observations. As a separate accounting correction, each common owner must fund its own startup equity contribution; an aggregate cash pool alone does not establish shareholder liquidity.

No parameter grid was searched to maximize GDP, force positive diffusion effects or minimize a final holdout error. Structural corrections were made for identified consistency problems, and descriptive source mappings were computed directly from the frozen observations.

## Starting-state size-moment check

Across 560 initial states (28 presets × ten seeds × two size mappings), the mean absolute discrepancy from the observed 2023 employment share of enterprise deaths falls from 6.160 to 1.917 percentage points. The inputs/moment were inspected during development. This is an **in-sample mapping diagnostic**, not holdout MAE, a historical forecast or independent empirical validation. The remaining discrepancy is retained by country in `size_mapping_diagnostics.json`.

## Unresolved failures and empirical requirements

In the final both-on screen, 46/140 paths reach very low employment, 86/140 exceed debt/GDP 300%, and 64 hit the two-firm floor. The employment and debt screens flag paths that need further calibration. Do not call the model a reliable macroeconomic forecasting system, validated policy tool or a proof that innovation/turnover has a particular real-world multiplier.

Count/size mappings do not identify joint firm productivity, age, leverage, survival and adoption distributions. A 2023 rate or a historical donor growth rate need not remain constant for 40 years. The price experiment represents one domestic good. Sector linkages, international goods and financial transmission, detailed financing institutions and full R&D capitalization remain outside the model. Behavioral wages, consumption, investment, credit, innovation success and absorptive capacity remain incompletely calibrated.

Further validation needs linked firm panels, measured household demand and firm financing responses, jointly calibrated targets, independent shock-response checks and a predeclared evaluation sample. The original statistical layer produced the archived TFP scores. The browser ABM produced the price comparisons below.

## Reproduction and exports

Follow `README.md`. Numerical simulation needs Node 18+ with no JavaScript dependencies. Offline data regeneration additionally needs pandas and openpyxl. The package includes the original PWT workbook and frozen Eurostat inputs. Older imports recompute with the current engine. The frozen engines permit historical replay of retired settings and Korea-only growth paths. Exported JSON preserves first-seed firm/network histories and event logs for both economies, all row paths and reconciliation checks. The separate event CSV labels its displayed-seed scope.

## Earlier prices and inflation experiment

Engine 1.5 tested a price rule with a 2% anchor and prior funded sales pressure. This section records the historical comparison. The current rule uses money, spending velocity and output.

The backtest uses all-items Eurostat HICP for a comparison with the model's single consumer good. The rule was chosen among feedback variants on 2014–2019 data and assessed in the later checks. Errors are in percentage points across 27 member countries. Inflation is the one-year change in year 2 and GDP growth is annualized over two years.

| Price rule | 2020–2023 inflation RMSE | 2025 inflation RMSE | 2025 GDP growth RMSE |
|---|---:|---:|---:|
| Fixed prices | 8.10 | 3.20 | 5.42 |
| Constant 2% anchor | 6.50 | 1.57 | 6.10 |
| Changing prices | 6.35 | 1.56 | 6.10 |

In the earlier study, inflation forecast errors fell and GDP growth forecast errors increased. See `price_validation.json` for the full protocol and other scores.

## Foreign matching, policy rates and the currency in engine 1.6

New configurations draw firm-level opportunities from a mean-preserving lognormal distribution. A common dispersion of 0.30 is illustrative. A national mean is an anchor for contact opportunities, and a firm adopts from the individual draw when the draw exceeds its own technology. The opening policy rate uses the ECB deposit facility rate or a matched BIS national series. Bulgaria and EU27 use ECB proxies. The first policy signal uses 2023 HICP and subsequent signals use lagged model inflation. Policy rate movements change effective loan interest and planned investment. Currency appreciation lowers price pressure and increases the chance of a foreign contact. The currency index represents a synthetic basket.

Retrospective check from the 2023 opening presets, scored on the already examined 2024 and 2025 targets. Medians of 20 matched seeds per preset. Each member country has equal weight. The representative EU27 economy is reported separately. There is no imposed currency shock in this comparison.

Inflation is the annual rate in the target year, compared with Eurostat all-items HICP. GDP growth is annualized from the opening year, compared with Eurostat chain-linked volume growth. Unemployment is the year-end model rate compared with Eurostat annual unemployment. Error units are percentage points.

| Configuration | 2024 inflation RMSE | 2025 inflation RMSE | 2025 GDP growth RMSE |
|---|---:|---:|---:|
| Earlier fixed-price setup | 2.86 | 3.20 | 5.42 |
| Changing prices alone | 1.28 | 1.56 | 6.10 |
| Varied foreign matches alone | 2.86 | 3.20 | 5.42 |
| Prices, policy and currency | 1.36 | 1.50 | 6.30 |
| All new channels | 1.36 | 1.50 | 6.30 |

Firm-level technology variation is available in new configurations and is preserved as a structural assumption. The monetary and currency channels are optional because their inflation and GDP error changes differ across metrics and years. See `open_economy_validation.json` for MAE, RMSE and all country results.

## Money-based inflation and real GDP in engine 1.7

The price rule compares opening private money times planned spending velocity with the most recent output valued at the preceding price. Prices adjust gradually. The first signal uses the opening balances and the model's opening goods scale. The central bank reacts to prior-year inflation, changes the borrowing rate and influences spending speed. The currency responds to the domestic policy rate after inflation relative to an assumed foreign real rate. Households translate last year's real income into a current-price spending plan. Actual purchases remain cash-constrained.

Each configuration has 140 paths from 28 presets and five common seeds over 40 annual steps. In the two inflation variants the test harness imposes the same 2% annual price increase. Policy, currency and tax changes are off. The GDP gap is the median of paired differences from the same fixed-price seed. Reference GDP above one unit is required for a percent comparison.

| Calculation at 2% inflation | Median GDP gap in year 10 | Median GDP gap in year 20 | Year-40 GDP below 50 |
|---|---:|---:|---:|
| Earlier spending calculation | -11.89% | -10.27% | 37 of 140 |
| Corrected spending calculation | -1.90% | -0.43% | 30 of 140 |

Development uses 2014–2019 targets and five matched seeds. Later checks cover 2020–2023 historical opening states and 2024–2025 actual 2023 presets with 20 matched seeds in the recent comparison. Historical private money for the opening scale uses the available starting-state assumptions. Each forecast uses only the opening inputs and model history.

The rate of price adjustment was selected using the 2014–2019 targets. The full scores, paired outputs, 40-year stress counts and rate-response comparison are in `money_validation.json`.

## Public demand and policy-sensitive credit in engine 1.8

The public purchase plan is separate from the opening composition. The trend in the default country budget base uses ten annual observations of real government final consumption ending in 2023. Government and business borrowing rates respond to the current policy decision. The effective rate on the outstanding public stock adjusts gradually. Interest settles on opening public claims. The optional shared-capacity rule counts part of bank-held public debt against business lending capacity.

The saving accounts sum household, firm, bank and government saving independently. Gross investment includes changes in inventories. The difference between national saving and gross investment equals the current account. Domestic settlement makes this balance zero. The public saving account also reconciles to debt issuance, changes in deposits and recapitalization.

Twenty-eight presets and five common seeds per configuration over forty annual steps. The public purchase plan is reduced by five percentage points of its budget base either from the first simulated year or from year eight. Legacy permits the starting snapshot to change when the opening control is edited. The revised run fixes the preset opening composition. The counterfactual reference has no public demand cut. GDP and debt thresholds are numerical screens.

| Cut timing | Earlier paths below half of opening GDP in year 40 | Revised paths |
|---|---:|---:|
| Year 1 | 73 of 140 | 0 of 140 |
| Year 8 | 78 of 140 | 0 of 140 |

Retrospective matched-country checks using the same preset origins and seeds. Development targets 2014–2019 use five seeds per origin. Later checks use 2020–2023 targets and the actual 2023 presets for 2024–2025, with 20 seeds for the recent comparison. The GDP trend versions use GDP growth known at the opening origin. The public consumption trend uses up to ten previous annual observations. The 2024–2025 observations have been used in earlier releases.

An early comparison favored a budget based on trend growth over last-year GDP. GDP trends for some countries would extrapolate exceptionally high growth. The final proxy uses the country’s historical real government consumption growth. It improved GDP errors in both later windows and reduced severe contractions in the public spending experiment. See `fiscal_validation.json` for rates, debt risks, tested alternatives and country outcomes.

## Foreign trade, real currency and loan pricing in engine 1.9

Reset restores Fixed mode for both the policy rule and the nominal exchange rate. Business borrowing is priced from the opening policy rate, a calibrated opening margin and the pass-through of each year's policy change. Earlier independent loan-rate paths are retired. The replacement of missing-country opening loan quotes with an assumed cross-country margin was tested and held back after higher GDP, unemployment and inflation errors in the eight affected presets.

The trade scenario uses 5% of gross Eurostat trade as a scale for the final-goods channel. Imports compete for household spending and their prices enter the consumer index. Export orders contribute to production plans. Exports settle from goods left after domestic purchases and normal inventories. The real strength index multiplies nominal strength by the ratio of domestic producer prices to foreign basket prices. Foreign prices and demand each grow at an assumed 2% per year.

The current account equals goods exports minus imports in this specification. It reconciles to national saving less gross investment and to the change in the bank's net external settlement position. External income, imported inputs and valuation of foreign assets are outside the modeled accounts.

2023 opening presets, compared with 2024 and 2025 revised observations. Medians of 20 common seeds per preset, with equal weight across the 27 member countries. The EU27 model preset is included in simulations and excluded from member scores.

| Configuration | 2025 GDP growth RMSE | 2025 unemployment RMSE | 2025 net exports / GDP RMSE | Debt above 300% in year 40 |
|---|---:|---:|---:|---:|
| Trade off | 4.84 | 4.14 | 11.10 | 51 of 140 |
| Open to trade | 4.28 | 3.70 | 11.71 | 87 of 140 |
| Trade with policy and currency rules | 4.35 | 4.05 | 12.02 | 42 of 140 |
| Broader trade coverage | 3.53 | 3.17 | 10.67 | 96 of 140 |

The study ran 4200 paths and 66640 annual steps. The maximum relative accounting residual was 3.02e-14. Offer trade as an experiment. The narrower 5% scale and an assumed 2% annual expansion of foreign real demand contain some of the extreme outcomes of the broader market. The historical growth and employment fit improved, but the external benchmarks and long-run fiscal outcomes give mixed results. See `trade_validation.json` for the full comparisons.

## Household investment and financial markets in engine 1.10

The market uses voluntary orders from deposits above planned household spending. New equity and corporate bonds fill some of a firm's cash gap before bank loans. Venture funding pays for secondhand capital and working cash. The model tracks household holdings, dividends, interest, repayments, write-offs and recoveries. The government can borrow through new bond issues to households and banks. Equity positions are measured at contributed cost.

Purchases of securities reallocate deposits. Gross investment tracks fixed investment and inventory changes. National saving minus gross investment reconciles to the current account with either trade setting.

Start from the 2023 presets. Compare the median of 20 matched seeds with revised 2025 Eurostat outcomes. Each of the 27 member countries has equal weight. GDP growth is annualized from opening.

| Configuration | 2025 real GDP growth RMSE | 2025 unemployment RMSE | 2025 inflation RMSE | Debt above 300% of nominal GDP in year 40 |
|---|---:|---:|---:|---:|
| Earlier rules | 4.84 | 4.14 | 1.42 | 51 of 140 |
| Household investment | 4.61 | 4.11 | 1.46 | 28 of 140 |
| Smaller deposit commitment | 4.53 | 4.09 | 1.42 | 25 of 140 |

The study ran 2,381 paths over 41,448 annual steps. The maximum relative residuals were 1.62e-14 for the financial ledgers and 5.68e-14 for saving minus investment. The market is optional. Startup entry fell and banks bought more of the new public debt. The funding weights are scenario assumptions. See `finance_validation.json` for country results and the combined trade and monetary runs.

## Opening values, international finance and active country defaults

Year 0 displays the observed local 2023 HICP and model opening stocks. Unobserved annual flows start in year 1. The public-debt capacity weight is derived from the new public bond quote relative to the expected business loan return and stays between 0.20 and 0.40. Foreign securities earn income on opening holdings. Unfilled domestic orders can use a current account surplus after planned foreign purchases. Currency valuation and gross foreign purchases settle outside current income.

Country defaults enable all four channels. Goods sell to higher bidders first. Competitiveness depends on relative technology as well as real exchange rates. A small group of foreign buyers is willing to pay a premium. Banks pay policy-linked interest on opening deposits. The model separates five tax bases and accepts signed domestic, foreign, rate and currency shocks.

2023 starting points, 20 paired seeds per preset and equal country weights. Compare 2025 GDP growth annualized from 2023, annual inflation and unemployment with the previously examined Eurostat observations.

| Outcome | Earlier RMSE | Current RMSE |
|---|---:|---:|
| Real GDP growth | 4.84 | 4.08 |
| Unemployment | 4.14 | 3.93 |
| Inflation | 1.42 | 1.59 |

Both trade flows were positive in all 11,200 years of the default and combined stress cases. The accounting checks covered 840 paths and 15,680 years. The largest relative gap was 1.21e-14. See `live_economy_validation.json` for country results and settings.

## Household distribution and external transaction reporting in engine 1.13

Income Gini uses annual household cash income after modeled direct taxes and includes wages, transfers, interest and dividends. It excludes principal, securities purchases, liquidation proceeds and currency revaluation. Negative values are retained. For positive total income the population Gini can exceed one with negative observations. Unequal values with a nonpositive total are marked unavailable, rather than clipped or shifted. An all-zero distribution has Gini zero by convention. Every household has equal weight. Household-size equivalence adjustments are outside the model.

Financial wealth is recorded deposits, public and corporate bonds, contributed equity in active firms and foreign securities at the current exchange rate. Housing, household debt, original unpriced firm and bank ownership, and contingent liquidation claims are excluded. Equity at paid-in cost is not a market valuation. This measure is a subset of total household net wealth. The synthetic opening income distribution is equal and the wealth distribution is lognormal by assumption. These are model outcomes, not country survey estimates.

Every year has income and financial-wealth Gini metrics. First-seed household vectors support complete histograms, means, medians, P10/P90 and independently ranked equal-population quintiles. Summarized trend metrics use medians and P10/P90 across paired seeds. Exports include scalar metrics for all seeds and first-seed distributions in the full JSON.

Public debt / GDP uses public bond face values divided by annual nominal GDP. Private debt / GDP uses active business bank loans plus outstanding corporate bond face values. It does not double count deposits or treat shares as debt. Household borrowing is not modeled. Nonpositive nominal GDP makes ratios unavailable.

Acquisition cost is tracked on each household foreign-security purchase. The national transaction position is household foreign acquisition cost plus the bank's signed foreign settlement position. Gross assets are household acquisition cost plus a positive bank settlement asset. Gross liabilities are a negative bank settlement position. The independently calculated annual change in assets less liabilities must equal the current account. Gross household purchases change the sector holding the external position and do not set its net flow. Separate currency revaluation bridges this transaction position to the net position at current exchange rates. Capital-account transfers and other volume changes are outside the model. With valuation present, the change in a market-valued international position is current account plus valuation, not current account alone.

References for definitions are OECD Income inequality (https://doi.org/10.1787/459aa7f1-en) and IMF External Sector Report 2025 (https://www.imf.org/-/media/Files/Publications/ESR/2025/English/text.ashx). These sources do not calibrate the household microdistribution.

The executed reporting study covered 59 paths and 2,272 annual steps, including 6 years with negative individual incomes. The maximum relative foreign transaction residual was 1.42e-13, and the recorded wealth reconciliation gap was 1.76e-15. A separate regression compared 6 matched paths and reproduced all 26,082 existing economic output values exactly against commit 71c77df72612cd0b0545ede080b73085651405ba. These additions improve reporting and enforce explicit accounting. No additional dynamic forecasting accuracy has been established. Historical accuracy studies above retain their original engine specifications.

## Empirical household moments, gross foreign positions and tariffs in engine 1.14

Opening income Ginis use Eurostat ilc_di12, age TOTAL, EU-SILC 2024 (generally 2023 income), divided by 100. Mapping equivalised disposable income to equally sized model households is a proxy. Persistent earnings ranks distribute the fixed, funded aggregate wage bill without changing the labor input or creating money. The correlation of income and wealth ranks is assumed to be 0.4. No future Gini is forced back to its opening target.

The financial-wealth benchmark is reconstructed from ECB HFCS 2023 C1 participation rates and C3 conditional financial-asset deciles and means. Quantiles interpolate linearly below P90. A Pareto upper decile matches the conditional mean. Probability-bin integrals preserve the mean, including the upper tail, on a 20,000-bin reference grid. Rounded '< 0.1' figures use a 0.05 midpoint. The resulting Gini is a derived proxy for financial assets, not an official published Gini for total net wealth. Twenty-two national inputs are covered. Bulgaria, Denmark, Poland, Romania, Sweden and EU27 use a euro-area proxy. The published HFCS J4 total net-wealth Gini is displayed separately. Country reference periods and survey comparability notes remain in the frozen workbook. Initial synthetic lognormal ranks match the chosen Gini moments at the actual household count, but do not reproduce survey microdata or every decile exactly.

Gross external settlement assets and liabilities start as matched stocks, using 5% of the smaller Eurostat 2023 FA A_LE/L_LE position in percent of GDP. This is a coverage and initialization proxy, not the complete national IIP. The selected EU27 aggregate is missing, so the matched-stock proxy uses GDP-weighted member positions and includes intra-EU exposure. It must not be interpreted as a consolidated extra-EU IIP. Domestic opening deposits, loans and equity remain balanced. Net receipts add foreign settlement assets; net payments add foreign funding. One quarter of excess offsetting positions unwinds each year, retaining the opening relationships. The rollover fraction and non-interest-bearing settlement balances are assumptions. Household foreign securities have their own cash yield. Gross assets less liabilities reconcile independently to net foreign assets at acquisition cost. Their annual change equals the current account. Separate currency valuation bridges to the position at current exchange rates.

Opening trade volumes are positive benchmarks consistent with normalized expenditure GDP. The website keeps trade active, with positive minimum import-share and foreign-order parameters. Physical output and funded spending still constrain sales. It does not fabricate exports during a complete production collapse.

An ad valorem tariff raises the landed import price. Import VAT is levied on border value plus duty. Households pay domestic duty to the government; foreign suppliers receive the border value. Imports and the current account exclude domestic duty. Public saving includes it, and nominal GDP includes it as a product tax. Real GDP uses opening VAT and duty rates so a tax increase is not counted as extra real production. The same constant-price correction also fixes the previous VAT-rate artifact. This is a fixed-base model volume measure, not a complete chain-linked national accounting system. Tariff defaults are zero for experiments and are not estimated national tariff schedules. Imported intermediates, product-specific exemptions, retaliation and trade-policy uncertainty are outside the model.

Primary definitions: Eurostat ilc_di12 and bop_gdp6_q; ECB HFCS 2023 tables C1/C3/J4; European Commission VAT taxable amount (https://taxation-customs.ec.europa.eu/taxation/vat/vat-directive/taxable-amount_en); OECD tariff national accounting (https://www.oecd.org/en/blogs/2025/05/understanding-the-impact-of-changing-tariffs-on-gdp.html). Frozen files and SHA256 hashes are in HOUSEHOLD_TRADE_MANIFEST.json. Run scripts/enrich_households_trade.py after earlier profile enrichment, then tests/household-trade.mjs.

The current checks passed 168 opening states and 140 simulation paths over 5,600 years. Both gross trade flows and both gross foreign stocks stayed positive in 3,408 surplus years and 2,192 deficit years. The largest relative accounting residual was 4.02e-13. Opening Gini fitting errors were at most 2.55e-15 for income and 2.00e-15 for financial wealth. This improves initial-data fit and accounting; it does not establish better macroeconomic forecast accuracy. All path summaries are retained in household_trade_validation.json. Earlier studies above are archived specifications.

## Named event planner in engine 1.14.1

The separate event window groups direct shocks under editable names and common timing. Each annual event has a start year, inclusive full-strength duration and remaining fraction per later year. Several signed channels can be combined in one event, with 20 direct effects in total. The per-year preview uses the simulator's existing shock calculation: multiplicative percentage channels and additive policy-rate/currency offsets. It shows imposed changes, not predicted macroeconomic outcomes. Scenario events leave the reference unchanged. Saving, cancelling, exports and older flat schedules retain their meaning.

Scheduling verification: **PASS**, executed 2026-11-15T19:55:14.233Z, covering 22 simulation paths and 248 annual steps. Checks include exact start/end timing, fading, permanent effects, overlapping channels, invalid schedules, saved-setting and JSON replay, preserved 1.14 reference settings and identical economic row outputs with and without event metadata. No event changes outcomes before its start. The economic shock equations are unchanged, so this release makes no additional empirical accuracy claim. Full results are in event_editor_validation.json; the reproducible checks are tests/event-schedule.mjs.

## Empirical capital-input mappings in engine 1.15

2023 ECB QSA household foreign debt securities and listed shares anchor foreign order shares. VIFA look-through is available for 21 member presets; six use direct holdings of the same instruments and may understate indirect exposures. The representative EU27 uses the euro area's extra-area share, not a consolidated extra-EU observation. Foreign relative weight equals the domestic weight sum times foreign share / (1 minus foreign share). Italy's weight 150.18 corresponds to a 60.03% order-share proxy. The mapping uses stocks to initialize new annual orders; it does not estimate a behavioral response. There is no clipping at weight 100.

Financial-income tax rates divide EC DG TAXUD 2023 household capital-income receipts by Eurostat gross household property income. Bulgaria's missing denominator and the Netherlands' negative net receipts use an explicit EU27 fallback. Italy's effective proxy is 12.0656%; it is not the statutory rate on any individual security. Source taxes and income include broader concepts than the model's cash interest and dividends. The earlier wage-tax budget proxy is reduced by separately allocated capital receipts to avoid duplication.

The financial-wealth levy uses Italy's 0.20% financial-product levy / IVAFE proxy, Belgium's observed securities-account receipts / household financial assets, and Spain's observed wealth and solidarity-tax receipts / household financial assets. These uniform proxies do not reproduce exemptions, thresholds, fixed current-account charges, regional schedules or exact tax bases. Spain's real tax also covers non-financial wealth. Other member presets retain zero on the comparable modeled base, rather than an invented positive levy; this does not imply absence of real-estate, inheritance or transaction taxes. EU27 uses a GDP-weighted member proxy, not an EU-wide tax law. Separately allocated Spanish recurring wealth receipts are also removed from the broader D5 wage-tax fallback. Primary snapshots and all transformations are in capital_input_benchmarks.json, the official source manifest and scripts/enrich_capital_inputs.py.

Input, replay, annual accounts and migration checks: PASS, 449 paths, 8,968 annual steps; largest relative residual 7.31e-13. Both gross trade flows stay positive in 168 of 168 longer paths, while 22 end above 300% public debt/GDP. The green question/event panel explicitly belongs to setup; a separate divider labels computed outcomes.

The following same-engine comparison uses five common seeds per preset and previously examined 2025 observations. GDP is annualized between 2023 and 2025. All 27 countries have equal weight and remain in the scores. No input is selected from these outcomes. **The updated input proxies worsen these errors; improved forecasting accuracy is not established.**

| Metric | Earlier RMSE pp | Updated RMSE pp |
|---|---:|---:|
| Annualized real GDP growth | 4.652 | 4.915 |
| Unemployment | 4.748 | 5.073 |
| Inflation | 1.673 | 1.932 |

All country predictions and longer paths are retained in capital_input_validation.json.

## GDP income, TFP and treasury repayment in engine 1.16

The outcome panel separates gross wages, gross capital income and net production taxes at current prices. Gross capital income includes depreciation and retains negative values. Modeled business research grants are treated as production subsidies, added to operating surplus and deducted from net production taxes. The components reconcile independently to expenditure GDP. Interest, dividends, direct taxes and principal repayment do not create additional GDP. These are income shares, not causal contributions to GDP growth.

TFP level is 100 times the existing normalized productivity residual, based on real goods output, production hours, capital and the configured PWT accounting exponent. It is a within-economy index before optional settling, not an absolute cross-country PWT level or the latent firm-knowledge index. The annual outcome tables identify their first seed, separately from ensemble charts.

Eurostat 2023 nasa_10_f_bs, S13 non-consolidated assets F2 and F5 in percent of GDP, anchors treasury cash and government equity/fund holdings in all 28 presets. Italy opens with 4.7% cash/deposits and 9.5% equity/fund shares; EU27 with 8.7% and 17.6%. Governments hold liquidity for payments, and the wider F5 portfolio need not be small. It is mapped to residual book claims on domestic firms, not asserted to equal non-financial public-company ownership. Government receives its share of current dividends and capital liquidation proceeds. Household new equity dilutes the original public claim. Scripts/enrich_government_assets.py, frozen government_cash_equity_2023.json and government_asset_benchmarks.json retain the selections and source definitions.

Treasury cash above the observed opening cash/GDP ratio times lagged real GDP at current producer prices repays outstanding government bonds pro rata. This liquidity target is an assumption. No borrowing is made solely to refill it. Debt principal reduces treasury cash and outstanding household/bank bonds without becoming household income, a taxable return or bank equity. Existing excess cash can also repay bonds during a current deficit. If no debt remains, excess cash is retained as an asset rather than erased.

Separate annual and cumulative counts show payment defaults, continuing-firm restructurings, default-related exits and loan write-offs. Cumulative counts are events, not unique firms. With entry/exit active, default normally closes the firm; otherwise its debt is restructured. Minimum-population restructurings are marked in the event log. Other exits can also write off debt. A stale forced-exit flag in firms retained by the numerical floor is now cleared, and a regression verifies it cannot independently cause repeated restructurings. Default frequency is not empirically estimated. A zero final-year count can be valid even after earlier events.

Current validation: **PASS**, 371 paths, 8,372 annual steps and 28 official opening presets. Maximum relative accounting residual 2.20e-14; maximum income/expenditure GDP gap 1.99e-13 nominal units. Bond repayments occurred in 933 checked years. The high-surplus test reduced debt from 134.00 to 63.73, retiring 70.27 units of principal. Severe seed-2026 tests produced 34 continuing-firm restructurings with exits off and 29 default-related exits with exits on; both final-year default counts were zero. These tests check accounting and mechanisms, not a calibrated real-world default rate.

Frozen engine 1.15 and current engine, original 2023 country inputs, three common seeds per preset, equal weights across 27 countries, previously examined 2025 observations. No coefficient selection from these scores. GDP growth annualized 2023-2025. The following errors worsen slightly. No improved macroeconomic forecasting accuracy is claimed.

| Metric | Frozen 1.15 RMSE pp | Current 1.16 RMSE pp |
|---|---:|---:|
| Annualized real GDP growth | 4.779 | 4.816 |
| Unemployment | 4.116 | 4.145 |
| Inflation | 1.896 | 1.906 |

All results and limitations are retained in income_fiscal_validation.json. The earlier capital-input numerical study above is reproduced with its frozen 1.15 engine so government ownership and repayment changes do not confound that comparison. Current parameter and configuration checks use the current registry.

## Population, schooling, retirement and housing in engine 1.17

457 paths and9,112 annual steps passed current checks, with maximum relative residual2.32e-14. All 28opening inputs enter without clipping. Population balances, mortgage principal, pension cash, public/household/firm/financial ledgers, income/expenditure GDP and S−I=CA/NFA transactions=CA reconcile. Tests cover all 16channel combinations and parameter boundaries. There were10 mortgage defaults in7 paths. The year 4education-quality change first affected worker human capital in year14. With additions off,63,504 shared frozen 1.16values are reproduced within numerical tolerance.

The original-mechanism numerical studies above use frozen 1.16country inputs with the additions off, or their explicitly frozen engine specifications. The current full-coverage study is separate. Every current path is retained. No coefficient was selected from the diagnostic errors below.

| Metric | Frozen 1.16 RMSE pp | Full1.17 RMSE pp |
|---|---:|---:|
| Annualized real GDP growth | 4.816 | 3.890 |
| Unemployment | 4.145 | 2.793 |
| Inflation | 1.906 | 2.172 |

GDP and unemployment errors fall; inflation error rises. These are previously examined2025 observations and definitions/coverage differ. This is not an untouched validation or proof of overall accuracy.

# Population, schooling, retirement and housing — model 1.17

Each step is one year. Opening GDP is 100; the opening labor force is 100 units. New country defaults activate all four additions. These are aggregate scenario mechanisms with empirically anchored stocks, not fitted demographic, pension, school-quality or housing forecasts.

## Data and coverage

The three extraction scripts and `integrate_society_inputs.py` reproduce all mappings from frozen official inputs. Population, age shares, births, deaths, net migration plus statistical adjustment, age-specific mortality allocations, public education, household education, actual/imputed rents and tenure shares cover all 28 presets at 2023. PWT `hc` is a schooling/returns-based index, not observed school quality. EU human capital uses an employment-weighted member proxy.

Population and age shares refer to 1 January 2023; housing/financial stocks generally to end-2023, annual income/expenditure to 2023 and most private pension ratios to 2021. These reference periods anchor a normalized model snapshot rather than a literal common balance-sheet date. They do not form a real-time forecast vintage.

Public old-age spending uses government COFOG GF1002 cash benefits D62; it is broader than purely contributory pensions. Household dwelling structures exclude land. Ireland uses the observed EU dwelling/GDP ratio because its selected national stock is missing. Housing loans and residential/total fixed-investment shares cover all 28. Owner and mortgage-holder observations describe people living in those tenures and are mapped to a synthetic household count.

Private pension sources mostly use 2021 private DB/DC entitlements and cash flows, preserving their source year. France, Hungary and Malta use 2023 pension-fund asset proxies, Estonia uses its supervisor’s 2023 fund data, and EU27 is derived. Where national cash flows and stocks are not comparable, total flows/total entitlements across covered 2021 members gives a common ratio applied to the local stock proxy. This avoids dividing an EU GDP-flow fallback by a small national fund stock. New mortgage quotes have 20 national comparable EUR series, outstanding-stock quotes 19; others use a labeled euro-area spread combined with the local policy rate.

## Population and skills

Three stocks represent ages 0–14, 15–64 and 65+. The sum changes exactly by births minus deaths plus net migration. Observed mortality partitions calibrate age-specific hazards. Their future aggregate death rate responds to cohort composition. Fractional annual aging moves1/15of surviving children into working age and1/50of surviving working-age people into the older cohort. These transition fractions approximate within-group age distributions. Migration’s age and skill mix is assumed. Net emigration cannot exceed a remaining cohort. Migrants bring no free deposits or foreign portfolios; household groups retain domestic assets.

Labor force size follows working-age population at fixed participation, normalized to100at opening. Opening employment uses source unemployment ages15–74; using working-age15–64to drive its later scale is an explicit approximation. Employment/unemployment chart values remain percentages of the current labor force. Separate units track jobs, worker inflows/outflows and payroll. Cohort stocks do not simulate individual household age histories or legal national retirement ages.

Education is a reallocation within funded government and household purchases. It is not added to expenditure a second time. The government source includes transfers and investment; household funding does not uniquely identify private providers. The model labels these coverage proxies and assigns separate public/household-funded quality multipliers, both initially1. No private-provider advantage is presumed.

Quality-adjusted delivered resources per child determine an incoming-worker schooling target, using an assumed0.2elasticity. The default10-year lag prevents an immediate effect on existing adults. The mean skill stock combines continuing workers, graduates with lagged schooling and migrant skills. Production uses human capital relative to its opening PWT level, avoiding an artificial starting GDP jump. Skills increase labor efficiency and the learning/research capacity of firms. Wage, capital-capacity and demand constraints can still make total GDP respond differently from potential labor productivity.

## Public and funded pensions

Observed old-age cash benefits are removed from flat social support before a separate demographic benefit rule pays them. Benefits scale with the older cohort, producer prices and an assumed partial real-wage indexation. Pension contributions earmark existing worker withholding; they do not levy a second tax. Other revenues or borrowing cover a gap. Public pension promises are not added to outstanding government bonds. No distinct national pension-benefit tax schedule or actuarial entitlement is estimated.

Private funded accounts hold residual stakes in existing firms and bank deposits. Opening pension ownership replaces part of the original household ownership; assets are not cloned. New contributions exchange household cash for fund units at current NAV. Dividends, policy-linked deposit interest and liquidation proceeds have matching payers. Fund asset values follow the actual modeled book claims. The source’s wider DB/DC universe is approximated by funded accounts without DB guarantees or national tax schedules.

Investment income accrues to household saving even before it becomes spendable. Pension contributions and withdrawals exchange assets and cash, while valuation changes affect wealth separately. This gives the effective pension-saving adjustment without treating withdrawals as extra GDP or bank profit. The cash-income histogram excludes asset redemptions and noncash imputed rent. Planned withdrawals depend on the source benefit/assets proxy, aging and liquidity. Funds can sell original stakes pro rata to original owners using their existing cash; otherwise a withdrawal can be delayed. No money is created to meet a pension promise.

## Housing, borrowing and GDP

Observed household dwelling structures are carved out of opening PWT total capital; productive firm capital is the remainder. Current-price structures and PWT national-price capital are different measurement concepts, so this split is a proxy. Construction takes its observed dwelling/total GFCF share of the original investment envelope. Firm plans and household construction orders use the same demand target, which responds to relative housing/replacement costs, supply per person and policy-linked borrowing costs. The chosen responses are assumptions, not housing elasticities estimated from the diagnostic scores.

Households hold primary residences and/or investment property. Initial tenure preferences stay fixed within a numerical sample: renters may own property that they let to others. This avoids assuming that every household eventually becomes an owner merely because the synthetic sample has no new household IDs. Housing/loan allocations and subsequent tenure behavior are not fitted household microdata.

New mortgage quotes equal the opening policy rate plus a source-matched spread plus policy pass-through of the current rate change. Existing contracts reprice gradually. New lending needs cash/collateral, prior positive cash income, an assumed debt-service limit and bank lending capacity. Mortgages compete with business lending and the existing public-debt exposure. Observed opening loans are not clipped to the new-loan LTV ceiling; their real collateral may include land excluded from the modeled structure stock.

Four source balance sheets need additional mortgage funding beyond the deposits/equity already represented. A residual term liability is paired with household term claims, pays the current positive policy rate and rolls over. It is capped by opening mortgages and does not rescue inconsistent opening business-credit configurations. These claims are a closing balance-sheet proxy, not measured national bond portfolios. Existing mortgage loans never add a duplicate initial cash endowment.

Mortgage origination creates matching deposits and loan assets. Principal repayment reduces both. Persistent unpaid current interest can trigger nonrecourse foreclosure: collateral transfers to the financial sector, the loan closes and any uncovered principal becomes a creditor loss. This is a model recovery convention, not a statement of national legal recourse. Unpaid interest is reported as a shortfall, without an additional accrued-interest capitalization rule. Repossessed homes can be sold or rented. Property depreciation and valuation changes have explicit counterparts in financial-sector equity.

Actual rents transfer cash to household/financial-sector landlords. Owner-occupied housing produces imputed consumption and income without cash. Both enter GDP once, with housing operating surplus included in gross capital income. New housing construction is investment. Existing-house sales, mortgage principal and house-price gains do not add GDP. Rent adjustment is separate from asset-price adjustment. Only actual rents enter the model consumer basket, using a national-accounts spending-share proxy; owner-occupied imputed rent and house-price gains are excluded.

Financial wealth includes pension and term claims. Recorded net wealth adds dwelling value and subtracts mortgages. Land, unpriced original household firm/bank ownership, legal pension guarantees and detailed household debt products remain outside this partial wealth measure. The net-wealth Gini is not fitted to the broader survey net-wealth benchmark.

## Verification and limits

`society_validation.json` contains every path and the current diagnostic scores. Tests cover all 28 opening economies, baseline/events, all 16 channel combinations, parameter boundaries, exact population/housing/mortgage/fund flows, school delays, foreclosure, capital/investment separation and S−I=CA/NFA transactions=CA. Original-mechanism regression studies use frozen 1.16 country inputs with the new channels off. Independent current sector-ledger tests use the full active presets. The four additions off reproduce all 63,504 shared frozen 1.16 values within numerical tolerance. Passing accounting checks is not evidence of fitted causal multipliers or reliable long-run forecasts.

Primary accounting references: Eurostat pension metadata https://ec.europa.eu/eurostat/cache/metadata/en/nasa_10_pens_esms.htm; ESA2010 https://eur-lex.europa.eu/eli/reg/2013/549/oj/eng; ECB owner-occupied housing https://www.ecb.europa.eu/press/economic-bulletin/articles/2022/html/ecb.ebart202201_01~f643aad55c.en.html. Exact data URLs, flags, source years and SHA256 hashes are retained in the manifests and benchmark JSONs.


## Foreign projection and event checks — engine 1.18

390 paths, 14,636 annual steps; maximum relative accounting gap 1.57e-14. With projections disabled, 74,007 common row values reproduce frozen 1.17. No forecast accuracy improvement is inferred.

# Foreign productivity projections and event examples — engine 1.18

The population, education, pension and housing additions were completed and
published as engine 1.17 before this change. Those mechanisms remain active.

## Source and interpretation

The frozen source is OECD Economic Outlook 117 long-term scenarios, the 2025
update, reported last updated on 6 January 2026 and retrieved on 8 November
2026. Its public annual data run through 2100. Six conditional paths vary the
energy transition, climate damage and mitigation costs. BAU1 is the default
scenario choice; that choice is an assumption, not an empirical finding.

The published variable EFFLABS is trend labour efficiency. OECD uses

\[Y_t=(EFFLABS_t L_t)^{0.67}K_t^{0.33}.\]

Thus the implied Hicks-neutral productivity multiplier within each country is

\[A_t/A_{2023}=(EFFLABS_t/EFFLABS_{2023})^{0.67}.\]

This transformation must not be confused with GDP growth, GDP per worker or a
directly published PWT-comparable TFP forecast. EFFLABS is a headcount-based
residual; PWT separately adjusts labour for human capital. Linking the derived
growth to the existing PWT opening level is an explicit cross-source proxy.
OECD's model includes empirically estimated convergence alongside assumed
global technical progress, decaying momentum and climate/mitigation channels.
The future is not observed, and conditional scenarios are not predictions
with established accuracy for this simulator.

## Rest-of-world average

The opening PWT pool contains 118 countries other than the USA and China.
Published comparable OECD national paths overlap 47 of them, representing
74.98577409185644% of the pool's fixed 2023 PPP output. The internal OECD model's
139-country coverage is not its public per-country data coverage.

For the covered set C, the linked index is

\[R_t=\frac{\sum_{i\in C} GDP^{PPP}_{i,2023}\,ctfp_{i,2023}
 (EFFLABS_{i,t}/EFFLABS_{i,2023})^{0.67}}
 {\sum_{i\in C} GDP^{PPP}_{i,2023}\,ctfp_{i,2023}}.\]

R_2023 = 1. The full opening rest-of-world level is retained and grown by R.
Covered-sample evolution therefore proxies uncovered countries; missing
national forecasts are not fabricated. No overlapping OECD/world aggregate
enters the sum. The home country remains in the rest-of-world pool when
covered, matching its established definition of excluding only USA and China.
Raw national-currency efficiency levels are never averaged across countries.

## Time, updates and shocks

Each step is one year. The foreign calendar starts in 2023 and advances with
every step, including optional settling. Normal year 1 therefore uses the
2024-to-2023 annual ratio. A donor closes year t at

\[D_t=D_{t-1}(1+(g^{source}_t+s_t)/100),\]

where s is the additive foreign-growth event offset in percentage points.
Source growth varies by calendar year. A scenario change uses the new
scenario's subsequent annual rates and retains the level already accumulated.
Events may raise or reduce each source separately, overlap and fade. A
completed growth shock does not reverse its accumulated level effect. Rates
at or below -100% are rejected rather than silently producing invalid levels.

The donor endpoint is appended only after current learning. Adoption still
uses completed history with the configured additional delay. A foreign growth
event can affect competition through the subsequent foreign technology basket
and later domestic adoption; it never grants immediate domestic knowledge.

The published paths end in 2100. Afterward the final published annual rate is
repeated, flagged and described as extrapolation. There is no random forecast
revision law or feedback from the representative domestic economy into OECD
paths. Scenario controls and named events supply explicit changes. The dataset
is a frozen reproducible vintage; it does not silently update over the network.

Published paths are enabled in country presets. Disabling them restores the
three existing fixed historical-growth controls. Generic defaults keep that
legacy mode for reproducibility. Saved custom fixed-growth values or paths
migrate in fixed-rate mode so their inputs are not ignored; resetting an
economy enables the new country default. Other settings and events persist.

## Event examples

Every event example supplies a name, start, duration, remaining fraction and
nonzero effects. A planner with neither parameter paths nor saved shocks opens a filled economic-downturn example
as an unsaved draft. Parameter-based examples display their actual paths instead. Selecting another example replaces that untouched draft. Apply commits it, Cancel leaves the experiment unchanged.
Saved events reopen without adding an example. The foreign innovation example
adds 0.5 percentage points to US/rest-of-world growth and 0.8 to China's growth
for five years, then halves the remaining effect each later year. These sizes
are illustrative assumptions, not estimated probabilities or effect sizes.

## Validation boundary

`tests/foreign-projections.mjs` verifies raw-source hashes, the transformation,
the excluded-country weighted average, all six scenarios, annual compounding,
prospective changes, positive/negative/overlapping/fading events, adoption
delay, the tail, settling, saved-setting migration and source-off equivalence
to frozen 1.17. It also checks all four social channels and the GDP/financial
identities across every opening economy.

This 2025/2026 projection vintage was unavailable in 2023. Existing retrospective
2025 error comparisons keep this new option off and remain separate, previously
examined diagnostics. Adding these projections does not demonstrate improved
past-only forecasting accuracy. No response coefficient was optimized against
those scores.

`scripts/build_foreign_projections.py` compiles only frozen official inputs.
Exact URLs and hashes are in `research/forecast_source_candidates/candidate_manifest.json`
and `dist/data/foreign_projections.json`. The generated browser module contains
the same paths, avoiding network requests during a simulation.

Primary sources:

- [OECD 2025 long-run model and production function](https://www.oecd.org/en/publications/oecd-global-long-run-economic-scenarios_00353678-en/full-report/component-4.html)
- [OECD estimation and coverage annex](https://www.oecd.org/en/publications/oecd-global-long-run-economic-scenarios_00353678-en/full-report/component-8.html)


## Filled event assumptions and presentation correction — engine 1.18.1

68 paths and 1,584 annual steps passed, maximum relative residual 1.28e-14. All 56 pre-change valid paths retained exactly the same numerical rows. 30 malformed inputs were rejected. The selected parameter assumptions are visible and editable alongside shocks; a different example replaces an untouched default downturn. The long social/housing outcome card is removed while its model channels remain. No behavioral coefficient or forecasting accuracy improvement is inferred. Full evidence: event_input_validation.json.

## Browser verification for engine 1.26.0

{
  "status": "PASS",
  "modelVersion": "1.26.0",
  "executedAt": "2026-11-15T20:09:54.404Z",
  "browserPaths": 4,
  "yearsPerPath": 40,
  "checkedNumericValues": 75424,
  "maxRelativeDifference": 6.821210263296962e-13,
  "screenshot": "research/browser-demography-income-foreign-1_26.jpg",
  "checks": [
    "Country-specific pension age visible in main controls: USA66.5, China60, dated source definitions and sex/career caveats shown.",
    "Retirement-age example configures +2years from year5; annual population groups and scenario/reference eligibility differ at the scheduled date.",
    "Year6/ref/scenario changes preserve expanded population details and selected year.",
    "Foreign public claims, issuance, repayments and interest shown; China source instrument split and interpolated income-share status verified.",
    "Evidence shows mixed current forecast errors separately from historical1.25 fiscal comparison.",
    "Full browser JSON export reproduces every numeric row in both economies and seeds with the current engine."
  ],
  "limitations": [
    "Browser interactions verify the interface and reproducibility, not empirical forecast accuracy.",
    "Population profiles and legal references are dated2023; five-year interpolation, policy responses and incomplete external coverage remain disclosed."
  ]
}

## Official source manifest

- unemployment: une_rt_a
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/une_rt_a?lang=en&freq=A&unit=PC_ACT&sex=T&age=Y15-74&time=2023
  Retrieved 2026-11-02T15:33:47.000420+00:00; SHA256 7cff11667e0bda0b688b60ce8a1bd1099dbd692782d881b2cfa35f7433359968
- public_debt: gov_10dd_edpt1
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10dd_edpt1?lang=en&freq=A&unit=PC_GDP&sector=S13&na_item=GD&time=2023
  Retrieved 2026-11-02T15:33:47.001540+00:00; SHA256 980f062e025cc1757f7fed6e20aca8847bbb27ca282164650d0ce74ea59c2101
- national_accounts: nama_10_gdp
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&freq=A&unit=CP_MEUR&time=2023
  Retrieved 2026-11-02T15:33:47.002800+00:00; SHA256 2df96e9f14064e0bfbb998da0e0106d5016aa259fb3bd4ac4065b8cbf9b5e6ea
- government_accounts: gov_10a_main
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10a_main?lang=en&freq=A&unit=MIO_EUR&sector=S13&time=2023
  Retrieved 2026-11-02T15:33:53.112618+00:00; SHA256 98dc7dd6e1703c7d6f429e5e3c871fb9861046c8cddabde1f01e9a3de63032e7
- capacity: ei_bsin_q_r2
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/ei_bsin_q_r2?lang=en&freq=Q&indic=BS-ICU-PC&s_adj=SA&sinceTimePeriod=2023-Q1&untilTimePeriod=2023-Q4
  Retrieved 2026-11-02T15:33:53.122365+00:00; SHA256 6eaeabb91a305b1e0acfcb488d800925dde02d36a786845059854084c38dba8d
- financial_stocks: nasa_10_f_bs
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_f_bs?lang=en&freq=A&unit=PC_GDP&co_nco=NCO&time=2023&na_item=F2
  Retrieved 2026-11-02T15:33:54.410833+00:00; SHA256 19b604287b61b836c12b81238831495d521207c32f573441d4634d72447570b0
- public_rd_funding: rd_e_gerdfund
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/rd_e_gerdfund?lang=en&freq=A&unit=MIO_EUR&sectfund=GOV&time=2023
  Retrieved 2026-11-02T15:33:59.950759+00:00; SHA256 b786f28f9cf7ad0986d00209c668da5d100a343bb155bf4a0e166539f6c06da6
- corporate_loan_rates: ECB MIR
  https://data-api.ecb.europa.eu/service/data/MIR/M.AT+BE+HR+CY+EE+FI+FR+DE+GR+IE+IT+LV+LT+LU+MT+NL+PT+SK+SI+ES+U2.B.A20.A.R.A.2240.EUR.O?startPeriod=2023-01&endPeriod=2023-12&format=csvdata
  Retrieved 2026-11-02T15:34:07.023791+00:00; SHA256 b39bc4d6c458b1e9312804b6e1f8e4e6971bfa5498e13434487722b7b5667430
- household_income: nasa_10_nf_tr
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_nf_tr?lang=en&freq=A&sector=S14_S15&na_item=B6G&time=2023
  Retrieved 2026-11-02T15:44:26.227050+00:00; SHA256 1e8a28bd4a61c14b929b07c775e3022d55146ebb4ec4b85773afc4f024220b70
- household_deductions: nasa_10_nf_tr
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_nf_tr?lang=en&freq=A&sector=S14_S15&na_item=D5&na_item=D61&direct=PAID&unit=CP_MEUR&time=2023
  Retrieved 2026-11-02T16:01:09.461645+00:00; SHA256 6bd4e7a984b4d3d0afe427afbe361b9fc02ef8f9a49ec91e32acb4554497e37c
- rd_performance: rd_e_gerdtot
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/rd_e_gerdtot?lang=en&freq=A&unit=MIO_EUR&time=2023
  Retrieved 2026-11-02T16:11:47.555289+00:00; SHA256 fd7f6713fc42514674ce89e617fe7f4bdc8cedb6ded18a85c7acba2aa6ce8e83
- historical_gdp_growth: nama_10_gdp
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&freq=A&unit=CLV_PCH_PRE&na_item=B1GQ&sinceTimePeriod=2010&untilTimePeriod=2023
  Retrieved 2026-11-02T16:15:05.285646+00:00; SHA256 81ebb625ee4af906852f2254fe0acfaaf919407a083d7f18c4e6778920e141e9
- historical_unemployment: une_rt_a
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/une_rt_a?lang=en&freq=A&unit=PC_ACT&sex=T&age=Y15-74&sinceTimePeriod=2010&untilTimePeriod=2023
  Retrieved 2026-11-02T16:15:05.287009+00:00; SHA256 1837bdda57d78b66a4894c4d728318e3d140285b217e11e33f460aa1fba587cb
- business_rd_costs: rd_e_gerdcost
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/rd_e_gerdcost?lang=en&freq=A&unit=MIO_EUR&sectperf=BES&time=2023
  Retrieved 2026-11-02T19:48:46.877887+00:00; SHA256 a1a3a4e33e8f1c2c47cdc504f4e203af75cdc9a1e196ee1b578d3e4eec17034f
- business_demography: bd_size
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/bd_size?lang=en&freq=A&age=TOTAL&indic_sbs=ENT_BRTHR_PC&indic_sbs=ENT_DTHR_PC&sizeclas=TOTAL&nace_r2=B-S_X_O_S94&sinceTimePeriod=2021&untilTimePeriod=2023
  Retrieved 2026-11-03T17:18:02.199187+00:00; SHA256 31c0f01550c2bb746d431847e303fd58462a8037e0e5d505aa8c92ee5aeb2727
- pwt_foreign_productivity: PWT 11.0
  https://dataverse.nl/api/access/datafile/554105
  Retrieved 2026-11-03; SHA256 7b337e94f39dfe304bc459e433f8ce0624496c812707ae0c924888f5142b3ab3
- business_demography_sizes: bd_size
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/bd_size?lang=en&freq=A&age=TOTAL&indic_sbs=EMP_DTHR_PC&indic_sbs=EMP_BRTHR_PC&indic_sbs=EMP_NR&indic_sbs=ENT_NR&indic_sbs=ENT_DTHR_PC&sizeclas=TOTAL&sizeclas=0&sizeclas=1-4&sizeclas=5-9&sizeclas=GE10&nace_r2=B-S_X_O_S94&time=2023
  Retrieved 2026-11-05T15:59:24.447636+00:00; SHA256 f7e378dc6727e2a948e443b9e5b47df3ded4d462d9ec814b0744e5effeb1a3cf
- labour_market_transitions: lfsi_long_a
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lfsi_long_a?lang=en&freq=A&unit=PC_EMP&unit=PC_UNE&sex=T&time=2023&wstatus=EMP_EMP&wstatus=EMP_UNE&wstatus=EMP_INAC&wstatus=UNE_EMP&wstatus=UNE_UNE&wstatus=UNE_INAC
  Retrieved 2026-11-05T16:46:09.521227+00:00; SHA256 5794710ff4dc4fb92cca2381b865c29b0634e1877cb99d14fb3e07fd8a3f5c7d
- ecb_deposit_rate: ECB FM.D.U2.EUR.4F.KR.DFR.LEV
  https://data-api.ecb.europa.eu/service/data/FM/D.U2.EUR.4F.KR.DFR.LEV?startPeriod=2023-12-29&endPeriod=2025-12-31&format=csvdata
  Retrieved 2026-11-06; SHA256 a649173c88b1c2110f57690503837e01e78bbfe5111de97ead61824d21e611cc
- bis_policy_rates: BIS WS_CBPOL
  https://stats.bis.org/api/v1/data/BIS,WS_CBPOL,1.0/M.XM+CZ+DK+HU+PL+RO+SE+US+CN?startPeriod=2023-12&endPeriod=2025-12&format=csv
  Retrieved 2026-11-06; SHA256 9906005ebbb831ddd2c9f758008a1c420327a9505cd035251fefeaa44dc65c21
- hicp_annual: Eurostat prc_hicp_aind
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/prc_hicp_aind?lang=en&freq=A&unit=RCH_A_AVG&coicop=CP00&sinceTimePeriod=2010&untilTimePeriod=2025
  Retrieved 2026-11-06; SHA256 e577f9dd755c323395a1bcf605788596ae6f06d2b01b0ebe02e6a7f2808a5ad8
- gdp_growth_2024_25: Eurostat nama_10_gdp
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&freq=A&unit=CLV_PCH_PRE&na_item=B1GQ&sinceTimePeriod=2024&untilTimePeriod=2025
  Retrieved 2026-11-06; SHA256 61467b4ea54a9bf9310948ddb07e7538dc6f3550b1f540282e03f6036eea5b35
- unemployment_2024_25: Eurostat une_rt_a
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/une_rt_a?lang=en&freq=A&unit=PC_ACT&sex=T&age=Y15-74&sinceTimePeriod=2024&untilTimePeriod=2025
  Retrieved 2026-11-06; SHA256 3cac4dabfe375ae358f66d3e939420f51af07df6cc2432622466b6bcb710add4
- trade_nominal: Eurostat nama_10_gdp, B1GQ, P6 and P7
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&freq=A&unit=CP_MEUR&na_item=B1GQ&na_item=P6&na_item=P7&sinceTimePeriod=2023&untilTimePeriod=2025
  Retrieved 2026-11-06; SHA256 c5081f1dfc0b80a6d064888ae2fb0eb950229dce6c4fdfc72beb2b2e9937874d
- bis_real_exchange_rates: BIS WS_EER monthly broad real exchange rates
  https://stats.bis.org/api/v1/data/BIS,WS_EER,1.0/M.R.B.?startPeriod=2023-01&endPeriod=2025-12&format=csv
  Retrieved 2026-11-06; SHA256 40a0e041513db414ba2c117d98956f857c982f461966312c51cad995b00fe532
- public_investment_growth: Eurostat nama_10_gdp, P3_S13 and P51G
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&freq=A&unit=CLV_PCH_PRE&na_item=P3_S13&na_item=P51G&sinceTimePeriod=2010&untilTimePeriod=2025
  Retrieved 2026-11-06; SHA256 ecac8c3674826029e14aabd5b09a0a103c429deebb1ca4c0f87ef91b7352891d
- capital_italian_wealth_scope: Italian Parliament financial-product levy / IVAFE scope, applicable 2023 ordinary rate
  https://temi.camera.it/leg19/temi/la-fiscalit-internazionale
  Retrieved 2026-11-07T16:51:17.874047+00:00; SHA256 0fb1e63524cae83368064707c08accbb8ab2d24d8d904aa73d9d4f26d47ab5ed
- capital_eu_wealth_scope: European Parliament 2025: wealth-tax bases and 2023 receipts
  https://www.europarl.europa.eu/RegData/etudes/ATAG/2025/779237/EPRS_ATA%282025%29779237_EN.pdf
  Retrieved 2026-11-07T16:51:17.874047+00:00; SHA256 952937c4cbef1f5be0c887aac1570aac83e813dfbff9ab3eb846177499aeb41c
- capital_portfolio_methodology: ECB household portfolio look-through methodology
  https://www.ecb.europa.eu/stats/pdf/Looking_through_note.en.pdf
  Retrieved 2026-11-07T16:51:17.874047+00:00; SHA256 f5f3e67ecc1cf488324cb6f037341a0e3ed4bb65a3d2ae3f67480e32732dac28
- capital_tax_profiles: EC DG TAXUD 2026 country tables, 2023 column
  https://taxation-customs.ec.europa.eu/document/download/ff0728c1-9176-4759-b981-8872e0374416_en?filename=Part2_country_profiles.xlsx
  Retrieved 2026-11-07T16:51:17.874047+00:00; SHA256 255af1100d42fc75769d24dc3f18fc940a2364f83d10a0dfebe54d478887b490
- capital_tax_lists: EC DG TAXUD 2026 national tax lists, 2023 column
  https://taxation-customs.ec.europa.eu/document/download/600d56d1-ea6e-416e-9981-1c8b9c603b6b_en?filename=NTL+edition+2026+web.xlsx
  Retrieved 2026-11-07T16:51:17.874047+00:00; SHA256 1a09d2fec191bc517f3fc1f35b380a1fb50c885253284a4ef4ae5cfd4d3f27c2
- foreign_portfolio_lookthrough: ECB QSA 2023Q4 VIFA, household debt securities and listed shares
  https://data-api.ecb.europa.eu/service/data/QSA/Q.N..W0+W1.S1M.S1.N.A.LE.F3+F511.T+_Z._Z.XDC._T.S.V.N.VIFA?startPeriod=2023-Q4&endPeriod=2023-Q4&format=csvdata
  Retrieved 2026-11-07T16:51:17.874047+00:00; SHA256 9aaa28b75022e95340894e95105dee8e80ffd88193876f97b6dfa5355cdd06e6
- foreign_portfolio_direct: ECB QSA 2023Q4 direct household securities
  https://data-api.ecb.europa.eu/service/data/QSA/Q.N..W0+W1.S1M.S1.N.A.LE.F3+F511+F522.T+_Z._Z.XDC._T.S.V.N._T?startPeriod=2023-Q4&endPeriod=2023-Q4&format=csvdata
  Retrieved 2026-11-07T16:51:17.874047+00:00; SHA256 dfe393e121f087ac30f598a67bf7a089a6629f51c05c018bfeb9b0d616397580
- household_property_income: Eurostat nasa_10_nf_tr S14_S15 D4 received, 2023
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_nf_tr?lang=en&freq=A&unit=CP_MEUR&sector=S14_S15&direct=RECV&na_item=D4&time=2023
  Retrieved 2026-11-07T16:51:17.874047+00:00; SHA256 77e0ebf41d95851cf708509964ab1209fff0ce58a249caa0ebd9e5c2861aa084
- household_financial_assets: Eurostat nasa_10_f_bs S14_S15 assets, 2023
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_f_bs?lang=en&freq=A&unit=MIO_EUR&co_nco=NCO&sector=S14_S15&finpos=ASS&time=2023
  Retrieved 2026-11-07T16:51:17.874047+00:00; SHA256 9a96fae67df773125dfe55080e38ae3ca9511573f33f15f10eb8b164169e2fc4
- government_cash_equity: Eurostat nasa_10_f_bs S13 F2/F5 assets, 2023
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_f_bs?lang=en&freq=A&unit=PC_GDP&co_nco=NCO&sector=S13&finpos=ASS&na_item=F2&na_item=F5&time=2023
  Retrieved 2026-11-07T18:00:57.453951+00:00; SHA256 185e8a9301ff0ca04dbeb8f471ad390bb764ca4747a39214c6ef4ca8e9573bae
- population_education_balance: demo_gind
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_gind?lang=en&freq=A&time=2023
  Retrieved 2026-11-08T02:11:12.213515+00:00; SHA256 6e1ae7e7de2ea8af72509dfd6b6f1bad0c859c569cbda4c1ad6a658ad198babe
- population_education_ages: demo_pjanind
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_pjanind?lang=en&freq=A&time=2023
  Retrieved 2026-11-08T02:11:11.307653+00:00; SHA256 87a75d72ebf42beebfa744e5892dc438688ebdc8ab8914ce1abe9540c8d2855c
- population_education_deaths_age: demo_magec
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/demo_magec?lang=en&freq=A&sex=T&unit=NR&time=2023
  Retrieved 2026-11-08T02:11:11.840870+00:00; SHA256 ac5e0dbe63de719fe9d25dd38c4caa77503a69a3c997265e3206cbe9378f22ab
- population_education_public_education: gov_10a_exp
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10a_exp?lang=en&freq=A&unit=PC_GDP&sector=S13&cofog99=GF09&na_item=TE&time=2023
  Retrieved 2026-11-08T02:11:11.084415+00:00; SHA256 db2f87e3d8ac362816d6eefc6ab4c09d586e5d68935a1e44aa5678165be5c749
- population_education_household_education_2018: nama_10_cp18
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_cp18?lang=en&freq=A&unit=PC_GDP&coicop18=CP10&time=2023
  Retrieved 2026-11-08T02:12:18.491638+00:00; SHA256 e52cf268bac9877d351c57f3d73cb55cedde22a4a848524980bb47f362f69f90
- population_education_attainment: edat_lfse_03
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/edat_lfse_03?lang=en&freq=A&sex=T&age=Y25-64&isced11=ED5-8&unit=PC&time=2023
  Retrieved 2026-11-08T02:11:12.291635+00:00; SHA256 7b1cdb9b7c6a8b41d6f2243ff0bf030855b8aa21fae2119c518d807a3826dcc9
- population_education_human_capital: PWT 11.0, Data sheet, hc and emp, 2023
  https://www.rug.nl/ggdc/productivity/pwt/
  Retrieved 2026-11-03; SHA256 7b337e94f39dfe304bc459e433f8ce0624496c812707ae0c924888f5142b3ab3
- population_education_housing_services: nama_10_cp18 CP041/CP042
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_cp18?lang=en&freq=A&unit=PC_GDP&coicop18=CP041&coicop18=CP042&time=2023
  Retrieved 2026-11-08T02:15:24.855522+00:00; SHA256 6884893e737d68317baf6f20b510d1923571e934ff655d7534e47ee4d479e036
- population_education_owner_occupancy: ilc_lvho02 OWN
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/ilc_lvho02?lang=en&freq=A&unit=PC&rskpovth=TOTAL&hhcomp=TOTAL&time=2023
  Retrieved 2026-11-08T02:12:02.739479+00:00; SHA256 ec0823a4fcf377ed26796be548bf111ec7f9ceffa8f96d1e448b956f3b8328b8
- housing_pension_oldage: housing_pension_oldage
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10a_exp?lang=en&time=2023&unit=PC_GDP&cofog99=GF1002&sector=S13&na_item=D62
  Retrieved 2026-11-08T02:09:15.170230+00:00; SHA256 bbd5d8fc5d2fb722a393c0b69c77c0f743d42a783268d43c330506c6e47a28ba
- housing_pension_dwellings: housing_pension_dwellings
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_nfa_bs?lang=en&time=2023&sector=S14_S15&unit=CP_MEUR
  Retrieved 2026-11-08T02:09:16.727663+00:00; SHA256 7f444e6c62fce0216b5e063c3d412bd55def604e754e7afcb9ac9efeaed4a3f7
- housing_pension_gdp: housing_pension_gdp
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&time=2023&unit=CP_MEUR&na_item=B1GQ
  Retrieved 2026-11-08T02:10:10.867665+00:00; SHA256 70ad239a3dbebac8525e6b95f997902ba8128dae7755f70957f3c75fc061ccb2
- housing_pension_gdp2021: housing_pension_gdp2021
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&time=2021&unit=CP_MEUR&na_item=B1GQ
  Retrieved 2026-11-08T02:12:02.875571+00:00; SHA256 e691b648131256a3264077661e42dc62b31c7e52bd1a74f538eeeb7f178e02be
- housing_pension_construction: housing_pension_construction
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_an6?lang=en&time=2023&unit=PC_GDP&asset10=N111G&asset10=N11G
  Retrieved 2026-11-08T02:16:17.943567+00:00; SHA256 6d00a2acd646980b84bb3dee6f4ea6e4f0c56fb25c8e9a77a74ad42793b46494
- housing_pension_ownership: housing_pension_ownership
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/ilc_lvho02?lang=en&time=2023&unit=PC&hhcomp=TOTAL&rskpovth=TOTAL
  Retrieved 2026-11-08T02:12:02.739479+00:00; SHA256 ec0823a4fcf377ed26796be548bf111ec7f9ceffa8f96d1e448b956f3b8328b8
- housing_pension_private: housing_pension_private
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_pens1?lang=en&time=2021&unit=MIO_EUR&penscheme=S12P&penscheme=S12PC&penscheme=S12PB
  Retrieved 2026-11-08T02:12:02.763474+00:00; SHA256 96db394b2953879d3dd0533b71ea3119d9215e59e1c59d1ffc02cba066b05d09
- housing_pension_funds: housing_pension_funds
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nasa_10_f_bs?lang=en&time=2023&unit=PC_GDP&co_nco=NCO&sector=S129&finpos=ASS&na_item=F
  Retrieved 2026-11-08T02:10:58.359519+00:00; SHA256 06ab62db6d39042b62fdf50f34cc8fda8a68e3dfe53ac8190f67cfee031d6fa7
- housing_pension_mortgages: housing_pension_mortgages
  https://data-api.ecb.europa.eu/service/data/BSI/M..N.A.A22.A.1.U6.2250.Z01.E?startPeriod=2023-12&endPeriod=2023-12&format=csvdata
  Retrieved 2026-11-08T02:09:13.744692+00:00; SHA256 5b7b500097d6063bff62c64292733f4055e45c2aeb9fdefe18d1b217f4a834fb
- housing_pension_newrate: housing_pension_newrate
  https://data-api.ecb.europa.eu/service/data/MIR/M..B.A2C.A.R.A.2250.EUR.N?startPeriod=2023-01&endPeriod=2023-12&format=csvdata
  Retrieved 2026-11-08T02:13:35.775472+00:00; SHA256 a857bf67a94b53b88d187a7a452ab8e51c95be89541550db8ad6d6fa2ec86615
- housing_pension_stockrate: housing_pension_stockrate
  https://data-api.ecb.europa.eu/service/data/MIR/M..B.A22.A.R.A.2250.EUR.O?startPeriod=2023-01&endPeriod=2023-12&format=csvdata
  Retrieved 2026-11-08T02:13:35.743308+00:00; SHA256 3bc83976ba080b5c2a289eb3698db1f38ff3eb4545ed64cbe035badd569b0876
- housing_pension_estonia: housing_pension_estonia
  https://www.fi.ee/sites/default/files/fi_eft_1_2024_eng.pdf
  Retrieved 2026-11-08T02:19:15.980210+00:00; SHA256 f5f0382e416b0be143d24ff2fb92a8b229f5bd07a92babe79266ef2bc1504f3e
- oecd_eo117_efflabs_gdp.csv: OECD EO117 long-term scenarios
  https://sdmx.oecd.org/public/rest/v1/data/OECD.ECO.MAD,DSD_EO_LTB@DF_EO_LTB,1.0/.EFFLABS+GDPVTRD..A?startPeriod=2023&endPeriod=2100&format=csvfile
  Retrieved 2026-11-08T12:44:02.103312+00:00; SHA256 d4d182de404604d1571a3ba3e6d0a802226968841c8a5752e6f480f866334af5
- oecd_eo117_structure.xml: OECD EO117 long-term scenarios
  https://sdmx.oecd.org/public/rest/v1/dataflow/OECD.ECO.MAD/DSD_EO_LTB@DF_EO_LTB/1.0?references=all
  Retrieved 2026-11-08T12:44:02.103312+00:00; SHA256 1dfe9f22cf47a9135f025db03d8425bb44677cadf9910e2fb241233a4534d412
- employment_2023.json: Eurostat lfsi_emp_a
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lfsi_emp_a?lang=en&freq=A&age=Y15-64&sex=T&time=2023
  Retrieved 2026-11-12; SHA256 c9b65439e78c42fa44a290eeb90ff9336f0a9941425428a2e9782efb31c6c634
- transition_2023.json: Eurostat lfsi_long_a
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lfsi_long_a?lang=en&freq=A&sex=T&time=2023
  Retrieved 2026-11-12; SHA256 2a66bc86ed94ad619bdcb4f7033a5b517ea87c016e39fbeb3c18b704dfd3976e
- social_spending_gov_exp_2023: gov_exp_2023
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10a_exp?lang=en&freq=A&unit=PC_GDP&sector=S13&time=2023
  Retrieved 2026-11-12T18:37:14.719536+00:00; SHA256 3a0531ca8159cfeac91cd9bddea12b09cd1fd7a749fa1e9cdc757bb29dc1a4d4
- social_spending_gov_main_2023: gov_main_2023
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10a_main?lang=en&freq=A&unit=PC_GDP&sector=S13&time=2023
  Retrieved 2026-11-12T18:37:14.719536+00:00; SHA256 8aaff63292afe6c5dfff082f10ed85ee9729d99f3e8c2841923f166a4d06c009
- social_spending_pensions_all_schemes_2023: pensions_all_schemes_2023
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/spr_exp_pens?lang=en&freq=A&unit=PC_GDP&time=2023
  Retrieved 2026-11-12T18:37:14.719536+00:00; SHA256 71b1e42373ddbc14b6ab1e7c4836824f78c81d32eb5d34537a06e48db315ea37

PWT 11.0: CC BY 4.0; Feenstra, Inklaar and Timmer (2015), The Next Generation of the Penn World Table, AER 105(10), 3150–3182. Eurostat, ECB and BIS sources acknowledged.

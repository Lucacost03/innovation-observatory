# OECD long-term productivity projection candidate

Retrieved 8 November 2026 from official OECD endpoints. Data Explorer identifies the vintage as **OECD Economic Outlook 117 long-term scenarios** (2025 update), last updated 6 January 2026. These are conditional scenarios, not observed future facts or guaranteed predictions.

## Reproducible source files

`candidate_manifest.json` records exact URLs, bytes and SHA-256 for the primary metadata, annual CSV and method pages. The working endpoint includes `/public/rest/v1/`. The API request selects EFFLABS and GDPVTRD, all published areas, all six scenarios, annual 2023–2100. `oecd_candidate_extraction.json` parses the raw series, code labels and selected transformations. `extract_candidate.py` recreates the extraction from the downloaded CSV/XML and fetches the method pages.

The CSV contains 59,904 observations: 64 area codes × 6 scenarios × 78 years × 2 measures. The 64 codes include 49 individual countries and regional/group aggregates. The research paper's internal model covers 139 countries; this is **not** the public per-country series coverage.

## Productivity definition

The published measure EFFLABS is **trend labour efficiency**, with source unit `XDC_SAL`, multiplier 0. Do not average its absolute national-currency levels across countries. Within-country ratios can be used.

Box 1 of the official 2025 method uses:

Y = (EFFLABS × L)^α K^(1−α), with α = 0.67 in every country.

Consequently its implied Hicks-neutral productivity multiplier is:

A(t) / A(2023) = [EFFLABS(t) / EFFLABS(2023)]^0.67.

This is an accounting transformation of OECD labour efficiency, **not a directly published PWT-comparable TFP forecast**. OECD efficiency is a residual using employment headcounts, while PWT ctfp adjusts labour separately for human capital. Attaching OECD efficiency-derived growth to the existing PWT opening ctfp level is a cross-source model proxy. It must retain that label. It must not be confused with GDP growth or GDP per worker.

The efficiency projection uses an estimated 1996–2023 mixed-convergence model with rule of law, economic globalisation and macro stability proxies, plus assumed global technical progress, decaying momentum and scenario-specific climate damages/carbon-mitigation costs. Thus empirical estimation informs the path, while key future assumptions remain.

## Six scenarios

- BAU1: business-as-usual transition, median climate damage, no mitigation cost.
- BAU2: business-as-usual transition, high climate damage, no mitigation cost.
- ET1: accelerated transition, median damage, slow mitigation-cost reduction.
- ET2: accelerated transition, median damage, fast mitigation-cost reduction.
- ET3: accelerated transition, high damage, slow mitigation-cost reduction.
- ET4: accelerated transition, high damage, fast mitigation-cost reduction.

Exact source names are preserved in the extracted JSON, including the source's duplicated word in the BAU1 label.

## Rest of world

47 countries overlap the existing 118-country PWT rest-of-world pool, representing **74.98577409185644%** of that pool's fixed 2023 PPP output. This excludes USA and China. A fixed-weight mean of the covered countries' PWT opening ctfp levels grown with their own OECD-derived multipliers can produce a changing covered-country index. Renormalising its first value to one before applying it to the old full-pool level preserves the opening anchor but explicitly assumes that the covered sample's evolution proxies the unobserved countries. Label it a **covered-country rest-of-world projection proxy**. Do not present the 47-country projection as complete world coverage or substitute an overlapping OECD/world aggregate into the same weighted sum.

## Limits for implementation and validation

- Annual path variation and alternative scenarios are supported by the source. Stochastic revisions or domestic feedback into these external projections would be additional assumptions.
- The source ends at 2100. Any continuation past 2100 needs a visible extrapolation convention.
- A 2025 scenario vintage updated in 2026 was unavailable in 2023. Applying it to an economy opening in 2023 is a retrospective scenario, not leakage-safe historical forecasting. Existing 2025 backtests should keep the forecast option disabled, or be explicitly relabeled; no forecasting accuracy improvement follows from adding the source.
- Source levels are rounded more heavily in far-future years, so small annual differences can reflect published rounding.

Primary method: https://www.oecd.org/en/publications/oecd-global-long-run-economic-scenarios_00353678-en/full-report/component-4.html

Primary estimation annex: https://www.oecd.org/en/publications/oecd-global-long-run-economic-scenarios_00353678-en/full-report/component-8.html

Dataset: https://data-explorer.oecd.org/vis?df%5Bag%5D=OECD.ECO.MAD&df%5Bds%5D=dsDisseminateFinalDMZ&df%5Bid%5D=DSD_EO_LTB%40DF_EO_LTB

from pathlib import Path
import csv,json,hashlib,datetime,xml.etree.ElementTree as ET,urllib.request
p=Path(__file__).resolve().parent
ns={'s':'http://www.sdmx.org/resources/sdmxml/schemas/v2_1/structure','c':'http://www.sdmx.org/resources/sdmxml/schemas/v2_1/common'}
root=ET.parse(p/'oecd_eo117_structure.xml').getroot()
labels={}
for cl in root.findall('.//s:Codelist',ns):
 if cl.attrib.get('id')=='CL_SCENARIO':
  for code in cl.findall('s:Code',ns):
   labels[code.attrib['id']]=next(n.text for n in code.findall('c:Name',ns)if n.attrib.get('{http://www.w3.org/XML/1998/namespace}lang')=='en')
rs=list(csv.DictReader((p/'oecd_eo117_efflabs_gdp.csv').open()))
raw={}
for r in rs:
 raw.setdefault(r['REF_AREA'],{}).setdefault(r['SCENARIO'],{}).setdefault(r['MEASURE'],{})[r['TIME_PERIOD']]=float(r['OBS_VALUE'])
w=list(csv.DictReader(open(p.parents[1]/'dist/data/pwt_rest_of_world_weights.csv')))
matched=[r for r in w if r['countrycode'] in raw]
cov=sum(float(r['weight'])for r in matched)
print('All area codes',len(raw),'matched ROW countries',len(matched),'share of existing ROW output',cov)
print('matched',','.join(r['countrycode']for r in matched))
alpha=.67
summary={}
for area in ['USA','CHN']:
 summary[area]={}
 for sc in labels:
  z=raw[area][sc]['EFFLABS'];a0=z['2023'];summary[area][sc]={str(y):(z[str(y)]/a0)**alpha for y in [2023,2025,2030,2050,2100]}
(p/'oecd_candidate_extraction.json').write_text(json.dumps({'source':'OECD EO117 long-term scenarios (2025 update)','updatedSource':'Data Explorer reports last update 2026-01-06','retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scenarioLabels':labels,'labourShare':alpha,'tfpGrowthTransformation':'(EFFLABS[t]/EFFLABS[2023])**0.67; this derives Hicks-neutral productivity under OECD fixed-share production, not a published PWT-comparable TFP forecast','baseYear':2023,'lastYear':2100,'units':{'EFFLABS':'XDC_SAL, unit multiplier 0; labour efficiency level in national currency-based units; use ratios within a country only','GDPVTRD':'USD_PPP,unit multiplier 0; potential output at fixed2021 PPP'},'rowOverlap':{'countries':len(matched),'shareOfExistingCoveredPwtRowOutput':cov,'codes':[r['countrycode']for r in matched]},'selectedTFPMultipliers':summary,'rawLevels':raw},separators=(',',':'))+'\n')
urls={
'oecd_eo117_structure.xml':'https://sdmx.oecd.org/public/rest/v1/dataflow/OECD.ECO.MAD/DSD_EO_LTB@DF_EO_LTB/1.0?references=all',
'oecd_eo117_efflabs_gdp.csv':'https://sdmx.oecd.org/public/rest/v1/data/OECD.ECO.MAD,DSD_EO_LTB@DF_EO_LTB,1.0/.EFFLABS+GDPVTRD..A?startPeriod=2023&endPeriod=2100&format=csvfile',
'page_response.txt':'https://www.oecd.org/en/topics/sub-issues/economic-outlook/long-run-economic-scenarios-2025-update.html',
'data_response.txt':'https://sdmx.oecd.org/public/rest/v1/data/OECD.ECO.MAD,DSD_EO_LTB@DF_EO_LTB,1.0/USA.EFFLABS..A?startPeriod=2023&endPeriod=2100&format=csvfile'
}
for name,slug in [('oecd_2025_methods.html','component-4.html'),('oecd_2025_annex_b.html','component-8.html')]:
 url='https://www.oecd.org/en/publications/oecd-global-long-run-economic-scenarios_00353678-en/full-report/'+slug
 b=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=30).read();(p/name).write_bytes(b);urls[name]=url
manifest={name:{'url':url,'sha256':hashlib.sha256((p/name).read_bytes()).hexdigest(),'bytes':(p/name).stat().st_size}for name,url in urls.items()}
(p/'candidate_manifest.json').write_text(json.dumps({'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':manifest},indent=2)+'\n')
print(json.dumps(summary,indent=2))

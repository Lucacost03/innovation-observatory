"""Extract verified age-specific labour-force participation without changing presets.

Source rates define a curve shape. A model preserving its existing opening
aggregate must calibrate this shape to its own annual/single-year cohort weights;
that calibrated curve is a modelling proxy, not another survey observation.
"""
from pathlib import Path
import csv,hashlib,io,json,math
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
DEMOGRAPHY=ROOT.parent/'demography_1_26'
profiles=json.loads((REPO/'research/frozen_engine_v1_28/profiles.json').read_text())
manifest=json.loads((ROOT/'manifest.json').read_text())
entry=next(x for x in manifest if x['file']=='lfsa_argan_agebands_2023.json')
rawbytes=(ROOT/entry['file']).read_bytes()
assert hashlib.sha256(rawbytes).hexdigest()==entry['sha256']
raw=json.loads(rawbytes)
geo_by_code=dict(AUT='AT',BEL='BE',BGR='BG',HRV='HR',CYP='CY',CZE='CZ',DNK='DK',EST='EE',FIN='FI',FRA='FR',DEU='DE',GRC='EL',HUN='HU',IRL='IE',ITA='IT',LVA='LV',LTU='LT',LUX='LU',MLT='MT',NLD='NL',POL='PL',PRT='PT',ROU='RO',SVK='SK',SVN='SI',ESP='ES',SWE='SE',EU27='EU27_2020')
bands=[('Y15-24',15,25),('Y25-54',25,55),('Y55-64',55,65),('Y_GE65',65,101)]
source_page='https://ec.europa.eu/eurostat/databrowser/view/lfsa_argan/default/table?lang=en'
def eurostat(geo,age):
 sel=dict(freq='A',unit='PC',sex='T',age=age,citizen='TOTAL',geo=geo,time='2023');index=0
 for d,size in zip(raw['id'],raw['size']):index=index*size+raw['dimension'][d]['category']['index'][sel[d]]
 value=raw['value'].get(str(index));flag=raw.get('status',{}).get(str(index))
 assert value is not None and math.isfinite(value) and 0<=value<=100,(geo,age,value)
 return {'rate':value,'sourceFlag':flag,'rawIndex':index,'coordinates':sel}
countries={}
ilo_manifest=json.loads((DEMOGRAPHY/'ilo_participation_manifest.json').read_text())
for p in profiles:
 code=p['code'];c={'name':p['name'],'poolId':p['params']['foreignPoolId'],'sourceYear':2023,'openingModelParticipation':p['params']['initialParticipationRate'],'openingModelAgeScope':p.get('labourAge','15–64'),'bands':[]}
 if code in geo_by_code:
  geo=geo_by_code[code]
  for band,low,high in bands:
   o=eurostat(geo,band);c['bands'].append({'minAge':low,'maxAgeExclusive':high,'sourceAgeBand':band,**o})
  c.update({'sourceAggregate15to64':eurostat(geo,'Y15-64'),'sourceProvider':'Eurostat EU Labour Force Survey','sourceURL':source_page,'downloadURL':entry['url'],'rawFile':'research/participation_1_29/'+entry['file'],'rawSHA256':entry['sha256'],'rawSourceUpdated':raw['updated'],'sourceStatus':'Survey estimates, total sex and all citizenship; source quality flags retained.'})
 else:
  source=next(x for x in ilo_manifest if x['file']==f'ilo_{code}_participation_2023.csv')
  b=(DEMOGRAPHY/source['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==source['sha256']
  rows=list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))
  def ilo(classif):
   chosen=[x for x in rows if x['ref_area']==code and x['sex']=='SEX_T'and x['time']=='2023'and x['classif1']==classif]
   assert len(chosen)==1,(code,classif,len(chosen))
   o=chosen[0];v=float(o['obs_value']);assert 0<=v<=100 and math.isfinite(v)
   return {'rate':v,'sourceFlag':o['obs_status']or None,'coordinates':o}
  for band,low,high in bands:
   iband='AGE_AGGREGATE_'+('YGE65'if band=='Y_GE65'else band)
   c['bands'].append({'minAge':low,'maxAgeExclusive':high,'sourceAgeBand':iband,**ilo(iband)})
  c.update({'sourceAggregate15to64':ilo('AGE_YTHADULT_Y15-64'),'sourceProvider':'ILOSTAT published provider estimates','sourceURL':source['url'],'rawFile':'research/demography_1_26/'+source['file'],'rawSHA256':source['sha256'],'rawSourceRetrievedAt':source['retrievedAt'],'sourceStatus':'Published provider estimates, not treated as direct national survey observations; exact source codes and flags retained without inferring their meaning from precision.'})
  assert len({x['coordinates']['source']for x in c['bands']})==1
  c['sourceCode']=c['bands'][0]['coordinates']['source']
 c['openingAggregateMinusSource15to64']=c['openingModelParticipation']-c['sourceAggregate15to64']['rate']
 c['configuredPostRetirementRelativePercent']=p['params']['postRetirementParticipation']
 c['impliedOpeningOlderParticipation']=c['openingModelParticipation']*c['configuredPostRetirementRelativePercent']/100
 c['impliedOpeningOlderMinusSource65plus']=c['impliedOpeningOlderParticipation']-c['bands'][-1]['rate']
 c['calibrationCaveat']='The source annual survey/provider population and model opening age-cohort population differ. Preserve the chosen opening aggregate by recalibrating the age-rate curve, with all adjusted rates bounded0–100%. Future fixed age-specific rates reweighted by ageing cohorts are an explicit composition-only scenario; no future behavioural trend or reform elasticity is estimated.'
 if code=='CHN':c['calibrationCaveat']+=' China retains an opening15+ national proxy applied to model15–64cohorts; the calibrated curve is not observed Chinese15–64participation. Source ILO15–64and15+ denominators must not be conflated.'
 countries[code]=c
assert len(countries)==30
result={'openingYear':2023,'countries':countries,'definition':'Labour force participation = employed plus unemployed people divided by population of the same age, ×100. Rates are percentages, not fractions. Age intervals use an exclusive upper bound. Older age101 is the numerical model terminal boundary, not a survey maximum age.','method':'Use country-specific15–24,25–54,55–64rates as a three-step age curve. The initial aggregate is calibrated separately to the model opening aggregate. As single-year cohorts age/migrate, aggregate15–64participation changes even when within-band rates stay fixed. Age65+ source rates are retained for older-work calibration and independent checks; they are not compulsory pension exit rates.','eurostatSourceFlagDefinitions':raw.get('extension',{}).get('status',{}).get('label',{}),'limitations':['Source rates do not estimate future participation, business-cycle responses, schooling-policy effects or pension-reform elasticities.','Within each band all ages share one rate. The age-band pattern is empirical; its fixed future continuation and any within-band interpolation are assumptions.','Eurostat annual estimates use total sex and citizenship; USA/China estimates use ILO published provider definitions, which are not perfectly identical national survey scopes.','2023 observations were retrieved in2026 and may be revised. This is not a real-time2023forecast vintage.','Any adjustment preserving the pre-existing opening aggregate is a model-calibration transformation; adjusted individual age rates must be labelled as proxies.','China opening aggregate remains a15+scope proxy, unlike the model age15–64denominator; both original and ILO source rates are retained explicitly.']}
(ROOT/'participation_age_rates_2023.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
validation={'status':'PASS','profiles':len(countries),'disjointBandsPerProfile':4,'coveredWorkingAgeProfiles':sum(len(x['bands'])==4 for x in countries.values()),'missingValues':[],'eurostatSurveyProfiles':len(geo_by_code),'ILOProviderProfiles':['USA','CHN'],'sourceFlaggedBands':{c:{x['sourceAgeBand']:x['sourceFlag']for x in v['bands']if x['sourceFlag']}for c,v in countries.items()if any(x['sourceFlag']for x in v['bands'])},'sourceRatesExample':{c:{x['sourceAgeBand']:x['rate']for x in countries[c]['bands']}for c in ['EU27','ITA','USA','CHN']},'openingOlderAgreement':{c:{'configuredRelativePercent':v['configuredPostRetirementRelativePercent'],'impliedOpeningOlderRate':v['impliedOpeningOlderParticipation'],'rawSourceOlderRate':v['bands'][-1]['rate'],'differencePercentagePoints':v['impliedOpeningOlderMinusSource65plus']}for c,v in countries.items()},'allRatesBetween0and100':all(0<=b['rate']<=100 for c in countries.values()for b in c['bands'])}
(ROOT/'validation.json').write_text(json.dumps(validation,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(validation,ensure_ascii=False))

// National PWT levels anchor a proxy. A representative foreign leader and its
// premium are synthetic; no observed national firm frontier is claimed.
export const FOREIGN_PROVIDERS = [
  {code: 'USA', name: 'United States', relative: 'usTechnology', growth: 'usGrowth'},
  {code: 'CHN', name: 'China', relative: 'chinaTechnology', growth: 'chinaGrowth'},
  {code: 'KOR', name: 'South Korea', relative: 'koreaTechnology', growth: 'koreaGrowth'}
];
export function initializeForeign(p) {
  return Object.fromEntries(FOREIGN_PROVIDERS.map(s => [s.code,
    p.initialTechnology * p[s.relative] * p.foreignLeaderPremium]));
}
export function learnForeign(a, lagged, p, seed, time, id, draw) {
  if (!p.foreignContact || !p.foreignAdoption || draw(seed, time, id, 500) >= p.foreignContact)
    return {a, gain: 0, source: null, target: 0};
  const provider = FOREIGN_PROVIDERS[Math.min(2, Math.floor(draw(seed, time, id, 501) * 3))];
  const target = lagged[provider.code];
  const rate = Math.max(0, Math.min(1, p.foreignAdoption * p.absorptiveCapacity * p.humanCapital));
  const gain = rate * Math.max(0, target - a);
  return {a: a + gain, gain, source: gain > 0 ? provider.code : null, target};
}

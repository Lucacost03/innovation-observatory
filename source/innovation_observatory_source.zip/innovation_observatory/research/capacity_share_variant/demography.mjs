// Synthetic enterprise turnover. Aggregate demography rates are proxy targets;
// selection, liquidation, startup size and financing rules remain assumptions.
const sum = xs => xs.reduce((a, b) => a + b, 0);
const MIN_FIRMS = 2;
export const ENTRY_SLOTS = 360;

export function exitHazards(firms, p) {
  if (!p.firmDynamics || !firms.length) return firms.map(() => 0);
  const mean = sum(firms.map(f => f.a)) / firms.length;
  const scores = firms.map(f => Math.exp(Math.min(20,
    p.exitSelection * Math.max(0, Math.log(mean / Math.max(f.a, 1e-12))) +
    p.exitDistress * Math.min(2, (f.arrears || 0) / p.defaultAfter))));
  const target = p.exitRate / 100;
  if (!target) return scores.map(() => 0);
  // Match the mean nonfinancial hazard, rather than accidentally increasing
  // the aggregate target when productivity dispersion changes.
  let lo = 0, hi = 1;
  for (let k = 0; k < 55; k++) {
    const mid = (lo + hi) / 2;
    if (sum(scores.map(s => -Math.expm1(-mid * s))) / firms.length < target) lo = mid;
    else hi = mid;
  }
  return scores.map(s => -Math.expm1(-(lo + hi) / 2 * s));
}

function ownerTransfer(e, amount) {
  // Liquidation and returned startup equity are capital transactions, not a
  // second household income flow.
  for (const h of e.households) h.cash += amount * h.ownership;
}

function estateReceipt(e, estate, amount, stats) {
  const recovery = Math.min(estate.claim, amount);
  estate.claim -= recovery;
  e.bank.equity += recovery;
  stats.loanRecoveries += recovery;
  ownerTransfer(e, amount - recovery);
}

function buyEstateCapital(e, buyer, target, p, stats) {
  let purchased = 0;
  for (const estate of e.estates) {
    const quantity = Math.min(estate.capital, target - purchased, buyer.cash / p.liquidationPrice);
    if (quantity <= 0) continue;
    const price = quantity * p.liquidationPrice;
    estate.capital -= quantity; buyer.capital += quantity; buyer.cash -= price;
    purchased += quantity; stats.capitalTransfers += quantity;
    estateReceipt(e, estate, price, stats);
    if (purchased >= target - 1e-12) break;
  }
  return purchased;
}

function auctionEstates(e, p, stats) {
  const bidders = e.firms;
  for (const estate of e.estates) {
    const book = estate.capital + estate.inventory;
    if (book <= 1e-12) continue;
    const bids = bidders.map(f => Math.max(0, f.cash - p.liquidityBuffer / 100 * f.sales) * p.liquidationBidShare);
    const available = sum(bids), payment = Math.min(available, p.liquidationPrice * book);
    if (payment <= 1e-12) continue;
    const fraction = payment / (p.liquidationPrice * book);
    const soldCapital = estate.capital * fraction, soldInventory = estate.inventory * fraction;
    bidders.forEach((f, i) => {
      const share = bids[i] / available;
      f.cash -= payment * share;
      f.capital += soldCapital * share;
      f.inventory += soldInventory * share;
    });
    estate.capital -= soldCapital; estate.inventory -= soldInventory;
    stats.capitalTransfers += soldCapital; stats.inventoryTransfers += soldInventory;
    estateReceipt(e, estate, payment, stats);
  }
}

export function transition(e, p, noiseTime, t, draw) {
  const stats = {entries: 0, exits: 0, entryAttempts: 0, unfundedEntries: 0,
    floorBlockedExits: 0, capBlockedEntries: 0, loanWriteoffs: 0, loanRecoveries: 0,
    capitalTransfers: 0, inventoryTransfers: 0, startupFunding: 0,
    exitsEmployment: 0, events: []};
  if (!p.firmDynamics) return stats;
  const opening = e.firms, n = opening.length;
  const oldLinks = new Map(opening.map((f, i) => [f.id, e.links[i].map(j => opening[j].id)]));
  const hazards = exitHazards(opening.map(f => ({...f, a: f.openingTechnology})), p);
  const candidates = opening.filter((f, i) => {
    f.exitProbability = f.forcedExit ? 1 : hazards[i];
    return f.forcedExit || draw(e.seed, noiseTime, f.id, 400) < hazards[i];
  }).sort((a, b) => Number(b.forcedExit) - Number(a.forcedExit) ||
    b.exitProbability - a.exitProbability || a.id - b.id);
  const selected = new Set(candidates.slice(0, Math.max(0, n - MIN_FIRMS)).map(f => f.id));
  stats.floorBlockedExits = candidates.length - selected.size;
  for (const f of opening) {
    if (!selected.has(f.id)) {
      if (f.forcedExit) {
        // Explicit numerical floor: a blocked failed firm is restructured.
        const repayment = Math.min(f.cash, f.loan);
        f.cash -= repayment; f.loan -= repayment;
        stats.loanWriteoffs += f.loan; e.bank.equity -= f.loan;
        f.loan = 0; f.arrears = 0; f.restructured++;
      }
      continue;
    }
    const repayment = Math.min(f.cash, f.loan);
    f.cash -= repayment; f.loan -= repayment;
    const loss = f.loan;
    e.bank.equity -= loss; stats.loanWriteoffs += loss;
    ownerTransfer(e, f.cash);
    e.estates.push({id: f.id, exitTime: t, capital: f.capital, inventory: f.inventory, claim: loss});
    stats.exits++; stats.exitsEmployment += f.employment;
    stats.events.push({type: 'exit', id: f.id, t, a: f.a, openingTechnology: f.openingTechnology,
      probability: f.exitProbability, financialDefault: !!f.forcedExit, loanWriteoff: loss});
  }
  e.firms = opening.filter(f => !selected.has(f.id));
  // Unsold physical assets remain explicitly dormant. An auction transfers
  // funded cash and existing assets; no fire-sale transfer enters GDP or GFCF.
  auctionEstates(e, p, stats);
  const incumbents = e.firms.slice();
  const totalCapital = sum(incumbents.map(f => f.capital)) + sum(e.estates.map(s => s.capital));
  const startupCapital = Math.max(1e-9, totalCapital / n * p.entrantSize);
  const startupCash = startupCapital * p.startupLiquidity;
  let equityBudget = sum(e.households.map(h => h.cash)) * p.entryFinanceShare / 100;
  const donorCapacity = new Map(incumbents.map(f => [f.id, f.capital * .2]));
  const cap = Math.max(p.firms, p.maxFirms);
  const probability = n * p.entryRate / 100 / ENTRY_SLOTS;
  for (let slot = 0; slot < ENTRY_SLOTS; slot++) {
    if (draw(e.seed, noiseTime, slot, 410) >= probability) continue;
    stats.entryAttempts++;
    if (e.firms.length >= cap) { stats.capBlockedEntries++; continue; }
    const availableCapital = sum(e.estates.map(s => s.capital)) + sum([...donorCapacity.values()]);
    const funds = startupCapital + startupCash;
    const householdCash = sum(e.households.map(h => h.cash));
    if (equityBudget < funds || householdCash < funds || availableCapital < startupCapital - 1e-10) {
      stats.unfundedEntries++; continue;
    }
    const id = p.firms + noiseTime * 512 + slot;
    const donor = incumbents[Math.min(incumbents.length - 1,
      Math.floor(draw(e.seed, noiseTime, slot, 411) * incumbents.length))];
    const a = donor.a * p.entrantTechnology;
    const f = {id, birthTime: t, initialWeight: 0, capital: 0, loan: 0, cash: funds,
      inventory: 0, a, employment: 0, hours: 1, util: p.initialUtilization / 100,
      share: 0, sales: 0, output: 0, marketGDP: 0,
      initialGDP: startupCapital / e.p.capitalOutputRatio, rd: 0, researchHours: 0,
      productionHours: 0, ownKnowledgeGain: 0, diffusionGain: 0, foreignGain: 0,
      learningGap: 0, arrears: 0, restructured: 0, innovation: false, grant: 0,
      openingTechnology: a, exitProbability: 0, foreignSource: null, foreignTarget: 0};
    e.households.forEach(h => { h.cash -= funds * h.cash / householdCash; });
    equityBudget -= funds; stats.startupFunding += funds;
    let bought = buyEstateCapital(e, f, startupCapital, p, stats);
    for (const seller of incumbents) {
      const quantity = Math.min(donorCapacity.get(seller.id), startupCapital - bought);
      if (quantity <= 0) continue;
      seller.capital -= quantity; seller.cash += quantity;
      f.capital += quantity; f.cash -= quantity;
      donorCapacity.set(seller.id, donorCapacity.get(seller.id) - quantity);
      bought += quantity; stats.capitalTransfers += quantity;
    }
    if (Math.abs(f.capital - startupCapital) > 1e-7 || f.cash < -1e-8) throw Error('Startup asset funding failed.');
    e.firms.push(f); stats.entries++;
    stats.events.push({type: 'entry', id, t, a, capital: f.capital, equityFunding: funds,
      copiedDomesticFirm: donor.id});
  }
  e.estates = e.estates.filter(s => s.capital + s.inventory > 1e-10);
  const shareTotal = sum(e.firms.map(f => f.share));
  const entryMass = stats.entries ? Math.min(.3, stats.entries * p.entrantSize / n) : 0;
  const newborn = new Set(stats.events.filter(s => s.type === 'entry').map(s => s.id));
  e.firms.forEach(f => {
    f.share = newborn.has(f.id) ? entryMass / stats.entries :
      (shareTotal > 0 ? f.share / shareTotal : 1 / incumbents.length) * (1 - entryMass);
  });
  const index = new Map(e.firms.map((f, i) => [f.id, i]));
  const degree = Math.min(p.networkDegree, e.firms.length - 1);
  e.links = e.firms.map(f => {
    const links = new Set((oldLinks.get(f.id) || []).filter(id => index.has(id) && id !== f.id).slice(0, degree));
    for (let j = 0; links.size < degree && j < e.firms.length * 2; j++) {
      const start = Math.floor(draw(e.seed, noiseTime, f.id, 450 + j) * e.firms.length);
      for (let k = 0; k < e.firms.length; k++) {
        const id = e.firms[(start + k) % e.firms.length].id;
        if (id !== f.id && !links.has(id)) { links.add(id); break; }
      }
    }
    return [...links].map(id => index.get(id));
  });
  e.totalEntries += stats.entries; e.totalExits += stats.exits;
  e.events.push(...stats.events);
  return stats;
}

import {PARAMETERS,DEFAULTS,METRICS,sanitize} from './parameters.mjs';
import {transition} from './demography.mjs';
import {FOREIGN_PROVIDERS,initializeForeign,learnForeign} from './foreign.mjs';
const sum=a=>a.reduce((s,x)=>s+x,0),clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export function uniform(seed,t,i,stream=0){let x=(seed^Math.imul(t+10007,0x9e3779b1)^Math.imul(i+17,0x85ebca6b)^Math.imul(stream+3,0xc2b2ae35))>>>0;x^=x>>>16;x=Math.imul(x,0x7feb352d);x^=x>>>15;x=Math.imul(x,0x846ca68b);x^=x>>>16;return((x>>>0)+.5)/4294967296;}
const normal=(s,t,i,k=0)=>Math.sqrt(-2*Math.log(uniform(s,t,i,k)))*Math.cos(2*Math.PI*uniform(s,t,i,k+1));
const weights=a=>{let z=sum(a);return a.map(x=>x/z);};
export function gini(values){let a=values.slice().sort((x,y)=>x-y),z=sum(a);return z<=1e-12?0:clamp(2*sum(a.map((x,i)=>(i+1)*x))/(a.length*z)-(a.length+1)/a.length,0,1);}
export function validateTimeline(paths=[]){if(!Array.isArray(paths)||paths.length>20)throw Error('Use up to 20 parameter paths.');return paths.map(x=>{const d=PARAMETERS.find(p=>p.key===x.key&&p.dynamic);if(!d)throw Error('Only behavioral parameters can change over time.');let start=Number(x.start),end=Number(x.end),target=Number(x.target);if(!Number.isInteger(start)||!Number.isInteger(end)||start<1||end<start||end>120||!Number.isFinite(target)||target<d.min||target>d.max||(d.integer&&!Number.isInteger(target))||!['step','ramp','pulse'].includes(x.mode))throw Error('Invalid parameter timeline for '+d.label);return{key:x.key,start,end,target,mode:x.mode};});}
export function validateShocks(shocks=[]){if(!Array.isArray(shocks)||shocks.length>20)throw Error('Use up to 20 shocks.');return shocks.map(x=>{let start=Number(x.start),duration=Number(x.duration),magnitude=Number(x.magnitude),recovery=Number(x.recovery??0);if(!['demand','supply','credit','government'].includes(x.type)||!Number.isInteger(start)||start<1||!Number.isInteger(duration)||duration<1||duration>120||!Number.isFinite(magnitude)||magnitude< -95||magnitude>100||!Number.isFinite(recovery)||recovery<0||recovery>1)throw Error('Invalid shock schedule.');return{type:x.type,start,duration,magnitude,recovery};});}
export function effectiveParameters(base,t,paths){let p={...base};for(const x of paths){if(t<x.start)continue;if(x.mode==='pulse'&&t>x.end)continue;let w=x.mode==='ramp'?clamp((t-x.start+1)/(x.end-x.start+1),0,1):1;p[x.key]+=w*(x.target-p[x.key]);}for(const d of PARAMETERS)if(d.integer)p[d.key]=Math.round(p[d.key]);return p;}
function shockValues(t,shocks){const a={demand:1,supply:1,credit:1,government:1};for(const s of shocks){if(t<s.start)continue;let dt=t-(s.start+s.duration-1),m=s.magnitude/100;if(dt>0)m*=s.recovery===0?0:Math.pow(s.recovery,dt);a[s.type]*=Math.max(.01,1+m);}return a;}
// The model is a closed representative economy. Source-year stocks are scales;
// decision laws and synthetic distributions are not identified causal estimates.
export function adoptKnowledge(knowledge,target,rate){return knowledge+clamp(rate,0,1)*Math.max(0,target-knowledge);}
export class Economy {
 constructor(raw,seed){
  this.p=sanitize(raw);const p=this.p;this.seed=seed;this.wage=p.laborShare/p.employmentRate;this.initialResearchPayroll=p.rdBusiness*p.rdLaborShare/100;
  this.gov={cash:p.governmentDeposit};this.bank={equity:p.bankEquity,bonds:p.initialPublicDebt*p.bankGovernmentShare/100,reserves:0};
  this.frontier=p.initialTechnology*p.frontierGap;this.foreign=initializeForeign(p);this.foreignHistory=[{...this.foreign}];this.estates=[];this.events=[];this.totalEntries=0;this.totalExits=0;this.lastOutput=100;this.lastTechnology=p.initialTechnology;
  const c=100-p.governmentShare-p.investmentShare;
  if(c<0)throw Error('Opening public consumption plus fixed investment exceeds initial GDP. Reduce those two shares.');
  this.initialConsumption=c;this.initialVAT=c-c/(1+p.consumptionTax/100);this.initialGoods=100-this.initialVAT;
  const cw=weights(Array.from({length:p.firms},(_,i)=>Math.exp(p.heterogeneity*normal(seed,-1,i,10))));
  const aa=Array.from({length:p.firms},(_,i)=>Math.exp(p.heterogeneity*normal(seed,-1,i,12))),avg=sum(aa.map((a,i)=>a*cw[i]));
  this.firms=cw.map((share,i)=>({id:i,birthTime:0,initialWeight:share,foreignGain:0,foreignSource:null,foreignTarget:0,exitProbability:0,capital:100*p.capitalOutputRatio*share,loan:100*p.capitalOutputRatio*share*p.initialLeverage,
   cash:p.firmLiquidity*share,inventory:p.inventoryTarget*share,a:p.initialTechnology*aa[i]/avg,employment:p.employmentRate*share,
   hours:1,util:p.initialUtilization/100,share,sales:(100-p.investmentShare-this.initialVAT)*share,
   output:this.initialGoods*share,marketGDP:100*share,initialGDP:100*share,rd:this.initialResearchPayroll*share,researchHours:this.initialResearchPayroll*share/this.wage,ownKnowledgeGain:0,diffusionGain:0,learningGap:0,
   arrears:0,restructured:0,innovation:false,grant:0}));
  const hw=weights(Array.from({length:p.households},(_,i)=>Math.exp(p.wealthInequality*normal(seed,-1,i,14))));
  this.households=hw.map((w,i)=>({id:i,cash:p.householdWealth*w,bonds:p.initialPublicDebt*(1-p.bankGovernmentShare/100)*w,income:p.initialIncome/p.households,ownership:w,employed:0}));
  // Existing loan stocks are matched against the observed deposits and equity.
  // They are not treated as a second initial cash endowment.
  this.bank.reserves=p.householdWealth+p.firmLiquidity+p.governmentDeposit+p.bankEquity-this.loans()-this.bank.bonds;
  if(this.bank.reserves< -1e-8)throw Error('Opening financial stocks are inconsistent: increase deposits/equity or reduce initial business loans and the bank share of public debt.');
  this.bank.reserves=Math.max(0,this.bank.reserves);this.endowment=this.bank.reserves;
  const initialProductionHours=Math.max(1e-6,p.employmentRate-this.initialResearchPayroll/this.wage);
  this.lp=this.initialGoods/initialProductionHours/p.initialTechnology;
  this.kp=this.initialGoods/(100*p.capitalOutputRatio*p.initialUtilization/100*p.initialTechnology);
  this.tfpScale=this.initialGoods/(Math.pow(100*p.capitalOutputRatio,p.tfpCapitalShare/100)*Math.pow(initialProductionHours,1-p.tfpCapitalShare/100));
  this.cohort=new Map(this.firms.map(f=>[f.id,{weight:f.initialWeight,a:f.a}]));
  this.techHistory=[new Map(this.firms.map(f=>[f.id,f.a]))];this.links=this.firms.map((f,i)=>{
   const set=new Set(),degree=Math.min(p.firms-1,p.networkDegree);
   for(let j=1;j<=degree;j++){let k=(i+(j%2?Math.ceil(j/2):-Math.ceil(j/2))+p.firms)%p.firms;
    if(uniform(seed,-2,i,j)<p.rewiring)k=Math.floor(uniform(seed,-3,i,j)*p.firms);
    let tries=0;while((k===i||set.has(k))&&tries++<p.firms)k=(k+1)%p.firms;if(k!==i)set.add(k);
   }return [...set];
  });this.check();
 }
 loans(){return sum(this.firms.map(f=>f.loan));}
 dormantCapital(){return sum(this.estates.map(e=>e.capital));}
 totalInventory(){return sum(this.firms.map(f=>f.inventory))+sum(this.estates.map(e=>e.inventory));}
 publicDebt(){return this.bank.bonds+sum(this.households.map(h=>h.bonds));}
 ensureGov(amount,p=this.p){
  const gap=Math.max(0,amount-this.gov.cash);if(!gap)return;
  const cash=sum(this.households.map(h=>h.cash)),target=gap*(1-p.bankGovernmentShare/100),householdPurchase=Math.min(cash,target);
  if(cash>0)for(const h of this.households){const buy=householdPurchase*h.cash/cash;h.cash-=buy;h.bonds+=buy;}
  this.gov.cash+=householdPurchase;const bankPurchase=gap-householdPurchase;this.bank.bonds+=bankPurchase;this.gov.cash+=bankPurchase;
 }
 payIncome(f,amount,p,allocation){
  const paid=Math.min(Math.max(0,amount),f.cash);f.cash-=paid;const tax=paid*p.incomeTax/100;this.gov.cash+=tax;
  this.households.forEach((h,i)=>{const x=(paid-tax)*allocation[i];h.cash+=x;h.income+=x;});return paid;
 }
 support(amount,p,shares=null){
  this.ensureGov(amount,p);this.gov.cash-=amount;this.households.forEach((h,i)=>{const x=amount*(shares?shares[i]:1/this.households.length);h.cash+=x;h.income+=x;});
 }
 check(realResidual=0,goodsOutput=1,marketResidual=0,gdp=1){
  const deposits=sum(this.households.map(h=>h.cash))+sum(this.firms.map(f=>f.cash))+this.gov.cash,loans=this.loans();
  const bankResidual=this.bank.reserves+loans+this.bank.bonds-deposits-this.bank.equity;
  const sectorResidual=sum(this.households.map(h=>h.cash+h.bonds))+sum(this.firms.map(f=>f.cash-f.loan))+this.gov.cash-this.publicDebt()+this.bank.equity-this.endowment;
  const scale=Math.max(1,Math.abs(deposits),loans,this.publicDebt(),Math.abs(this.bank.equity));
  if(new Set(this.firms.map(f=>f.id)).size!==this.firms.length)throw Error('Duplicate firm identity');
  for(const e of this.estates)for(const k of ['capital','inventory','claim'])if(!Number.isFinite(e[k])||e[k]<-1e-7)throw Error('Invalid liquidation estate');
  for(const f of this.firms)for(const k of ['cash','loan','capital','inventory','a','employment','hours','util'])if(!Number.isFinite(f[k])||f[k]< -1e-7)throw Error('Invalid firm '+k);
  for(const h of this.households)for(const k of ['cash','bonds'])if(!Number.isFinite(h[k])||h[k]< -1e-7)throw Error('Invalid household '+k);
  if(!Number.isFinite(this.bank.equity)||!Number.isFinite(this.gov.cash)||this.gov.cash< -1e-7)throw Error('Invalid financial stock');
  const relativeResidual=Math.max(Math.abs(bankResidual)/scale,Math.abs(sectorResidual)/scale,Math.abs(realResidual)/Math.max(1,goodsOutput),Math.abs(marketResidual)/Math.max(1,gdp));
  if(relativeResidual>1e-8)throw Error('Accounting reconciliation failed.');
  return{bankResidual,sectorResidual,realResidual,marketResidual,relativeResidual};
 }
 initialSnapshot(){
  const p=this.p;return {t:0,initialObservation:1,firmCount:this.firms.length,entries:0,exits:0,cumulativeEntries:0,cumulativeExits:0,entryAttempts:0,unfundedEntries:0,floorBlockedExits:0,capBlockedEntries:0,loanWriteoffs:0,loanRecoveries:0,startupFunding:0,capitalTransfers:0,inventoryTransfers:0,capitalResidual:0,dormantCapital:0,dormantInventory:0,foreignGain:0,foreignGainFixed:0,foreignAdopters:0,foreignUSA:0,foreignCHN:0,foreignKOR:0,exitsEmployment:0,output:100,goodsOutput:this.initialGoods,consumption:this.initialConsumption,consumptionGoods:this.initialConsumption/(1+p.consumptionTax/100),consumptionTax:this.initialVAT,
   government:p.governmentShare,investment:p.investmentShare,inventoryChange:0,knowledge:p.initialTechnology,ownKnowledgeGain:0,diffusionGain:0,learningGapFixed:0,inventory:sum(this.firms.map(f=>f.inventory)),technology:p.initialTechnology,productivity:1,
   employment:p.employmentRate,effectiveHours:p.employmentRate,productionHours:p.employmentRate-this.initialResearchPayroll/this.wage,researchHours:this.initialResearchPayroll/this.wage,
   utilization:p.initialUtilization,capital:100*p.capitalOutputRatio,loans:this.loans(),rd:this.initialResearchPayroll,rdNonLaborBenchmark:p.rdBusiness-this.initialResearchPayroll,publicResearch:p.publicResearch,publicRDGrants:p.publicResearch*p.publicGrantShare/100*p.rdLaborShare/100,
   publicResearchNonBusiness:p.publicResearch*(1-p.publicGrantShare/100),publicDebt:this.publicDebt(),bankPublicDebt:this.bank.bonds,householdPublicDebt:sum(this.households.map(h=>h.bonds)),
   bankEquity:this.bank.equity,householdDeposits:p.householdWealth,firmDeposits:p.firmLiquidity,governmentDeposits:p.governmentDeposit,wages:p.laborShare,
   gini:gini(this.households.map(h=>h.cash)),defaults:0,recap:0,technologyGrowth:0,loanInterest:0,governmentInterest:0,researchPayrollResidual:0,laborResidual:0,...this.check()};
 }
 step(noiseTime,t,paths=[],shocks=[]){
  const p=effectiveParameters(this.p,t,paths),shock=shockValues(t,shocks),fs=this.firms,hs=this.households,n=fs.length;
  const oldInventory=this.totalInventory(),oldTotalCapital=sum(fs.map(f=>f.capital))+this.dormantCapital(),openingBankBonds=this.bank.bonds,openingHouseholdBonds=hs.map(h=>h.bonds),previousTechnology=this.lastTechnology;
  for(const estate of this.estates)estate.capital*=1-p.depreciation/100;
  const plans=hs.map(h=>Math.max(0,shock.demand*(p.consumptionIncome*h.income+p.consumptionWealth*h.cash)));
  const cPlan=sum(plans)/(1+p.consumptionTax/100),rawG=p.governmentShare/100*this.lastOutput*shock.government;
  const gPlan=Math.max(p.fiscalFloor/100*rawG,rawG-p.fiscalAdjustment*Math.max(0,this.publicDebt()-p.debtTarget/100*this.lastOutput));
  hs.forEach(h=>{h.income=0;h.employed=0;});
  const degree=Math.min(n-1,p.networkDegree);
  for(let i=0;i<n;i++){const set=new Set(this.links[i].slice(0,degree));for(let j=0;j<degree;j++){const old=[...set][j];if(old===undefined||uniform(this.seed,noiseTime,fs[i].id,100+j)<p.networkEvolution){if(old!==undefined)set.delete(old);let k=Math.floor(uniform(this.seed,noiseTime,fs[i].id,140+j)*n),tries=0;while((k===i||set.has(k))&&tries++<n)k=(k+1)%n;if(k!==i)set.add(k);}}this.links[i]=[...set];}
  const desiredWeights=weights(fs.map(f=>(p.firmDynamics?Math.max(1e-12,f.capital):1)*Math.exp(clamp(p.marketSelection*Math.log(f.a),-30,30))));
  fs.forEach((f,i)=>{f.share=(1-p.shareAdjustment)*f.share+p.shareAdjustment*desiredWeights[i];f.innovation=false;f.oldInventory=f.inventory;f.oldCapital=f.capital;f.previousGDP=f.marketGDP;f.grant=0;f.openingTechnology=f.a;f.forcedExit=false;f.foreignGain=0;f.foreignSource=null;f.foreignTarget=0;});
  const desiredInvest=fs.map(f=>Math.max(0,p.investmentShare/100*f.marketGDP*(1+p.accelerator*(f.util-this.p.initialUtilization/100))));
  const desiredRD=fs.map(f=>p.rdBusiness/100*p.rdLaborShare/100*f.marketGDP),expected=cPlan+gPlan+sum(desiredInvest);
  this.wage=Math.max(1e-9,p.laborShare/this.p.employmentRate*Math.pow(Math.max(1e-9,this.lastTechnology/this.p.initialTechnology),p.wageAdjustment));
  fs.forEach((f,i)=>{
   f.target=Math.max(0,expected*f.share+p.inventoryTarget/100*f.sales-f.inventory);
   const hoursNeeded=f.target/(this.lp*f.a)+desiredRD[i]/this.wage;
   const employmentTarget=clamp(hoursNeeded,0,100)*(1+p.laborFriction*normal(this.seed,noiseTime,fs[i].id,20));
   f.employment=Math.max(0,f.employment+p.laborAdjustment*(employmentTarget-f.employment));
   const ht=clamp(hoursNeeded/Math.max(1e-9,f.employment),p.minimumHours/100,p.maximumHours/100);f.hours=clamp(f.hours+p.hoursAdjustment*(ht-f.hours),p.minimumHours/100,p.maximumHours/100);
   const ut=clamp(f.target/Math.max(1e-9,this.kp*f.capital*f.a),p.minimumUtilization/100,1);f.util=clamp(f.util+p.utilizationAdjustment*(ut-f.util),p.minimumUtilization/100,1);
  });
  let employment=sum(fs.map(f=>f.employment));if(employment>100)fs.forEach(f=>f.employment*=100/employment);
  // Grants finance the already-planned business research payroll. They do not
  // generate a second research wage payment or a second innovation dose.
  const publicBudget=p.publicResearch/100*this.lastOutput,grantPlan=publicBudget*p.publicGrantShare/100*p.rdLaborShare/100;
  let publicGrants=0;
  fs.forEach((f,i)=>{f.grant=Math.min(desiredRD[i],grantPlan*f.share);this.ensureGov(f.grant,p);this.gov.cash-=f.grant;f.cash+=f.grant;publicGrants+=f.grant;});
  const loanNeeds=fs.map(f=>Math.max(0,this.wage*f.employment*f.hours+p.liquidityBuffer/100*f.sales-f.cash));
  const eligible=fs.map((f,i)=>Math.min(loanNeeds[i],Math.max(0,p.maxLeverage*f.capital-f.loan))*clamp(p.creditAvailability*shock.credit,0,1));
  const capacity=p.capitalRequirement===0?Infinity:Math.max(0,this.bank.equity/(p.capitalRequirement/100)-this.loans()),eligibleTotal=sum(eligible),ration=eligibleTotal?Math.min(1,capacity/eligibleTotal):0;
  fs.forEach((f,i)=>{const lend=eligible[i]*ration;f.cash+=lend;f.loan+=lend;const hours=f.employment*f.hours,afford=Math.min(hours,f.cash/this.wage);if(afford<hours)f.employment*=hours?afford/hours:0;});
  const order=hs.map((_,i)=>i).sort((a,b)=>uniform(this.seed,noiseTime,a,22)-uniform(this.seed,noiseTime,b,22));let workerIndex=0,workerRemaining=100/hs.length;
  let wages=0,investment=0,goodsOutput=0,researchHours=0,productionHours=0,rd=0;
  fs.forEach((f,i)=>{
   const allocation=new Array(hs.length).fill(0);let jobs=f.employment;
   while(jobs>1e-10&&workerIndex<order.length){const j=order[workerIndex],taken=Math.min(jobs,workerRemaining);allocation[j]+=taken;hs[j].employed+=taken;jobs-=taken;workerRemaining-=taken;if(workerRemaining<1e-10){workerIndex++;workerRemaining=100/hs.length;}}
   if(f.employment>1e-10)for(let j=0;j<allocation.length;j++)allocation[j]/=f.employment;
   const fundedHours=f.employment*f.hours;f.researchHours=Math.min(fundedHours,desiredRD[i]/this.wage);f.productionHours=Math.max(0,fundedHours-f.researchHours);f.rd=f.researchHours*this.wage;
   f.wages=this.payIncome(f,fundedHours*this.wage,p,allocation);wages+=f.wages;rd+=f.rd;researchHours+=f.researchHours;productionHours+=f.productionHours;
   const lc=this.lp*f.productionHours*f.a*shock.supply,kc=this.kp*f.capital*f.util*f.a*shock.supply*clamp(1+p.supplyVolatility*normal(this.seed,noiseTime,fs[i].id,24),.25,1.75);
   f.output=Math.max(0,Math.min(lc,kc,f.target));goodsOutput+=f.output;f.investment=Math.min(f.output,desiredInvest[i]);investment+=f.investment;
   f.capital=(1-p.depreciation/100)*f.capital+f.investment;f.inventory+=f.output-f.investment;
  });
  const unemployed=Math.max(0,100-sum(fs.map(f=>f.employment))),unemploymentShares=hs.map(h=>Math.max(0,100/hs.length-h.employed));
  this.support(p.incomeSupport/100*this.lastOutput,p);
  if(unemployed>1e-9)this.support(p.unemploymentReplacement/100*this.wage*unemployed,p,unemploymentShares.map(x=>x/unemployed));
  const publicNonBusiness=publicBudget*(1-p.publicGrantShare/100);this.support(publicNonBusiness,p);
  // Treasury funding is settled before household cash-constrained purchases.
  // Households can use wages received this period; demand plans use only past
  // information, while actual purchases use realized, funded current cash.
  this.ensureGov(gPlan,p);
  const budgets=hs.map((h,i)=>Math.min(h.cash,plans[i])),actualCPlan=sum(budgets)/(1+p.consumptionTax/100);
  let demand=actualCPlan+gPlan,sales=new Array(n).fill(0),available=new Set(fs.map((_,i)=>i).filter(i=>fs[i].inventory>1e-12));
  for(let pass=0;pass<n&&demand>1e-10&&available.size;pass++){const denom=sum([...available].map(i=>fs[i].share));let spent=0;
   for(const i of [...available]){const x=Math.min(fs[i].inventory,demand*fs[i].share/denom);sales[i]+=x;fs[i].inventory-=x;spent+=x;if(fs[i].inventory<1e-12)available.delete(i);}
   demand-=spent;if(spent<1e-12)break;
  }
  const totalSales=sum(sales),cRatio=actualCPlan+gPlan>0?actualCPlan/(actualCPlan+gPlan):0,consumptionGoods=totalSales*cRatio,government=totalSales-consumptionGoods;
  const vat=consumptionGoods*p.consumptionTax/100,consumption=consumptionGoods+vat,nominalBudget=sum(budgets);
  if(nominalBudget>0)hs.forEach((h,i)=>h.cash-=budgets[i]*consumption/nominalBudget);
  this.gov.cash+=vat;this.gov.cash-=government;fs.forEach((f,i)=>{f.cash+=sales[i];f.sales=sales[i];f.marketGDP=f.output+sales[i]*cRatio*p.consumptionTax/100;});
  let interestReceived=0,loanInterest=0,defaults=0;const lagged=this.techHistory[Math.max(0,this.techHistory.length-1-p.adoptionLag)],newA=[];
  fs.forEach((f,i)=>{
   const scale=Math.max(f.previousGDP,f.initialGDP,1e-9),prob=1-Math.exp(-p.innovationEfficiency*f.rd/scale*p.humanCapital);let a=f.a;
   f.innovationProbability=prob;const previousKnowledge=a;if(uniform(this.seed,noiseTime,fs[i].id,30)<prob){a*=1+p.innovationStep/100*(1-p.innovationDispersion/100+2*p.innovationDispersion/100*uniform(this.seed,noiseTime,fs[i].id,31));f.innovation=true;}
   const knownPeers=this.links[i].map(j=>lagged.get(fs[j].id)).filter(Number.isFinite);
   const neighbor=knownPeers.length?sum(knownPeers)/knownPeers.length:a;
   const target=(1-p.frontierAccess)*Math.max(a,neighbor)+p.frontierAccess*Math.max(a,this.frontier);f.ownKnowledgeGain=a-previousKnowledge;f.learningGap=Math.max(0,target-a);const afterLearning=adoptKnowledge(a,target,p.diffusion*p.absorptiveCapacity*p.humanCapital);f.diffusionGain=afterLearning-a;
   const donorHistory=this.foreignHistory[Math.max(0,this.foreignHistory.length-1-p.adoptionLag)];
   const foreign=learnForeign(afterLearning,donorHistory,p,this.seed,noiseTime,f.id,uniform);
   f.foreignGain=foreign.gain;f.foreignSource=foreign.source;f.foreignTarget=foreign.target;a=foreign.a;newA.push(a);
   const due=f.loan*p.loanRate/100,interest=Math.min(f.cash,due);f.cash-=interest;this.bank.equity+=interest;interestReceived+=interest;loanInterest+=interest;f.arrears=interest<due-1e-8?f.arrears+1:0;
   const profit=Math.max(0,f.sales+f.investment+f.inventory-f.oldInventory+f.grant-f.wages-interest-p.depreciation/100*f.oldCapital);
   const tax=Math.min(f.cash,profit*p.profitTax/100);f.cash-=tax;this.gov.cash+=tax;
   const dividend=Math.min(Math.max(0,f.cash-p.liquidityBuffer/100*f.sales),Math.max(0,profit-tax)*p.dividendShare/100);f.cash-=dividend;
   hs.forEach(h=>{const x=dividend*h.ownership;h.cash+=x;h.income+=x;});
   const repay=Math.min(f.loan*p.repaymentRate/100,Math.max(0,f.cash-p.liquidityBuffer/100*f.sales));f.cash-=repay;f.loan-=repay;
   if(f.arrears>=p.defaultAfter){defaults++;if(p.firmDynamics)f.forcedExit=true;else{const recovery=Math.min(f.cash,f.loan*p.recoveryRate/100);f.cash-=recovery;f.loan-=recovery;this.bank.equity-=f.loan;f.loan=0;f.arrears=0;f.restructured++;}}
  });
  fs.forEach((f,i)=>{f.a=newA[i];if(this.cohort.has(f.id))this.cohort.get(f.id).a=f.a;});
  for(const source of FOREIGN_PROVIDERS)this.foreign[source.code]*=1+p[source.growth]/100;
  this.foreignHistory.push({...this.foreign});
  this.frontier=Math.max(...newA,this.frontier*(1+p.frontierGrowth/100+p.publicResearchReturn*publicNonBusiness/Math.max(this.lastOutput,1e-9)));
  // Only opening government claims earn the full annual-period interest.
  const bankInterest=openingBankBonds*p.bondRate/100,hhInterest=openingHouseholdBonds.map(b=>b*p.bondRate/100),governmentInterest=bankInterest+sum(hhInterest);
  this.ensureGov(governmentInterest,p);this.gov.cash-=governmentInterest;this.bank.equity+=bankInterest;interestReceived+=bankInterest;
  hs.forEach((h,i)=>{h.cash+=hhInterest[i];h.income+=hhInterest[i];});
  const turnover=transition(this,p,noiseTime,t,uniform);
  this.techHistory.push(new Map(this.firms.map(f=>[f.id,f.a])));
  const requiredEquity=p.capitalRequirement/100*this.loans(),bankDividend=Math.min(Math.max(0,this.bank.equity-requiredEquity),interestReceived*p.bankDividend/100);
  this.bank.equity-=bankDividend;hs.forEach(h=>{const x=bankDividend*h.ownership;h.cash+=x;h.income+=x;});
  let recap=0;if(p.bankBackstop&&this.bank.equity<0){recap=-this.bank.equity+this.p.bankEquity*p.recapitalizationTarget/100;this.ensureGov(recap,p);this.gov.cash-=recap;this.bank.equity+=recap;}
  const output=goodsOutput+vat,inventoryChange=this.totalInventory()-oldInventory;
  const realResidual=goodsOutput-consumptionGoods-government-investment-inventoryChange,marketResidual=output-consumption-government-investment-inventoryChange;
  const effectiveHours=sum(fs.map(f=>f.employment*f.hours)),laborResidual=effectiveHours-productionHours-researchHours,researchPayrollResidual=wages-this.wage*productionHours-rd;
  if(Math.abs(laborResidual)>1e-7||Math.abs(researchPayrollResidual)>1e-7*Math.max(1,wages))throw Error('Research labor/payroll reconciliation failed.');
  const active=this.firms,capital=sum(active.map(f=>f.capital)),openingCapital=sum(fs.map(f=>f.oldCapital));
  const capitalResidual=capital+this.dormantCapital()-oldTotalCapital-investment+p.depreciation/100*oldTotalCapital;
  if(Math.abs(capitalResidual)>1e-7*Math.max(1,oldTotalCapital))throw Error('Capital stock/transfer reconciliation failed.');
  const checks=this.check(realResidual,goodsOutput,marketResidual,output);
  const alpha=this.p.tfpCapitalShare/100,rawTfp=goodsOutput/Math.max(1e-12,Math.pow(openingCapital,alpha)*Math.pow(Math.max(productionHours,1e-9),1-alpha));
  const tech=sum(active.map(f=>f.a*f.capital))/Math.max(1e-12,capital);this.lastTechnology=tech;this.lastOutput=output;
  const openingWeightTotal=sum(fs.map(f=>f.oldCapital));
  const foreignGain=sum(fs.map(f=>f.foreignGain*f.oldCapital))/Math.max(1e-12,openingWeightTotal);
  const foreignAdopters=fs.filter(f=>f.foreignGain>0).length;
  const row={t,initialObservation:0,firmCount:active.length,cumulativeEntries:this.totalEntries,cumulativeExits:this.totalExits,dormantCapital:this.dormantCapital(),dormantInventory:sum(this.estates.map(e=>e.inventory)),capitalResidual,foreignGain,foreignGainFixed:sum(fs.map(f=>f.initialWeight*f.foreignGain)),foreignAdopters,foreignUSA:fs.filter(f=>f.foreignSource==='USA').length,foreignCHN:fs.filter(f=>f.foreignSource==='CHN').length,foreignKOR:fs.filter(f=>f.foreignSource==='KOR').length,...Object.fromEntries(Object.entries(turnover).filter(([key])=>key!=='events')),output,goodsOutput,consumption,consumptionGoods,consumptionTax:vat,government,investment,inventoryChange,inventory:this.totalInventory(),
   technology:tech,knowledge:sum([...this.cohort.values()].map(f=>f.weight*f.a)),ownKnowledgeGain:sum(fs.map(f=>f.initialWeight*f.ownKnowledgeGain)),diffusionGain:sum(fs.map(f=>f.initialWeight*f.diffusionGain)),learningGapFixed:sum(fs.map(f=>f.initialWeight*f.learningGap)),productivity:rawTfp/this.tfpScale,employment:sum(fs.map(f=>f.employment)),effectiveHours,productionHours,researchHours,
   utilization:100*sum(active.map(f=>f.util*f.capital))/Math.max(1e-9,capital),capital,loans:this.loans(),rd,rdNonLaborBenchmark:sum(fs.map(f=>p.rdBusiness/100*(1-p.rdLaborShare/100)*f.previousGDP)),publicResearch:publicGrants+publicNonBusiness,publicRDGrants:publicGrants,publicResearchNonBusiness:publicNonBusiness,
   publicDebt:this.publicDebt(),bankPublicDebt:this.bank.bonds,householdPublicDebt:sum(hs.map(h=>h.bonds)),bankEquity:this.bank.equity,householdDeposits:sum(hs.map(h=>h.cash)),firmDeposits:sum(active.map(f=>f.cash)),governmentDeposits:this.gov.cash,
   wages,gini:gini(hs.map(h=>h.cash)),defaults,recap,technologyGrowth:100*Math.log(tech/previousTechnology),loanInterest,governmentInterest,researchPayrollResidual,laborResidual,...checks};
  if(!Object.values(row).every(Number.isFinite))throw Error('Non-finite output');return row;
 }
 snapshot(){return this.firms.map(f=>({id:f.id,birthTime:f.birthTime,exitProbability:f.exitProbability,foreignGain:f.foreignGain,foreignSource:f.foreignSource,foreignTarget:f.foreignTarget,a:f.a,initialWeight:f.initialWeight,ownKnowledgeGain:f.ownKnowledgeGain,diffusionGain:f.diffusionGain,learningGap:f.learningGap,capital:f.capital,output:f.output,employment:f.employment,loan:f.loan,cash:f.cash,rd:f.rd,researchHours:f.researchHours,share:f.share,innovation:f.innovation,restructured:f.restructured}));}
}
export function simulate(params,seed,{paths=[],shocks=[],snapshots=false}={}){
 const p=sanitize(params),pp=validateTimeline(paths),ss=validateShocks(shocks),e=new Economy(p,seed),rows=[],agents=[],networks=[];let initial=e.initialSnapshot();
 for(let t=0;t<p.burnIn;t++)initial=e.step(t,-p.burnIn+t,[],[]);
 rows.push({...initial,t:0});if(snapshots){agents.push(e.snapshot());networks.push(e.links.map(a=>a.slice()));}
 for(let t=1;t<=p.periods;t++){rows.push(e.step(p.burnIn+t,t,pp,ss));if(snapshots){agents.push(e.snapshot());networks.push(e.links.map(a=>a.slice()));}}
 return{rows,agents,networks,events:e.events,foreignHistory:e.foreignHistory,links:snapshots?e.links:[],params:p,seed,modelVersion:'1.3.0'};
}
export function quantile(values,q){let a=values.slice().sort((x,y)=>x-y),x=(a.length-1)*q,l=Math.floor(x);return a[l]+(a[Math.ceil(x)]-a[l])*(x-l);}
export function summarize(runs){return runs[0].rows.map((_,t)=>{let r={t};for(let key of Object.keys(METRICS)){let a=runs.map(x=>x.rows[t][key]);r[key]={median:quantile(a,.5),mean:sum(a)/a.length,low:quantile(a,.1),high:quantile(a,.9)};}return r;});}
export function runEnsemble(payload,progress=()=>{}){const p=sanitize(payload.params),reference=sanitize(payload.reference??DEFAULTS);for(const d of PARAMETERS.filter(d=>d.design))reference[d.key]=p[d.key];let paths=validateTimeline(payload.paths??[]),shocks=validateShocks(payload.shocks??[]),base=[],scenario=[];for(let i=0;i<p.replications;i++){let seed=p.seed+i*7919;base.push(simulate(reference,seed,{snapshots:i===0}));scenario.push(simulate(p,seed,{paths,shocks,snapshots:i===0}));progress((i+1)/p.replications);}let residuals={maxBank:0,maxReal:0,maxSector:0,maxRelative:0,maxMarket:0,maxLabor:0,maxPayroll:0};for(const r of [...base,...scenario])for(const x of r.rows){residuals.maxBank=Math.max(residuals.maxBank,Math.abs(x.bankResidual));residuals.maxReal=Math.max(residuals.maxReal,Math.abs(x.realResidual));residuals.maxSector=Math.max(residuals.maxSector,Math.abs(x.sectorResidual));residuals.maxRelative=Math.max(residuals.maxRelative,x.relativeResidual);residuals.maxMarket=Math.max(residuals.maxMarket,Math.abs(x.marketResidual));residuals.maxLabor=Math.max(residuals.maxLabor,Math.abs(x.laborResidual));residuals.maxPayroll=Math.max(residuals.maxPayroll,Math.abs(x.researchPayrollResidual));}let paired=base.map((b,i)=>{let s=scenario[i].rows[p.periods],r=b.rows[p.periods];return{seed:b.seed,output:100*(s.output/Math.max(1e-9,r.output)-1),technology:100*(s.technology/r.technology-1),knowledge:100*(s.knowledge/r.knowledge-1),employment:s.employment-r.employment,loans:s.loans-r.loans};});const diagnostics=diagnoseComparison(p,reference,paths,shocks,base,scenario);return{diagnostics,modelVersion:'1.3.0',baseline:summarize(base),scenario:summarize(scenario),first:{baseline:base[0],scenario:scenario[0]},paired,residuals,params:p,reference,paths,shocks,raw:{baseline:base.map(r=>({seed:r.seed,rows:r.rows})),scenario:scenario.map(r=>({seed:r.seed,rows:r.rows}))},completedAt:new Date().toISOString(),simulations:p.replications*2};}

export function comparisonSettings(params,reference,paths=[],shocks=[]){
 const differences=PARAMETERS.filter(d=>!d.design&&Math.abs(params[d.key]-reference[d.key])>1e-10).map(d=>({key:d.key,label:d.label,reference:reference[d.key],scenario:params[d.key],unit:d.unit}));
 const rates=Array.from({length:params.periods},(_,i)=>{const t=i+1,p=effectiveParameters(params,t,paths);return{t,reference:clamp(reference.diffusion*reference.absorptiveCapacity*reference.humanCapital,0,1),scenario:clamp(p.diffusion*p.absorptiveCapacity*p.humanCapital,0,1)};});
 const higher=rates.filter(x=>x.scenario>x.reference+1e-12).length,lower=rates.filter(x=>x.scenario<x.reference-1e-12).length;
 const otherPaths=paths.filter(x=>!['diffusion','absorptiveCapacity'].includes(x.key)),otherDifferences=differences.filter(x=>!['diffusion','absorptiveCapacity'].includes(x.key));
 return{differences,rates,higherSteps:higher,lowerSteps:lower,adoptionDirection:lower&&higher?'mixed':lower?'lower':higher?'higher':'unchanged',isolatedAdoptionComparison:!otherPaths.length&&!otherDifferences.length&&!shocks.length,otherPathCount:otherPaths.length,shockCount:shocks.length};
}
export function decomposeTechnology(referenceFirms,scenarioFirms){
 const kb=sum(referenceFirms.map(f=>f.capital)),ks=sum(scenarioFirms.map(f=>f.capital));
 const base=sum(referenceFirms.map(f=>f.a*f.capital))/Math.max(1e-12,kb);
 const reference=new Map(referenceFirms.map((f,i)=>[f.id??i,f])),scenario=new Map(scenarioFirms.map((f,i)=>[f.id??i,f]));
 let within=0,reallocation=0,entry=0,exit=0,fixed=0,less=0,common=0;
 for(const [id,b]of reference){const f=scenario.get(id);if(f){common++;within+=b.capital/kb*(f.a-b.a);reallocation+=(f.capital/ks-b.capital/kb)*f.a;fixed+=(b.initialWeight??0)*(f.a-b.a);if(f.a<b.a-1e-10)less++;}else exit-=b.capital/kb*b.a;}
 for(const [id,f]of scenario)if(!reference.has(id))entry+=f.capital/ks*f.a;
 const factor=100/Math.max(1e-12,base);
 return{withinFirmPercent:within*factor,reallocationPercent:reallocation*factor,entryPercent:entry*factor,exitPercent:exit*factor,populationPercent:(entry+exit)*factor,totalPercent:(within+reallocation+entry+exit)*factor,fixedWeightIndexDifference:fixed,firmsWithLessKnowledge:less,commonFirms:common,scenarioOnlyFirms:scenario.size-common,referenceOnlyFirms:reference.size-common};
}
export function diagnoseComparison(params,reference,paths,shocks,base,scenario){
 const settings=comparisonSettings(params,reference,paths,shocks),final=params.periods;
 const distribution=values=>({median:quantile(values,.5),low:quantile(values,.1),high:quantile(values,.9)});
 const localDirectEffect=settings.rates.map(({t,reference:r,scenario:s})=>({t,...distribution(base.map(b=>(s-r)*b.rows[t].learningGapFixed))}));
 const feedback=Object.fromEntries(['employment','wages','consumption','investment','rd','loans','publicDebt'].map(key=>[key,distribution(base.map((b,i)=>scenario[i].rows[final][key]-b.rows[final][key]))]));
 const firstSeed=base[0].agents.length?{seed:base[0].seed,...decomposeTechnology(base[0].agents[final],scenario[0].agents[final])}:null;
 return{settings,localDirectEffect,firstSeed,feedback,note:'The direct effect changes only the adoption rate at identical reference states. It is a local mechanism diagnostic, not the full macroeconomic counterfactual or an empirical causal estimate. Weight decomposition matches permanent IDs and includes unmatched population contributions. Original-cohort knowledge freezes at the last observation on exit and excludes entrants; it is not active-firm productivity.'};
}
export const SENSITIVITY_SPECIFICATIONS=[
 {id:'configured',label:'Configured assumptions',changes:{}},
 {id:'wage_low',label:'Wage response 0.5',changes:{wageAdjustment:.5}},
 {id:'wage_full',label:'Wage response 1.0',changes:{wageAdjustment:1}},
 {id:'spend_low',label:'Income-spending response 0.7',changes:{consumptionIncome:.7}},
 {id:'spend_full',label:'Income-spending response 1.0',changes:{consumptionIncome:1}},
 {id:'selection_off',label:'No productivity-based customer switching',changes:{marketSelection:0}},
 {id:'public_return',label:'Assumed public frontier return 0.15',changes:{publicResearchReturn:.15}},
 {id:'debt_rule',label:'Assumed debt-driven spending cuts 0.04',changes:{fiscalAdjustment:.04}}
];
export function runSensitivity(payload,progress=()=>{}){
 const count=Math.min(5,sanitize(payload.params).replications),rows=[];
 for(let i=0;i<SENSITIVITY_SPECIFICATIONS.length;i++){
  const spec=SENSITIVITY_SPECIFICATIONS[i],r=runEnsemble({...payload,params:{...payload.params,...spec.changes,replications:count},reference:{...payload.reference,...spec.changes}},p=>progress((i+p)/SENSITIVITY_SPECIFICATIONS.length));
  rows.push({id:spec.id,label:spec.label,changes:spec.changes,seeds:count,simulations:r.simulations,gdp:quantile(r.paired.map(x=>x.output),.5),technology:quantile(r.paired.map(x=>x.technology),.5),knowledge:quantile(r.paired.map(x=>x.knowledge),.5),employment:quantile(r.paired.map(x=>x.employment),.5),flaggedPaths:[...r.raw.baseline,...r.raw.scenario].filter(b=>b.rows.some(x=>x.employment<50||x.publicDebt>3*Math.max(1e-9,x.output))).length});
 }
 return{modelVersion:'1.3.0',rows,simulations:rows.reduce((s,x)=>s+x.simulations,0),seedsPerSpecification:count,note:'Eight predeclared illustrative specifications. Each changed coefficient is applied to both reference and scenario. These are sensitivity probes, not empirically estimated parameter bounds, confidence intervals or model selection. Custom parameter paths may override a changed starting coefficient.'};
}

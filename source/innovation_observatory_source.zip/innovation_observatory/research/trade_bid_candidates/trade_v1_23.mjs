const sum = values => values.reduce((total,value)=>total+value,0);
const clamp = (value,low,high) => Math.max(low,Math.min(high,value));

export function tradeConditions(nominalCurrency, producerPrice, foreignPrice, params, foreignDemandIndex = 1, relativeTechnology = 1) {
  const importPrice = foreignPrice / (nominalCurrency / 100);
  const realExchangeRate = 100 * producerPrice / importPrice;
  const relativePrice = realExchangeRate / 100;
  const importTariff=params.importTariff??0;
  const landedImportPrice=importPrice*(1+importTariff/100);
  const tradeCompetitiveness = clamp(relativeTechnology,.25,4);
  const quality = tradeCompetitiveness**params.tradeQualitySensitivity;
  const baseShare = params.importShare / 100;
  const weight = baseShare * (producerPrice/landedImportPrice) ** params.importElasticity / quality;
  const marketShare = weight / (1 - baseShare + weight);
  // A small repeat-customer component is less sensitive to spot prices.
  const exportOrders = params.exportDemand*foreignDemandIndex*(.10+.90*quality*relativePrice**-params.exportElasticity);
  const exportBid = producerPrice*clamp((quality/relativePrice)**.45,.65,1.35);
  return {
    tradeActive:params.tradeEnabled,
    foreignPriceIndex:100*foreignPrice,
    foreignDemandIndex:100*foreignDemandIndex,
    importPrice,landedImportPrice,importTariff,realExchangeRate,tradeCompetitiveness,exportBid,
    importBudgetShare:params.tradeEnabled ? clamp(marketShare,.10*baseShare,.95) : 0,
    exportOrders:params.tradeEnabled ? exportOrders : 0,
  };
}

export function addImportPrices(domestic, previous, importConsumerPrice, basketShare, hasTraded) {
  if (!hasTraded) return {...domestic,importConsumerPrice,goodsConsumerPriceIndex:domestic.consumerPriceIndex};
  const domesticChange = domestic.consumerPrice / previous.consumerPrice;
  const foreignChange = importConsumerPrice / previous.importConsumerPrice;
  const change = domesticChange + basketShare * (foreignChange - domesticChange);
  // Keep the non-rent basket separate. The headline index may already include
  // rents; chaining it here would apply their weight again every year.
  const goodsConsumerPriceIndex=(previous.goodsConsumerPriceIndex??previous.consumerPriceIndex)*change;
  return {...domestic,importConsumerPrice,goodsConsumerPriceIndex,
    inflation:100*(change-1),consumerPriceIndex:goodsConsumerPriceIndex};
}

function fillOrder(firms,demand,sales) {
  const available=new Set(firms.map((_,i)=>i).filter(i=>firms[i].inventory>0));
  for (let pass=0;pass<firms.length&&demand>0&&available.size;pass++) {
    const weights=sum([...available].map(i=>firms[i].share));
    const fallback=1/available.size;
    let filled=0;
    for (const i of available) {
      const firm=firms[i];
      const share=weights>0?firm.share/weights:fallback;
      const quantity=Math.min(firm.inventory,demand*share);
      sales[i]+=quantity;
      firm.inventory-=quantity;
      filled+=quantity;
      if (firm.inventory<=0) available.delete(i);
    }
    demand-=filled;
    if (filled<=0) break;
  }
}

export function clearGoodsMarket(firms,domesticDemand,domesticBid,trade) {
  const domesticSales=firms.map(()=>0),exportSales=firms.map(()=>0),exportReceipts=firms.map(()=>0);
  const orders=[{quantity:domesticDemand,bid:domesticBid,exported:false}];
  if (trade.exportOrders>0) {
    // Differentiated goods have a small pool of buyers who bid above the local
    // price. The remaining foreign orders span a range of willingness to pay.
    orders.push({quantity:.10*trade.exportOrders,bid:Math.max(domesticBid*1.01,trade.exportBid),exported:true});
    for (const spread of [1.10,1.03,.97,.90])
      orders.push({quantity:.225*trade.exportOrders,bid:trade.exportBid*spread,exported:true});
  }
  orders.sort((a,b)=>b.bid-a.bid);
  for (const order of orders) {
    if (!order.exported) {
      fillOrder(firms,order.quantity,domesticSales);
      continue;
    }
    const sales=firms.map(()=>0);
    fillOrder(firms,order.quantity,sales);
    sales.forEach((quantity,i)=>{
      exportSales[i]+=quantity;
      exportReceipts[i]+=quantity*order.bid;
    });
  }
  return {domesticSales,exportSales,exportReceipts};
}

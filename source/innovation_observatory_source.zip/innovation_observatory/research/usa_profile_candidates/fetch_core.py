from pathlib import Path
import json,urllib.request,concurrent.futures,hashlib,datetime
OUT=Path(__file__).parent
indicators=['NY.GDP.MKTP.CD','NE.CON.PRVT.ZS','NE.CON.GOVT.ZS','NE.GDI.FTOT.ZS','NE.EXP.GNFS.ZS','NE.IMP.GNFS.ZS','SP.POP.TOTL','SP.POP.0014.TO.ZS','SP.POP.65UP.TO.ZS','SP.DYN.CBRT.IN','SP.DYN.CDRT.IN','FP.CPI.TOTL.ZG','SL.TLF.CACT.ZS','SL.EMP.TOTL.SP.ZS','GC.DOD.TOTL.GD.ZS','SH.XPD.GHED.GD.ZS','SE.XPD.TOTL.GD.ZS']
url='https://api.worldbank.org/v2/country/USA/indicator/'+';'.join(indicators)+'?source=2&date=2023&format=json&per_page=100'
def fetch(name,url):
 try:
  raw=urllib.request.urlopen(url,timeout=35).read();(OUT/(name+'.json')).write_bytes(raw);return {'name':name,'url':url,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 except Exception as e:return {'name':name,'url':url,'error':str(e)}
result=fetch('world_bank_usa_2023',url);print(json.dumps(result));(OUT/'fetch_manifest.json').write_text(json.dumps([result],indent=2))
if 'error' not in result:
 data=json.loads((OUT/'world_bank_usa_2023.json').read_text());print([(x['indicator']['id'],x['value'])for x in data[1]])

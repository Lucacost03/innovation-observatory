# USA2023 candidate evidence

This folder contains research inputs only. No model, application, or preset is changed here.

- `candidate.json`: exact observed2023 rows, proposed parameter mappings, source URLs/file hashes, equations and coverage gaps.
- `frozen_observations.json`: USA2023 PWT11 and Eurostat R&D rows extracted from existing repository snapshots.
- `primary_manifest.json`: raw primary-source HTML URLs, retrieval times and hashes.
- `manifest.json`: hashes of all frozen input files, including the extra Eurostat PC_GDP request.
- `*.html`: downloaded official BLS, FederalReserve, FRED, OECD source pages.
- `eurostat_rd_us_pc_gdp.json`: direct Eurostat US2023 businessR&D/GDP (2.66%) to avoid mixing dollar GDP with euro R&D.

Rebuild without network: run `python research/usa_profile_candidates/extract_frozen.py` then `python research/usa_profile_candidates/build_candidates.py`. The former requires pandas plus an Excel reader; the latter uses Python standard library only.

Refresh official HTML: `python research/usa_profile_candidates/fetch_primary.py`. This intentionally fixes FederalReserve release at2026-03-19 so all2023 macro and financial rows use one vintage. FRED pages additionally preserve later revisions for inspection; those later flow observations are not mixed into the fixed-vintage GDP-based parameter candidates. Labor-series age scope is matched15–64.

Extra Eurostat URL: https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/rd_e_gerdtot?geo=US&time=2023&unit=PC_GDP

The macro expenditure identity closes to0.1bnUSD rounding error. GovernmentConsumption13.54%GDP maps to13.193% of modeled domestic final uses; government investment is included in investment instead of counted again as government purchases. Government transfers are excluded from that consumption numerator. Health10.1%GDP and socialprotection7.9%GDP are total COFOG functional spending; they must not be inserted as extra purchased services or cash pension payments.

Opening household deposits51.458%GDP combine currency/checkables, time/savings, other deposits, excluding money-market funds. Company deposits16.380%GDP combine nonfinancial corporate and noncorporate businesses; corporate-only equals9.338%GDP and has a narrower scope comparable to European S11. Source institutional boundaries differ explicitly. Household residential structures97.068%GDP exclude land and can be carved out of PWT capital; residential mortgages46.805%GDP are liabilities, not an extra deposit creation. These are candidates subject to the model's opening financial balance reconciliation.

Publicemployee pension entitlements are included in the observed30632.1bnUSD aggregate. That aggregate is not a private-only funded pension estimate. Unsupported social-spending breakdowns, demographic dynamics, financialwealth distribution and enterprise demography remain unverified. Use clearly labeled assumptions or turn the respective layer off; no European value is an observed US value.

Inflation4.1% is annual-average CPI-U, while end2023 federal-funds target midpoint5.375% is a derived representation of the5.25–5.50range. Neither is a current2026 observation or forecast. Future behavioral responses are scenario assumptions, not identified empirical causal coefficients.

from pathlib import Path
import json,hashlib
import pandas as pd
R=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;S=R/'research/source_snapshots';obs={}
pwt=pd.read_excel(S/'pwt110.xlsx',sheet_name='Data');a=pwt[(pwt.countrycode=='USA')&(pwt.year==2023)].iloc[0]
fields=['pop','rgdpna','rnna','labsh','delta','csh_c','csh_i','csh_g','csh_x','csh_m','ctfp','rtfpna','hc','cgdpo','cgdpe','emp']
obs['pwt']={'year':2023,'countrycode':'USA','values':{f:float(a[f]) for f in fields},'url':'https://www.rug.nl/ggdc/productivity/pwt/','sha256':hashlib.sha256((S/'pwt110.xlsx').read_bytes()).hexdigest()}
obs['pwt']['derived']={'capitalOutputRatio':float(a.rnna/a.rgdpna),'laborShare':float(a.labsh*100),'tfpCapitalShare':float((1-a.labsh)*100),'depreciation':float(a.delta*100),'initialHumanCapital':float(a.hc),'initialPopulationMillions':float(a['pop'])}
def decode(name):
 p=S/(name+'.json');d=json.loads(p.read_text());cats=[]
 for dim in d['id']:
  ix=d['dimension'][dim]['category']['index'];cats.append([k for k,_ in sorted(ix.items(),key=lambda x:x[1])])
 rows=[]
 for key,value in d.get('value',{}).items():
  if value is None:continue
  n=int(key);indices=[]
  for size in reversed(d['size']):indices.append(n%size);n//=size
  row={dim:cats[i][j] for i,(dim,j) in enumerate(zip(d['id'],reversed(indices)))}
  if row.get('geo')!='US':continue
  row.update(value=float(value),flag=d.get('status',{}).get(key,''));rows.append(row)
 return {'snapshot':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rows,'updated':d.get('updated')}
for name in ['rd_performance','business_rd_costs','public_rd_funding','bis_policy_rates']:
 if (S/(name+'.json')).exists():obs[name]=decode(name)
(OUT/'frozen_observations.json').write_text(json.dumps(obs,indent=2)+'\n');print(json.dumps(obs,indent=2))

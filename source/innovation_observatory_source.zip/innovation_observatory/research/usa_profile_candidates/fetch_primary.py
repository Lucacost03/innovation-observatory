from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.request import urlopen,Request
import json,hashlib,datetime
P=Path(__file__).resolve().parent
urls={
'fed_f2_20260319':'https://www.federalreserve.gov/Releases/Z1/20260319/html/f2.htm',
'fed_b101_20260319':'https://www.federalreserve.gov/Releases/Z1/20260319/html/b101.htm',
'fed_b103_20260319':'https://www.federalreserve.gov/Releases/Z1/20260319/html/b103.htm',
'fed_b104_20260319':'https://www.federalreserve.gov/Releases/Z1/20260319/html/b104.htm',
'fed_f101_20260319':'https://www.federalreserve.gov/Releases/Z1/20260319/html/f101.htm',
'fed_f106_20260319':'https://www.federalreserve.gov/Releases/Z1/20260319/html/f106.htm',
'fed_f107_20260319':'https://www.federalreserve.gov/Releases/Z1/20260319/html/f107.htm',
'fred_gcons':'https://fred.stlouisfed.org/data/A955RC1A027NBEA',
'fred_employment':'https://fred.stlouisfed.org/data/LREM64TTUSA156N',
'fred_participation':'https://fred.stlouisfed.org/data/LRAC64TTUSA156N',
'fred_gfcf':'https://fred.stlouisfed.org/data/NFIXDCUSA',
'fed_rate':'https://www.federalreserve.gov/newsevents/pressreleases/monetary20231213a.htm',
'bls_cpi':'https://www.bls.gov/regions/mid-atlantic/data/consumerpriceindexannualandsemiannual_table.htm',
'oecd_cofog':'https://www.oecd.org/en/publications/2025/06/government-at-a-glance-2025_70e14c6c/full-report/government-expenditure-by-function-cofog_d2b167d4.html',
'fred_gdp':'https://fred.stlouisfed.org/data/GDPA',
'fred_pce':'https://fred.stlouisfed.org/data/PCECA',
'fred_exports':'https://fred.stlouisfed.org/data/EXPGSA',
'fred_imports':'https://fred.stlouisfed.org/data/IMPGSA',
}
def get(kv):
 n,u=kv
 d={'name':n,'url':u,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  b=urlopen(Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=18).read(); p=P/(n+'.html');p.write_bytes(b)
  d.update(file=p.name,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
 except Exception as e:d['error']=str(e)
 return d
r=list(ThreadPoolExecutor(max_workers=8).map(get,urls.items()))
(P/'primary_manifest.json').write_text(json.dumps(r,indent=2))
print([(d['name'],d.get('bytes',d.get('error'))) for d in r])

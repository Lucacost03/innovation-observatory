"""Rebuild USA2023 candidate observations from frozen primary-source HTML.
Run python research/usa_profile_candidates/fetch_primary.py to refresh raw HTML;
then this script. No model files are changed. Snapshot release fixed2026-03-19.
"""
from pathlib import Path
import re,html,json,hashlib,datetime
P=Path(__file__).resolve().parent
manifest=json.loads((P/'primary_manifest.json').read_text())
meta={d['name']:d for d in manifest if 'file' in d}
def clean(x):return html.unescape(' '.join(re.sub('<[^>]*>',' ',x).split()))
obs={}
for name,m in meta.items():
 if not name.startswith('fed_') or not '_20260319' in name:continue
 for row in re.findall(r'<tr\b[^>]*>.*?</tr>',(P/m['file']).read_text(),re.S):
  x=clean(row); s=re.search(r'\b(?:FA|FL|LM)\d{9}\b',x)
  if not s:continue
  after=x[s.end():].split()
  try:v=float(after[0].replace(',',''))
  except (ValueError,IndexError):continue
  key=s.group();obs[key]={'value':v,'year':2023,'unit':'billion USD','description':x[:s.start()].strip(),'source':m['url'],'source_file':m['file'],'source_sha256':m['sha256'],'release_date':'2026-03-19','status':'observed','measure':'end-year stock' if name.startswith('fed_b') else 'annual flow'}
for name,series,unit in [('fred_employment','LREM64TTUSA156N','percent population15–64'),('fred_participation','LRAC64TTUSA156N','percent population15–64'),('fred_gdp','GDPA','billion USD'),('fred_pce','PCECA','billion USD'),('fred_gcons','A955RC1A027NBEA','billion USD'),('fred_exports','EXPGSA','billion USD'),('fred_imports','IMPGSA','billion USD'),('fred_gfcf','NFIXDCUSA','million USD')]:
 m=meta[name];t=(P/m['file']).read_text();found=re.search(r'2023-01-01\s*</th>\s*<td[^>]*>\s*([\d.,-]+)',t)
 if not found:raise ValueError('2023 row missing '+name)
 obs[series]={'value':float(found[1].replace(',','')),'year':2023,'unit':unit,'source':m['url'],'source_file':m['file'],'source_sha256':m['sha256'],'status':'observed','vintage_note':'Retrieved2026-11-13; series vintages differ from fixed Fed2026-03-19 release. Core GDP expenditure candidates use coherent Fed release.'}
for key,value,unit,name,note in [
 ('cpiAnnualAverageInflation',4.1,'percent','bls_cpi','Annual CPI-U average2023 versus2022; December12-month3.4% is a different definition.'),
 ('fedTargetLowerEnd2023',5.25,'percent annual','fed_rate','December13,2023 FOMC statement; target federal funds rate range, not effective market rate.'),
 ('fedTargetUpperEnd2023',5.5,'percent annual','fed_rate','December13,2023 target range upper bound.'),
 ('cofogHealthTotal',10.1,'percent GDP','oecd_cofog','OECD2025 report:2023 COFOG general-government total health expenditure. Not directly government purchased P3 healthcare; do not add both as extra spending.'),
 ('cofogSocialProtectionTotal',7.9,'percent GDP','oecd_cofog','2023 COFOG social protection total expenditure; not an old-age cash benefit or total household cash-transfer series.')]:
  m=meta[name];obs[key]={'value':value,'year':2023,'unit':unit,'source':m['url'],'source_file':m['file'],'source_sha256':m['sha256'],'status':'observed','note':note}
params={}
def put(k,v,units,formula,inputs,note='',status='proxy'):
 params[k]={'value':v,'unit':units,'year':2023,'status':status,'formula':formula,'observations':inputs,'note':note}
def val(k):return obs[k]['value']
gdp=val('FA086902005');c=val('FA156901001');g=val('FA366901005');i=val('FA835019005')+val('FA365019005');den=c+g+i
put('governmentShare',100*g/den,'% domestic final uses','100*Gconsumption/(PCE+Gconsumption+privatefixedinvestment+publicgrossinvestment)',['FA366901005','FA156901001','FA835019005','FA365019005'],'Closed-economy allocation proxy; transfers excluded. Same frozen2026-03-19 release.')
params['initialGovernmentShare']=dict(params['governmentShare'])
put('investmentShare',100*i/den,'% domestic final uses','100*(privatefixedinvestment+publicgrossinvestment)/(PCE+Gconsumption+privatefixedinvestment+publicgrossinvestment)',['FA835019005','FA365019005','FA156901001','FA366901005'])
put('initialParticipationRate',val('LRAC64TTUSA156N'),'percent population15–64','OECD annual participation, total sex,15–64',['LRAC64TTUSA156N'],status='observed')
put('employmentRate',100*val('LREM64TTUSA156N')/val('LRAC64TTUSA156N'),'percent labour force15–64','100*employment/population / participation/population',['LREM64TTUSA156N','LRAC64TTUSA156N'],'Both are OECD same-age annual2023 series; unemployment is remaining labour force, inactivity separate.')
put('householdWealth',100*sum(val(k) for k in ['FL153020005','FL153030005','LM153030505'])/gdp,'% opening GDP','100*(HH+NPISH checkablescurrency+time/savings+otherdeposits)/GDP',['FL153020005','FL153030005','LM153030505','FA086902005'],'F2-like deposits only; excludes money-market funds. Distribution and bank counterpart balance are still modeled.')
put('firmLiquidity',100*sum(val(k) for k in ['FL103020005','FL103030003','FL103091003','FL113020005','FL113030003'])/gdp,'% opening GDP','100*(nonfinancialcorporate deposits+nonfinancialnoncorporate deposits)/GDP',['FL103020005','FL103030003','FL103091003','FL113020005','FL113030003','FA086902005'],'Includes noncorporate business; European S11-only scope differs. Use corporate-only9.338% if matching narrow S11; broaderfirms16.380% if matching all model enterprises.')
put('initialIncome',100*val('FA156012005')/gdp,'% opening GDP','100*disposablepersonalIncome/GDP',['FA156012005','FA086902005'],'US NIPA personal income includes NPISH and differs from ESA household gross-disposable-income concept; explicit proxy.')
put('initialMortgageGDP',100*val('FL153165105')/gdp,'% opening GDP','100*one-to-four-family residential mortgage liabilities/GDP',['FL153165105','FA086902005'],'US financialaccounts excludes NPISHcommercialmortgages; opening stock only.')
put('initialHousingGDP',100*val('LM155012665')/gdp,'% opening GDP','100*householdresidentialstructures replacementcost/GDP',['LM155012665','FA086902005'],'Structures exclude land. This is a current-price stock mapped to PWT national-price capital; ensure carve-out below total capital.')
put('residentialInvestmentShare',100*val('FA835012001')/i,'% total fixed investment','100*private residential investment/(privatefixedinvestment+publicgrossinvestment)',['FA835012001','FA835019005','FA365019005'],'Private residential investment includes households and housing enterprises; publichousing not distinguished.')
put('policyRate',5.375,'% annual','(5.25+5.50)/2',['fedTargetLowerEnd2023','fedTargetUpperEnd2023'],'End2023 target range midpoint. An explicit policy-instrument representation, not annual effective rate.')
put('initialInflation',4.1,'% annual','BLS annual average CPI-U growth',['cpiAnnualAverageInflation'],status='observed')
put('initialPolicyInflation',4.1,'% annual','BLS annual average CPI-U growth',['cpiAnnualAverageInflation'],'Model response starts from annual observed inflation, target is separate.',status='observed')
frozen=json.loads((P/'frozen_observations.json').read_text())
pwt_units={'capitalOutputRatio':'ratio','laborShare':'percent gross income','tfpCapitalShare':'percent gross income','depreciation':'percent annual','initialHumanCapital':'PWT hc index','initialPopulationMillions':'million people'}
pwt_formulas={'capitalOutputRatio':'rnna/rgdpna','laborShare':'100*labsh','tfpCapitalShare':'100*(1-labsh)','depreciation':'100*delta','initialHumanCapital':'hc','initialPopulationMillions':'pop'}
for k,v in frozen['pwt']['derived'].items():put(k,v,pwt_units[k],pwt_formulas[k],[],'PWT11 USA2023. Exact input values, workbook SHA256 and primary source URL in frozen_observations.json.')
rd=frozen['business_rd_costs']['rows'];lc=next(x['value'] for x in rd if x['expend']=='CUR_LC');total=next(x['value'] for x in rd if x['expend']=='TOTAL')
for key,number,desc in [('RD_LABOUR',lc,'BusinessperformedGERD labourcosts'),('RD_BES_TOTAL',total,'BusinessperformedGERD totalcosts')]:
 obs[key]={'value':number,'year':2023,'unit':'million EUR','description':desc,'source':'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/rd_e_berdcost?geo=US&time=2023&unit=MIO_EUR','source_file':'../source_snapshots/business_rd_costs.json','source_sha256':frozen['business_rd_costs']['sha256'],'status':'observed'}
put('rdLaborShare',100*lc/total,'% business GERD','100*EurostatUS businessGERD labourcosts/totalbusinessGERD',['RD_LABOUR','RD_BES_TOTAL'],'Both MIO_EUR,2023; no currencyconversion needed. Frozen snapshotstatusflags preserved.')
rd=frozen['public_rd_funding']['rows'];b=next(x['value'] for x in rd if x['sectperf']=='BES');t=next(x['value'] for x in rd if x['sectperf']=='TOTAL')
for key,number,desc in [('RD_GOV_BES',b,'Governmentfunded businessGERD'),('RD_GOV_TOTAL',t,'Governmentfunded totalGERD')]:
 obs[key]={'value':number,'year':2023,'unit':'million EUR','description':desc,'source':'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/rd_e_gerdfund?geo=US&time=2023&unit=MIO_EUR&sectfund=GOV','source_file':'../source_snapshots/public_rd_funding.json','source_sha256':frozen['public_rd_funding']['sha256'],'status':'observed'}
put('publicGrantShare',100*b/t,'% government-funded GERD','100*GOV-fundedBES/GOV-fundedTOTAL',['RD_GOV_BES','RD_GOV_TOTAL'],'All2023 MIO_EUR, same source denominator.')
rdp=P/'eurostat_rd_us_pc_gdp.json'
if rdp.exists():
 d=json.loads(rdp.read_text());ids=d['id'];cats=[]
 for dim in ids:cats.append([k for k,v in sorted(d['dimension'][dim]['category']['index'].items(),key=lambda x:x[1])])
 for ix,v in d['value'].items():
  n=int(ix);indices=[]
  for size in reversed(d['size']):indices.append(n%size);n//=size
  row={dim:cats[j][k] for j,(dim,k) in enumerate(zip(ids,reversed(indices)))}
  if row.get('sectperf')=='BES':
   obs['RD_BES_PC_GDP']={'value':float(v),'year':2023,'unit':'percent GDP','source':'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/rd_e_gerdtot?geo=US&time=2023&unit=PC_GDP','source_file':rdp.name,'source_sha256':hashlib.sha256(rdp.read_bytes()).hexdigest(),'selection':row,'flag':d.get('status',{}).get(ix,''),'status':'observed'}
   put('rdBusiness',float(v),'percent GDP','EurostatUS2023 BES,PC_GDP',['RD_BES_PC_GDP'],'Direct PC_GDP avoids mixing EUR R&D with USD GDP.')
rdpub=P/'eurostat_rd_public_us_pc_gdp.json'
if rdpub.exists():
 d=json.loads(rdpub.read_text());cats=[]
 for dim in d['id']:cats.append([k for k,v in sorted(d['dimension'][dim]['category']['index'].items(),key=lambda x:x[1])])
 for ix,v in d['value'].items():
  n=int(ix);indices=[]
  for size in reversed(d['size']):indices.append(n%size);n//=size
  row={dim:cats[j][k] for j,(dim,k) in enumerate(zip(d['id'],reversed(indices)))}
  if row.get('sectperf')=='TOTAL':
   obs['RD_GOV_PC_GDP']={'value':float(v),'year':2023,'unit':'percent GDP','source':'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/rd_e_gerdfund?geo=US&time=2023&unit=PC_GDP&sectfund=GOV','source_file':rdpub.name,'source_sha256':hashlib.sha256(rdpub.read_bytes()).hexdigest(),'selection':row,'flag':d.get('status',{}).get(ix,''),'status':'observed'}
   put('publicResearch',float(v),'percent GDP','EurostatUS2023 GOVfundedTOTAL,PC_GDP',['RD_GOV_PC_GDP'],'Direct source percentage; public funder not GOV+HES performers.')
result={'country':'USA','year':2023,'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Candidate research only; no model edits or accuracy claim. Source vintages differ explicitly; GDP-based model candidates use fixed coherent Fed2026-03-19 national accounts.','nominal_macro_billion_USD':{'GDP':gdp,'PCE':c,'governmentConsumption':g,'GFCF':i,'exports':val('FA266903011'),'imports':val('FA266903001'),'inventoryChange':val('FA145020005'),'domesticFinalUsesDenominator':den},'candidate_parameters':params,'observations':obs,'unmapped_observed_statistics':{'publicHealthTotalGDP':10.1,'socialProtectionTotalGDP':7.9,'allOccupationalPensionEntitlementsGDP':100*val('FL153050005')/gdp},'coverage_gaps':['COFOG P3 health/education within totalP3 unavailable: totalfunctionalTE is not equivalent. Do not copy Europe observed allocations.','US statutoryVAT absent. Generic consumption tax may represent effective state/local sales+excise tax only with explicit broader proxy; zero VAT is real, not missing.','Private-only fundedpensionDB/DC assets, actualcontributions andbenefitpayments not extracted. FL153050005 includes publicemployeeplans; do not call it privateonly.','Publicoldagecash/socialinsurancecontribution allocations, unemploymentcashbenefits, survivor/sicknessbreakdowns not yet matched. Disable empirical allocation claims; use explicit scenario assumptions if enabled.','Gini of householdfinancialwealth not observed here; SCF totalnetwealth Gini would be a different concept.','US enterprisebirth/death, firm-size dispersion, VC series not yet harmonized with Eurostatenterprise definition. Do not relabel EU values US empirical.','Owneroccupancy/mortgagedowner share, rentalserviceGDP, mortgageopeningrate/pass-through require sources. Housingstock andmortgage alone do not give fullcoverage.','Governmentgeneraldebtconsolidation, governmentF2/equity, nationalgrossforeignassets/liabilities not yet aligned. Parent must reconcile opening balance sheet and mark unresolvedvalues assumed.','Population age-cohort shares, births/deaths/migration and agehazards unavailable in this bounded extraction; PWT population/humancapital observed, demographicdynamics should use explicit assumptions/off.'],'checks':{'GDP_expenditure_rounding_error':c+val('FA835019905')+val('FA366902005')+val('FA266903011')-val('FA266903001')-gdp,'employment_population_percent':val('LREM64TTUSA156N'),'employment_reconstructed':params['employmentRate']['value']*params['initialParticipationRate']['value']/100}}
(P/'candidate.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:round(v['value'],6) for k,v in params.items()})
print('GDPaccounting rounding difference',result['checks']['GDP_expenditure_rounding_error'])

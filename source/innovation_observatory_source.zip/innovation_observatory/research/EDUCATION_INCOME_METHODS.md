# Income shares and national education anchors — engine 1.21.0

This release corrects reporting definitions and replaces uniform school-quality inputs with documented national learning proxies. Accounting, source arithmetic and preservation of the previous economic response pass the checks below. No new causal coefficient or out-of-sample forecasting improvement is claimed.

## Two income components

Labour income L is gross model wages, including paid research. Gross capital income K is the existing gross operating surplus, before interest, profit tax and depreciation. Its definition is unchanged. The displayed denominator is F = L + K, labelled **GDP income excluding net taxes**. The displayed shares are 100 L / F and 100 K / F. The capital share is computed as the complement of the labour share, including after display rounding, so the pair totals 100%.

GDP at market prices still reconciles to L + K + net production taxes. Taxes less subsidies remain in fiscal accounts, raw exports and the identity audit. Removing their row from the outcome display does not distribute government tax receipts to capital or change production, wages, tax cash flows or market-price GDP. These are income shares, not estimates of labour and capital contributions to GDP growth. Gross capital income includes capital consumption; it is not household disposable capital income.

Negative capital income is retained, so a valid pair may include a labour share above 100% and a negative capital share. When combined income is nonpositive or numerically zero, the shares are undefined and masked in tables/charts. They are not fabricated as a 0%/100% pair.

## Primary education data

Source: World Bank, Human Capital Index 2020, Harmonized Test Scores (HD.HCI.HLOS), Expected Years of School (HD.HCI.EYRS), and Learning-Adjusted Years of School (HD.HCI.LAYS). The World Bank formula is LAYS = expected years × harmonized score / 625. We use the quality factor score / 625 as a learning-outcome proxy, with 625 as the advanced-learning reference. It is neither a literal percentage of curriculum mastered nor an estimate of school effectiveness isolated from family background.

- Catalog: https://datacatalog.worldbank.org/search/dataset/0038030/human-capital-index
- Official workbook: https://datacatalogfiles.worldbank.org/ddh-published-v2/0038030/1/DR0046209/hci_data_september_2020.xlsx
- Official CSV archive: https://databankfiles.worldbank.org/public/ddpext_download/HCI_CSV.zip
- Method and country appendix: https://documents1.worldbank.org/curated/en/456901600111156873/pdf/The-Human-Capital-Index-2020-Update-HumanCapital-in-the-Time-of-covid-19.pdf

Frozen workbook SHA256: `1cf2ddf10b386a5fb8439a3d6294736fe7d8d9ba3b4152a58f2022095ccbbf95`.
Frozen CSV archive SHA256: `f9fe346a4b38d529fc2a3898ddd49371ad623fae8421b8c4a955b214c9b0f3cc`.

Both files and retrieval metadata are in `research/education_quality_candidates/`. The two formats are consistency checks on the same source, not independent estimates. The report download was blocked by the download route; its method and appendix were inspected through web retrieval. That failed raw download is disclosed in the manifest.

`scripts/integrate_education_quality.py` verifies the frozen hashes, matches 87 values (three indicators for 29 national economies) across the workbook and CSV, and checks all 29 LAYS identities. It records each assessment's year and program separately from the 2020 release year. Most underlying assessments are 2018; Cyprus and China use 2015 metadata. These are pre-pandemic anchors for the model's 2023 snapshot, not observations of learning in 2023. Later pandemic losses and subsequent reforms are not inferred.

Rounded examples: Italy 493, United States 512, China 441, Estonia 543, Romania 442. All national presets use their own score. EU27 is a constructed mean using each member's 2023 population aged 0–14 as a pupil-cohort weight. It is not an official EU test score, uses no GDP weights, and cannot reproduce assessment-sample weights. EU learning-adjusted schooling is the weighted mean of national LAYS, not the product of two separately averaged indicators.

China's 441 is the World Bank's **extrapolated national estimate**, with PISA/PIRLS 2015 metadata. The strong results for selected Chinese provinces are not treated as national observations. Additional representativeness uncertainty is explicit. No test-score confidence interval is invented from the unrelated lower/upper bounds of the overall HCI index.

## What the learning data can and cannot change

Public and household-funded education quality controls now open at the national quality factor. A national mean cannot identify causal public/private differences. Assigning that factor to both funding channels is explicitly labelled an **assumed national-anchor allocation fallback**. Household funding is also not identical to private-school ownership. A controlled public/private comparison would require consistent sector coverage and adjustment for pupil background and selection; those estimates are unavailable in this source bundle.

Education resources are the sum of delivered real public and household education spending, each multiplied once by its quality relative to the country's opening anchor. Funding is not counted twice. The resulting change in resources per child enters the existing response rule. Current adult human capital remains the PWT schooling-based measure. This prevents the addition of a new score field from immediately changing GDP or double counting existing skills.

The existing 0.2 resource elasticity and ten-year learning lag remain unestimated assumptions. They were not adjusted to make GDP rise or make this release's paths look better. A score difference alone cannot identify a causal return to education or its GDP effect. Cross-country anchors improve the correspondence of the inputs to measured learning; they do not establish the model's causal accuracy.

Legacy saved quality values and quality-path targets are multiplied by the current country anchor, preserving their previous relative settings (for example, 1.5 becomes a 50% increase over that anchor). Current-version edits and references remain intact. Invalid blank, null and boolean values still fail validation. Reset selects the updated country source preset.

## Executed checks

`npm test` passed the current release suite: education/income, all-country inputs, startup funding, saved settings, event scheduling, counters, financial accounting, trade and external finance.

The education/income report records 129 paths and 5,070 model years, including all 30 presets and paired baseline/reference runs. It compared 1,028,418 old economic row values against a frozen import closure and profiles from published engine 1.20.0, source commit `b7a64f02074e4dcf8842ef053afafff7045bef3e`. The only excluded old fields are the two intentionally rebased income shares. Baselines and equivalent relative education reforms reproduce the old response within 1e-9. The maximum relative accounting residual is 1.12e-14; the maximum two-share gap is zero. With a reform starting in year 4 and the existing ten-year lag, the first human-capital/GDP change is in year 14. Tests also cover signed capital income, undefined shares, funding × quality counted once, source coverage, legacy scenario/reference/path migration and malformed targets.

The separate current all-country suite passed 135 paths and 4,980 years. Existing finance, trade and foreign-position stress tests passed. `scripts/check_global_sources.py` passed its 28 source hashes, 205 PWT field checks, 1,731 European mappings, 1,607 Eurostat source-coordinate checks and 108 independent PWT comparisons. The new learning-source checks are reported separately; they do not inflate that older source count.

Browser checks verify different Italy, US and China learning inputs, source coverage and caveats, a filled relative education experiment, two-row income reporting at opening and later years, and evidence/simulator navigation. Exact observations and proof image paths are retained in `research/browser_qa.json`.

These tests establish definitions, input mapping, deterministic replay, timing and accounting consistency. Reliable long-run macroeconomic forecasts, causal policy effects and separate public/private efficiency remain unestablished. Earlier studies below retain their original scope, input vintage and engine labels.

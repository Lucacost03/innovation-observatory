# Opening-2023 empirical tariffs: all 30 presets

This bundle calibrates the model's single imported-good price wedge to observed customs-duty yields. It covers EU27, every EU member, USA and China, with no country filled from a regional tariff assumption. The preferred rates are in `tariff_inputs_2023.json`; `effectiveTariffRate` is a decimal fraction and `effectiveTariffPercent` is a percentage.

The estimate is customs duties divided by goods imports in the same country, currency and calendar year. This estimates the average duty paid across imported goods, including goods that enter duty free. It is not a statutory most-favoured-nation rate, a tax on services, or a forecast of tariff policy after 2023.

## Preferred sources and extraction

| Presets | Customs-duty numerator | Goods-import denominator | Units |
|---|---|---|---|
| EU27 and 27 members | Eurostat `gov_10a_taxag`, receiver `S212`, transaction `D2121`, year 2023 | Eurostat `ext_lt_intratrd`, annual `MIO_IMP_VAL`, `TOTAL`, year 2023 | EUR million |
| USA | BEA annual NIPA customs duties, `B235RC1A027NBEA`, 2023 observation 81.633 | BEA annual balance-of-payments goods imports, `B1242C1A027NBEA`, 2023 observation 3104.719 | USD billion, converted to million in output |
| China | MOF 2023 nationwide final general-public-budget accounts, customs-duty **actual** column 2590.88 | NBS 2023 statistical communiqué, goods imported 17984.2 | Numerator CNY 100 million; denominator CNY billion; both converted to million |

Sources:

- [Eurostat accrued import duties API](https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10a_taxag?lang=en&unit=MIO_EUR&sector=S212&na_item=D2121&time=2023).
- [Eurostat goods imports by intra/extra-EU partner API](https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/ext_lt_intratrd?lang=en&freq=A&indic_et=MIO_IMP_VAL&sitc06=TOTAL&time=2023).
- [BEA customs duties distributed by FRED](https://fred.stlouisfed.org/series/B235RC1A027NBEA) and [BEA goods imports](https://fred.stlouisfed.org/series/B1242C1A027NBEA).
- [BEA's official explanation of tariffs in national accounts](https://www.bea.gov/help/faq/1476): customs duties enter government taxes; the border value of imports excludes customs duties.
- [MOF nationwide final-account table, published 30 August 2024](https://yss.mof.gov.cn/2023zyjs/202408/t20240830_3942864.htm). The 2915.00 entry is the budget, not the actual. The March execution report's 2590.87 was slightly revised to 2590.88 in the final accounts.
- [NBS 2023 communiqué, published 28 February 2024](https://www.stats.gov.cn/english/PressRelease/202402/t20240228_1947918.html). This denominator uses the stated 2023 release vintage; subsequent annual charts can revise historical trade slightly. Import VAT and excise are excluded from the tariff numerator.

`source_manifest.json` records source URLs, retrieval date, byte sizes and SHA-256 hashes. Numeric source responses are retained intact. All source years are 2023; current WTO profiles can display later or even future tariff schedules and were not substituted for the opening year.

## EU trade and fiscal scope

National trade includes intra-EU goods movements, which are duty free. Each member's preferred rate therefore divides its observed duties by all-partner goods imports. The EU27 aggregate divides EU-wide duties by **extra-EU** goods imports; intra-EU trade is not foreign trade for that aggregate. Applying the EU27 rate to every member's total imports would overstate the tariff wedge. The output retains intra/extra amounts and the extra-EU share for inspection.

The EU numerator is EUR 25,318.6 million; the 27 reported country observations sum to EUR 25,318.8 million, a EUR 0.2 million rounding difference. All member observations, including Malta, are positive. The EU27 extra-EU goods denominator is EUR 2,529,313.4 million.

`S212` identifies duties accruing to EU institutions, **not** national `S13` tax revenue. [ESA2010 chapter 19](https://ec.europa.eu/eurostat/esa2010/chapter/view/19/) paragraphs 19.30 and 19.32 describe gross duties, collection costs and their service treatment. [The Commission's customs own-resources guidance](https://commission.europa.eu/strategy-and-policy/eu-budget/long-term-eu-budget/2021-2027/revenue/own-resources/customs-duties_en) states that members retain 25% as collection costs in 2021–2027. Do not add the full gross import wedge to a member's empirical government tax revenue. Collection compensation and payment to the EU require a separately disclosed fiscal mapping.

For true consolidated EU accounts, EU institutions are EU resident, as described in [Eurostat European accounts methodology](https://ec.europa.eu/eurostat/en/web/sector-accounts/methodology/european-accounts). By contrast, `gov_10a_main` headline EU fiscal series aggregate national general government. A model using those headline totals must disclose that sector boundary rather than quietly assuming EU-institution taxes are already included. See [general-government metadata](https://ec.europa.eu/eurostat/cache/metadata/en/gov_10a_main_esms.htm) and [tax-aggregate metadata](https://ec.europa.eu/eurostat/cache/metadata/en/gov_10a_taxag_esms.htm).

A previously inspected EU-budget cash-outturn table was rejected for tariff calibration: it included negative 2023 Malta cash adjustments and historical UK payments, so dividing net cash by 75% did not give clean current-year duty observations. The accrued Eurostat source avoids that particular timing error.

## WITS cross-check, not the selected default

`wits_tariffs_2023.json` retains all 30 WITS 2023 weighted effectively applied schedule rates. The exact country pages and raw web text snapshots are retained. The legacy WITS code `ROM` maps to `ROU`; `EUN` maps to `EU27`. Every opening-year rate was read from its explicit 2023 page.

The [WITS bilateral tariff technical note](https://wits.worldbank.org/Bilateral-Tariff-Technical-Note.html) says unilateral hikes outside MFN/preferences are excluded and notes product-weight, coverage and ad-valorem-conversion limitations. Thus the USA WITS value 1.36% cannot represent its full observed duty yield. Its observed calendar-year BEA yield is about 2.63%. China's WITS value is 2.17%, versus its observed customs-duty yield about 1.44%. Product composition, exemptions, preferences and actual payment affect these differences. WITS rates should not be silently relabelled as fiscal collection rates.

National EU WITS schedule weights also should not be substituted directly for an observed duty yield on a national trade series including intra-EU trade. The preferred accrued-duty calculation removes the need to guess an EU-country statutory tariff difference.

## Model mapping and limits

- The simulator has one composite imported good. All-product goods data therefore provide an explicit aggregate calibration proxy; imported inputs, consumer goods, capital goods and tariff-line incidence are not separately estimated here.
- No tariff is assigned to imported services. If a future model mixes goods and services into the tariff base, the goods share must be calibrated separately rather than applying these rates to all imports.
- EU and China denominators use merchandise trade statistics; USA uses BEA balance-of-payments goods. Customs ports, residence, freight/insurance valuation, processing trade and transit routing can differ. In particular, a port state's recorded duty does not establish the ultimate household incidence of the duty.
- The denominator covers duty-free imports as well as taxed goods. A low national aggregate rate is not evidence that the country has a low statutory external tariff schedule.
- These are empirical opening-year average yields. A future tariff shock changes an assumed tariff wedge; holding the initial rate fixed is a simulation policy assumption, not an empirical projection.
- Calibration alone does not establish out-of-sample model accuracy or a causal tariff elasticity.

## Reproduction and checks

Run `python research/tariffs_1_30/rebuild.py` in the checkout. It regenerates both input JSON files and the source manifest from retained snapshots. Add `--refresh` to refetch the six numeric primary sources. WITS origin requests returned HTTP 403 to Python, so the 30 source pages were retrieved through public web text lookup and retained separately; refresh them through the same route if desired.

The extractor asserts complete 30-preset coverage, nonmissing positive rates, valid units, the annual 2023 observation, agreement of national intra-plus-extra with all-partner goods imports, EU duties aggregation within publication rounding, and selection of China's actual final-account column. Rebuilding completed successfully on 20 November 2026. No simulator source, build output, Git history or published site was changed by this research task.

#!/usr/bin/env python3
"""Rebuild opening-2023 empirical tariff inputs from retained primary snapshots.

Run `python research/tariffs_1_30/rebuild.py` from the checkout.
Pass --refresh to refetch numeric primary sources before rebuilding.
WITS snapshots were retrieved through the public web text service because its
origin rejected direct Python requests (403); refresh those snapshots separately.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import urllib.request

ROOT = Path(__file__).resolve().parent
SOURCES = {
    'eurostat_duties_accrued_2023.json': 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10a_taxag?lang=en&unit=MIO_EUR&sector=S212&na_item=D2121&time=2023',
    'eurostat_goods_imports_selected_2023.json': 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/ext_lt_intratrd?lang=en&freq=A&indic_et=MIO_IMP_VAL&sitc06=TOTAL&time=2023',
    'fred_customs_annual.html': 'https://fred.stlouisfed.org/data/B235RC1A027NBEA',
    'fred_goods_imports_annual.html': 'https://fred.stlouisfed.org/data/B1242C1A027NBEA',
    'china_2023_final_accounts.html': 'https://yss.mof.gov.cn/2023zyjs/202408/t20240830_3942864.htm',
    'china_2023_nbs_communique.html': 'https://www.stats.gov.cn/english/PressRelease/202402/t20240228_1947918.html',
}
ISO = {'EU27_2020':'EU27','AT':'AUT','BE':'BEL','BG':'BGR','HR':'HRV','CY':'CYP','CZ':'CZE','DK':'DNK','EE':'EST','FI':'FIN','FR':'FRA','DE':'DEU','EL':'GRC','HU':'HUN','IE':'IRL','IT':'ITA','LV':'LVA','LT':'LTU','LU':'LUX','MT':'MLT','NL':'NLD','PL':'POL','PT':'PRT','RO':'ROU','SK':'SVK','SI':'SVN','ES':'ESP','SE':'SWE'}

class Text(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]
    def handle_data(self, data):
        if data.strip(): self.parts.append(data.strip())

class TableRows(HTMLParser):
    def __init__(self):
        super().__init__();self.rows=[];self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='tr':self.row=[]
        elif tag in ('td','th'):self.cell=[]
    def handle_data(self,data):
        if self.cell is not None:self.cell.append(data)
    def handle_endtag(self,tag):
        if tag in ('td','th') and self.cell is not None:
            if self.row is not None:self.row.append(''.join(self.cell).strip())
            self.cell=None
        elif tag=='tr' and self.row is not None:
            self.rows.append(self.row);self.row=None

def html_text(filename):
    parser=Text(); parser.feed((ROOT/filename).read_text()); return ' '.join(parser.parts)

def fetch(filename, url):
    request=urllib.request.Request(url, headers={'User-Agent':'Innovation Observatory empirical tariff audit contact public statistics'})
    body=urllib.request.urlopen(request, timeout=55).read()
    if not body: raise ValueError(f'Empty source response: {url}')
    if filename.endswith('.json'): json.loads(body)
    (ROOT/filename).write_bytes(body)
    return filename,len(body)

def cell(dataset, **selection):
    flat=0
    for dim, size in zip(dataset['id'],dataset['size']):
        categories=dataset['dimension'][dim]['category']['index']
        if isinstance(categories,list): categories={code:i for i,code in enumerate(categories)}
        code=selection.get(dim)
        if code is None:
            if size != 1: raise ValueError(f'Missing selection for {dim}')
            index=0
        else: index=categories[code]
        flat=flat*size+index
    values=dataset['value']
    return values.get(str(flat)) if isinstance(values,dict) else values[flat]

def wits():
    snapshots=json.loads((ROOT/'wits_2023_web_snapshots.json').read_text())
    extra=json.loads((ROOT/'wits_CZE_2023_web_snapshot.json').read_text())
    results=[b['result'] for b in snapshots]+[extra]
    out={}
    header=re.compile(r'([^\n]+) Trade Summary 2023 \| WITS \| Text \(https://wits\.worldbank\.org/CountryProfile/en/Country/([A-Z]+)/Year/2023/Summarytext\)')
    for result in results:
        text='\n'.join(c['text'] for c in result.get('content',[]) if c['type']=='text')
        matches=list(header.finditer(text))
        for n,match in enumerate(matches):
            section=text[match.start():matches[n+1].start() if n+1<len(matches) else len(text)]
            rate=re.search(r'The trade weighted average tariff was ([\d.]+)',section)
            if not rate: continue
            original=match[2]; code={'ROM':'ROU','EUN':'EU27'}.get(original,original)
            out[code]={'year':2023,'weightedAppliedPercent':float(rate[1]),'sourceCode':original,'sourceUrl':f'https://wits.worldbank.org/CountryProfile/en/Country/{original}/Year/2023/Summarytext','scope':'WITS effectively applied product-weighted schedule rate; excludes unilateral hikes outside MFN/preferences'}
    assert len(out)==30, sorted(out)
    return out

def annual_fred(filename):
    match=re.search(r'2023-01-01\s+([\d,.]+)',html_text(filename))
    if not match: raise ValueError(f'2023 annual observation missing from {filename}')
    return float(match[1].replace(',',''))

def build():
    duties=json.loads((ROOT/'eurostat_duties_accrued_2023.json').read_text())
    goods=json.loads((ROOT/'eurostat_goods_imports_selected_2023.json').read_text())
    wits_data=wits(); rows={}
    for geo,code in ISO.items():
        eu=code=='EU27'
        duty=cell(duties,geo=geo)
        intra=cell(goods,geo=geo,partner='EU27_2020')
        extra=cell(goods,geo=geo,partner='EXT_EU27_2020')
        imports=extra if eu else cell(goods,geo=geo,partner='WORLD')
        assert imports>0 and duty>0
        if not eu: assert abs(imports-intra-extra)<0.21, (geo,imports,intra,extra)
        rows[code]={'year':2023,'effectiveTariffRate':duty/imports,'effectiveTariffPercent':100*duty/imports,'dutiesMillion':duty,'goodsImportsMillion':imports,'currency':'EUR','intraEuGoodsImportsMillion':intra,'extraEuGoodsImportsMillion':extra,'extraEuShare':1 if eu else extra/imports,'estimator':'Accrued customs import duties D2121, receiver S212 / goods imports','dutySource':SOURCES['eurostat_duties_accrued_2023.json'],'importSource':SOURCES['eurostat_goods_imports_selected_2023.json'],'importScope':'EU27 extra-EU goods (excludes intra-EU)' if eu else 'National all-partner goods (includes zero-duty intra-EU)','sourceUpdated':{'duties':duties.get('updated'),'imports':goods.get('updated')},'witsScheduleCrossCheck':wits_data[code]}
    usa_duty=annual_fred('fred_customs_annual.html')
    usa_goods=annual_fred('fred_goods_imports_annual.html')
    rows['USA']={'year':2023,'effectiveTariffRate':usa_duty/usa_goods,'effectiveTariffPercent':100*usa_duty/usa_goods,'dutiesMillion':usa_duty*1000,'goodsImportsMillion':usa_goods*1000,'currency':'USD','estimator':'BEA calendar-year federal customs duties / BEA calendar-year BoP goods imports','dutySource':SOURCES['fred_customs_annual.html'],'importSource':SOURCES['fred_goods_imports_annual.html'],'importScope':'All-partner goods, balance-of-payments basis; not the narrow dutiable customs base','witsScheduleCrossCheck':wits_data['USA']}
    mof=TableRows();mof.feed((ROOT/'china_2023_final_accounts.html').read_text())
    customs=[row for row in mof.rows if row and row[0].strip()=='关税']
    if len(customs)!=1 or len(customs[0])!=6:raise ValueError('MOF customs final-account row missing')
    china_duty=float(customs[0][3].replace(',',''))*100 # actual final, not budget, CNY100m to CNY1m
    nbs=html_text('china_2023_nbs_communique.html')
    imports=re.search(r'(?:value of goods imported was|value of goods import was|value of goods imports was)\s*([\d,.]+)\s*billion yuan',nbs)
    if not imports: raise ValueError('NBS goods import statement missing')
    china_goods=float(imports[1].replace(',',''))*1000
    rows['CHN']={'year':2023,'effectiveTariffRate':china_duty/china_goods,'effectiveTariffPercent':100*china_duty/china_goods,'dutiesMillion':china_duty,'goodsImportsMillion':china_goods,'currency':'CNY','estimator':'MOF 2023 national final accounts customs duties / NBS commodity goods imports','dutySource':SOURCES['china_2023_final_accounts.html'],'importSource':SOURCES['china_2023_nbs_communique.html'],'importScope':'All-partner goods, customs/statistical basis; import VAT and excise excluded','witsScheduleCrossCheck':wits_data['CHN']}
    assert len(rows)==30
    assert all(0<r['effectiveTariffRate']<0.10 for r in rows.values())
    state_sum=sum(row['dutiesMillion'] for code,row in rows.items() if code not in ('EU27','USA','CHN'))
    assert abs(state_sum-rows['EU27']['dutiesMillion'])<0.5, (state_sum,rows['EU27']['dutiesMillion'])
    result={'benchmarkYear':2023,'retrievedDate':'2026-11-20','rateUnit':'decimal ad valorem fraction; percent separately provided','measurement':'Observed economy-wide accrued/received customs duty yield on goods imports, not a statutory tariff schedule','limitations':['Composite model import good maps all-product trade data into one price wedge; sector and product heterogeneity are not estimated.','EU national denominator includes duty-free intra-EU imports; EU27 excludes intra-EU imports. Do not multiply a national average by an external-only import base.','Customs clearance, port routing and national-accounts residence can differ, especially for transit hubs. The observed yield is an aggregate calibration proxy.','Goods import valuations differ across reporting systems (EU/China trade statistics versus USA balance-of-payments goods). No service tariffs or VAT are invented.','USA BEA calendar-year receipt/import vintages are current retrieved observations; do not mix federal fiscal-year customs receipts with calendar-year imports.','Year 0 is 2023. These inputs do not represent 2025/2026/2027 tariff changes.','Accrued EU S212 import duties are gross including collection costs; EU member fiscal retention/service compensation and transfers require a separate sector-scope reconciliation.'],'countries':dict(sorted(rows.items()))}
    (ROOT/'tariff_inputs_2023.json').write_text(json.dumps(result,indent=2)+'\n')
    (ROOT/'wits_tariffs_2023.json').write_text(json.dumps(dict(sorted(wits_data.items())),indent=2)+'\n')
    manifest=[]
    for name,url in SOURCES.items():
        raw=(ROOT/name).read_bytes()
        manifest.append({'file':name,'url':url,'retrievedDate':'2026-11-20','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    for name in ('wits_2023_web_snapshots.json','wits_CZE_2023_web_snapshot.json'):
        raw=(ROOT/name).read_bytes();manifest.append({'file':name,'source':'WITS public pages retrieved via web text service; per-country URLs in extracted index','retrievedDate':'2026-11-20','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    (ROOT/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'coverage':len(rows),'EU27DutiesMillion':rows['EU27']['dutiesMillion'],'sumMemberDutiesMillion':state_sum,'effectiveTariffPercent':{k:round(v['effectiveTariffPercent'],6) for k,v in sorted(rows.items())}},indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--refresh',action='store_true');args=parser.parse_args()
    missing={n:u for n,u in SOURCES.items() if args.refresh or not (ROOT/n).exists()}
    if missing:
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for result in pool.map(lambda pair:fetch(*pair),missing.items()):print('Saved',*result)
    build()

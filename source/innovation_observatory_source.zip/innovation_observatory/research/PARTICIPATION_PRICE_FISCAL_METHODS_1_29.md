# Participation, imported costs and fiscal balance — engine 1.29.0

The three requested mechanisms are implemented. **Numerical and accounting checks pass; historical GDP and current-account forecasting accuracy did not improve in this comparison.** Source fidelity and internal consistency do not establish reliable forecasts or causal policy effects.

## Participation and population

The old rule assigned the same participation probability at every age from 15 to 64. Changing the composition within that group could not change its aggregate rate. The new rule uses country-specific 2023 rates for ages 15–24, 25–54 and 55–64. European inputs come from Eurostat EU-LFS `lfsa_argan`, total sex and all citizenship. USA and China use retained ILOSTAT published provider estimates. All 30 presets have complete age bands. Raw coordinates, flags, hashes and extraction scripts are retained in `research/participation_1_29/`.

One common logit intercept reconciles source age rates with the model's cohort weights and opening aggregate. Fitted probabilities remain between 0 and 100%; these adjusted probabilities are modelling proxies. Source rates for ages 65+ are mapped through the existing relative participation control. USA combines an OECD opening aggregate with an ILO age shape; that source difference is explicit.

China's opening participation now uses the ILOSTAT 15–64 estimate of 75.202%, replacing the old 66.1028% national 15+ proxy. It is labelled a published estimate. Opening employment within its labour force remains a separate 95% scenario assumption. Initial GDP and labour force remain normalised to 100; no output, cash or additional opening jobs are created by this reporting correction.

As cohorts age, survive and migrate, their weights change. Within-band future participation is held fixed as a composition-only scenario. All 30 presets consequently show changing aggregate participation. This cross-section does not identify future sex/cohort trends, schooling decisions, cyclical discouragement or policy effects. Fixed population and unchanged policy can correctly give constant participation; no arbitrary noise is added. Age-specific unemployment is not modelled: job allocation retains a common employment share within the active labour force.

Pension eligibility remains distinct from compulsory labour exit and statistical working age, which stays 15–64. The existing pension-reform coefficient shifts the late-career/older participation transition relative to its opening position; this response is an assumption. Human-capital averaging uses the same active-age weights. Existing broad mortality and migration allocation assumptions remain.

## Imported production costs and real trade prices

The real exchange-rate index is nominal currency strength multiplied by domestic producer prices divided by foreign prices. A higher value means real appreciation. The imported-cost index is `100 × foreign price / (currency strength / 100)`. Its annual producer-price contribution is the existing pass-through coefficient times `100 × log(current import cost / previous import cost)`.

This replaces the old arithmetic nominal-FX-only producer term. It includes foreign price changes, treats reciprocal currency moves symmetrically in logs, and does not generate repeated inflation from a constant import-cost level. The resulting domestic producer price enters the same year's real exchange rate and trade conditions. Direct consumer-import prices remain a separate CPI component. Money, velocity, output, central-bank responses and the disclosed annual price guards remain active.

This is an aggregate pricing proxy in a value-added economy, not a complete intermediate input-output ledger. It adds no intermediate purchase, foreign payment or extra GDP. Consumer-import tariffs are not silently extended to firm inputs. OECD `IMGR_INT / PROD` could measure imported intermediates relative to gross output, but the accessed OECD downloads returned 403 and national coefficients could not be verified. Missing values and failed access are retained in `research/import_cost_1_29/evidence.json`. The existing common pass-through, usually 0.10, remains an editable assumption, not a measured national exposure or estimated elasticity. EU27 would require consolidated extra-EU inputs; summing member imports would incorrectly include internal trade.

Primary IMF research supports dampening of competitiveness effects through imported input costs, but does not imply generally neutral current accounts. Trade openness can offset lower elasticities. No zero-current-account or neutrality target is imposed. Demand, trade volumes, technology, foreign income and financing respond jointly. Controlled cases verify partial and complete mathematical price offsets. Large changes that exceed the annual price guard are reported as bounded. Every country also has matched depreciation experiments with and without producer-cost feedback; no effect appears before the shock.

## Government deficit / GDP

Deficit equals total government expenditure minus total revenue, the negative of net lending/borrowing. Dividing by that year's nominal GDP and multiplying by 100 gives the ratio. Positive means deficit; negative means surplus. The existing full fiscal coverage includes current and capital items, with its source scopes, noncash adjustments and assumed private counterparts retained.

Bond issuance, principal repayment and asset purchases are financing transactions. They do not become extra revenue or expenses. Year 0 shows the 2023 annual fiscal reference, which is not paid again into opening stocks. Generic experiments without an opening fiscal reference show unavailable values. The ratio is unavailable when nominal GDP is not positive. The outcomes, chart selector and government budget show the measure.

## Executed validation and limits

450 paths and 11760 annual steps cover every preset. Five paired seeds compare independently frozen 1.28 with 1.29: the first pair runs 120 years and the other four run 12. Each country also has an eight-year legacy replay and four twelve-year import-cost/depreciation comparisons. 57480 shared numeric values replay the frozen engine with the new mechanisms disabled. 3630 network frames preserve valid live, unique, non-self links. Maximum relative accounting residual: 2.353672812205332e-14. GDP, matched capital payments, public/private debt bridges, population, S − I = CA and changes in net foreign assets reconcile.

Using identical revised 2024/25 observations, pooled 29-country GDP RMSE changes 3.7014100060578676 → 3.7455683719927637 percentage points; MAE 2.8674851392728447 → 2.8908795354421257. Current-account RMSE changes 2.752196819477575 → 2.7546238806347842 percentage points of GDP; MAE 2.0708267347591023 → 2.078276478668073. 15 country GDP errors and 21 current-account errors worsen. All misses remain in the report. The overlapping EU27 aggregate is scored separately.

These observations were already examined in earlier work. This is a retrospective diagnostic, not an untouched holdout or independent forecasting validation. Repeated seeds are not additional historical observations. No coefficient or country inclusion was selected against future GDP or current-account values.

The 120-year paths are structural stress tests far beyond the evidence, not forecasts. 4 of 30 end below 1% modelled private debt/GDP; 3 exceed 300% at some point. These are diagnostic cutoffs, not calibrated targets. Weak output, extreme debt, currency bounds and price guards remain visible. Some long-run dynamics remain unrealistic.

Browser exports for USA and China use eight years and ten paired seeds each. Independent Node replays verify aggregate paths, paired effects, 95% intervals and inference. Per-country hashes and numeric comparisons are in `research/participation_1_29/browser_qa_USA.json` and `browser_qa_CHN.json`. Participation endpoints, the China scope correction and opening/final deficit displays were inspected. The current visual proof is `research/browser-participation-costs-1_29.jpg`.

## Primary references

- Eurostat: https://ec.europa.eu/eurostat/databrowser/view/lfsa_argan/default/table?lang=en
- ILOSTAT: exact API URLs and provider coordinates in `participation_age_rates_2023.json`.
- IMF: https://www.imf.org/-/media/files/publications/esr/2019/english/ch2.pdf
- ECB: https://www.ecb.europa.eu/press/economic-bulletin/html/eb201702.en.html
- OECD definitions: https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/trade-in-value-added/tiva-indicators-guide-2023.pdf

Opening source year is 2023; revised data retrieved in 2026 are not a real-time 2023 forecast vintage.

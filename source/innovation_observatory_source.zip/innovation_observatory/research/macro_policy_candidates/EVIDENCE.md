# Monetary policy and education evidence check

Reviewed 12 November 2026. Research notes only; not a calibration or forecast validation. All sources below are primary central-bank publications or original research.

## Requested zero policy-rate floor

Enforcing a 0% minimum is a scenario convention requested by the user. It must not be described as a real-world impossibility: the ECB's official history records a deposit facility rate of -0.10% effective 11 June 2014 and -0.50% effective 18 September 2019. The current model's historical profiles may legitimately contain negative rates before this convention is applied; any clamping must be documented in imported-scenario and backtest reports.

Source: ECB, Official interest rates, historical table.
https://www.ecb.europa.eu/stats/policy_and_exchange_rates/key_ecb_interest_rates/html/index.en.html

## Asset-purchase accounting

A central bank can acquire an existing government bond by creating settlement reserves. If a commercial bank sells, its bond asset falls and reserve asset rises by the same value. If a resident nonbank sells, the seller swaps its bond for a bank deposit and the commercial bank gains matching reserves and a deposit liability. Neither operation directly creates private net wealth or GDP. Broad money rises in the second case, not automatically in the first. Keep those cases distinct; do not count reserves themselves as household spending balances.

Source: Bank of England, Silvana Tenreyro, Quantitative easing and quantitative tightening, 4 April 2023, section QE is an asset swap.
https://www.bankofengland.co.uk/speech/2023/april/quantitative-easing-quantitative-tightening-speech-silvana-tenreyro

The Bank's 2009 explanation places asset purchases alongside very low policy rates and weak nominal spending; purchases can expand narrow money, while nonbank sellers' deposits also expand broad money. Its policy objective is price stability, not direct budget finance. A model trigger involving weak observed inflation and limited remaining rate cuts is defensible as a stated scenario rule; the source does not identify one universal numerical threshold, persistence length, purchase cap or share of GDP.

Source: Bank of England, Quantitative easing, Quarterly Bulletin 2009 Q2.
https://www.bankofengland.co.uk/-/media/boe/files/quarterly-bulletin/2009/quantitative-easing.pdf

## Inflation and money demand

The exchange identity does not establish that every change in a chosen money aggregate causes an equal price change. ECB analysis stresses real money demand, real income, interest rates and the velocity of money. Portfolio reallocations can change liquid aggregates without equivalent changes in consumption. The response to asset purchases depends on willingness and capacity to borrow, lend and spend. A model must therefore retain money, output and velocity channels but should not guarantee that purchases mechanically return inflation to target.

Source: ECB, Isabel Schnabel, Money and inflation, 25 September 2023.
https://www.ecb.europa.eu/press/key/date/2023/html/ecb.sp230925_1~7ad8ef22e2.en.html

## Interest income, reserve interest and remittances

Purchased assets earn income; reserve liabilities can incur policy-linked interest costs. The mismatch between longer-lived bond income and repriced reserve costs can produce losses as rates rise. A realistic extension should account for both legs rather than remitting gross coupon income as net profit. The ECB's profit-allocation arrangements are institutional and not identical to a single-country central bank: ECB profits go to national central banks, while retained earnings and loss carry-forwards can delay distribution.

Source: ECB, FAQs on the ECB's Annual Accounts, sections on interest rates, profit allocation and losses.
https://www.ecb.europa.eu/press/publications/html/ecb.faq_ECB_Annual_Accounts.en.html

The ECB's explainer states that national central banks usually transfer remaining profits to governments after amounts retained. Hence an explicitly simplified national model may remit positive distributable net profits to its Treasury, retaining losses to offset subsequent income, with that simplification disclosed. Do not treat negative central-bank equity as automatic commercial-bank insolvency.

Source: ECB, Profits and losses of the ECB and the euro area national central banks: where do they come from?, updated 19 May 2023.
https://www.ecb.europa.eu/ecb-and-you/explainers/tell-me-more/html/ecb_profits.en.html

## Education spending and quality

Original 2024 US K-12 spending meta-analysis finds that additional per-student public spending can improve educational outcomes, with heterogeneous effects across settings. Its reported average is 0.0316 standard deviations of test scores and 2.8 percentage points of college-going for a $1,000 per-pupil increase sustained for four years. These education outcomes are not annual macro GDP elasticities. The article does not justify applying a universal coefficient to every EU economy or reducing one just because a simulated GDP path looks large.

Source: C. Kirabo Jackson and Claire L. Mackevicius, What Impacts Can We Expect from School Spending Policy? Evidence from Evaluations in the United States, American Economic Journal: Applied Economics 16(1), 2024, pp. 412–446, DOI 10.1257/app.20220279.
https://www.aeaweb.org/articles?id=10.1257/app.20220279

The earlier working paper finds little evidence of diminishing returns across the baseline spending levels it studies. This does not prove linear returns at all funding levels or in every country. It does mean a newly invented damping cap should not be attributed to this paper.

Source: Jackson and Mackevicius, The Distribution of School Spending Impacts, NBER Working Paper 28517 (2021, revised July 2021).
https://www.nber.org/papers/w28517

## Implications for this model (inferences, not source estimates)

1. `Society.closeEducation` already uses delivered public and private spending, deflates it to real resources, divides by the number of children, multiplies each spending flow by its quality assumption once, then applies an assumed 0.2 elasticity and the model's cohort lag. Spending dependence therefore exists; exposing a funding index or factorizing the formula for clarity can improve interpretation without changing the mechanism.
2. Do not multiply the resulting resource-dependent quality into the same resources a second time. That would double the funding channel.
3. Leave the education elasticity, cohort lag and production multiplier unchanged unless empirical comparison supports a change. Education-on/off and quality/spending sensitivities isolate contribution; they do not establish forecast accuracy.
4. Compare any candidate coefficient against held-out observed outcomes with the same timing and country definitions, reporting errors and uncertainty. Lags imply that a two-year GDP backtest cannot identify a ten-year schooling-to-worker effect. A long-run scenario growing rapidly may instead be driven by innovation, adoption, investment or financing assumptions.
5. QE tests should verify exact balance-sheet changes, no initial GDP/net-wealth creation, finite eligible securities, stock redemption, both reserve and coupon interest, prior-information timing, and continued S-I=CA and current-account/NFA reconciliation. Such tests improve internal correctness but do not by themselves validate inflation predictions.

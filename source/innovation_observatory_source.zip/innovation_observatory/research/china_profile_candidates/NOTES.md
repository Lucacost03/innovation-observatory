China opening-year candidate bundle — 2023

This folder contains candidate research inputs only. No application/model files were edited. `candidate_observations.json` has72 observations/derivations with named source, unit, year, vintage, definition caveat, and explicit missing-data flags. `manifest.json` hashes the files. Run `build_candidates.py` to rebuild observations; run `refresh_sources.py` first to refetch primary raw sources. `fetch_candidate.py` records the attempted24-indicatorWDI retrieval; all timed out, so no fabricated WDI values enter the observations.

Use the2023 UN national-accounts current-CNY components with UNGDP129427.17bnCNY. C_HH51212.06bn, C_G22247.42bn, GCF53233.02bn, GFCF52359.03bn, inventories874bn, X25337.008655746bn, M22544.355986729bn. The source has a −57.982669017bn discrepancy GDP−(C+G+GCF+X−M), about−0.0448%GDP. Keep an explicit statistical-discrepancy/reconciliation line if accounting requires equality. Do not silently change observed trade or consumption. GCF and GFCF differ. The UN metadata distinguishes nationalofficial components from supplementary estimates.

NBS2023 preliminary GDP126058.2bn is a different vintage from the UN2026upload129427.17bn. NBS deposit/GDP or R&D/GDP derivations should use their own same-releaseGDP denominator, or be labelled as mixed-vintage if intentionally rebased. All deposits137876.5bn household/81795.9bn NFC include RMB and foreign currencies. They are not complete financial-sector or household balance sheets. Medium/long consumption loans are not all mortgages.

The NBS communiqué footnote6 provides0–14population230.63m. Therefore15+population1179.04m, nationalemployment740.41m gives a62.7977% age15+employment proxy. Do not present this as observed15–64employment. Urban surveyed unemployment5.2% is urban-only and cannot complete a whole-China labourforce identity. National participation and consistent-coverage unemployment remain missing; use clearly identified assumptions rather than copy EU values. Endyearpopulation1409.67m,65+216.76m, crude birth/death6.39/7.87perthousand.

PBOC yearend2023policy instrument is the seven-day reverse-repo1.80%, effective2023-08-15. One-yearLPR3.45% is a lending-quote rate and is not interchangeable. AnnualCPI inflation0.2%, M2growth9.7%, M2stock292300bnCNY.

FinalR&D enterprise-performed2592.22bnCNY, total3335.71bn;2.65%officialGDPintensity. Performance and funding are different dimensions: government-institute-performed385.63bn is not government-fundedGERD. Parent handles PWTcapital/TFP/human-capital and foreign-pool calculations.

Chinese general public-budget revenue/spending21678.4/27457.4bn is a partialbudget account, not completegeneral-governmentS13. Itseducation4124.2bn, health2239.3bn and socialsecurity/employment3988.3bn are not directly comparable to ESA/COFOGP3consumption. They are partial empirical references only. Separate finaleducationstatistics give fiscaleducation5043.947bn=4.00%GDP, broadly defined across budget types and SOEschool appropriations. The all-source−fiscaleducation residual is not household private-education consumption. MOE raw download403; its officialpage was verified through websearch but raw could not be frozen.

Health preliminary government2414.79bn is narrower than general-governmenthealth including compulsorysocialinsurance; NHC's socialhealth4167.68bn includes the latter. Neither can directly set general-governmenthealthCOFOGP3 without a coverage reconciliation. Publicpensionbenefits/privatepensionassets remain flagged unverified rather than using inconsistent central-only or socialsecuritybudget numbers.

IncomeGini0.465 is NBSpercapitadisposableincome reproduced in UNICEFChina2024Atlas (websearchverified, raw403). It is not an EU-SILCequivalised income statistic. NBSincomequintile means are provided for a separately labelled distribution calibration; householdquintiles/percapitaincome do not establishpersonweights. WealthGini remains unverified.

`mof_statecapital_expenditure_2023.html` was an investigated URL that proved to be local-governmentstatecapitaloperations, not national socialinsurance expenditure. It is deliberately excluded from candidateobservations. It must never be used as a pension total.

No model-accuracy improvement is established by this bundle. It improves empirical coverage and transparency; root must still run model/accounting checks and separately label assumptions and scenarios.

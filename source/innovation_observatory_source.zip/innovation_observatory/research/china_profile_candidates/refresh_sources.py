#!/usr/bin/env python3
"""Refetch frozen primary sources and emit hashes; no app/model edits.
Usage: python research/china_profile_candidates/refresh_sources.py
Then: python research/china_profile_candidates/build_candidates.py
A remote403/timeout is preserved in refresh_manifest.json, never converted to zero.
"""
from pathlib import Path
import json,hashlib,urllib.request,concurrent.futures
P=Path(__file__).resolve().parent
C=json.loads((P/'candidate_observations.json').read_text())
def get(kv):
 k,s=kv; r={'source':k,'url':s['url']}
 try:
  data=urllib.request.urlopen(urllib.request.Request(s['url'],headers={'User-Agent':'InnovationObservatoryResearch/1.0'}),timeout=30).read()
  fn=s.get('file') or k+'_source.html';(P/fn).write_bytes(data)
  r.update(file=fn,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
 except Exception as e:r['error']=str(e)
 return r
results=list(concurrent.futures.ThreadPoolExecutor(6).map(get,C['sources'].items()))
(P/'refresh_manifest.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))

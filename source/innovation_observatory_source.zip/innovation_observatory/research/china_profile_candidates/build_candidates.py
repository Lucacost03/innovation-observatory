#!/usr/bin/env python3
"""Build China2023 candidate observations from the frozen official-source transcription.
This creates research candidates only; it never changes application/model files.
"""
import json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
S={
 'nbs':dict(url='https://www.stats.gov.cn/english/PressRelease/202402/t20240228_1947918.html',file='nbs_communique_2023.html',vintage='2024-02 preliminary2023 communiqué'),
 'rd':dict(url='https://www.stats.gov.cn/english/PressRelease/202410/t20241014_1956904.html',file='nbs_rd_2023.html',vintage='2024-10 final2023R&Dcommunique'),
 'un':dict(url='https://data.un.org/Data.aspx?d=SNAAMA&f=grID%3A101%3BcurrID%3ANCU%3BpcFlag%3A0%3BcrID%3A156&q=china',file='un_nationalaccounts_2023.html',vintage='UNSNAAMAJanuary2026upload, viewed2026-11-13'),
 'moe':dict(url='https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html',file=None,vintage='2024-12-19final2023education'),
 'mof':dict(url='https://bgt.mof.gov.cn/zhuantilanmu/rdwyh/ysbgjyszx/202402/t20240201_3928009.htm',file='mof_budget_2023.html',vintage='2024-02executionreport'),
 'nhc':dict(url='https://www.gov.cn/lianbo/bumen/202408/P020240829729470466631.pdf',file='nhc_health_2023.pdf',vintage='2024-08preliminary2023health'),
 'rate':dict(url='https://english.www.gov.cn/news/202308/16/content_WS64dc3d10c6d0868f4e8de990.html',file='pbc_rate_2023_gov.html',vintage='2023-08-16PBOCoperationofficialgovernmentrelease'),
 'gini':dict(url='https://www.unicef.cn/media/28801/file/%E4%B8%AD%E5%9B%BD%E5%84%BF%E7%AB%A5%E5%8F%91%E5%B1%95%E6%8C%87%E6%A0%87%E5%9B%BE%E9%9B%862024.pdf',file='unicef_china_inequality_2024.pdf',vintage='2024ChinaAtlasofChildDevelopmentIndicators, NBSunderlyingdata')
}
O=[]
def add(k,v,u,s,n='',status='observed',**extra):
 O.append(dict(key=k,value=v,unit=u,year=2023,status=status,source=s,note=n,**extra))
for k,v in dict(gdpPreliminary=126058.2,householdDeposits=137876.5,nonfinancialFirmDeposits=81795.9,allFinancialInstitutionDeposits=289913.2,allFinancialInstitutionLoans=242239.6,householdConsumptionLoans=57943.8,householdShortTermConsumptionLoans=10354.1,householdMediumLongConsumptionLoans=47589.7).items():
 add(k,v,'billionCNY','nbs','Yearendstock exceptGDP. These deposits include RMBandforeigncurrencies; broad loan totals are not domesticbusiness-only loans.')
for k,v in dict(gdp=129427.17,householdConsumption=51212.06,governmentFinalConsumption=22247.42,grossCapitalFormation=53233.02,grossFixedCapitalFormation=52359.03,inventoryChange=874.0,exports=25337.008655746,imports=22544.355986729).items():
 add(k,v,'billionCNY','un','Currentprices;China mainland. Generalgovernmentconsumption is not total governmentspending; GFCF includes acquisitions less disposals of valuables.')
for k in ['householdConsumption','governmentFinalConsumption','grossCapitalFormation','grossFixedCapitalFormation','inventoryChange','exports','imports']:
 r=next(x for x in O if x['key']==k);add(k+'GDP',100*r['value']/129427.17,'percentGDP','un','DerivedwithsameUNrevisedGDPvintage',status='derived')
res=129427.17-(51212.06+22247.42+53233.02+25337.008655746-22544.355986729)
add('nationalAccountsDiscrepancy',res,'billionCNY','un','GDP−(C+G+GCF+X−M); preserve explicitly. UN imports/exports use supplementaryestimation; do not silently overwriteobservations to forceexactidentity.',status='derived')
for k,v,u in [ ('initialInflation',.2,'percentannualCPI'),('producerInflation',-3.,'percentannualPPI'),('population',1409.67,'millionpersons'),('populationAge0to14',230.63,'millionpersons'),('populationAge16to59',864.81,'millionpersons'),('populationAge60plus',296.97,'millionpersons'),('populationAge65plus',216.76,'millionpersons'),('employed',740.41,'millionpersons'),('urbanUnemployment',5.2,'percenturbanlaborforceannualaverage'),('birthRate',6.39,'perthousandpopulation'),('deathRate',7.87,'perthousandpopulation'),('naturalPopulationGrowth',-1.48,'perthousandpopulation'),('broadMoneyM2',292300,'billionCNY'),('broadMoneyM2Growth',9.7,'percentannual'),('narrowMoneyM1',68100,'billionCNY'),('currencyM0',11300,'billionCNY'),('disposableIncomePerCapita',39218,'CNYperperson'),('medianDisposableIncomePerCapita',33036,'CNYperperson'),('householdConsumptionPerCapita',26796,'CNYperperson') ]:
 add(k,v,u,'nbs','NBSendyearpopulation andemployment. Urban unemployment does not cover national laborforce; never useasnational unemployment. Householdsurveyincome/consumption differsSNAsectoraccounts.')
add('incomeQuintileMean',[9215,20442,32195,50220,95055],'CNYperperson','nbs','Surveyhouseholds ordered bypercapitadisposableincome; not equivaliseddisposableincome. Quintiles should not be interpreted as householdcountweights forLorenzpersondistribution withoutweights.')
add('populationAge15plus',1409.67-230.63,'millionpersons','nbs','Populationtotalminusage0–14footnote6',status='derived')
add('employmentPopulationRatioAge15plusProxy',100*740.41/(1409.67-230.63),'percentpopulationage15plus','nbs','Nationalemployment / endyearpopulation15+; a coverage-consistent proxy only, not observedemployment15–64. Employmentseriesmayincludeemployeesoutsideconventionalworkingage.',status='derived_proxy')
add('populationAge15to64Share',100*(1409.67-230.63-216.76)/1409.67,'percenttotalpopulation','nbs','DerivedfromNBS0–14and65+counts; do not divideall-ageemploymentbythisrestricteddenominator.',status='derived')
add('populationAge65plusShare',100*216.76/1409.67,'percenttotalpopulation','nbs',status='derived')
add('childPopulationShare',100*230.63/1409.67,'percenttotalpopulation','nbs','0–14',status='derived')
add('policyRate',1.8,'percentannual','rate','Seven-dayreverse-repoinstrument, effective2023-08-15; yearendpolicyinstrumentobservation. NOTone-yearLPR3.45%.')
for k,v in dict(totalRD=3335.71,businessPerformedRD=2592.22,governmentInstitutePerformedRD=385.63,higherEducationPerformedRD=275.33).items():add(k,v,'billionCNY','rd','Final2023R&D; performanceandfundingare distinct. GovernmentinstituteperformedRD is not governmentfundedRD.')
add('rdGDP',2.65,'percentGDP','rd','Officialfinalratio; GDPvintage differslaterUNGDP')
add('businessPerformedRDGDPProxy',100*2592.22/126058.2,'percentGDP','rd','BERD/GDP derivedwithsameNBSGDPvintage; not BERD/businesssales',status='derived')
for k,v in dict(educationAllSources=6459.504,fiscalEducation=5043.947,generalPublicBudgetEducationFinal=4081.392).items():add(k,v,'billionCNY','moe','Broadeducationfundingaccount, NOTESA/COFOGP3. RawHTTP403; officialwebsearchverifiedtranscription. Fiscalincludesmultiplebudgets/SOEschoolappropriations.')
add('fiscalEducationGDP',4.00,'percentGDP','moe','Officialfiscaleducationfunding/GDP. Broadscope; usewithlabel.')
for k,v in dict(generalPublicBudgetRevenue=21678.4,generalPublicBudgetSpending=27457.4,generalPublicBudgetTaxRevenue=18112.9,generalPublicBudgetEducation=4124.2,generalPublicBudgetHealth=2239.3,generalPublicBudgetSocialSecurityEmployment=3988.3,generalPublicBudgetScienceTechnology=1082.3).items():add(k,v,'billionCNY','mof','PARTIALnationalgeneralpublicbudget; NOTtotalgeneralgovernment/S13. Includescapital/transferitems; no directP3comparison.')
for k,v in dict(totalHealth=9057.58,governmentHealth=2414.79,socialHealth=4167.68,personalHealth=2475.11).items():add(k,v,'billionCNY','nhc','Preliminaryhealthaccounts. Socialhealthincludescompulsorysocialinsurances; governmenthealth is narrowerthanGHEDgeneralgovernmenthealth. NotP3COFOG.')
add('incomeGini',.465,'coefficient0to1','gini','OfficialNBSdisposablepercapitahouseholdincomeGini reproducedbyUNICEFChina. Different equivalisations/surveys mean not directly interchangeablewithEU-SILC.')
missing=['nationalLaborForceParticipationAge15to64','nationalEmploymentPopulationAge15to64','nationalUnemploymentSameCoverage','netMigration','generalGovernmentRevenueMatchedScope','generalGovernmentSpendingMatchedScope','generalGovernmentDebtMatchedScope','financialSectorCompleteBalanceSheet','householdHousingStockMarketValue','businessLoanOnlyStock','mortgageStock','privatePensionAssets','publicPensionBenefits','privateEducationHouseholdConsumption','wealthGini','foreignHouseholdPortfolioWeight','effectiveFinancialIncomeTax','effectiveWealthTax']
obj=dict(country='CHN',openingYear=2023,retrieved='2026-11-13',scope='China mainland; excludesHongKongMacaoTaiwan',sources=S,observations=O,missing=[dict(key=k,status='not_verified',policy='Useanexplicitplausiblescenarioassumption/proxyonly;nevercopyEuropeanobservationandlabelChinaempirical') for k in missing],integrationWarnings=['NBSpreliminaryGDP126058.2bnCNYandUNrevisedGDP129427.17bnCNYmustnotbesilentlymixed.','UNcomponentscarry−57.982669017bnCNYdiscrepancy; retainreconciliationseparately.','TheNBSage15+employmentproxyisnotage15–64employment; urban5.2%unemploymentcannotcompleteanationallaborforceidentity.','ChineseMOFgeneralpublicbudgetreferencesarepartialfiscalaccounts; donotmarkasmatchedS13.','ForeignTFPcapital/humancapitalPWTandFXpoolsarebeinghandledbyparent.'])
(P/'candidate_observations.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
manifest={'retrieved':'2026-11-13','files':[]}
for f in sorted(P.iterdir()):
 if f.is_file() and f.name!='manifest.json':manifest['files'].append(dict(file=f.name,bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'{len(O)}observations; {len(missing)}explicitmissingfields; discrepancy={res:.9f}bnCNY')

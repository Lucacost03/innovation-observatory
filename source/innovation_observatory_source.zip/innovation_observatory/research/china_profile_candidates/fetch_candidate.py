from pathlib import Path
import json,urllib.request,hashlib,time,datetime,concurrent.futures
OUT=Path(__file__).resolve().parent
indicators=['NY.GDP.MKTP.CN','NE.CON.PRVT.CN','NE.CON.GOVT.CN','NE.GDI.FTOT.CN','NE.GDI.TOTL.CN','NE.EXP.GNFS.CN','NE.IMP.GNFS.CN','SP.POP.TOTL','SP.POP.0014.TO.ZS','SP.POP.1564.TO.ZS','SP.POP.65UP.TO.ZS','SP.DYN.CBRT.IN','SP.DYN.CDRT.IN','SM.POP.NETM','SL.EMP.TOTL.SP.ZS','SL.TLF.CACT.ZS','SL.UEM.TOTL.ZS','FP.CPI.TOTL.ZG','GB.XPD.RSDV.GD.ZS','SE.XPD.TOTL.GD.ZS','SH.XPD.GHED.GD.ZS','GC.DOD.TOTL.GD.ZS','GC.REV.XGRT.GD.ZS','GC.XPN.TOTL.GD.ZS']
def fetch(k):
 url='https://api.worldbank.org/v2/country/CHN/indicator/'+k+'?date=2023&format=json&per_page=100';p=OUT/('wdi_'+k+'.json')
 try:
  raw=urllib.request.urlopen(url,timeout=25).read();p.write_bytes(raw);a=json.loads(raw);v=a[1][0] if len(a)>1 and a[1] else {};return k,{'url':url,'file':p.name,'sha256':hashlib.sha256(raw).hexdigest(),'response':v,'updated':a[0].get('lastupdated') if isinstance(a[0],dict) else None}
 except Exception as e:return k,{'url':url,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=8)as pool:r=dict(pool.map(fetch,indicators))
(OUT/'wdi_manifest.json').write_text(json.dumps({'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'indicators':r},indent=2))
print(json.dumps({k:v.get('response',{}).get('value',v.get('error')) for k,v in r.items()},indent=2))

"""Transform an independently downloaded, verified OECD TiVA SDMX CSV.

No network guessing or automatic model writeback. Run with the CSV's actual
metadata column names/codes, inspecting its official DSD first. The script
requires both matching USD level observations; missing countries remain missing.
A regional EU row must be a consolidated source aggregate, not member sum.
"""
import argparse,csv,json
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('csv');p.add_argument('--year',required=True);p.add_argument('--activity',required=True)
p.add_argument('--partner',default='W');p.add_argument('--unit',required=True)
p.add_argument('--country-col',default='REF_AREA');p.add_argument('--indicator-col',default='MEASURE')
p.add_argument('--industry-col',default='ACTIVITY');p.add_argument('--partner-col',default='COUNTERPART_AREA')
p.add_argument('--unit-col',default='UNIT_MEASURE');p.add_argument('--year-col',default='TIME_PERIOD')
p.add_argument('--value-col',default='OBS_VALUE');p.add_argument('--out',required=True)
a=p.parse_args();rows={}
with open(a.csv,encoding='utf-8-sig',newline='')as f:
 reader=csv.DictReader(f)
 for c in [a.country_col,a.indicator_col,a.industry_col,a.partner_col,a.unit_col,a.year_col,a.value_col]:
  if c not in reader.fieldnames:raise ValueError(f'Missing metadata column {c}; inspect the CSV and official DSD. Available: {reader.fieldnames}')
 for r in reader:
  if r[a.year_col]!=a.year or r[a.industry_col]!=a.activity or r[a.partner_col]!=a.partner or r[a.unit_col]!=a.unit:continue
  indicator=r[a.indicator_col]
  if indicator not in ['IMGR_INT','PROD']:continue
  key=r[a.country_col]
  if indicator in rows.setdefault(key,{}):raise ValueError(f'Duplicate uncollapsed dimensions for {key}/{indicator}; inspect metadata rather than sum.')
  rows[key][indicator]=float(r[a.value_col])
result={k:{'year':int(a.year),'importedIntermediate':v['IMGR_INT'],'grossOutput':v['PROD'],'inputCostExposure':v['IMGR_INT']/v['PROD']} for k,v in rows.items()if 'IMGR_INT'in v and v.get('PROD',0)>0}
for k,v in result.items():
 if not 0<=v['inputCostExposure']<=1:raise ValueError(f'{k} ratio outside0–1. Check units, aggregate codes and data scope.')
Path(a.out).write_text(json.dumps({'inputCSV':str(Path(a.csv).name),'selection':vars(a),'countries':result,'status':'Source ratios only; no estimated price pass-through or causal response.'},indent=2)+'\n')
print(f'Extracted {len(result)} matched country aggregates; missing countries not imputed.')

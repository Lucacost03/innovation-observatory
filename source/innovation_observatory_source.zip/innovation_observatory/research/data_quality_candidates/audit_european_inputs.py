"""Read-only, offline audit of 28 frozen European presets.

Run from any directory: python3 research/data_quality_candidates/audit_european_inputs.py
Only outputs within this script's directory. Passing arithmetic is NOT forecast validation.
"""
from pathlib import Path
from collections import Counter
from functools import lru_cache
import json, math, statistics, hashlib, os

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DATA, RAW = ROOT/'dist/data', ROOT/'research/source_snapshots'
read = lambda p: json.loads(p.read_text())
profiles = [p for p in read(DATA/'profiles.json') if p['code'] not in ['USA','CHN']]
employment = {r['code']:r for r in read(DATA/'employment_population_benchmarks.json')['countries']}
capital = read(DATA/'capital_input_benchmarks.json')
households = read(DATA/'household_benchmarks.json')
population = read(DATA/'population_education_benchmarks.json')['countries']
housing = read(DATA/'housing_pension_benchmarks.json')['countries']
social = read(DATA/'social_spending_benchmarks.json')['countries']
checks, rawchecks, corrections, metadata = [], [], [], []

def check(p, key, expected, formula, actual=None, tolerance=1e-9):
    actual = p['params'].get(key) if actual is None else actual
    good = isinstance(actual,(int,float)) and math.isclose(actual,expected,rel_tol=tolerance,abs_tol=tolerance)
    checks.append({'country':p['code'],'key':key,'actual':actual,'expected':expected,
                   'status':'matches_mapping' if good else 'mapping_mismatch','formula':formula})
    return good

@lru_cache(None)
def rawload(stem):
    path=RAW/(stem+'.json')
    if stem=='employment_population':path=ROOT/'research/macro_employment_candidates/employment_2023.json'
    return read(path) if path.exists() else None

def verify_component(country,key,c):
    """Check source coordinates against frozen Eurostat JSON-stat, when present."""
    if not isinstance(c,dict):return
    source=c.get('dataset') or c.get('source')
    selection=c.get('selection',c)
    if not source or not isinstance(selection,dict) or 'value' not in c: return
    for stem in [source,source+'_2023',source+'_2021']:
        d=rawload(stem)
        if not d or 'id' not in d or not all(k in selection for k in d['id']):continue
        try:
            ix=0
            for dim,size in zip(d['id'],d['size']):
                ix=ix*size+d['dimension'][dim]['category']['index'][selection[dim]]
            values=d.get('value',{})
            value=values[ix] if isinstance(values,list) else values.get(str(ix))
            if value is None: continue
            good=math.isclose(c['value'],value,rel_tol=1e-10,abs_tol=1e-10)
            rawchecks.append({'country':country,'key':key,'source':stem,
                'selection':{k:selection[k] for k in d['id']},'componentValue':c['value'],
                'frozenSourceValue':value,'status':'matches_frozen_source' if good else 'source_mismatch'})
            return
        except (KeyError,IndexError,TypeError):continue

for p in profiles:
    code,x,prov=p['code'],p['params'],p['provenance']
    b=employment[code]
    check(p,'employmentRate',100*b['employmentPopulationPct']/b['participationPct'],
          '100 × published EMP_LFS/PC_POP ÷ ACT/PC_POP; both sex T, ages 15–64, 2023')
    check(p,'initialParticipationRate',b['participationPct'],'Published ACT / PC_POP, ages 15–64')
    for c in b['components']:verify_component(code,'employmentRate',c|{'dataset':'employment_population'})
    source=p.get('sourceValues',{})
    for key,expected in [('capitalOutputRatio',source['rnna']/source['rgdpna']),
                         ('laborShare',100*source['labsh']),('tfpCapitalShare',100*(1-source['labsh'])),
                         ('depreciation',100*source['delta'])]:
        check(p,key,expected,'Frozen PWT sourceValues; EU27 uses documented weighted member aggregate')
    comps={c['na_item']:c['value'] for c in prov['governmentShare']['components']}
    gdp=comps['B1GQ'];domestic=sum(comps[k] for k in ['P31_S14_S15','P3_S13','P51G'])
    check(p,'governmentShare',100*comps['P3_S13']/domestic,'P3_S13 / (household consumption + P3_S13 + GFCF), percent; proxy, not GDP share')
    check(p,'initialGovernmentShare',100*comps['P3_S13']/domestic,'Same opening government demand normalization')
    check(p,'investmentShare',100*comps['P51G']/domestic,'GFCF / domestic-use denominator, percent')
    for key in ['initialPublicDebt','householdWealth','firmLiquidity','governmentDeposit','initialPublicEquity']:
        c=prov[key].get('components',[])
        if len(c)==1:check(p,key,c[0]['value'],'Direct mapped source percentage of GDP; condensed model balance sheet is a proxy')
    for key in ['initialIncome','publicResearch','rdBusiness']:
        c=prov[key].get('components',[])
        if c:check(p,key,100*c[0]['value']/gdp,'Source currency flow / same-year nominal GDP × 100')
    c=prov['initialUtilization'].get('components',[])
    if len(c)==4:check(p,'initialUtilization',statistics.mean(v['value'] for v in c),'Mean of four annual industrial capacity readings, not whole-economy utilization')
    c=prov['consumptionTax'].get('components',[])
    if len(c)==2:check(p,'consumptionTax',100*c[0]['value']/(c[1]['value']-c[0]['value']),'VAT / household consumption net of VAT; fiscal proxy, not statutory rate')
    for key in ['publicGrantShare','rdLaborShare']:
        c=prov[key].get('components',[])
        if len(c)==2:check(p,key,100*c[0]['value']/c[1]['value'],'Matched numerator / denominator ×100; same source year and universe')
    c=prov['loanSpread'].get('components',[])
    if len(c)==12:check(p,'loanSpread',statistics.mean(v['value'] for v in c)-x['initialPolicyRate'],
                        'Mean of twelve already-annualized monthly NFC stock quotes − opening policy rate')
    c=prov['bondRate'].get('components',[])
    if len(c)==2:check(p,'bondRate',100*c[0]['value']/(gdp*c[1]['value']/100),'Interest expenditure / end-year government gross debt ×100; not current market yield')
    c=prov['incomeSupport'].get('components',[])
    if c:check(p,'incomeSupport',100*(c[0]['value']-(c[1]['value'] if len(c)>1 else 0))/gdp,'Cash benefits net of separately modeled unemployment cash benefits / GDP')
    c=prov['unemploymentReplacement'].get('components',[])
    if len(c)==2 and c[0].get('na_item')=='D62PAY_GF1005':
        target=100*c[0]['value']/gdp
        unemployed=100-x['employmentRate']
        expected=100*target/(x['laborShare']/x['employmentRate']*unemployed)
        if not check(p,'unemploymentReplacement',expected,
              '100 × unemployment cash benefit/GDP percentage ÷ (laborShare / employedLFpercentage × unemployedLFpercentage)'):
            actual=x['unemploymentReplacement']/100*x['laborShare']/x['employmentRate']*unemployed
            corrections.append({'country':code,'key':'unemploymentReplacement','oldValue':x['unemploymentReplacement'],
                'candidateValue':expected,'sourceBenefitGDPpct':target,'modelBenefitGDPpct':actual,
                'relativeCashFlowErrorPct':100*(actual/target-1),'reason':'Employment migrated from15–74to15–64 but benefit-denominator calibration was not refreshed.'})
    for key in ['entryRate','exitRate']:
        c=prov[key].get('components',[])
        if len(c)==1:
            check(p,key,c[0]['value'],'Enterprise births or deaths / active-enterprise population, annual%; broad business economy, not venture-financed firms')
            verify_component(code,key,c[0]|{'dataset':'business_demography'})
    c=prov['entrantSize'].get('components',[])
    if c:
        check(p,'entrantSize',c[0]['value']/x['entryRate'],
              'Employment share in enterprise births / enterprise birth-rate; assumes common capital/labor scale')
        verify_component(code,'entrantSize',c[0]|{'dataset':'business_demography_sizes'})
    groups=prov['firmSizeDispersion'].get('components',[])
    if len(groups)==4:
        total=sum(g['count'] for g in groups);mean=sum(g['count']*math.log(g['mean']) for g in groups)/total
        sd=math.sqrt(sum(g['count']*(math.log(g['mean'])-mean)**2 for g in groups)/total)
        check(p,'firmSizeDispersion',sd,'Count-weighted SD of log class-mean employment; grouped descriptive proxy for capital distribution')
        for g in groups:
            for c in g['components']:verify_component(code,'firmSizeDispersion',c|{'dataset':'business_demography_sizes'})
    groups=prov['exitSizeSensitivity'].get('components',[])
    if len(groups)>=2:
        total=sum(g['count'] for g in groups)
        xb=sum(g['count']*math.log(g['mean']) for g in groups)/total
        yb=sum(g['count']*math.log(-math.log1p(-g['deathRate']/100)) for g in groups)/total
        slope=-sum(g['count']*(math.log(g['mean'])-xb)*(math.log(-math.log1p(-g['deathRate']/100))-yb) for g in groups)/sum(g['count']*(math.log(g['mean'])-xb)**2 for g in groups)
        check(p,'exitSizeSensitivity',slope,'Negative count-weighted log-hazard/log-size slope; descriptive correlation, not causal identification')
    for key,expected in population[code]['params'].items():
        check(p,key,expected,'Same frozen population/education benchmark; empirical inputs, future behavioral effects remain assumptions')
    hp=housing[code]
    for key,field in [('publicPensionGDP','publicOldAgeCashGDP'),('initialHousingGDP','housingStructuresGDP'),
             ('initialMortgageGDP','mortgageDebtGDP'),('mortgagedOwnerShare','mortgagedOwnerPopulationShare'),
             ('initialPrivatePensionGDP','privatePensionGDP'),('mortgageOpeningRate','mortgageStockRate')]:
        check(p,key,hp[field]['value'],'Matched frozen housing/pension benchmark; preserve benchmark year and fallback flag')
    check(p,'mortgageSpread',hp['mortgageNewRate']['openingPolicySpread'],'Annualized new-loan quote − opening policy rate')
    check(p,'residentialInvestmentShare',100*hp['housingInvestmentShareOfGFCF']['value'],'Dwelling GFCF / total GFCF, convert fraction to percent')
    if not hp['privatePensionBenefitsGDP'].get('fallback') and not hp['privatePensionGDP'].get('fallback'):
        check(p,'privatePensionContributionRate',100*hp['privatePensionContributionsGDP']['value']/x['laborShare'],
              'Actual employer + household cash pension contributions/GDP ÷ model wage bill/GDP ×100; source2021, not2023')
        check(p,'privatePensionWithdrawalRate',100*hp['privatePensionBenefitsGDP']['value']/hp['privatePensionGDP']['value'],
              'Private cash benefits/entitlements ×100; source2021, not2023')
    check(p,'publicPensionContributionShare',min(100,100*x['publicPensionGDP']/(x['laborShare']*x['incomeTax']/100)),
          'Old-age cash benefits / model worker withholding, capped100%; budget earmark proxy')
    for key,expected in social[code]['allocationParameters'].items():
        check(p,key,expected,'Matched social expenditure reporting allocation; no extra spending')
    cb=capital[code]
    domestic_weights=sum(x.get(k,d) for k,d in [('ventureWeight',50),('businessEquityWeight',15),('corporateBondWeight',15),('governmentBondWeight',20)])
    share=cb['observedForeignSecurities']/cb['observedTotalSecurities']
    check(p,'foreignPortfolioWeight',domestic_weights*share/(1-share),
          'Domestic relative-weight sum × foreign securities stock share/(1−share); stock composition proxies future order flows')
    for key in ['financialIncomeTax','wealthTax']:check(p,key,cb[key],'Frozen country fiscal benchmark; effective proxy, not statutory schedule')
    for key,expected in [('initialIncomeGini',100*households[code]['incomeGini']),('initialWealthGini',100*households[code]['financialWealthGini'])]:
        # Registry may use a unit interval instead of percentage; preserve explicit units.
        if x[key]<1:expected/=100
        check(p,key,expected,'Income2024survey usually2023income; financial-wealth Gini estimated from grouped2023wave data, not total net-wealth Gini')
    for key,meta in prov.items():
        for c in meta.get('components') or []:verify_component(code,key,c)
        if key in x and isinstance(meta.get('value'),(int,float)) and not math.isclose(x[key],meta['value'],rel_tol=1e-9,abs_tol=1e-9):
            metadata.append({'country':code,'key':key,'parameterValue':x[key],'provenanceValue':meta['value'],
               'status':'source_value_differs_from_mapped_parameter','note':'Source value/unit copied into provenance; record sourceValue/sourceUnit and parameterValue/parameterUnit separately. Numeric mapping may be correct.'})

# Independent PWT workbook check against the cached sourceValues for 27 member presets.
pwt_checks=[]
try:
    from openpyxl import load_workbook
    w=load_workbook(RAW/'pwt110.xlsx',read_only=True,data_only=True)
    rows=w['Data'].iter_rows(values_only=True);header=next(rows);index={k:i for i,k in enumerate(header)}
    needed={p['code']:p for p in profiles if p['code']!='EU27'}
    for row in rows:
        code=row[index['countrycode']]
        if code not in needed or row[index['year']]!=2023:continue
        for field in ['rnna','rgdpna','labsh','delta']:
            actual=needed[code]['sourceValues'][field];expected=row[index[field]]
            pwt_checks.append({'country':code,'field':field,'sourceValue':actual,'workbookValue':expected,
               'status':'matches_frozen_source' if math.isclose(actual,expected,rel_tol=1e-10,abs_tol=1e-10) else 'source_mismatch'})
    w.close()
except ImportError:
    pwt_checks=[{'status':'not_checked','reason':'openpyxl unavailable'}]

bykey={}
for p in profiles:
    for key,value in p['params'].items():
        meta=p['provenance'].get(key,{})
        q=[c for c in checks if c['country']==p['code'] and c['key']==key]
        bykey.setdefault(p['code'],{})[key]={'value':value,'sourceStatus':meta.get('status','unestimated_default'),
            'sourceYear':meta.get('year'),'dataset':meta.get('dataset'),'note':meta.get('note'),
            'fallback':bool(meta.get('fallback')),'mappingCheck':q[-1]['status'] if q else 'not_recomputed_in_this_audit',
            'causalCoefficientEstimated':False}

assumptions={p['code']:[{'key':k,'value':v,'note':p['provenance'].get(k,{}).get('note','Unestimated model/scenario default; no empirical coefficient supplied.')}
    for k,v in p['params'].items() if p['provenance'].get(k,{}).get('status') in ['assumed',None]] for p in profiles}
fallbacks=[]
for p in profiles:
    for key,meta in p['provenance'].items():
        if meta.get('fallback') or 'fallback' in meta.get('note','').lower() or 'unavailable' in meta.get('note','').lower() or 'proxy for EU27' in meta.get('note',''):
            fallbacks.append({'country':p['code'],'key':key,'status':meta.get('status'),'note':meta.get('note')})

files=['dist/data/profiles.json','dist/data/employment_population_benchmarks.json',
       'dist/data/capital_input_benchmarks.json','dist/data/housing_pension_benchmarks.json',
       'dist/data/population_education_benchmarks.json','dist/data/social_spending_benchmarks.json',
       'research/source_snapshots/pwt110.xlsx']
hashes=[{'file':s,'sha256':hashlib.sha256((ROOT/s).read_bytes()).hexdigest()} for s in files]
stale_summaries=[{'country':p['code'],'stored':p.get('dataSummary'),
    'current':dict(Counter(v.get('status') for v in p['provenance'].values()))} for p in profiles
    if p.get('dataSummary')!={k:sum(v.get('status')==k for v in p['provenance'].values()) for k in ['observed','derived','proxy']}]
result={'auditDate':'2026-11-13','scope':'28 European country/EU27 presets; frozen official source arithmetic and metadata only; no future forecast validation',
    'summary':{'profiles':len(profiles),'mappingChecks':dict(Counter(c['status'] for c in checks)),
        'frozenJSONStatChecks':dict(Counter(c['status'] for c in rawchecks)),
        'frozenPWTChecks':dict(Counter(c['status'] for c in pwt_checks)),
        'provenanceValueMetadataDifferences':len(metadata)},
    'checks':checks,'rawSourceChecks':rawchecks,'pwtSourceChecks':pwt_checks,
    'candidateCorrections':corrections,'metadataDifferences':metadata,'countryParameterAudit':bykey,
    'staleCountryDataSummary':stale_summaries,
    'explicitAssumptionsAndDefaults':assumptions,'coverageLimitationsAndFallbacks':fallbacks,
    'inputHashes':hashes,
    'limitations':['Passing a source or mapping check does not establish predictive accuracy or causal validity.',
      'Annual source years differ:2023base,2021private pensions,2024income survey; these are disclosed proxies, not one common vintage.',
      'Government education TE includes capital/transfers; household education spending is not private school ownership. Do not relabel as direct school quality.',
      'Foreign portfolio stock composition is a flow-allocation proxy, not empirically estimated household orders.',
      'Firm birth/death rates use enterprise-population denominators; do not treat them as employment rates or venture-financed-only flows.',
      'Gini financial-wealth estimates use grouped survey tables and differ from total net-wealth Gini; preserve base and units.',
      'No new network requests: audit verifies preserved source snapshots, not latest revisions or untouched holdout forecasts.']}
(OUT/os.environ.get('COUNTRY_AUDIT_OUTPUT','european_input_audit.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result['summary'],indent=2))
print('Candidate numerical corrections:',len(corrections))
print('Mapping mismatches:',[(c['country'],c['key']) for c in checks if c['status']=='mapping_mismatch'])

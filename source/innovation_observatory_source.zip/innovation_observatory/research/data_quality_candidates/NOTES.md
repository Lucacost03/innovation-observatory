# Frozen European input audit, 13 November 2026

Run `python3 research/data_quality_candidates/audit_european_inputs.py` to recreate `european_input_audit.json`. The script writes only in this candidate directory. It reads the current 28 European/EU27 presets, retained official JSON-stat snapshots, PWT workbook and country benchmark files. It excludes the new US/China presets, which have separate audits. It does not download revised data or alter the model.

## Concrete correction to integrate

The earlier employment migration changed the labor-force basis from ages 15–74 to matched ages 15–64 but left the unemployment-benefit replacement calibration on its previous denominator. Twenty presets have separately identified unemployment cash benefits. The resulting opening cash flow differs from its preserved government spending observation by −3.07% to +4.76%. These are relative errors in the unemployment benefit component, not percentages of GDP and not total social spending errors.

Preserve the observed cash benefit flow by recomputing:

`unemploymentReplacement = 100 × (100 × unemploymentCash / GDP) / ((laborShare / employmentRate) × (100 − employmentRate))`

Both employment percentages then refer to the same current 15–64 labor force. `candidateCorrections` records each country's source flow, current implied model flow and exact candidate value. Recompute after any later employment or labor-share changes. Do not manufacture a separate unemployment rate for presets whose fiscal breakdown is unavailable: their existing total cash benefits are already included in flat support, with no extra unemployment transfer.

Examples: Latvia's current component is 4.76% above its source flow; Estonia 3.64% above; Portugal 3.32% above; Slovenia 3.07% below. This is a source-mapping repair, not a new estimated benefit-response coefficient.

## Metadata corrections

* `dist/parameters.mjs` still describes `employmentRate` as “100 − Eurostat annual unemployment”. The actual preset is `100 × published employment/population ÷ participation`, both ages 15–64. The parameter is employment/labor force, not employment/population. `evidence.json` was updated by the earlier migration; the registry label was missed.
* All 28 `dataSummary` records predate later additions. For example Italy stores observed=2, derived=3, proxy=18, while its current provenance entries contain observed=6, derived=9, proxy=69, assumed=7. Recompute these counts rather than treating the obsolete summary as coverage evidence.
* Four provenance entries per country copied their underlying source's `value` and `unit` despite applying a mapping to the parameter. The numeric parameters currently reproduce their documented mappings: mortgage spread is quote minus policy rate; dwelling investment share converts a fraction into percent; private pension contribution rate divides source cash-flow/GDP by the model wage bill/GDP; private pension withdrawal rate divides benefits/GDP by entitlement stock/GDP. Preserve separate `sourceValue`/`sourceUnit` and `parameterValue`/`parameterUnit`, or rename the inherited fields. These 112 differences are metadata ambiguities, not 112 incorrect parameter values.

## What the reproducible checks establish

The audit checks the arithmetic of observed opening debt and deposit mappings; same-year nominal GDP ratios; VAT net-base conversion; domestic-use public demand and investment normalization; public research funding and business allocation; business R&D labor-cost shares; annualized loan quotes; pensions, housing and demography; social spending reporting allocations; foreign securities weights; financial-income/wealth-tax benchmarks; Gini units; enterprise entry/exit denominators; grouped firm-size statistics.

All 27 member countries' four cached PWT fields (`rnna`, `rgdpna`, `labsh`, `delta`) are independently checked against the retained workbook (108 field checks). Numerous Eurostat component selections are checked directly against frozen JSON-stat values rather than merely against a second summary. The output records exact coordinates for these checks. Components not resolved to a retained raw table are not called source-verified. An unchanged benchmark copy only establishes mapping consistency.

The matched R&D labor-cost cases also use the same business GERD total as the source business research intensity: no unmatched cost-total/GERD denominator discrepancy was found. No empirical parameter was adjusted simply to smooth GDP or venture funding.

## Country coverage that remains proxy or assumption

* Business R&D labor-cost split is unavailable for France, Ireland, Netherlands and EU27: the documented 60% default is an assumption. Do not label it an observed labor share.
* This euro-denominated corporate loan-rate source does not provide an aligned economy-wide rate for Bulgaria, Czechia, Denmark, Hungary, Poland, Romania, Sweden or EU27: their default loan quote remains an assumption until replaced by a comparable local-currency series.
* National private pension entitlements/cash-flow data are incomplete for Estonia, France, Hungary, Malta and EU27. The funded-universe/covered-member fallback is a proxy, not observed national cash flows. The directly available private pension snapshot is 2021, not the 2023 macro opening year.
* Grouped financial-wealth survey fallbacks are used for Bulgaria, Denmark, Poland, Romania, Sweden and EU27. A financial-wealth Gini is different from the reported total net-wealth Gini. Sampling and grouped-tail assumptions remain even where a national survey is available.
* EU27 gross foreign positions use an aggregate proxy; the household foreign securities exposure uses the euro area's extra-area holdings as a proxy, not a consolidated extra-EU observation. National direct-holdings-only fallbacks omit fund look-through where unavailable.
* Foreign securities **stock** composition anchors future **order-flow** weights. The stocks are observed; the mapping into annual household portfolio decisions is an explicit behavioral proxy.
* Public education uses total COFOG education spending, which includes capital and transfers. Household education-services expenditure does not identify private school ownership. PWT schooling-based human capital does not directly observe school quality. Do not call these three concepts interchangeable.
* Enterprise birth/death rates divide events by active enterprises in the broad business economy, not by employment and not by venture-financed firms. Entrant employment-size ratios and size/hazard correlations do not observe startup capital or causal technology-based exit hazards.
* Employment levels and participation use ages 15–64. Labor-market transition probabilities retain the broader 15–74 source, which is disclosed as a proxy.

The JSON enumerates all stored source statuses and the unestimated scenario/default inputs for every country/key. Parameters without empirical causal estimates should remain explicitly identified; real observations of a level do not identify its future response law. Zero values can be empirically appropriate on a specific tax base; inserting a positive tax solely to make it nonzero would weaken the source mapping.

These source/mapping checks do not establish forecast accuracy, validate the micro behavior, or turn simulations into observed future data. A genuine predictive comparison still needs a time-matched historical calibration and an untouched evaluation window. Existing revised source snapshots are not a real-time historical vintage.

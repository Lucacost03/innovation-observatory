# Global inputs, entry and accounting — engine 1.20.0

This release adds the United States and China to the 27 EU country presets and representative EU27 economy. Each step remains one year; the normalized opening snapshot uses 2023 inputs with explicitly disclosed reference dates and revision vintages. Simulated futures and response coefficients are not observations.

## Data standard for every preset

Matched country observations take priority. A direct statistic, an arithmetic derivation, a proxy mapped to the model and a missing-data/behavioural assumption are distinguished. The complete parameter audit covers numerical choices as well. Source integrity, mapping consistency, structural plausibility and predictive accuracy are different claims.

The European audit independently checks 1,731 mapping calculations,1,607 frozen Eurostat coordinates and 108 PWTworkbook fields. Twenty unemployment-benefit replacement scales used the denominator from the previous employment definition. Recomputing them with matched 15–64 employment/participation preserves their original observed cash-benefit/GDP flow; the error in that component previously ranged from−3.07% to+4.76%. Source and mapped parameter values are now separate fields, and coverage summaries are recomputed. The after-correction audit has no numerical mapping or value-metadata discrepancies. This does not establish that every official statistic is error-free.

Additional integrity checks hash 28 retained primary-source files and check 205 PWTfields across all 29 national economies. The EU aggregate retains its explicit weighted construction. Missing European R&D cost splits, unmatched local-currency loan quotes, funded-pension data, wealth-survey coverage and extra-EUportfolio scopes remain identified in research/data_quality_candidates/NOTES.md. Stock compositions do not estimate annual portfolio responses.

## United States

The Federal Reserve release dated 19 March 2026 provides one coherent 2023 GDP/expenditure/deposit vintage, rather than mixing revisions. GDP is 27,811.5 bnUSD; its published expenditure components differ by 0.1 bnUSD rounding. Government consumption excludes transfers; public gross investment stays in total fixed investment. Household deposits exclude money-market funds. Firm deposits include corporate and noncorporate enterprises, broader than European S11.

Matched OECD annual employment and participation use ages 15–64. Annual-average CPI-Uinflation is 4.1%; the end 2023 policy representation is the 5.375% midpoint of the federal-funds target range, not the annual effective rate. OECD IDDdisposable-income Gini is 0.3944025. FHFAend 2023 outstanding principal-weighted mortgage interest is 4.0%; the Q4 new-loan rate is 7.0%, producing a 1.625 point opening policy spread. These are distinct stock/new-loan conventions.

Debt/GDP uses the explicitly identified IMFcalendar-GDP vintage; a later fiscal-year-denominator alternative is retained without blending. WDIannual population differs from PWT's vintage; PWT still supplies the capital, income-share and schooling anchors. The Social Security retirement cash observation excludes government-employee plans, and cannot be labelled the full public old-age bill. OECDhealth and social-protection totals are broader functional spending, not COFOGP3 services or cash alone. The public-budget view labels these as limited-coverage references.

Effective tax bases, full private-only funded pensions, financial-wealth distribution, national enterprise demography/size distributions, foreign portfolio allocation and several housing/demographic flows lack matched inputs in the retained bundle. Their configured fallback values are explicitly assumed, with US-specific portfolio/home-bias and loan conventions. No federal statutory VAT is invented: the model consumption wedge is an assumed sales/excise proxy.

## China

UNSNAAMA revised 2023 current-CNYaccounts supply expenditure shares. The source GDP129,427.17 bnCNY differs from component spending by−57.982669 bnCNY; the discrepancy is retained in the observations. NBSpreliminaryGDP126,058.2 bnCNY supplies the denominator for deposits/income ratios from the same communiqué. These vintages are not silently mixed into a supposedly single measured balance sheet.

NBSannualCPIinflation is 0.2%. The end 2023 policy anchor is the 1.80% seven-day reverse-repo rate, not LPR. Public pension benefit payments total 6,522.23 bnCNY from MOFfinal insurance accounts; this excludes funeral/admin/interfund spending. The commercial-institution mortgage stock is 38,170 bnCNY, with the source scope caveat retained. The 3.97% Decembernew-loan mortgage quote supplies its spread over policy; using it for the unobserved opening stock rate is explicitly a proxy. The 3.75% new-business quote is also distinguished from the outstanding book.

MOFSDDSoperations consolidate four budgets and remove interbudget transfers, giving revenue 32,499.9 bnCNY and spending 39,846.2 bnCNY. This broader measure replaces any claim that the partial general public budget is complete. It remains distinct from ESACOFOG P3 functional services. Final domestic/import VAT and export refunds supply an effective uniform-wedge proxy; actual multiple rates and other tax bases are not replicated. Household savings-deposit interest is exempt from individual income tax and is excluded from the model financial-income base. The aggregate rate on other financial flows remains an assumption because portfolio/holding-period exemptions are not identified. Property/stamp duties are not reclassified as annual financial-wealth taxes.

NBSnationwide employment and age 15+population imply 62.7977% employment/population. A same-vintage national participation/unemployment pair was not verified. The preset explicitly assumes 5% national unemployment and derives participation; it does not use urban-only 5.2% unemployment. Applying this 15+level to the model's 15–64 cohort evolution is a visible coverage proxy. The income Gini 0.465 uses NBSper-capita disposable income, a different equivalence/weighting definition from OECD/EU-SILC. Wealth concentration and missing portfolio, school, pension and housing quantities remain assumptions.

## Foreign membership and projections

All 30 contexts exclude their home members from every foreign source. European countries use USA,China and ROW,with home excluded fromROW. EU27 excludes all 27 members. The US usesEU27,China and ROW; China usesUSA,EU27 and ROW. Named pools and ROWare disjoint. Their PWTctfplevels use 2023 PPPoutput weights. Contact probabilities and the trade-competitiveness basket remain simplified, unestimated weights.

OECD EO117 EFFLABS ratios are transformed with its 0.67 labour share, then linked to PWTopening levels. Pool paths use fixed opening output×TFPweights over covered members, with coverage percentages retained for each home context. Covered-sample evolution proxies uncovered members; no national forecast is invented for them. Six conditional scenarios vary annual growth through 2100; the final growth rate is extrapolated afterward. This 2025/2026 vintage was unavailable in 2023 and cannot provide a real-time historical forecast test. UIcontrols, donor tables, trade comparisons, events and findings all use the active source set. Self-country foreign growth shocks have no effect.

## Startup rule and controlled comparisons

The previous rule multiplied current productive capital per surviving firm by an observed mean entrant employment ratio. As firm counts shrank, this became a rising minimum capital requirement for every entrant. The nine examined baselines ended with 2–6 firms and no entry or VCfunding in their final decade, even where available VCbudgets rose.

Mean startup capital now uses opening productive capital per initial synthetic firm. Each prospective entrant draws a mean-preserving lognormal size. Its shape uses the incumbent grouped-size dispersion as a disclosed proxy because a matched entrant distribution was unavailable. The employment-to-capital conversion, shape and fixed real benchmark remain assumptions; this is not a fitted firm-entry forecast. Actual financing prices use the liquidation discount only for assets still available in estates; the remainder costs the producer price. Working cash is fully funded. No deposits or capital are granted free.

Every entrant still requires pooled household equity. Broad observed enterprise births include founder/self-financed/debt-only firms that this simplified financing channel does not separately represent. Funding and entry may still decline; no minimum entry count or rising VCtrend is imposed. Attempted capital/cash demand, available venture orders and finance versus asset rejections are separate metrics.

The controlled nine-path comparison holds country inputs/foreign pools fixed. The purchase-cost correction alone reproduces 143,892 common values from the frozen instrumented 1.19.1 engine. Opening-scale varied sizes produce late entry in all nine examined paths. GDP and unemployment effects are mixed and recorded. These are mechanism/accounting comparisons, not evidence of improved empirical forecasting accuracy or a coefficient search.

## Additional accounting repair

Long runs exposed an existing underwater-house sale bug. A seller could repay more mortgage principal than sale proceeds plus available cash, causing a negative deposit. A subsequent negative pension contribution corrupted fund units. Offers now respect the seller's actual cash needed to release the matching mortgage collateral. The debt is not forgiven. Pension contributions cannot be negative, and aggregate pension units must equal household holdings. A direct underfunded/funded sale test and Romanian long-run paths cover this failure. No education elasticity, lag or growth cap was changed.

## Validation and remaining limits

npm test runs the current all-country and controlled startup suites, configuration migration, event scheduling, counters, finance, trade and foreign-asset components. The primary all-country report includes 135 paths and 4,980 annualsteps, including 30 presets×2 seeds×baseline/stress 40 yearpaths; its largest relative reconciliation gap is 1.12 e−14. Both trade flows and gross external positions stayed positive throughout all 4,800 annualsteps in that baseline/stress matrix. Selected severe or deliberately inactive scenarios can still have binding real resource constraints; the model does not invent exports in a complete production collapse.

The current results retain floor/cap hits, falling firm populations, extreme employment/debt outcomes and all controlled comparison results. Macroeconomic realism, complete national-account coverage, endogenous institution-specific response estimates and untouched out-of-sample accuracy remain unestablished. Source/mapping corrections improve input fidelity; accounting identities do not prove that simulated futures are true.

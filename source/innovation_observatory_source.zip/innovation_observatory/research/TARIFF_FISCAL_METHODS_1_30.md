# Empirical tariffs, dated capital fiscal policy and debt reconciliation — engine 1.30

The opening economy is still **2023**, and each period is one year. The latest actual fiscal observations are separate references: Eurostat's 21 October 2026 EDP release for EU members/EU27 in 2025; BEA's 29 October 2026 NIPA vintage, whole general government in calendar 2025; and the latest verified matching MOF four-budget consolidated China reference in 2024, using NBS final 2024 GDP. China's later partial budget releases are not silently treated as a verified consolidated total. Denmark's missing 2025 revenue remains null. A federal US fiscal-year deficit and a narrow Chinese budget deficit are not substituted for broader model coverage. References are verified as of 20 November 2026; source releases can subsequently be revised.

## What was wrong and what changed

The deficit formula already used total expenditure minus total revenue over current nominal GDP, correctly including capital coverage and excluding bond principal repayment. Large 2023 figures were sometimes being compared with later actuals. In addition, 2023 capital fiscal expenses were repeated as a fixed budget-base share forever. For Italy, this perpetuated exceptional payable-tax-credit expenditure. The retained source capital expense is about 9.150% of GDP in 2023, 5.405% in 2024 and 6.022% in 2025. It includes capital formation/non-produced assets plus capital transfers; these financing payments do not add another good to national investment.

Every preset with a verified split now uses its published calendar-year capital fiscal expense and receipt shares through 2025. Those shares are applied to the existing lagged nominal public-budget base, rather than targeting a deficit or GDP outcome. Where a component is missing, only the most recent verified component is carried forward, with its source year recorded. After the last observed year, continuing the latest share is explicitly an assumption. China's missing current/capital split is unchanged. Fiscal current coverage, tax receipts, pensions, demand, financing and income remain simulated. No coefficient was chosen from the diagnostic GDP, current-account or deficit outcomes.

**This is a conditional historical simulation**, incorporating fiscal information published after 2023. Its comparisons to 2024–25 GDP and fiscal outcomes are not a real-time forecast or an untouched holdout. The change improves the date coverage of capital inputs; it does not make every model deficit equal observed data. Italy still has an important limitation: accrual expenditure on payable credits and later use against taxes affect deficit and cash debt differently. A verified opening credit-liability stock and redemption schedule were unavailable; no schedule is invented. The model's cash-equivalent transfer bridge does not reproduce that full EDP adjustment.

## Opening tariff measurement and recipient

All 30 presets now use observed 2023 customs duties divided by matched goods-import value, multiplied by 100. This is an **effective duty yield**, not a statutory MFN schedule. Duty-free/preferential goods dilute the average; unilateral duties received can enter it. Import VAT and excise are excluded. These are opening-year estimates, not 2026 tariff-policy forecasts.

- EU members: Eurostat `gov_10a_taxag`, receiver `S212`, transaction `D2121`, accrued customs duties in million EUR, divided by `ext_lt_intratrd` all-partner goods imports, including duty-free intra-EU trade. EU27 uses extra-EU imports only. The sum of member duties differs by EUR0.2 million from the aggregate due to source rounding. National collection/residence and transit differences make this an aggregate proxy.
- USA: BEA calendar-year customs duties via FRED `B235RC1A027NBEA`, USD81.633 billion, divided by BOP goods imports `B1242C1A027NBEA`, USD3,104.719 billion: **2.629320%**. The denominator is broader than the dutiable customs base.
- China: MOF final 2023 national customs receipts of CNY259.088 billion divided by NBS 2023 goods imports of CNY17,984.2 billion: **1.440642%**. Final accounts supersede the earlier execution estimate.
- EU27: **1.001007%**; Italy: **0.513398%**. National EU averages are lower because their denominator includes intra-EU trade. Each country's actual numerator, denominator, currency, scope and exact source URL are retained in `data/tariffs_2023.json`.

The detailed WITS 2023 schedule-based rates are retained as cross-checks, not mixed with the preferred duty-yield estimator. Their preference/partner coverage and treatment of unilateral duties differ. Raw primary snapshots, SHA256 manifests and extraction scripts remain in `research/tariffs_1_30`.

The model has one composite import good. Mapping a goods duty yield to that good is a coverage proxy, not an assertion that services pay customs duties. Gross duty raises the import consumer price before VAT, contributes to nominal product taxes, and enters real GDP at the opening tax rate. A tariff-rate increase does not itself become extra real production. The import-choice weight is analytically re-expressed for each opening tariff to preserve the previously source-matched opening border import value. This is not a new tariff shock at year 0.

National EU customs duties belong to EU institutions; 25% is retained as collection compensation under the 2021–27 own-resources arrangements. The model settles net75% externally, distinguishes compensation from national customs tax, and removes the corresponding opening collection-fee coverage from the residual receipt bridge so it is not counted twice. Non-EU domestic customs tax coverage is similarly reclassified out of other production taxes. EU institutions are domestic at EU27 level. The EU27 fiscal benchmark still sums member-government S13 accounts, so its category mapping is an aggregate bridge rather than a full EU-institution budget.

The fee and external duty use a net settlement proxy; there is no extra collection-service production or GDP created. A complete national-accounts service/export ledger is not modeled. The opening residual external income/transfer coverage is rebased once for explicit net customs settlement, preserving opening CA rather than counting the existing EU payment twice. Future tariff changes alter actual settlement and are not rebased away. Continuation of the25% collection compensation beyond2027 is an assumption.

## Exact public-debt explanation

The independently checked stock bridge is:

Δ outstanding public debt = total deficit + Δ treasury cash + recapitalisation − public-equity liquidation proceeds − noncash pension interest.

The ratio change is decomposed exactly into deficit/current GDP, other stock-flow adjustments/current GDP, and the change caused by the nominal GDP denominator. Thus a reduced deficit can coexist with rising debt/GDP. Cash buffers, recapitalisation and noncash accruals also distinguish debt changes from the deficit. Floating-point cancellation is measured relative to debt scale; very large nominal long-run quantities can have a nonzero absolute residual despite tiny relative error.

The graph menu uses the English displayed labels in alphabetical order, with metric keys as deterministic ties. Historical chart endpoints remain inspectable with Home/End and arrow keys. Tooltips and fiscal outcomes show the calendar year. With optional settling, displayed year0 is after the settling years; it is not relabelled2023.

## Executed verification and accuracy limits

228 paths and 9096 annual steps passed. All30 presets have three matched 1.29/1.30 seed pairs (one120-year pair and two12-year pairs), plus an8-year legacy replay for every preset. Six economies have no-anticipation zero/raised-tariff cases. 131370 shared values reproduce frozen1.29 with the new switches disabled. The largest relative sector-account residual is 2.942321170221002e-14; the largest relative public-debt bridge residual is 6.298250809777528e-11. Checks include expenditure GDP, S−I=CA, ΔNFA=CA, public debt holders, public/private debt bridges, capital buyer/seller payments, gross international activity, source-year capital paths, missing references, saved-edit migration and alphabetical graph options. Source audits reproduce the empirical ratios from retained raw data; hashes establish integrity, not statistical truth.

Across29 individual countries (EU27 separately), conditional deficit RMSE changes **2.62533780109248 to 2.607327163118978 ppGDP**; MAE changes 2.081057465451267 to 2.0526517923081244. GDP-growth RMSE changes **3.656153306981908 to 3.6551844713889814 pp** and CA RMSE **2.813652766161387 to 2.8138375442993953 ppGDP**. The last comparison worsens slightly. These are date-conditioned retrospective diagnostics on revised observations already examined in earlier work. Repeated seeds are not additional historical observations. No overall forecasting or causal-policy accuracy is established. Every country error and the remaining deviations from observed deficits are retained, not replaced by a target.

Paired scenarios still inherit unestimated trade, fiscal, price, innovation and demographic responses. Century-long runs extrapolate far beyond observed policy and can hit price/currency bounds or other implausible states. They are numerical stress tests, not national forecasts. `data/revision130_validation.json` contains every comparison, long-run diagnostic and limitation.

## Reproduction

Restore shared fixtures with `python3 scripts/unpack_source_fixtures.py`, then run `npm run test:revision130`. Source mappings can be rebuilt with `node scripts/integrate_1_30.mjs` after the frozen1.29 inputs and current fiscal/participation mappings are in place; it always derives the preserved opening moments from frozen1.29. `extract_capital.py` and `extract.py` generate the dated policy and newer reference modules; tariffs `rebuild.py` reconstructs all30 duty yields from retained primary snapshots. The full source ZIP includes the same code, evidence, raw sources and validation scripts with lossless fixture restoration.

## Browser verification

Managed-preview checks completed for Italy, USA, China and Denmark: empirical tariff controls, current evidence, missing-source display, separate observed/simulated dates, alphabetical graph options, Home/End chart inspection and the expandable public debt bridge. A matched Italy8-year/3-seed experiment completed. Current evidence and the existing graph layout were visually inspected; `research/browser_qa_1_30.json` retains the scope. All30-country coverage comes from source and model tests rather than browser sampling.

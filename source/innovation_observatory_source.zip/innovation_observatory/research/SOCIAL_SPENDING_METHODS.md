# Country-specific spending allocations — engine 1.19.1

This update verifies and exposes the composition of budgets already represented in the economy. It changes their functional classification, not aggregate payments, tax rates, the pension law, education responses or financing behaviour. All 28 presets use their own source percentages; no Italian or EU percentage is imposed on other countries.

## Verified official inputs

Frozen Eurostat 2023 general-government accounts (`gov_10a_main`), functional expenditure (`gov_10a_exp`) and all-scheme pension statistics (`spr_exp_pens`) cover all 27 EU members plus EU27. The benchmark contains 392 complete core country/indicator observations, exact selections, source flags and SHA256 hashes. Raw observations and extraction code are in research/social_spending_candidates; the public download is data/social_spending_benchmarks.json. These are revised 2023 opening references, not current 2026 spending.

| Official 2023 measure, % GDP | Italy | EU27 |
|---|---:|---:|
| Government revenue | 46.5 | 45.4 |
| Total government expenditure | 53.6 | 48.8 |
| Health expenditure, all transactions | 6.5 | 7.2 |
| Education expenditure, all transactions | 3.9 | 4.7 |
| Social protection, all transactions | 21.0 | 19.1 |
| Public old-age cash benefits | 13.2 | 9.6 |
| Public survivor cash benefits | 2.3 | 1.4 |
| Public sickness/disability cash benefits | 1.6 | 1.8 |

All 28 existing public old-age inputs match the official source. Replacing Italy's 13.2 with ESSPROS total pensions of 15.49 would mix pension types and public/private schemes. The corresponding EU27 all-scheme total is 12.28, with a different scope from its 9.6 public old-age cash benefits. Sickness/disability cash benefits are not identical to disability pensions. Pensions and other cash benefits are parts of social protection, not additional amounts to add on top of that aggregate.

Healthcare was previously unlabelled within government purchases; it was not necessarily absent from public consumption. Survivor and sickness/disability payments were unlabelled within flat cash social support. The model already removed old-age benefits from that flat support when paying its separately modelled retiree-linked old-age transfers. Earmarked pension contributions are part of existing worker tax/social-contribution receipts, not another tax receipt.

## Percentages applied to comparable budget totals

Health services and education services use their country's COFOG P3 function divided by COFOG total P3. Italy's shares are 6.1/17.9 = 34.08% and 3.4/17.9 = 18.99%. EU27's are 6.5/21.1 = 30.81% and 3.8/21.1 = 18.01%. Each year's actual model public purchases are split into these two categories and the residual other services. The three parts always sum to that existing purchase budget.

Source survivor and sickness/disability D62 amounts are divided by the original non-old-age cash-support pool after excluding any separately modelled unemployment benefit. Each year's existing non-old-age cash support uses those fixed percentages, with the residual labelled other cash support. When the age-linked pension mechanism is disabled, the old-age share remains identifiable inside the flat support pool. Allocations never add a second transfer or change which household receives the actual cash. For a custom malformed allocation whose shares exceed 100%, the reporting helper normalizes those shares rather than showing negative residual spending; all empirical preset shares fit without this guardrail.

Full COFOG health/education TE includes consumption, investment and transfers. Applying TE/TOTAL TE to the model's narrower current-expense total would not preserve the meaning of its actual service and benefit ledgers. The update therefore applies empirical shares to comparable transaction budgets and separately displays each source function's percentage of full national expenditure. It does not claim that all current model expense shares equal full national TE shares. Matching both every component/GDP ratio and every full-budget share would require a complete public investment, capital-transfer and tax ledger. Adding those totals as extra consumption would double count demand and distort GDP.

COFOG total P3 and main-table P3 differ by 0.1 percentage point in Italy and EU27. Shares use numerator and denominator from the same table. The cause of those table differences is not uniquely identified here; labels preserve the definitions and rounded source values.

The existing public school-resource funding proxy uses the broader education expenditure benchmark. Its calculation, effective-resource weights, elasticity and lag remain untouched. The new fiscal education-service classification is a different view of the same overall budget, not a second expense or a reason to reduce human-capital effects.

## Revenues, expenses and presentation

The Government sector view now shows each expense in nominal model units, as a percentage of current nominal GDP, and as a percentage of represented current expenses. Revenue minus current expenses equals public saving. Public bond principal redemption and bank recapitalisation remain separately labelled financing/exceptional operations outside the current-expense composition. Pension contribution earmarks are not added again to revenue.

Observed 2023 full-budget reference percentages appear separately from simulated annual outcomes. At year 0, simulated annual receipts/payments remain unobserved gaps; the official reference has nonzero spending values. General-government TE has wider coverage than the model's delivered purchases, cash transfers, research and interest. Public capital spending, other capital transfers, subsidies and some receipts do not have a complete separate ledger here. Differences in gross spending/revenue coverage must not be presented as forecast errors or filled with invented transfers.

Later spending/GDP can decline because the configured public-budget trend grows more slowly than GDP, or because actual orders are rationed. This is a scenario assumption/result, not a reason to automatically increase a source input or damp real GDP. The public budget rule remains editable and unchanged.

## Other sectors: supported shares and limits

Country allocation targets already applied elsewhere are now visible next to current configured percentages in each sector view:

- Household foreign securities composition: 28 presets, 22 with fund look-through and six direct-holding proxies. The same relative weight mapping continues to allocate the existing investment-market order budget. It is a securities-stock composition used as a flow-allocation proxy, not an estimated propensity to invest or a percentage of total household income.
- Business R&D labour costs / business GERD: 24 matched presets; France, Ireland, Netherlands and EU27 retain a labelled 60% assumption. Only the labour part is explicitly paid as research hours; other R&D costs remain a benchmark.
- National dwelling GFCF / total GFCF: 28 source proxies for the existing residential/business investment envelope, not an observation of who finances each project.
- Government-funded R&D performed by business / total public research: 26 matched presets; Bulgaria and EU27 retain labelled assumptions. The share applies to that research budget, not the total public budget.

Actual funding, capacity, market demand and disabled channels can keep realized spending below configured budgets. Custom scenario paths update the displayed configured percentage while the empirical reference stays fixed.

The household consumption/income ratio cannot simply replace the marginal consumption propensity: this model also has a wealth-draw term. National bank asset shares do not describe the combined bank, monetary authority, pension-fund and direct financial-market system. Household issuer data retrieved for 21 national areas plus euro area have incomplete country coverage, exclude the available fund look-through and omit some model instruments. The broad domestic debt/equity candidate also mixes financial-sector issuers with the model's narrower issuer set. Those candidates are recorded but rejected for this update, without inventing a common ratio or claiming a simulation improvement. Venture/equity/debt weights, deposit retention and the bank share of government bonds remain explicit assumptions.

## Executed tests

Before the changes, 168 complete 40-year baseline/stress paths were captured from published engine 1.19.0, commit 0a8e265d9c202f95c788c7a194911be7b18f42aa. After the changes, every previous numerical row value reproduced its original SHA256 projection exactly across 6,720 annual steps. The new classification sums reconcile with maximum absolute budget-amount residual below 2.3e-13 model units. GDP, inflation, employment, human capital, agent stocks and all original transactions are unchanged.

The new tests also verify all source hashes, 28 old-age benchmarks, all country allocation parameters, zero-budget cases, disabling age-linked pensions, migration of saved experiments, counterparty revenue/expense sums, S-I=CA and current-account/NFA transactions. They independently confirm 28 existing portfolio percentages, 24 research-labour targets, 28 housing-investment targets and 26 public research targets. Source targets stay fixed when users edit scenario allocation weights.

Additional sector-flow, configuration, event-input and monetary-policy suites passed. No new predictive-accuracy gain is claimed: these are source-definition, allocation and presentation corrections that preserve the existing economic dynamics.

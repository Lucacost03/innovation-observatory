"""Primary income-definition evidence. Does not change model parameters.
Python3+pandas/openpyxl; optional raw PWT files can be fetched by manifest URLs.
"""
from pathlib import Path
import json,hashlib,math
import pandas as pd,openpyxl
R=Path(__file__).resolve().parent;ROOT=R.parents[2];read=lambda p:json.loads(p.read_text())
for m in read(R/'manifest.json'):
 if 'sha256'in m:assert hashlib.sha256((R/m['file']).read_bytes()).hexdigest()==m['sha256'],m['file']
ps=read(ROOT/'dist/data/profiles.json');pwt=pd.read_stata(R/'pwt110_labor_detail.dta');pwt=pwt[pwt.year==2023].set_index('countrycode');euro=read(R/'eurostat_income_2023.json')
def val(geo,key):
 select={'freq':'A','unit':'CP_MEUR','na_item':key,'geo':geo,'time':'2023'}
 i=0
 for k,n in zip(euro['id'],euro['size']):
  if select[k]not in euro['dimension'][k]['category']['index']:return None,None,None
  i=i*n+euro['dimension'][k]['category']['index'][select[k]]
 return euro['value'].get(str(i)),euro.get('status',{}).get(str(i)),select
out={}
for profile in ps:
 code=profile['code'];a={'year':2023,'sourceLaborSharePct':profile['params']['laborShare'],'labshDefinition':'PWT adjusted labour compensation share on basic-price GDP; includes estimated self-employment labour where method provides it. Not observed employee wages / market-price GDP.'}
 if code!='EU27':
  row=pwt.loc[code];a.update(labsh=float(row.labsh),employeeCompensationShareBasic=float(row.comp_sh),method=str(row.i_labsh),status=str(row.i_labsh2),compensationObservationStatus=str(row.i_comp_sh));assert abs(a['labsh']*100-profile['params']['laborShare'])<1e-8
 else:
  weights=profile['aggregation']['weights'];a.update(labsh=sum(float(pwt.loc[w['country'],'labsh'])*w['gdpWeight']for w in weights),employeeCompensationShareBasic=sum(float(pwt.loc[w['country'],'comp_sh'])*w['gdpWeight']for w in weights),method='National labsh weighted by PWT rgdpna; representative aggregate, not official EU labour income account',status='Derived aggregate; national observation/interpolation statuses differ',aggregationWeights=weights);assert abs(a['labsh']*100-profile['params']['laborShare'])<1e-8
 if code not in ['USA','CHN']:
  obs={k:val(profile['geo'],k)[0]for k in ['B1GQ','D1','D21X31','D2X3']};assert all(z is not None for z in obs.values());g=obs['B1GQ'];a.update(eurostat2023MillionEUR=obs,eurostatFlags={k:val(profile['geo'],k)[1]for k in obs},eurostatCoordinates={k:val(profile['geo'],k)[2]for k in obs},netProductTaxesPctGDP=100*obs['D21X31']/g,netAllProductionTaxesPctGDP=100*obs['D2X3']/g,employeeCompensationPctMarketGDP=100*obs['D1']/g,employeeCompensationPctFactorGDP=100*obs['D1']/(g-obs['D2X3']),adjustedLaborCompensationPctMarketGDPProxy=100*a['labsh']*(g-obs['D21X31'])/g,conversionStatus='Proxy: PWT basic-price share times same-year Eurostat basic/market GDP. Different source vintages remain explicit; not literal employee compensation.')
 else:a.update(netProductTaxesPctGDP=None,adjustedLaborCompensationPctMarketGDPProxy=None,conversionStatus='Exact matching product-tax-only GDP bridge not independently verified; do not subtract all production taxes as if basic prices.')
 out[code]=a
book=ROOT/'research/fiscal_reconciliation/usa/Section1All.xlsx';w=openpyxl.load_workbook(book,read_only=True,data_only=True)
def table(name):
 rows=list(w[name].values);header=next(r for r in rows if r[0]=='Line');values={}
 for rid,row in enumerate(rows,1):
  if row[0]and str(row[0]).isdigit():
   for year in [2023,2024,2025]:
    c=header.index(str(year));values[(int(row[0]),year)]={'valueMillionUSD':row[c],'line':int(row[0]),'label':row[1].strip(),'cell':openpyxl.utils.get_column_letter(c+1)+str(rid),'seriesCode':row[2],'table':name,'year':year,'published':rows[4][0]}
 return values
gdp=table('T10105-A');income=table('T11000-A');us=[]
for y in [2023,2024]:
 g=gdp[(1,y)]['valueMillionUSD'];comp=income[(2,y)]['valueMillionUSD'];net=income[(7,y)]['valueMillionUSD']-income[(8,y)]['valueMillionUSD'];inc=income[(1,y)]['valueMillionUSD'];discrepancy=income[(24,y)]['valueMillionUSD'];assert g-inc==discrepancy
 us.append({'year':y,'GDPmillionUSD':g,'GDIIncomeMillionUSD':inc,'employeeCompensationMillionUSD':comp,'netProductionTaxesMillionUSD':net,'employeeCompensationPctMarketGDP':100*comp/g,'employeeCompensationPctFactorGDP':100*comp/(g-net),'GDPminusGDIStatisticalDiscrepancyMillionUSD':discrepancy,'coordinates':[gdp[(1,y)],income[(1,y)],income[(2,y)],income[(7,y)],income[(8,y)],income[(24,y)]]})
out['USA']['BEAAnnualContext']=us
out['USA']['employeeCompensationPctMarketGDP']=us[0]['employeeCompensationPctMarketGDP'];out['USA']['employeeCompensationPctFactorGDP']=us[0]['employeeCompensationPctFactorGDP'];out['USA']['netAllProductionTaxesPctGDP']=100*us[0]['netProductionTaxesMillionUSD']/us[0]['GDPmillionUSD']
out['USA']['BEAWorkbookSource']={'file':'../../fiscal_reconciliation/usa/Section1All.xlsx','sha256':hashlib.sha256(book.read_bytes()).hexdigest(),'url':'https://apps.bea.gov/national/Release/XLS/Survey/Section1All_xls.xlsx'}
(R/'income_anchors_2023.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','countries':len(out),'EuropeanIncomeCoordinates':28*4,'PWTNationalRows':29,'USCompensationMarketGDP':[x['employeeCompensationPctMarketGDP']for x in us],'USCompensationFactorGDP':[x['employeeCompensationPctFactorGDP']for x in us],'USFactorShareChangePP':us[1]['employeeCompensationPctFactorGDP']-us[0]['employeeCompensationPctFactorGDP'],'ChinaMethod':out['CHN']['method'],'ChinaStatus':out['CHN']['status']},indent=2))

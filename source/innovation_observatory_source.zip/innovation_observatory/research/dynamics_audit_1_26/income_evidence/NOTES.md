# Income-share measurement audit — source year2023

This folder supplies evidence, not new ABM coefficients or a claim of forecasting accuracy. `income_anchors_2023.json` has all30 model presets. `extract_income.py` verifies raw hashes and reconstructs the compact observations with Python3+pandas/openpyxl.

## PWT labour income is not literal employee wages

The official PWT methodology starts with compensation of employees and basic-price GDP, then estimates labour income attributable to self-employed people from mixed income or alternative methods. Basic-price GDP excludes net taxes on PRODUCTS. It is not automatically the factor-cost denominator obtained by excluding ALL taxes on production/imports less subsidies. Do not subtract totalD2 to claim a verified basic-price conversion.

A short exact statement in the official methodology appendix is: “Net taxes on products are excluded”. The relevant source is appendixC, Labour shares / Basic data and adjustment methods, printedappendixp21:
https://www.rug.nl/ggdc/docs/the_next_generation_of_the_penn_world_table.pdf

CurrentPWT11 documentation and its raw labour-detail observation flags retain the source/method distinction:
https://www.rug.nl/ggdc/productivity/pwt/
https://dataverse.nl/api/access/datafile/554028?format=original
https://dataverse.nl/api/access/datafile/554025

China2023labsh0.56118059158325195 uses the naive share and is marked assumedconstantorinterpolated. It is not a directly observed2023 adjusted self-employment share. USA2023labsh0.568302690982819 and Italy0.511646032333374 use mixed-income adjustment2 and are marked observed in the PWTlabour-detail source. All29 national methods/statuses are in the extract. EU27 is the existing representative aggregate, using nationalPWTlabsh and the retained rgdpna weights; national observation statuses differ.

## Eurostat matched concepts

The frozen annual2023 `nama_10_gdp` extract uses CP_MEUR and the same11November2026GDP vintage as the fiscal ledger. All28European presets have B1GQGDP, D1employeecompensation, D21X31netproducttaxes and D2X3allproduction/importtaxes less subsidies. Coordinates and flags are retained. DirectD1/marketGDP and D1/(GDP−D2X3) are distinct observed-data ratios. The PWTlabsh×(GDP−D21X31)/GDP result is an explicitly labelled adjusted-labour market-GDP PROXY across different source vintages. It is not an observed wage bill.

https://ec.europa.eu/eurostat/databrowser/view/nama_10_gdp/default/table?lang=en

## USA empirical context

The retained BEAannual Section1workbook, October29,2026vintage, contains NIPA1.10domestic compensation of employees paid. This is the relevant domestic production-income measure; personal compensation in2.1 has a different perimeter.2023employeecompensation/GDP=51.2349436061%;2024=51.2718001922%. On GDP less netproductiontaxes, the ratios are54.6950391582%and54.7707361930%, a0.0756970349percentagepoint change. These are employee-compensation ratios, not directly comparable to an adjustedPWTlabour-income proxy.

GDP exceeds the independently measured GDI by118.073billionUSD in2023and84.676billionUSD in2024. That statistical discrepancy remains explicit; no fabricated observational identity removes it. Workbook line/cell coordinates are in the JSON.

https://apps.bea.gov/national/Release/XLS/Survey/Section1All_xls.xlsx
https://www.bea.gov/data/income-saving/personal-income
https://www.bea.gov/resources/methodologies/nipa-handbook

## Meaning of the model's opening jump

The parent's executed published1.25defaultUSA screen found labour share58.1734421%atyear0and61.6145201%atyear1. Year0 omitted4.1088412units of other-production-tax coverage which enters year1. Holding opening labour income fixed and matching that tax perimeter changes the opening share to about60.7276%; roughly2.5542percentagepoints of the original3.4411point jump is a denominator discontinuity. The remaining roughly0.8869points comes from simulated labour-income/value-added changes. This arithmetic does NOT establish the empirical realism of that remaining transition or identify a business cycle.

A minimal defensible correction is consistent opening/step tax coverage, honest labour-proxy labels, and source-specific PWTobservation flags. Changing the wage parameter to force a chosen share would require a proper source-denominator and mixed-income bridge. The exactUSA/China product-tax-only bridge is unverified here and remains null.

## Distribution and raw files

RawPWT DTA/PDF files are retained with hashes for extraction. They can be omitted as optional large inputs from a size-limited source download if compactJSON, extractor and sourceURL/hashmanifest remain and that limitation is stated. Re-download may retrieve a revised source; verify hashes before claiming exact reproduction. BEArawbytes are already retained in the existing fiscal source folder and are not duplicated here.

from pathlib import Path
import urllib.request,hashlib,json,concurrent.futures,datetime
R=Path(__file__).resolve().parent
sources=[('eurostat_income_2023.json','https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?lang=en&freq=A&unit=CP_MEUR&na_item=B1GQ&na_item=D1&na_item=D21X31&na_item=D2X3&sinceTimePeriod=2023&untilTimePeriod=2023'),('pwt110_labor_detail.dta','https://dataverse.nl/api/access/datafile/554028?format=original'),('pwt110_user_guide.pdf','https://dataverse.nl/api/access/datafile/554025'),('pwt_methodology.pdf','https://www.rug.nl/ggdc/docs/the_next_generation_of_the_penn_world_table.pdf')]
def fetch(pair):
 name,url=pair;p=R/name
 try:
  data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=90).read();p.write_bytes(data)
  return dict(file=name,url=url,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),retrievedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
 except Exception as e:return dict(file=name,url=url,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:m=list(ex.map(fetch,sources))
(R/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2))
